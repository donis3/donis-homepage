﻿Donsraad v0.1.6 â€” portable build

Run Donsraad.exe. AutoHotkey does not need to be installed.

Keep this folder together. The exe reads and writes next to itself.

This zip does not include settings.json, profiles.json, or player_state.json.
On first run the app creates them. Updating over an existing folder leaves
those files alone. Missing keys from older versions are filled in on load;
your existing values are kept.

Shipped with the build:
  DISCLAIMER.txt
  TERMS.txt
  db\landsraad_houses.json
  db\landsraad_missions.json
  ui\donis.png
  ui\donsraad_icon.png
  anchors\1080p\*.png
  anchors\1440p\*.png
