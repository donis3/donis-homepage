#Requires AutoHotkey v2.0+

class LandsraadTab extends GuiPage {
    specs := ["Crafting", "Exploration", "Gathering", "Combat", "Sabotage"]
    leftSpecs := ["Crafting", "Gathering"]
    rightSpecs := ["Exploration", "Combat", "Sabotage"]
    weekLabel := ""
    houseCells := Map()
    trackedBg := "14532D"
    trackedBarTrack := "134E32"
    trackedProgFill := "4ADE80"
    trackedDoneBg := "1E3A5F"
    trackedDoneTrack := "172554"
    doneBadgeW := 40
    contributionMax := 14000
    iconSize := 30
    cellH := 40
    cellGap := 3
    sectionGap := 6
    titleH := 18
    nameTextH := 12
    contTextH := 12
    textBarGap := 4
    swatchBarW := 4
    swatchBarColor := "F87171"

    trackingCardY := 0

    __New(hostGui) {
        super.__New(hostGui, 2)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        colGap := 12
        halfW := (cardW - colGap) // 2
        col1 := m
        col2 := m + halfW + colGap

        scanW := 198
        resetW := 100
        hunterW := 118
        helpW := 28
        btnGap := 8
        headerBtnH := 28
        scanX := m + cardW - scanW
        resetX := scanX - btnGap - resetW
        hunterX := resetX - btnGap - hunterW
        helpX := hunterX - btnGap - helpW

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w200 h24 BackgroundTrans", "Landsraad contributions"))
        this.AddTextButton(2, helpX, y, helpW, headerBtnH, "?", (*) => TabHelpDialog.Show(this.guiObj, "landsraad"))
        this.AddBlueTextButton(2, hunterX, y, hunterW, headerBtnH, "Reward Hunter",
            (*) => RewardHunterWindow.Show(this.guiObj, this.profileManager,
                (*) => this.HostRef().RefreshMissionPickerTabs()))
        this.AddTextButton(2, resetX, y, resetW, headerBtnH, "Reset board", (*) => this.OnResetBoardClick())
        this.AddTextButton(2, scanX, y, scanW, headerBtnH, "Scan grid (1-2 minutes)", (*) => this.OnScanGridClick(), true)
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        weekY := y + headerBtnH + 2
        this.weekLabel := this.PageAdd(2, g.Add("Text",
            "x" m " y" weekY " w" cardW " h18 Right +0x200 BackgroundTrans", ""))
        headerEndY := weekY + 20

        this.ComputeHouseGridMetrics(headerEndY)

        this.houseCells := Map()
        colY := headerEndY
        loop this.leftSpecs.Length {
            spec := this.leftSpecs[A_Index]
            colY := this.BuildSpecColumn(g, col1, colY, halfW, spec)
        }
        colY := headerEndY
        loop this.rightSpecs.Length {
            spec := this.rightSpecs[A_Index]
            colY := this.BuildSpecColumn(g, col2, colY, halfW, spec)
        }

        this.BuildTrackingInfoCard(g, m, cardW)

        this.Refresh()
    }

    ComputeHouseGridMetrics(headerEndY) {
        trackCardH := 52
        bottomPad := 10
        footerH := 36
        contentBottom := this.winH - footerH - bottomPad - trackCardH
        availH := contentBottom - headerEndY - 6
        if (availH < 320)
            availH := 320

        maxSections := this.leftSpecs.Length
        if (this.rightSpecs.Length > maxSections)
            maxSections := this.rightSpecs.Length

        sectionFixed := this.titleH + 2 + 4
        houseRows := 5
        maxSectionH := availH / maxSections
        cellUnit := (maxSectionH - sectionFixed) / houseRows

        this.cellH := 40
        this.cellGap := 3
        this.sectionGap := 6
        this.iconSize := 30
        this.nameTextH := 12
        this.contTextH := 12
        this.textBarGap := 4

        if (cellUnit < 42) {
            this.cellH := 34
            this.cellGap := 2
            this.sectionGap := 4
            this.iconSize := 26
            this.textBarGap := 3
        }
        if (cellUnit < 36) {
            this.cellH := 30
            this.cellGap := 2
            this.sectionGap := 3
            this.iconSize := 24
            this.nameTextH := 11
            this.contTextH := 11
            this.textBarGap := 2
        }
        if (cellUnit < 32) {
            this.cellH := 28
            this.cellGap := 1
            this.sectionGap := 3
            this.iconSize := 22
        }

        this.trackingCardY := contentBottom
    }

    BuildTrackingInfoCard(g, m, cardW) {
        cardH := 52
        cardY := this.trackingCardY
        if (cardY < 1)
            cardY := this.winH - 36 - 10 - cardH

        this.PageAdd(2, g.Add("Text",
            "x" m " y" cardY " w" cardW " h" cardH " Background" this.surfaceColor))
        this.PageAdd(2, g.Add("Text",
            "x" m " y" cardY " w4 h" cardH " BackgroundEAB308"))

        g.SetFont("s9 bold cEAB308", "Segoe UI")
        this.PageAdd(2, g.Add("Text",
            "x" (m + 16) " y" (cardY + 10) " w" (cardW - 32) " h16 BackgroundTrans",
            "House tracking"))

        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(2, g.Add("Text",
            "x" (m + 16) " y" (cardY + 28) " w" (cardW - 32) " h18 BackgroundTrans",
            "Click a house to set a weekly contribution goal."))
    }

    BuildSpecColumn(g, colX, startY, colW, spec) {
        y := startY
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(2, g.Add("Text",
            "x" colX " y" y " w" colW " h" this.titleH " BackgroundTrans", spec))
        y += this.titleH + 2

        houses := this.GetHousesForSpec(spec)
        loop 5 {
            idx := A_Index
            houseEntry := (idx <= houses.Length) ? houses[idx] : Map("house", "", "iconSlug", "")
            y := this.BuildHouseCell(g, colX, y, colW, houseEntry)
        }
        return y + this.sectionGap
    }

    GetHousesForSpec(spec) {
        out := []
        if !IsObject(this.stateManager) || !(this.stateManager.allHousesList is Array)
            return out
        for _, entry in this.stateManager.allHousesList {
            if !(entry is Map)
                continue
            if (entry.Has("specialization") && entry["specialization"] == spec)
                out.Push(entry)
        }
        return out
    }

    BuildHouseCell(g, x, y, w, houseEntry) {
        h := this.cellH
        houseName := houseEntry.Has("house") ? houseEntry["house"] : ""
        pad := 6
        iconX := x + pad
        iconY := y + ((h - this.iconSize) // 2)
        textX := iconX + this.iconSize + 8
        textW := w - (textX - x) - pad
        barX := textX
        barW := textW
        barH := 3
        nameY := y + 4
        contY := nameY + this.nameTextH + 2
        barY := contY + this.contTextH + this.textBarGap

        cellBg := this.PageAdd(2, g.Add("Text",
            "x" x " y" y " w" w " h" h " Background" this.surfaceColor))

        swatchBar := ""
        if (houseName != "") {
            swatchBar := this.PageAdd(2, g.Add("Text",
                "x" x " y" y " w" this.swatchBarW " h" h " Hidden Background" this.swatchBarColor))
        }

        iconPath := this.GetHouseIconPath(houseEntry)
        iconBg := ""
        iconPic := ""
        if (iconPath != "") {
            iconBg := this.PageAdd(2, g.Add("Text",
                "x" (iconX - 1) " y" (iconY - 1) " w" (this.iconSize + 2) " h" (this.iconSize + 2)
                " Background" this.mutedColor))
            iconPic := this.PageAdd(2, g.Add("Picture",
                "x" iconX " y" iconY " w" this.iconSize " h" this.iconSize, iconPath))
        } else {
            iconBg := this.PageAdd(2, g.Add("Text",
                "x" iconX " y" iconY " w" this.iconSize " h" this.iconSize " Background" this.mutedColor))
        }

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        nameCtrl := this.PageAdd(2, g.Add("Text",
            "x" textX " y" nameY " w" textW " h" this.nameTextH " Background" this.surfaceColor, houseName))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        contCtrl := this.PageAdd(2, g.Add("Text",
            "x" textX " y" contY " w" textW " h" this.contTextH " Background" this.surfaceColor, "0"))

        progBg := this.PageAdd(2, g.Add("Text",
            "x" barX " y" barY " w" barW " h" barH " Background" this.mutedColor))
        progFill := this.PageAdd(2, g.Add("Text",
            "x" barX " y" barY " w0 h" barH " BackgroundEAB308"))

        doneCtrl := ""
        if (houseName != "") {
            doneX := x + w - pad - this.doneBadgeW
            doneY := y + 2
            g.SetFont("s8 bold cEAB308", "Segoe UI")
            doneCtrl := this.PageAdd(2, g.Add("Text",
                "x" doneX " y" doneY " w" this.doneBadgeW " h14 Hidden Center +0x200 Background" this.surfaceColor,
                "Done"))
        }

        if (houseName != "") {
            clickHandler := this.MakeHouseClickHandler(houseName)
            this.BindHouseCellClick(cellBg, clickHandler)
            this.BindHouseCellClick(nameCtrl, clickHandler)
            this.BindHouseCellClick(contCtrl, clickHandler)
            this.BindHouseCellClick(progBg, clickHandler)
            this.BindHouseCellClick(progFill, clickHandler)
            if IsObject(iconBg)
                this.BindHouseCellClick(iconBg, clickHandler)
            if IsObject(iconPic)
                this.BindHouseCellClick(iconPic, clickHandler)
            if IsObject(swatchBar)
                this.BindHouseCellClick(swatchBar, clickHandler)
            if IsObject(doneCtrl)
                this.BindHouseCellClick(doneCtrl, clickHandler)

            this.houseCells[houseName] := Map(
                "cellBg", cellBg,
                "swatchBar", swatchBar,
                "iconBg", iconBg,
                "nameCtrl", nameCtrl,
                "contCtrl", contCtrl,
                "doneCtrl", doneCtrl,
                "progBg", progBg,
                "progFill", progFill,
                "barW", barW,
                "goal", 0,
                "cont", 0
            )
            this.RefreshHouseCellStyle(houseName, this.houseCells[houseName])
        }

        return y + h + this.cellGap
    }

    GetHouseIconPath(houseEntry) {
        if !(houseEntry is Map)
            return ""
        slug := houseEntry.Has("iconSlug") ? houseEntry["iconSlug"] : ""
        if (slug != "") {
            scaled := A_ScriptDir "\db\house_icons_scaled\1440p\" slug "_72x72.png"
            if FileExist(scaled)
                return scaled
        }
        if houseEntry.Has("iconFile") {
            path := A_ScriptDir "\db\" houseEntry["iconFile"]
            if FileExist(path)
                return path
        }
        return ""
    }

    FormatContribution(value) {
        try {
            n := Integer(value)
        } catch {
            return "0"
        }
        if (n < 0)
            n := 0
        return Format("{:L}", n)
    }

    FormatContributionLine(cont, goal) {
        line := this.FormatContribution(cont)
        if (goal > 0)
            line .= " / " this.FormatContribution(goal)
        return line
    }

    GetProgressWidth(contribution, barW, maxValue := "") {
        try {
            n := Integer(contribution)
        } catch {
            n := 0
        }
        if (n < 0)
            n := 0
        try {
            cap := (maxValue != "") ? Integer(maxValue) : this.contributionMax
        } catch {
            cap := this.contributionMax
        }
        if (cap < 1)
            cap := this.contributionMax
        if (n >= cap)
            return barW
        if (barW <= 0)
            return 0
        return Round(barW * n / cap)
    }

    MakeHouseClickHandler(houseName) {
        return (*) => this.OnHouseCellClick(houseName)
    }

    BindHouseCellClick(ctrl, handler) {
        if IsObject(ctrl)
            ctrl.OnEvent("Click", handler)
    }

    IsTabActive() {
        return IsObject(this.host) && this.host.activeTab == this.pageId
    }

    RefreshHouseCellStyle(houseName, cell) {
        goal := cell.Has("goal") ? cell["goal"] : 0
        cont := cell.Has("cont") ? cell["cont"] : 0
        isTracked := goal > 0
        goalReached := isTracked && cont >= goal
        swatchOwned := false
        if IsObject(this.profileManager)
            swatchOwned := this.profileManager.IsHouseSwatchOwned(houseName)
        applyVisibility := this.IsTabActive()

        if IsObject(cell["swatchBar"]) {
            if swatchOwned {
                cell["swatchBar"].Opt("Background" this.swatchBarColor)
                if applyVisibility
                    cell["swatchBar"].Visible := true
            } else if applyVisibility {
                cell["swatchBar"].Visible := false
            }
            if applyVisibility
                cell["swatchBar"].Redraw()
        }

        if goalReached {
            fillColor := this.trackedDoneBg
            iconColor := this.trackedDoneTrack
            barTrackColor := this.trackedDoneTrack
            barFillColor := "EAB308"
        } else if isTracked {
            fillColor := this.trackedBg
            iconColor := this.trackedBarTrack
            barTrackColor := this.trackedBarTrack
            barFillColor := this.trackedProgFill
        } else {
            fillColor := this.surfaceColor
            iconColor := this.mutedColor
            barTrackColor := this.mutedColor
            barFillColor := "EAB308"
        }

        if IsObject(cell["cellBg"]) {
            cell["cellBg"].Opt("Background" fillColor)
            cell["cellBg"].Redraw()
        }

        if IsObject(cell["iconBg"]) {
            cell["iconBg"].Opt("Background" iconColor)
            cell["iconBg"].Redraw()
        }

        if IsObject(cell["nameCtrl"]) {
            cell["nameCtrl"].Opt("Background" fillColor)
            if goalReached
                cell["nameCtrl"].SetFont("s9 bold cE0F2FE", "Segoe UI")
            else if isTracked
                cell["nameCtrl"].SetFont("s9 bold cECFDF5", "Segoe UI")
            else
                cell["nameCtrl"].SetFont("s9 bold cE4E4E7", "Segoe UI")
            cell["nameCtrl"].Redraw()
        }

        if IsObject(cell["contCtrl"]) {
            cell["contCtrl"].Opt("Background" fillColor)
            if goalReached
                cell["contCtrl"].SetFont("s9 c93C5FD", "Segoe UI")
            else if isTracked
                cell["contCtrl"].SetFont("s9 cBBF7D0", "Segoe UI")
            else
                cell["contCtrl"].SetFont("s9 cA1A1AA", "Segoe UI")
            cell["contCtrl"].Redraw()
        }

        if IsObject(cell["doneCtrl"]) {
            if goalReached {
                cell["doneCtrl"].Opt("Background" fillColor)
                cell["doneCtrl"].SetFont("s8 bold cEAB308", "Segoe UI")
                if applyVisibility
                    cell["doneCtrl"].Visible := true
            } else if applyVisibility {
                cell["doneCtrl"].Visible := false
            }
            if applyVisibility
                cell["doneCtrl"].Redraw()
        }

        if IsObject(cell["progBg"]) {
            cell["progBg"].Opt("Background" barTrackColor)
            cell["progBg"].Redraw()
        }

        if IsObject(cell["progFill"]) {
            cell["progFill"].Opt("Background" barFillColor)
            cell["progFill"].Redraw()
        }
    }

    OnHouseCellClick(houseName) {
        if !IsObject(this.profileManager)
            return
        HouseGoalDialog.Show(this.guiObj, houseName, this.profileManager, (*) => this.Refresh())
    }

    OnScanGridClick() {
        this.RunScanLandsraadGridScenario()
    }

    OnResetBoardClick() {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("ClearLandsraadWeeklyData")
            return

        answer := MsgBox(
            "Clear this week's Landsraad data for the current profile?`n`n"
            "Grid scan results, contribution totals, and tracking goals will be removed. You can scan again afterward.",
            "Reset board",
            "YesNo Icon!")

        if (answer != "Yes")
            return

        if !this.profileManager.ClearLandsraadWeeklyData()
            return
        this.Refresh()
        this.RefreshMissionPickerTabs()
        this.ShowSessionHint()
        this.SetStatus("Landsraad board reset.")
        this.Log("Landsraad weekly scan data cleared for this profile.")
    }

    Refresh() {
        if !IsObject(this.weekLabel)
            return

        weekText := ""
        if IsObject(this.settingsManager)
            weekText := this.settingsManager.GetLandsraadWeekLabelText()
        if (weekText == "")
            this.weekLabel.Text := "No contribution week set"
        else
            this.weekLabel.Text := weekText

        for houseName, cell in this.houseCells {
            cont := 0
            goal := 0
            if IsObject(this.profileManager) {
                cont := this.profileManager.GetHouseContribution(houseName)
                goal := this.profileManager.GetHouseGoal(houseName)
            }
            cell["goal"] := goal
            cell["cont"] := cont
            if IsObject(cell["contCtrl"])
                cell["contCtrl"].Text := this.FormatContributionLine(cont, goal)
            barW := cell.Has("barW") ? cell["barW"] : 0
            barMax := goal > 0 ? goal : this.contributionMax
            fillW := this.GetProgressWidth(cont, barW, barMax)
            if IsObject(cell["progFill"])
                cell["progFill"].Move(, , fillW)
            this.RefreshHouseCellStyle(houseName, cell)
        }
    }
}
