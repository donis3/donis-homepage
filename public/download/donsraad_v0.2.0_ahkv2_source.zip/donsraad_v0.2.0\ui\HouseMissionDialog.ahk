#Requires AutoHotkey v2.0+

/**
 * Modal for assigning up to 3 missions to a scanned Landsraad house cell.
 * Destroyed and recreated when the selected house changes.
 */
class HouseMissionDialog {
    static dlg := ""
    static host := ""
    static ownerGui := ""
    static slotIdx := 0
    static houseName := ""
    static row := 0
    static col := 0
    static spec := ""
    static onChanged := ""

    static headerHousePic := ""
    static headerNameLbl := ""
    static headerSpecPic := ""
    static trackBtn := ""
    static clearTrackBtn := ""
    static progBg := ""
    static progFill := ""
    static contribLbl := ""
    static rewardsPanel := ""
    static rewardsCaption := ""
    static rewardRows := []
    static missionsPanel := ""
    static missionsCaption := ""
    static missionStartY := 0
    static missionColX := 0
    static missionColW := 0
    static missionEntries := []
    static footerClearBtn := ""
    static footerCloseBtn := ""

    static winW := 780
    static pad := 16
    static colGap := 20
    static sectionW := 364
    static headerIcon := 52
    static specIcon := 28
    static trackBtnW := 108
    static rewardRowH := 30
    static rewardRowGap := 4
    static huntedDiamondSize := 14
    static huntedIconPath := ""
    static contributionMax := 14000
    static btnBg := "27272F"
    static btnText := "E4E4E7"
    static btnTrackBg := "1E3A5F"
    static btnTrackText := "BFDBFE"
    static btnTargetBg := "166534"
    static btnTargetText := "ECFDF5"
    static btnDisabledBg := "141418"
    static btnDisabledText := "52525B"
    static btnElsewhereBg := "1E293B"
    static btnElsewhereText := "64748B"
    static panelBg := "18181B"
    static sectionTitleColor := "E4E4E7"
    static mutedText := "A1A1AA"
    static subtleText := "71717A"
    static goalText := "EAB308"
    static doneTextColor := "4ADE80"
    static huntedRowBg := "3B1736"
    static huntedTextColor := "F9A8D4"
    static checkDoneColor := "4ADE80"
    static checkPendingColor := "3F3F46"
    static trackedBarTrack := "27272F"
    static trackedProgFill := "4ADE80"
    static trackedDoneBar := "3B82F6"
    static rewardTiers := [700, 3500, 7000, 10500, 14000]
    static specIcons := Map(
        "Crafting", "spec_crafting.png",
        "Exploration", "spec_exploration.png",
        "Gathering", "spec_gathering.png",
        "Combat", "spec_combat.png",
        "Sabotage", "spec_sabotage.png"
    )

    static ShowOrUpdate(ownerGui, hostGui, slotIdx, houseName, row, col, spec := "", onChanged := "") {
        houseName := Trim(houseName)
        if (houseName == "" || slotIdx < 1 || !IsObject(hostGui))
            return

        houseChanged := IsObject(this.dlg)
            && (this.slotIdx != slotIdx || this.houseName != houseName)

        if houseChanged
            this.DestroyDialog()

        this.host := hostGui
        this.ownerGui := ownerGui
        this.slotIdx := slotIdx
        this.houseName := houseName
        this.row := row
        this.col := col
        this.spec := Trim(spec)
        this.onChanged := onChanged

        if !IsObject(this.dlg) {
            this.Build(ownerGui)
            this.Populate()
            this.dlg.Show("AutoSize Center")
        } else {
            this.Populate()
        }
    }

    static Build(ownerGui) {
        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "Assign missions")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        pad := this.pad
        w := this.winW
        hdrY := 12
        headerIcon := this.headerIcon
        specIcon := this.specIcon
        trackBtnW := this.trackBtnW
        rightClusterW := specIcon + 10 + trackBtnW
        nameX := pad + headerIcon + 10
        nameW := w - nameX - pad - rightClusterW - 8
        specX := w - pad - trackBtnW - 10 - specIcon
        trackX := w - pad - trackBtnW

        this.headerHousePic := dlg.Add("Picture",
            "x" pad " y" hdrY " w" headerIcon " h" headerIcon " BackgroundTrans", "")
        dlg.SetFont("s12 bold c" this.sectionTitleColor, "Segoe UI")
        this.headerNameLbl := dlg.Add("Text",
            "x" nameX " y" hdrY " w" nameW " h" headerIcon " +0x200 BackgroundTrans", "")
        this.headerSpecPic := dlg.Add("Picture",
            "x" specX " y" (hdrY + ((headerIcon - specIcon) // 2)) " w" specIcon " h" specIcon
            " BackgroundTrans", "")
        dlg.SetFont("s9 bold c" this.btnTrackText, "Segoe UI")
        this.trackBtn := dlg.Add("Text",
            "x" trackX " y" (hdrY + ((headerIcon - 28) // 2)) " w" trackBtnW " h28 Center +0x200 Background"
            this.btnTrackBg, "Track house")
        this.trackBtn.OnEvent("Click", (*) => this.OnTrackClick())

        progY := hdrY + headerIcon + 10
        dlg.SetFont("s8 c" this.mutedText, "Segoe UI")
        this.contribLbl := dlg.Add("Text",
            "x" pad " y" progY " w" (w - pad * 2) " h16 +0x200 BackgroundTrans Hidden", "")
        barY := progY + 18
        this.progBg := dlg.Add("Text",
            "x" pad " y" barY " w" (w - pad * 2) " h6 Background" this.trackedBarTrack " Hidden")
        this.progFill := dlg.Add("Text",
            "x" pad " y" barY " w0 h6 Background" this.trackedProgFill " Hidden")
        dlg.SetFont("s8 c" this.subtleText, "Segoe UI")
        this.clearTrackBtn := dlg.Add("Text",
            "x" pad " y" (barY + 10) " w120 h16 +0x200 BackgroundTrans Hidden", "Clear tracking")
        this.clearTrackBtn.OnEvent("Click", (*) => this.OnClearTracking())

        bodyY := barY + 12
        leftX := pad
        rightX := pad + this.sectionW + this.colGap

        dlg.SetFont("s10 bold c" this.sectionTitleColor, "Segoe UI")
        this.rewardsCaption := dlg.Add("Text",
            "x" leftX " y" bodyY " w" this.sectionW " h20 BackgroundTrans", "Rewards")
        rewardsPanelY := bodyY + 22
        rewardsPanelH := 5 * this.rewardRowH + 4 * this.rewardRowGap + 12
        this.rewardsPanel := dlg.Add("Text",
            "x" leftX " y" rewardsPanelY " w" this.sectionW " h" rewardsPanelH
            " Background" this.panelBg)

        this.rewardRows := []
        rowInnerX := leftX + 8
        rowInnerW := this.sectionW - 16
        checkW := 18
        goalW := 56
        diamondPad := 4
        nameX := rowInnerX + checkW + goalW + 6
        diamondX := rowInnerX + rowInnerW - this.huntedDiamondSize
        nameW := diamondX - nameX - diamondPad
        rowY := rewardsPanelY + 6
        loop 5 {
            rowBg := dlg.Add("Text",
                "x" rowInnerX " y" rowY " w" rowInnerW " h" this.rewardRowH
                " Background" this.panelBg)
            dlg.SetFont("s9 c" this.checkPendingColor, "Segoe UI")
            checkLbl := dlg.Add("Text",
                "x" rowInnerX " y" rowY " w" checkW " h" this.rewardRowH " Center +0x200 BackgroundTrans", "○")
            dlg.SetFont("s9 bold c" this.goalText, "Segoe UI")
            goalLbl := dlg.Add("Text",
                "x" (rowInnerX + checkW) " y" rowY " w" goalW " h" this.rewardRowH
                " Right +0x200 BackgroundTrans", "")
            dlg.SetFont("s9 c" this.sectionTitleColor, "Segoe UI")
            nameLbl := dlg.Add("Text",
                "x" nameX " y" rowY " w" nameW " h" this.rewardRowH " +0x200 BackgroundTrans", "")
            huntedPic := dlg.Add("Picture",
                "x" diamondX " y" (rowY + ((this.rewardRowH - this.huntedDiamondSize) // 2))
                " w" this.huntedDiamondSize " h" this.huntedDiamondSize " BackgroundTrans Hidden", "")
            this.rewardRows.Push(Map(
                "rowBg", rowBg,
                "checkLbl", checkLbl,
                "huntedPic", huntedPic,
                "goalLbl", goalLbl,
                "nameLbl", nameLbl
            ))
            rowY += this.rewardRowH + this.rewardRowGap
        }

        missionsY := bodyY
        this.missionsCaption := dlg.Add("Text",
            "x" rightX " y" missionsY " w" this.sectionW " h20 BackgroundTrans", "Mission targets")
        missionsPanelY := missionsY + 22
        this.missionsPanel := dlg.Add("Text",
            "x" rightX " y" missionsPanelY " w" this.sectionW " h" rewardsPanelH
            " Background" this.panelBg)

        dlg.SetFont("s8 c" this.mutedText, "Segoe UI")
        this.missionColX := rightX + 10
        this.missionColW := this.sectionW - 20
        this.missionStartY := missionsPanelY + 8
        this.missionEntries := []
        this.BuildMissionButtons(dlg)

        dlg.SetFont("s9 bold c" this.btnText, "Segoe UI")
        footerY := rewardsPanelY + rewardsPanelH + 14
        this.footerClearBtn := dlg.Add("Text",
            "x" pad " y" footerY " w" ((w - pad * 2 - 8) // 2) " h32 Center +0x200 Background" this.btnBg " Hidden",
            "Clear missions")
        this.footerClearBtn.OnEvent("Click", (*) => this.OnClearMissions())
        this.footerCloseBtn := dlg.Add("Text",
            "x" pad " y" footerY " w" (w - pad * 2) " h32 Center +0x200 Background" this.btnBg, "Close")
        this.footerCloseBtn.OnEvent("Click", (*) => this.Close())

        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        this.LayoutFooter()
    }

    static BuildMissionButtons(dlg) {
        this.missionEntries := []
        if !IsObject(this.host) || !IsObject(this.host.stateManager)
            return

        host := this.host
        spec := this.spec
        if (spec == "")
            return

        btnH := 28
        btnGap := 4
        y := this.missionStartY
        x := this.missionColX
        w := this.missionColW

        dlg.SetFont("s9 bold c" this.btnText, "Segoe UI")
        for _, m in host.stateManager.allMissionsList {
            mSpec := m.Has("specialization") ? m["specialization"] : ""
            mName := m.Has("name") ? m["name"] : ""
            if (mSpec != spec || mName == "")
                continue

            label := host.stateManager.FormatMissionLabel(mSpec, mName)
            btn := dlg.Add("Text",
                "x" x " y" y " w" w " h" btnH " Center +0x200", mName)
            btn.OnEvent("Click", this.MakeMissionToggleHandler(label))
            this.missionEntries.Push(Map("btn", btn, "label", label, "name", mName))
            y += btnH + btnGap
        }
    }

    static Populate() {
        if !IsObject(this.dlg)
            return

        houseName := this.houseName
        host := this.host
        pad := this.pad
        w := this.winW

        housePath := this.GetHouseIconPath(houseName)
        if (housePath != "") {
            try this.headerHousePic.Value := "*TransBlack " housePath
        } else {
            try this.headerHousePic.Value := ""
        }
        this.headerNameLbl.Text := houseName

        specPath := this.GetSpecIconPath(this.spec)
        if (specPath != "") {
            try this.headerSpecPic.Value := specPath
        } else {
            try this.headerSpecPic.Value := ""
        }

        cont := 0
        goal := 0
        swatchOwned := false
        houseEntry := ""
        if IsObject(host.profileManager) {
            cont := host.profileManager.GetHouseContribution(houseName)
            goal := host.profileManager.GetHouseGoal(houseName)
            swatchOwned := host.profileManager.IsHouseSwatchOwned(houseName)
            if host.profileManager.HasMethod("GetScannedHouseEntry")
                houseEntry := host.profileManager.GetScannedHouseEntry(houseName)
        }
        isTracked := goal > 0
        goalReached := isTracked && cont >= goal
        barW := w - pad * 2

        if isTracked {
            this.trackBtn.Text := "Edit goal"
            this.contribLbl.Visible := true
            this.contribLbl.Text := this.FormatContribution(cont) " / " this.FormatContribution(goal) " contribution"
            if goalReached {
                this.contribLbl.SetFont("s8 bold c" this.doneTextColor, "Segoe UI")
            } else {
                this.contribLbl.SetFont("s8 bold c" this.goalText, "Segoe UI")
            }
            this.progBg.Visible := true
            cap := goal > 0 ? goal : this.contributionMax
            fillW := goalReached ? barW : this.GetProgressWidth(cont, barW, cap)
            fillColor := goalReached ? this.trackedDoneBar : this.trackedProgFill
            this.progFill.Opt("Background" fillColor)
            this.progFill.Move(, , fillW)
            this.progFill.Visible := true
            this.clearTrackBtn.Visible := goalReached
        } else {
            this.trackBtn.Text := "Track house"
            this.contribLbl.Visible := false
            this.progBg.Visible := false
            this.progFill.Visible := false
            this.clearTrackBtn.Visible := false
        }

        this.PopulateRewardRows(houseEntry, cont, swatchOwned, host)
        this.LayoutBody(isTracked, goalReached)

        slotCount := this.SlotMissionCount(this.slotIdx)
        globalFull := this.TotalMissionCount() >= 3
        if IsObject(this.missionsCaption) {
            if globalFull && slotCount == 0 {
                this.missionsCaption.Text := "Mission targets — 3 / 3 used elsewhere"
            } else if globalFull {
                this.missionsCaption.Text := "Mission targets — click green to remove (3 / 3)"
            } else {
                this.missionsCaption.Text := "Mission targets"
            }
        }

        if goalReached && slotCount > 0
            this.footerClearBtn.Visible := true
        else
            this.footerClearBtn.Visible := false

        this.RefreshMissionButtons()
        this.LayoutFooter()
        try this.dlg.Show("AutoSize Center")
    }

    static PopulateRewardRows(houseEntry, cont, swatchOwned, host) {
        rewards := []
        if (houseEntry is Map) && houseEntry.Has("rewards") && (houseEntry["rewards"] is Array)
            rewards := houseEntry["rewards"]

        diamondPath := this.GetHuntedDiamondPath()
        loop 5 {
            tierIdx := A_Index
            row := this.rewardRows[tierIdx]
            if !IsObject(row)
                continue

            threshold := this.rewardTiers[tierIdx]
            achieved := cont >= threshold
            isSwatchRow := tierIdx == 5
            itemId := ""
            itemName := ""
            isHunted := false

            if isSwatchRow {
                itemName := swatchOwned ? "House Swatch Obtained" : "House Swatch"
            } else if (tierIdx <= rewards.Length) {
                reward := rewards[tierIdx]
                if (reward is Map) {
                    if IsObject(host.profileManager) {
                        itemId := host.profileManager.RewardItemFieldValue(reward.Has("item_id") ? reward["item_id"] : "")
                        itemName := host.profileManager.RewardItemFieldValue(reward.Has("item_name") ? reward["item_name"] : "")
                    } else {
                        itemId := reward.Has("item_id") ? Trim(reward["item_id"]) : ""
                        itemName := reward.Has("item_name") ? Trim(reward["item_name"]) : ""
                    }
                }
                if (itemName == "")
                    itemName := "—"
                if (itemId != "" && IsObject(host.profileManager) && host.profileManager.HasMethod("IsHuntedReward"))
                    isHunted := host.profileManager.IsHuntedReward(itemId)
            } else {
                itemName := "—"
            }

            rowBgColor := isHunted && !isSwatchRow ? this.huntedRowBg : this.panelBg
            row["rowBg"].Opt("Background" rowBgColor)

            if achieved {
                row["checkLbl"].Text := "✓"
                row["checkLbl"].SetFont("s10 bold c" this.checkDoneColor, "Segoe UI")
            } else {
                row["checkLbl"].Text := "○"
                row["checkLbl"].SetFont("s9 c" this.checkPendingColor, "Segoe UI")
            }

            if isHunted && !isSwatchRow && diamondPath != "" {
                try row["huntedPic"].Value := "*TransBlack " diamondPath
                row["huntedPic"].Visible := true
            } else {
                try row["huntedPic"].Value := ""
                row["huntedPic"].Visible := false
            }

            row["goalLbl"].Text := this.FormatContribution(threshold)

            if isSwatchRow && swatchOwned {
                row["nameLbl"].SetFont("s9 c" this.subtleText, "Segoe UI")
                row["nameLbl"].Text := itemName
            } else if isHunted {
                row["nameLbl"].SetFont("s9 bold c" this.huntedTextColor, "Segoe UI")
                row["nameLbl"].Text := itemName
            } else {
                row["nameLbl"].SetFont("s9 c" this.sectionTitleColor, "Segoe UI")
                row["nameLbl"].Text := itemName
            }
        }
    }

    static LayoutBody(isTracked, goalReached) {
        pad := this.pad
        hdrY := 12
        headerIcon := this.headerIcon
        leftX := pad
        rightX := pad + this.sectionW + this.colGap

        if isTracked {
            bodyY := hdrY + headerIcon + 10 + 18 + 6 + 10
            if goalReached
                bodyY += 18
        } else {
            bodyY := hdrY + headerIcon + 10 + 12
        }

        rewardsPanelY := bodyY + 22
        rewardsPanelH := 5 * this.rewardRowH + 4 * this.rewardRowGap + 12
        missionPanelH := rewardsPanelH
        if (this.missionEntries.Length > 0) {
            missionPanelH := this.missionEntries.Length * 28 + (this.missionEntries.Length - 1) * 4 + 16
            if (missionPanelH < rewardsPanelH)
                missionPanelH := rewardsPanelH
        }

        this.rewardsCaption.Move(leftX, bodyY)
        this.rewardsPanel.Move(leftX, rewardsPanelY, this.sectionW, rewardsPanelH)
        this.missionsCaption.Move(rightX, bodyY)
        this.missionsPanel.Move(rightX, rewardsPanelY, this.sectionW, missionPanelH)

        rowInnerX := leftX + 8
        rowInnerW := this.sectionW - 16
        checkW := 18
        goalW := 56
        diamondPad := 4
        nameX := rowInnerX + checkW + goalW + 6
        diamondX := rowInnerX + rowInnerW - this.huntedDiamondSize
        nameW := diamondX - nameX - diamondPad
        rowY := rewardsPanelY + 6
        for _, row in this.rewardRows {
            if !IsObject(row)
                continue
            row["rowBg"].Move(rowInnerX, rowY, rowInnerW, this.rewardRowH)
            row["checkLbl"].Move(rowInnerX, rowY, checkW, this.rewardRowH)
            row["goalLbl"].Move(rowInnerX + checkW, rowY, goalW, this.rewardRowH)
            row["nameLbl"].Move(nameX, rowY, nameW, this.rewardRowH)
            row["huntedPic"].Move(diamondX, rowY + ((this.rewardRowH - this.huntedDiamondSize) // 2))
            rowY += this.rewardRowH + this.rewardRowGap
        }

        this.missionStartY := rewardsPanelY + 8
        this.RepositionMissionButtons()
    }

    static GetHuntedDiamondPath() {
        if (this.huntedIconPath != "")
            return this.huntedIconPath
        path := A_ScriptDir "\db\reward_icons\diamond.png"
        if FileExist(path) {
            this.huntedIconPath := path
            return path
        }
        return ""
    }

    static GetProgressWidth(contribution, barW, maxValue := "") {
        try {
            n := Integer(contribution)
        } catch {
            n := 0
        }
        if (n < 0)
            n := 0
        try {
            cap := (maxValue != "") ? Integer(maxValue) : this.contributionMax
        } catch {
            cap := this.contributionMax
        }
        if (cap < 1)
            cap := this.contributionMax
        if (n >= cap)
            return barW
        if (barW <= 0)
            return 0
        return Round(barW * n / cap)
    }

    static LayoutFooter() {
        if !IsObject(this.dlg)
            return

        rBottom := 0
        mBottom := 0
        try this.rewardsPanel.GetPos(, &rPanelY, , &rPanelH)
        rBottom := rPanelY + rPanelH
        try this.missionsPanel.GetPos(, &mPanelY, , &mPanelH)
        mBottom := mPanelY + mPanelH
        y := (rBottom > mBottom ? rBottom : mBottom) + 14

        pad := this.pad
        w := this.winW
        halfW := (w - pad * 2 - 8) // 2
        btnH := 32
        if this.footerClearBtn.Visible {
            this.footerClearBtn.Move(pad, y, halfW, btnH)
            this.footerCloseBtn.Move(pad + halfW + 8, y, halfW, btnH)
        } else {
            this.footerCloseBtn.Move(pad, y, w - pad * 2, btnH)
        }
    }

    static RepositionMissionButtons() {
        if !(this.missionEntries is Array)
            return
        btnH := 28
        btnGap := 4
        y := this.missionStartY
        for _, entry in this.missionEntries {
            try entry["btn"].Move(this.missionColX, y, this.missionColW, btnH)
            y += btnH + btnGap
        }
    }

    static RefreshMissionButtons() {
        if !(this.missionEntries is Array) || !IsObject(this.host)
            return

        host := this.host
        slotIdx := this.slotIdx
        slotMissions := host.slotMissions.Has(slotIdx) ? host.slotMissions[slotIdx] : []

        targetedOnSlot := Map()
        for _, label in slotMissions {
            if (label != "")
                targetedOnSlot[label] := true
        }

        slotCount := this.SlotMissionCount(slotIdx)
        globalFull := this.TotalMissionCount() >= 3
        houseFull := slotCount >= 3
        takenElsewhere := this.GetTargetedMissionNames(slotIdx)

        for _, entry in this.missionEntries {
            label := entry["label"]
            mName := entry.Has("name") ? entry["name"] : ""
            isTargeted := targetedOnSlot.Has(label)
            takenOther := mName != "" && takenElsewhere.Has(StrLower(mName)) && !isTargeted

            entry["btn"].Visible := true
            entry["btn"].Text := mName

            if isTargeted {
                this.StyleMissionButton(entry["btn"], true, true)
            } else if takenOther {
                this.StyleMissionButton(entry["btn"], false, false, "elsewhere")
            } else {
                canToggle := !globalFull && !houseFull
                this.StyleMissionButton(entry["btn"], false, canToggle, canToggle ? "" : "limit")
            }
        }
    }

    static MakeMissionToggleHandler(label) {
        return (*) => this.OnMissionToggle(label)
    }

    static OnMissionToggle(label) {
        host := this.host
        slotIdx := this.slotIdx
        if !IsObject(host) || slotIdx < 1 || label == ""
            return
        if (this.houseName == "" || this.slotIdx != slotIdx)
            return

        missions := []
        if host.slotMissions.Has(slotIdx) {
            for _, ml in host.slotMissions[slotIdx] {
                if (ml != "")
                    missions.Push(ml)
            }
        }

        foundIdx := 0
        loop missions.Length {
            if (missions[A_Index] == label) {
                foundIdx := A_Index
                break
            }
        }

        if (foundIdx > 0) {
            missions.RemoveAt(foundIdx)
            if (missions.Length == 0)
                host.slotMissions.Delete(slotIdx)
            else
                host.slotMissions[slotIdx] := missions
        } else {
            if (this.TotalMissionCount() >= 3 || missions.Length >= 3)
                return
            taken := this.GetTargetedMissionNames(slotIdx)
            mName := ""
            if IsObject(host.stateManager) {
                parsed := host.stateManager.ParseMissionLabel(label)
                mName := parsed.missionName
            }
            if (mName != "" && taken.Has(StrLower(mName)))
                return
            missions.Push(label)
            host.slotMissions[slotIdx] := missions
        }

        this.PersistAndRefresh()
    }

    static OnClearMissions() {
        host := this.host
        slotIdx := this.slotIdx
        if !IsObject(host) || slotIdx < 1
            return
        if host.slotMissions.Has(slotIdx)
            host.slotMissions.Delete(slotIdx)
        this.PersistAndRefresh()
    }

    static OnClearTracking() {
        host := this.host
        if !IsObject(host) || !IsObject(host.profileManager) || Trim(this.houseName) == ""
            return
        host.profileManager.SetHouseGoal(this.houseName, 0)
        this.OnGoalSaved()
    }

    static OnTrackClick() {
        host := this.host
        if !IsObject(host) || !IsObject(host.profileManager) || Trim(this.houseName) == ""
            return
        owner := IsObject(this.ownerGui) ? this.ownerGui : host.guiObj
        HouseGoalDialog.Show(owner, this.houseName, host.profileManager, (*) => this.OnGoalSaved())
    }

    static OnGoalSaved() {
        this.RebuildDialog()
        if IsObject(this.onChanged)
            try this.onChanged.Call()
    }

    static RebuildDialog() {
        if !IsObject(this.dlg) || !IsObject(this.host)
            return

        owner := this.ownerGui
        host := this.host
        slotIdx := this.slotIdx
        houseName := this.houseName
        row := this.row
        col := this.col
        spec := this.spec
        onChanged := this.onChanged
        ownerGui := IsObject(owner) ? owner : host.guiObj

        this.DestroyDialog()

        this.host := host
        this.ownerGui := owner
        this.slotIdx := slotIdx
        this.houseName := houseName
        this.row := row
        this.col := col
        this.spec := spec
        this.onChanged := onChanged

        this.Build(ownerGui)
        this.Populate()
        try this.dlg.Show("AutoSize Center")
    }

    static PersistAndRefresh() {
        host := this.host
        if IsObject(host) {
            host.SaveMissionSelections()
            host.RefreshStatusOverlay()
            host.RefreshStatusProgress()
            if IsObject(host.pickerGridTab)
                host.pickerGridTab.UpdateTargetCounter()
        }
        if IsObject(this.onChanged)
            try this.onChanged.Call()
        this.Populate()
    }

    static StyleMissionButton(btn, targeted, enabled, disabledKind := "") {
        if !IsObject(btn)
            return
        if targeted {
            btn.Opt("Background" this.btnTargetBg)
            btn.SetFont("s9 bold c" this.btnTargetText, "Segoe UI")
        } else if enabled {
            btn.Opt("Background" this.btnBg)
            btn.SetFont("s9 bold c" this.btnText, "Segoe UI")
        } else if disabledKind == "elsewhere" {
            btn.Opt("Background" this.btnElsewhereBg)
            btn.SetFont("s9 c" this.btnElsewhereText, "Segoe UI")
        } else {
            btn.Opt("Background" this.btnDisabledBg)
            btn.SetFont("s9 c" this.btnDisabledText, "Segoe UI")
        }
        btn.Redraw()
    }

    static SlotMissionCount(slotIdx) {
        host := this.host
        if !IsObject(host) || !host.slotMissions.Has(slotIdx)
            return 0
        cnt := 0
        for _, label in host.slotMissions[slotIdx] {
            if (label != "")
                cnt++
        }
        return cnt
    }

    static TotalMissionCount() {
        host := this.host
        if !IsObject(host)
            return 0
        total := 0
        for _, missions in host.slotMissions {
            if !(missions is Array)
                continue
            for _, label in missions {
                if (label != "")
                    total++
            }
        }
        return total
    }

    static GetTargetedMissionNames(exceptSlot := 0) {
        taken := Map()
        host := this.host
        if !IsObject(host) || !IsObject(host.stateManager)
            return taken
        for slotIdx, missions in host.slotMissions {
            for _, label in missions {
                if (label == "")
                    continue
                if (slotIdx == exceptSlot)
                    continue
                parsed := host.stateManager.ParseMissionLabel(label)
                if (parsed.missionName != "")
                    taken[StrLower(parsed.missionName)] := true
            }
        }
        return taken
    }

    static GetHouseIconPath(houseName) {
        if (houseName == "" || !IsObject(this.host) || !IsObject(this.host.stateManager))
            return ""
        for _, entry in this.host.stateManager.allHousesList {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName) {
                slug := entry.Has("iconSlug") ? entry["iconSlug"] : ""
                if (slug != "") {
                    scaled := A_ScriptDir "\db\house_icons_scaled\1440p\" slug "_72x72.png"
                    if FileExist(scaled)
                        return scaled
                    raw := A_ScriptDir "\db\house_icons\" slug ".png"
                    if FileExist(raw)
                        return raw
                }
                break
            }
        }
        return ""
    }

    static GetSpecIconPath(spec) {
        if (spec == "" || !this.specIcons.Has(spec))
            return ""
        path := A_ScriptDir "\db\spec_icons\" this.specIcons[spec]
        if FileExist(path)
            return path
        return ""
    }

    static FormatContribution(value) {
        try {
            n := Integer(value)
        } catch {
            return "0"
        }
        if (n < 0)
            n := 0
        return Format("{:L}", n)
    }

    static DestroyDialog() {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.headerHousePic := ""
        this.headerNameLbl := ""
        this.headerSpecPic := ""
        this.trackBtn := ""
        this.clearTrackBtn := ""
        this.progBg := ""
        this.progFill := ""
        this.contribLbl := ""
        this.rewardsPanel := ""
        this.rewardsCaption := ""
        this.rewardRows := []
        this.missionsPanel := ""
        this.missionsCaption := ""
        this.missionStartY := 0
        this.missionColX := 0
        this.missionColW := 0
        this.missionEntries := []
        this.footerClearBtn := ""
        this.footerCloseBtn := ""
    }

    static Close(*) {
        this.DestroyDialog()
        this.host := ""
        this.ownerGui := ""
        this.slotIdx := 0
        this.houseName := ""
        this.row := 0
        this.col := 0
        this.spec := ""
        this.onChanged := ""
    }

    static IsOpen() {
        return IsObject(this.dlg)
    }
}
