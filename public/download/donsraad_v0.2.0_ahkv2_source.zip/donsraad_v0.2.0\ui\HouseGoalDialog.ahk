#Requires AutoHotkey v2.0+

/**
 * Modal to set weekly Landsraad contribution tracking goal for a house.
 */
class HouseGoalDialog {
    static dlg := ""
    static profileManager := ""
    static houseName := ""
    static onSaved := ""
    static swatchRow := ""
    static swatchOwnedState := false
    static tiers := [700, 3500, 7000, 10500, 14000]
    static btnBg := "27272F"
    static btnActiveBg := "EAB308"
    static btnText := "E4E4E7"
    static btnActiveText := "18181B"
    static swatchRowOffBg := "27272F"
    static swatchRowOnBg := "14532D"
    static swatchCheckOnColor := "4ADE80"
    static swatchCheckOffColor := "A1A1AA"

    static Show(ownerGui, houseName, profileManagerInst, onSaved := "") {
        if (Trim(houseName) == "" || !IsObject(profileManagerInst))
            return

        this.Close()
        this.profileManager := profileManagerInst
        this.houseName := houseName
        this.onSaved := onSaved

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "Contribution goal")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"
        dlg.MarginX := 16
        dlg.MarginY := 10

        dlg.SetFont("s11 bold cE4E4E7", "Segoe UI")
        dlg.Add("Text", "w320 BackgroundTrans", houseName)
        dlg.SetFont("s9 cA1A1AA", "Segoe UI")
        dlg.Add("Text", "w320 BackgroundTrans",
            "Choose a weekly contribution goal. Resets with the Landsraad week.")

        currentGoal := profileManagerInst.GetHouseGoal(houseName)
        this.swatchOwnedState := profileManagerInst.IsHouseSwatchOwned(houseName)
        btnW := 320
        btnH := 30
        swatchRowH := 30

        this.swatchRow := dlg.Add("Text",
            "w" btnW " h" swatchRowH " +0x200 Background" this.swatchRowOffBg, "")
        this.swatchRow.OnEvent("Click", (*) => this.OnSwatchRowClick())
        this.StyleSwatchRow()

        dlg.SetFont("s9 bold cE4E4E7", "Segoe UI")
        dontBtn := dlg.Add("Text",
            "w" btnW " h" btnH " Center +0x200 Background" this.btnBg, "Don't track")
        dontBtn.OnEvent("Click", (*) => this.OnPick(0))
        this.StyleGoalButton(dontBtn, currentGoal == 0)

        loop this.tiers.Length {
            tier := A_Index
            amount := this.tiers[tier]
            label := "Tier " tier " — " this.FormatAmount(amount)
            btn := dlg.Add("Text",
                "w" btnW " h" btnH " Center +0x200 Background" this.btnBg, label)
            btn.OnEvent("Click", this.MakePickHandler(amount))
            this.StyleGoalButton(btn, currentGoal == amount)
        }

        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("AutoSize Center")
    }

    static StyleSwatchRow() {
        if !IsObject(this.swatchRow)
            return
        if this.swatchOwnedState {
            this.swatchRow.Opt("Background" this.swatchRowOnBg)
            this.swatchRow.SetFont("s10 bold c" this.swatchCheckOnColor, "Segoe UI")
            this.swatchRow.Text := "  ☑   House Swatch Owned"
        } else {
            this.swatchRow.Opt("Background" this.swatchRowOffBg)
            this.swatchRow.SetFont("s10 c" this.swatchCheckOffColor, "Segoe UI")
            this.swatchRow.Text := "  ☐   House Swatch Owned"
        }
        this.swatchRow.Redraw()
    }

    static OnSwatchRowClick() {
        if !IsObject(this.profileManager) || Trim(this.houseName) == ""
            return
        this.swatchOwnedState := !this.swatchOwnedState
        this.StyleSwatchRow()
        this.profileManager.SetHouseSwatchOwned(this.houseName, this.swatchOwnedState)
        if IsObject(this.onSaved)
            try this.onSaved.Call()
    }

    static StyleGoalButton(btn, selected) {
        if !IsObject(btn)
            return
        if selected {
            btn.Opt("Background" this.btnActiveBg)
            btn.SetFont("s9 bold c" this.btnActiveText, "Segoe UI")
        } else {
            btn.Opt("Background" this.btnBg)
            btn.SetFont("s9 bold c" this.btnText, "Segoe UI")
        }
        btn.Redraw()
    }

    static MakePickHandler(amount) {
        return (*) => this.OnPick(amount)
    }

    static OnPick(goal) {
        if IsObject(this.profileManager) && Trim(this.houseName) != ""
            this.profileManager.SetHouseGoal(this.houseName, goal)
        if IsObject(this.onSaved)
            try this.onSaved.Call()
        this.Close()
    }

    static FormatAmount(value) {
        try {
            return Format("{:L}", Integer(value))
        } catch {
            return String(value)
        }
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.profileManager := ""
        this.houseName := ""
        this.onSaved := ""
        this.swatchRow := ""
        this.swatchOwnedState := false
    }
}
