#Requires AutoHotkey v2.0+

/**
 * Ultra-high-performance Windows 10/11 native WinRT OCR engine for AutoHotkey v2.
 * 
 * Uses Windows.Media.Ocr via direct WinRT COM interfaces with zero external CLI dependencies.
 * Passes in-memory screen buffers directly to the WinRT pipeline for sub-millisecond to low-millisecond execution.
 */
class Ocr {
    static isInitialized := false
    static cachedEngine := 0
    static cachedLang := ""

    /**
     * Initializes WinRT COM runtime if not already initialized.
     */
    static Init() {
        if (this.isInitialized)
            return
        ; RO_INIT_MULTITHREADED = 1
        DllCall("combase\RoInitialize", "int", 1)
        this.isInitialized := true
    }

    /**
     * Gets or creates a singleton IOcrEngine instance for the specified language tag.
     * @param {String} lang - e.g. "en-US", "en", or "" for user profile languages.
     * @returns {Ptr} - Pointer to IOcrEngine COM interface.
     */
    static GetEngine(lang := "en-US") {
        this.Init()

        if (this.cachedEngine && this.cachedLang == lang)
            return this.cachedEngine

        if (this.cachedEngine) {
            ObjRelease(this.cachedEngine)
            this.cachedEngine := 0
        }

        pOcrEngineStatics := this.GetActivationFactory("Windows.Media.Ocr.OcrEngine", "{5bffa85a-3384-3540-9940-699120d428a8}")
        pOcrEngine := 0

        if (lang != "") {
            try {
                pLangFactory := this.GetActivationFactory("Windows.Globalization.Language", "{9b0252ac-0c27-44f8-b792-9793fb66c63e}")
                hLangTag := this.CreateHString(lang)
                pLanguage := 0
                ; ILanguageFactory::CreateLanguage (Slot 6)
                ComCall(6, pLangFactory, "ptr", hLangTag, "ptr*", &pLanguage)
                this.DeleteHString(hLangTag)
                ObjRelease(pLangFactory)

                if (pLanguage) {
                    ; IOcrEngineStatics::TryCreateFromLanguage (Slot 9)
                    ComCall(9, pOcrEngineStatics, "ptr", pLanguage, "ptr*", &pOcrEngine)
                    ObjRelease(pLanguage)
                }
            } catch {
                pOcrEngine := 0
            }
        }

        ; Fallback to user profile languages if specific language not available
        if (!pOcrEngine) {
            ; IOcrEngineStatics::TryCreateFromUserProfileLanguages (Slot 10)
            ComCall(10, pOcrEngineStatics, "ptr*", &pOcrEngine)
        }

        ObjRelease(pOcrEngineStatics)

        if (!pOcrEngine)
            throw Error("Failed to initialize Windows OCR Engine. Please ensure Windows English OCR language pack is installed.")

        this.cachedEngine := pOcrEngine
        this.cachedLang := lang
        return pOcrEngine
    }

    /**
     * Performs OCR directly on a specific screen bounding box.
     * Captures only the targeted area into memory and runs WinRT OCR.
     * 
     * @param {Integer} x - Screen X coordinate.
     * @param {Integer} y - Screen Y coordinate.
     * @param {Integer} w - Width in pixels.
     * @param {Integer} h - Height in pixels.
     * @param {String} lang - Language tag (default "en-US").
     * @returns {Object} - { text: String, lines: Array, words: Array }
     */
    static FromRect(x, y, w, h, lang := "en-US") {
        targetX := Round(x)
        targetY := Round(y)
        targetW := Max(1, Round(w))
        targetH := Max(1, Round(h))
        ResolutionManager().ClampCapture(&targetX, &targetY, &targetW, &targetH)

        pBitmap := Gdip_BitmapFromScreen(targetX, targetY, targetW, targetH)
        if (!pBitmap)
            return { text: "", lines: [], words: [] }

        result := this.FromBitmap(pBitmap, lang)
        Gdip_DisposeImage(pBitmap)
        return result
    }

    /**
     * OCR for small gold-on-dark HUD text. Pads, upscales, then thresholds to black-on-white.
     */
    static FromHudRect(x, y, w, h, lang := "en-US", scale := 4, pad := 10, lumaMin := 90) {
        targetX := Round(x) - pad
        targetY := Round(y) - pad
        targetW := Max(1, Round(w) + (pad * 2))
        targetH := Max(1, Round(h) + (pad * 2))
        ResolutionManager().ClampCapture(&targetX, &targetY, &targetW, &targetH)

        pBitmap := Gdip_BitmapFromScreen(targetX, targetY, targetW, targetH)
        if (!pBitmap)
            return { text: "", lines: [], words: [] }

        pScaled := Gdip_ResizeBitmap(pBitmap, scale)
        Gdip_DisposeImage(pBitmap)
        if (!pScaled)
            return { text: "", lines: [], words: [] }

        Gdip_PrepareHudTextForOcr(pScaled, lumaMin)
        result := this.FromBitmap(pScaled, lang)
        Gdip_DisposeImage(pScaled)
        return result
    }

    /**
     * Performs OCR from a GDI+ Bitmap pointer.
     * @param {Ptr} pBitmap - GDI+ bitmap pointer.
     * @param {String} lang - Language tag (default "en-US").
     * @returns {Object} - { text: String, lines: Array, words: Array }
     */
    static FromBitmap(pBitmap, lang := "en-US") {
        if (!pBitmap)
            return { text: "", lines: [], words: [] }

        pSoftwareBitmap := this.CreateSoftwareBitmapFromGdiplusBitmap(pBitmap)
        if (!pSoftwareBitmap)
            return { text: "", lines: [], words: [] }

        return this.RecognizeSoftwareBitmap(pSoftwareBitmap, lang)
    }

    /**
     * Performs OCR from a Windows HBITMAP handle.
     */
    static FromHBitmap(hBitmap, lang := "en-US") {
        if (!hBitmap)
            return { text: "", lines: [], words: [] }

        pBitmap := 0
        DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hBitmap, "ptr", 0, "uptr*", &pBitmap)
        if (!pBitmap)
            return { text: "", lines: [], words: [] }

        result := this.FromBitmap(pBitmap, lang)
        DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)
        return result
    }

    /**
     * Converts a GDI+ Bitmap into a WinRT ISoftwareBitmap via in-memory stream and BitmapDecoder.
     */
    static CreateSoftwareBitmapFromGdiplusBitmap(pBitmap) {
        this.Init()

        ; 1. Create IStream on HGlobal
        pStream := 0
        hr := DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", 1, "ptr*", &pStream, "hresult")
        if (hr != 0 || !pStream)
            throw Error("CreateStreamOnHGlobal failed (" Format("0x{:08X}", hr) ")")

        ; 2. Save GDI+ bitmap as BMP into IStream
        CLSID_BMP := this.GUIDFromString("{557CF400-1A04-11D3-9A73-0000F81EF32E}")
        status := DllCall("gdiplus\GdipSaveImageToStream", "ptr", pBitmap, "ptr", pStream, "ptr", CLSID_BMP, "ptr", 0)
        if (status != 0) {
            ObjRelease(pStream)
            throw Error("GdipSaveImageToStream failed with status: " status)
        }

        ; 3. Rewind IStream to beginning (IStream::Seek - Slot 5)
        ComCall(5, pStream, "int64", 0, "uint", 0, "ptr", 0)

        ; 4. Wrap IStream as WinRT IRandomAccessStream
        guidIRAS := this.GUIDFromString("{905A0FE1-BC53-11DF-8C49-001E4FC686DA}")
        pRandomAccessStream := 0
        hr := DllCall("shcore\CreateRandomAccessStreamOverStream", "ptr", pStream, "uint", 0, "ptr", guidIRAS, "ptr*", &pRandomAccessStream, "hresult")
        ObjRelease(pStream)

        if (hr != 0 || !pRandomAccessStream)
            throw Error("CreateRandomAccessStreamOverStream failed (" Format("0x{:08X}", hr) ")")

        ; 5. Get BitmapDecoderStatics and create BitmapDecoder
        pDecoderStatics := this.GetActivationFactory("Windows.Graphics.Imaging.BitmapDecoder", "{438ccb26-bcef-4e95-bad6-23a822e58d01}")
        pAsyncDecoder := 0
        ; IBitmapDecoderStatics::CreateAsync (Slot 14)
        ComCall(14, pDecoderStatics, "ptr", pRandomAccessStream, "ptr*", &pAsyncDecoder)
        ObjRelease(pDecoderStatics)
        ObjRelease(pRandomAccessStream)

        if (!pAsyncDecoder)
            throw Error("BitmapDecoder::CreateAsync failed")

        this.WaitForAsync(pAsyncDecoder)

        ; IAsyncOperation<BitmapDecoder>::GetResults (Slot 8)
        pDecoder := 0
        ComCall(8, pAsyncDecoder, "ptr*", &pDecoder)
        ObjRelease(pAsyncDecoder)

        if (!pDecoder)
            throw Error("Failed to obtain BitmapDecoder results")

        ; 6. Query IBitmapFrameWithSoftwareBitmap to access GetSoftwareBitmapAsync
        iidFrameWithSB := this.GUIDFromString("{fe287c9a-420c-4963-87ad-691436e08383}")
        pFrameWithSB := 0
        ComCall(0, pDecoder, "ptr", iidFrameWithSB, "ptr*", &pFrameWithSB)
        ObjRelease(pDecoder)

        if (!pFrameWithSB)
            throw Error("QueryInterface IBitmapFrameWithSoftwareBitmap failed")

        pAsyncSoftwareBitmap := 0
        ; IBitmapFrameWithSoftwareBitmap::GetSoftwareBitmapAsync (Slot 6)
        ComCall(6, pFrameWithSB, "ptr*", &pAsyncSoftwareBitmap)
        ObjRelease(pFrameWithSB)

        if (!pAsyncSoftwareBitmap)
            throw Error("BitmapDecoder::GetSoftwareBitmapAsync failed")

        this.WaitForAsync(pAsyncSoftwareBitmap)

        ; IAsyncOperation<SoftwareBitmap>::GetResults (Slot 8)
        pSoftwareBitmap := 0
        ComCall(8, pAsyncSoftwareBitmap, "ptr*", &pSoftwareBitmap)
        ObjRelease(pAsyncSoftwareBitmap)

        return pSoftwareBitmap
    }

    /**
     * Recognizes text from an initialized ISoftwareBitmap COM object.
     */
    static RecognizeSoftwareBitmap(pSoftwareBitmap, lang := "en-US") {
        if (!pSoftwareBitmap)
            return { text: "", lines: [], words: [] }

        pOcrEngine := this.GetEngine(lang)

        ; IOcrEngine::RecognizeAsync (Slot 6)
        pAsyncOp := 0
        ComCall(6, pOcrEngine, "ptr", pSoftwareBitmap, "ptr*", &pAsyncOp)
        ObjRelease(pSoftwareBitmap)

        if (!pAsyncOp)
            return { text: "", lines: [], words: [] }

        this.WaitForAsync(pAsyncOp)

        ; IAsyncOperation<OcrResult>::GetResults (Slot 8)
        pOcrResult := 0
        ComCall(8, pAsyncOp, "ptr*", &pOcrResult)
        ObjRelease(pAsyncOp)

        if (!pOcrResult)
            return { text: "", lines: [], words: [] }

        ; IOcrResult::get_Text (Slot 8)
        hResultText := 0
        ComCall(8, pOcrResult, "ptr*", &hResultText)
        fullText := this.HStringToString(hResultText)
        this.DeleteHString(hResultText)

        ; IOcrResult::get_Lines (Slot 6)
        pLines := 0
        ComCall(6, pOcrResult, "ptr*", &pLines)

        linesArray := []
        wordsArray := []

        if (pLines) {
            lineCount := 0
            ; IVectorView<OcrLine>::get_Size (Slot 7)
            ComCall(7, pLines, "uint*", &lineCount)

            loop lineCount {
                lineIdx := A_Index - 1
                pLine := 0
                ; IVectorView<OcrLine>::GetAt (Slot 6)
                ComCall(6, pLines, "uint", lineIdx, "ptr*", &pLine)

                if (pLine) {
                    hLineText := 0
                    ; IOcrLine::get_Text (Slot 7)
                    ComCall(7, pLine, "ptr*", &hLineText)
                    lineText := this.HStringToString(hLineText)
                    this.DeleteHString(hLineText)
                    linesArray.Push(lineText)

                    ; IOcrLine::get_Words (Slot 6)
                    pWords := 0
                    ComCall(6, pLine, "ptr*", &pWords)
                    if (pWords) {
                        wordCount := 0
                        ComCall(7, pWords, "uint*", &wordCount)

                        loop wordCount {
                            wordIdx := A_Index - 1
                            pWord := 0
                            ComCall(6, pWords, "uint", wordIdx, "ptr*", &pWord)
                            if (pWord) {
                                hWordText := 0
                                ; IOcrWord::get_Text (Slot 7)
                                ComCall(7, pWord, "ptr*", &hWordText)
                                wText := this.HStringToString(hWordText)
                                this.DeleteHString(hWordText)

                                rectBuf := Buffer(16, 0)
                                ; IOcrWord::get_BoundingRect (Slot 6)
                                ComCall(6, pWord, "ptr", rectBuf)

                                rx := NumGet(rectBuf, 0, "float")
                                ry := NumGet(rectBuf, 4, "float")
                                rw := NumGet(rectBuf, 8, "float")
                                rh := NumGet(rectBuf, 12, "float")

                                wordsArray.Push({
                                    text: wText,
                                    x: rx,
                                    y: ry,
                                    w: rw,
                                    h: rh
                                })

                                ObjRelease(pWord)
                            }
                        }
                        ObjRelease(pWords)
                    }
                    ObjRelease(pLine)
                }
            }
            ObjRelease(pLines)
        }

        ObjRelease(pOcrResult)

        return {
            text: Trim(fullText),
            lines: linesArray,
            words: wordsArray
        }
    }

    /**
     * Normalizes multi-line raw OCR text into a single clean line.
     */
    static NormalizeText(rawText) {
        if (!rawText)
            return ""
        ; Replace newlines with spaces and condense multiple whitespaces
        cleaned := RegExReplace(rawText, "[\r\n]+", " ")
        cleaned := RegExReplace(cleaned, "\s+", " ")
        return Trim(cleaned)
    }

    /**
     * Parse Landsraad contribution from reward-line HUD OCR, e.g.
     * "1 ,200 Landsraad Contribution" -> 1200
     */
    static ParseLandsraadContribution(text) {
        norm := this.NormalizeText(text)
        if (norm == "")
            return { found: false, number: "", value: 0, rawText: norm }

        if RegExMatch(norm, "i)([\d,OolI|][\d,OolI|,\s]*)\s+Landsraad", &m) {
            numberStr := this.NormalizeHudNumberText(m[1])
            if (numberStr != "")
                return {
                    found: true,
                    number: numberStr,
                    value: this.ParseHudDigits(numberStr),
                    rawText: norm
                }
        }

        bestValue := 0
        bestNumber := ""
        pos := 1
        while RegExMatch(norm, "([\d,OolI|][\d,OolI|,\s]*)", &m, pos) {
            numberStr := this.NormalizeHudNumberText(m[1])
            pos := m.Pos(0) + m.Len(0)
            if (numberStr == "")
                continue
            value := this.ParseHudDigits(numberStr)
            if (value > bestValue) {
                bestValue := value
                bestNumber := numberStr
            }
        }

        if (bestNumber != "")
            return {
                found: true,
                number: bestNumber,
                value: bestValue,
                rawText: norm
            }

        return { found: false, number: "", value: 0, rawText: norm }
    }

    static NormalizeHudNumberText(text) {
        s := Trim(text)
        if (s == "")
            return ""

        s := StrReplace(s, "O", "0")
        s := StrReplace(s, "o", "0")
        s := StrReplace(s, "l", "1")
        s := StrReplace(s, "I", "1")
        s := StrReplace(s, "|", "1")
        s := RegExReplace(s, "\s+", "")
        s := RegExReplace(s, "[^\d,]", "")
        return s
    }

    static ParseHudDigits(numberStr) {
        digits := StrReplace(numberStr, ",", "")
        if (digits == "")
            return 0
        try {
            return Integer(digits)
        } catch {
            return 0
        }
    }

    /**
     * Matches raw OCR text against an array of known mission names/objects.
     * Supports exact case-insensitive match, substring match, and token-overlap scoring.
     */
    static FindBestMatch(rawText, candidateList) {
        norm := this.NormalizeText(rawText)
        if (norm == "" || !IsObject(candidateList) || candidateList.Length == 0)
            return { matchedName: norm, confidence: 0.0, raw: rawText, item: "" }

        normLower := StrLower(norm)
        ; Clean punctuation for comparison (keep letters and digits)
        cleanNorm := RegExReplace(normLower, "[^a-z0-9 ]", "")
        cleanNorm := RegExReplace(cleanNorm, "\s+", " ")
        cleanNorm := Trim(cleanNorm)

        bestName := norm
        bestItem := ""
        bestScore := 0.0

        for _, item in candidateList {
            nameStr := (item is String) ? item : (item.HasOwnProp("name") ? item.name : (item.Has("name") ? item["name"] : String(item)))
            nameLower := StrLower(nameStr)
            cleanCandidate := RegExReplace(nameLower, "[^a-z0-9 ]", "")
            cleanCandidate := RegExReplace(cleanCandidate, "\s+", " ")
            cleanCandidate := Trim(cleanCandidate)

            ; 1. Exact match
            if (cleanNorm == cleanCandidate) {
                return {
                    matchedName: nameStr,
                    item: item,
                    confidence: 1.0,
                    raw: rawText
                }
            }

            ; 2. Substring match
            if (InStr(cleanCandidate, cleanNorm) || InStr(cleanNorm, cleanCandidate)) {
                score := 0.85
                if (score > bestScore) {
                    bestScore := score
                    bestName := nameStr
                    bestItem := item
                }
            }

            ; 3. Token overlap match (handles multi-line word wrapping)
            normTokens := StrSplit(cleanNorm, " ")
            candTokens := StrSplit(cleanCandidate, " ")
            if (normTokens.Length > 0 && candTokens.Length > 0) {
                matchCount := 0
                for _, token in normTokens {
                    if (token == "")
                        continue
                    for _, cToken in candTokens {
                        if (token == cToken) {
                            matchCount++
                            break
                        }
                    }
                }
                overlapScore := (matchCount / Max(normTokens.Length, candTokens.Length)) * 0.8
                if (overlapScore > bestScore) {
                    bestScore := overlapScore
                    bestName := nameStr
                    bestItem := item
                }
            }
        }

        return {
            matchedName: (bestScore >= 0.4) ? bestName : norm,
            item: bestItem,
            confidence: bestScore,
            raw: rawText
        }
    }

    /**
     * Extract tier 1–4 house reward item names from rewards-band tooltip OCR.
     * Rewards appear in order as "amount - item name". Tier 5 (swatch) is ignored.
     * Matches OCR names to db/landsraad_rewards.json using characters 3–10 of the normalized name.
     */
    static ParseHouseRewardTiers(text, rewardDb := "") {
        norm := this.NormalizeText(text)
        empty := { found: false, tiers: [], ocrTexts: [], rawText: norm }

        if (norm == "")
            return empty

        ocrTexts := this.ExtractHouseRewardOcrNames(norm)
        if (ocrTexts.Length == 0)
            return empty

        if !IsObject(rewardDb) || rewardDb.Length == 0
            rewardDb := this.LoadLandsraadRewardsDb()

        tiers := []
        loop Min(4, ocrTexts.Length) {
            rewardTier := A_Index
            ocrText := ocrTexts[A_Index]
            match := this.MatchHouseRewardName(ocrText, rewardDb)
            tiers.Push({
                reward_tier: rewardTier,
                ocrText: ocrText,
                item_id: match.item_id,
                item_name: match.item_name,
                matched: match.matched
            })
        }

        return {
            found: tiers.Length > 0,
            tiers: tiers,
            ocrTexts: ocrTexts,
            rawText: norm
        }
    }

    static MakeEmptyHouseRewardEntries() {
        entries := []
        loop 4
            entries.Push(Map("item_id", "", "item_name", ""))
        return entries
    }

    static FormatHouseRewardEntries(parsed) {
        entries := this.MakeEmptyHouseRewardEntries()
        if !IsObject(parsed) || !parsed.found || !IsObject(parsed.tiers)
            return entries

        loop Min(4, parsed.tiers.Length) {
            tier := parsed.tiers[A_Index]
            if !IsObject(tier)
                continue
            itemId := ""
            itemName := ""
            if tier.matched {
                itemId := tier.item_id
                itemName := tier.item_name
            } else if (Trim(tier.ocrText) != "") {
                itemName := Trim(tier.ocrText)
            }
            entries[A_Index] := Map("item_id", itemId, "item_name", itemName)
        }
        return entries
    }

    static ExtractHouseRewardOcrNames(text) {
        norm := this.NormalizeText(text)
        if RegExMatch(norm, "i)House Rewards:\s*(.*)", &section)
            norm := Trim(section[1])
        if (norm == "")
            return []

        delims := this.FindHouseRewardDelimiters(norm)
        if (delims.Length == 0)
            return []

        names := []
        loop delims.Length {
            nameStart := delims[A_Index].nameStart
            if (A_Index < delims.Length)
                nameEnd := delims[A_Index + 1].pos - 1
            else
                nameEnd := StrLen(norm)
            if (nameEnd < nameStart)
                continue

            name := this.CleanHouseRewardOcrName(SubStr(norm, nameStart, nameEnd - nameStart + 1))
            if (name != "" && !this.IsHouseRewardSwatch(name))
                names.Push(name)
        }
        return names
    }

    static FindHouseRewardDelimiters(norm) {
        delims := []
        pos := 1
        while RegExMatch(norm, "(\d+(?:,\d+)*)\s*-\s*", &m, pos) {
            delims.Push({ pos: m.Pos(0), nameStart: m.Pos(0) + m.Len(0) })
            pos := m.Pos(0) + 1
        }
        pos := 1
        while RegExMatch(norm, "(?<!\d)\s+-\s+", &m, pos) {
            nameStart := m.Pos(0) + m.Len(0)
            duplicate := false
            for _, delim in delims {
                if (Abs(delim.nameStart - nameStart) <= 2) {
                    duplicate := true
                    break
                }
            }
            if !duplicate
                delims.Push({ pos: m.Pos(0), nameStart: nameStart })
            pos := m.Pos(0) + 1
        }

        if (delims.Length == 0)
            return delims

        loop delims.Length - 1 {
            i := A_Index
            loop delims.Length - i {
                j := A_Index
                if (delims[j].pos > delims[j + 1].pos) {
                    temp := delims[j]
                    delims[j] := delims[j + 1]
                    delims[j + 1] := temp
                }
            }
        }
        return delims
    }

    static CleanHouseRewardOcrName(name) {
        s := Trim(name)
        if (s == "")
            return ""
        s := RegExReplace(s, "^\s*-\s*", "")
        s := RegExReplace(s, "\s+0+\s*$", "")
        return Trim(s)
    }

    static IsHouseRewardSwatch(name) {
        return RegExMatch(Trim(name), "i)placeables\s+swatch")
    }

    static CountMatchedHouseRewardTiers(parsed) {
        if !IsObject(parsed) || !parsed.found
            return 0
        matched := 0
        for _, tier in parsed.tiers {
            if tier.matched
                matched++
        }
        return matched
    }

    static HouseRewardParseNeedsRetry(parsed) {
        if !IsObject(parsed) || !parsed.found
            return false

        matched := 0
        hasUnmatched := false
        for _, tier in parsed.tiers {
            if tier.matched
                matched++
            else if (Trim(tier.ocrText) != "")
                hasUnmatched := true
        }

        if (matched == 0)
            return false
        if (parsed.tiers.Length < 4 || hasUnmatched)
            return true
        return matched < 4
    }

    static MatchHouseRewardName(ocrText, rewardDb) {
        unmatched := { item_id: "", item_name: ocrText, matched: false }
        if (Trim(ocrText) == "" || !IsObject(rewardDb))
            return unmatched
        if this.IsHouseRewardSwatch(ocrText)
            return unmatched

        candidates := []
        names := []
        for _, entry in rewardDb {
            if !(entry is Map)
                continue
            itemName := entry.Has("item_name") ? entry["item_name"] : ""
            if (itemName == "")
                continue
            if !this.RewardPrefixMatches(ocrText, itemName)
                continue
            candidates.Push(entry)
            names.Push(itemName)
        }

        if (candidates.Length == 0) {
            for _, entry in rewardDb {
                if !(entry is Map)
                    continue
                itemName := entry.Has("item_name") ? entry["item_name"] : ""
                if (itemName == "")
                    continue
                candidates.Push(entry)
                names.Push(itemName)
            }
            if (candidates.Length == 0)
                return unmatched
        }

        if (candidates.Length == 1) {
            entry := candidates[1]
            return {
                item_id: entry.Has("item_id") ? entry["item_id"] : "",
                item_name: entry.Has("item_name") ? entry["item_name"] : ocrText,
                matched: true
            }
        }

        best := this.FindBestMatch(ocrText, names)
        if (best.confidence < 0.4)
            return unmatched

        for _, entry in candidates {
            if (entry.Has("item_name") && entry["item_name"] == best.matchedName)
                return {
                    item_id: entry.Has("item_id") ? entry["item_id"] : "",
                    item_name: entry["item_name"],
                    matched: true
                }
        }
        return unmatched
    }

    static RewardPrefixMatches(ocrText, dbName) {
        ocrKey := this.RewardMatchKey(ocrText)
        dbKey := this.RewardMatchKey(dbName)
        if (ocrKey == "" || dbKey == "")
            return false
        if (ocrKey == dbKey)
            return true

        ocrNorm := this.RewardNormalizedName(ocrText)
        dbNorm := this.RewardNormalizedName(dbName)
        if (StrLen(ocrKey) < 8 && InStr(dbNorm, ocrKey, , 3))
            return true
        if (StrLen(dbKey) < 8 && InStr(ocrNorm, dbKey, , 3))
            return true
        return false
    }

    static RewardMatchKey(name) {
        s := this.RewardNormalizedName(name)
        if (StrLen(s) < 3)
            return s
        return SubStr(s, 3, Min(8, StrLen(s) - 2))
    }

    static RewardNormalizedName(name) {
        return RegExReplace(StrLower(this.NormalizeText(name)), "[^a-z0-9]", "")
    }

    static RewardNameKey(name, limit := true) {
        s := this.RewardNormalizedName(name)
        return limit ? SubStr(s, 1, 10) : s
    }

    static LoadLandsraadRewardsDb() {
        static cached := ""
        if (cached is Array)
            return cached

        cached := []
        dbPath := A_ScriptDir "\db\landsraad_rewards.json"
        if !FileExist(dbPath)
            return cached

        try {
            parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
            if (parsed is Array)
                cached := parsed
        }
        return cached
    }

    ; ==============================================================================
    ; INTERNAL WINRT & COM HELPERS
    ; ==============================================================================

    static WaitForAsync(pAsyncOp) {
        iidAsyncInfo := this.GUIDFromString("{00000036-0000-0000-C000-000000000046}")
        pAsyncInfo := 0
        ComCall(0, pAsyncOp, "ptr", iidAsyncInfo, "ptr*", &pAsyncInfo)

        if (!pAsyncInfo)
            return

        status := 0
        loop {
            ; IAsyncInfo::get_Status (Slot 7)
            ComCall(7, pAsyncInfo, "int*", &status)
            if (status != 0) ; 0 = Started
                break
            Sleep(1)
        }

        ObjRelease(pAsyncInfo)
    }

    static CreateHString(str) {
        hString := 0
        hr := DllCall("combase\WindowsCreateString", "wstr", str, "uint", StrLen(str), "ptr*", &hString, "hresult")
        if (hr != 0)
            throw Error("WindowsCreateString failed for: " str " (" Format("0x{:08X}", hr) ")")
        return hString
    }

    static DeleteHString(hString) {
        if (hString)
            DllCall("combase\WindowsDeleteString", "ptr", hString)
    }

    static HStringToString(hString) {
        if (!hString)
            return ""
        length := 0
        pBuf := DllCall("combase\WindowsGetStringRawBuffer", "ptr", hString, "uint*", &length, "ptr")
        return StrGet(pBuf, length, "UTF-16")
    }

    static GUIDFromString(guidStr) {
        buf := Buffer(16, 0)
        DllCall("ole32\CLSIDFromString", "wstr", guidStr, "ptr", buf, "hresult")
        return buf
    }

    static GetActivationFactory(className, iidStr) {
        hString := this.CreateHString(className)
        iidBuf := this.GUIDFromString(iidStr)
        pFactory := 0
        hr := DllCall("combase\RoGetActivationFactory", "ptr", hString, "ptr", iidBuf, "ptr*", &pFactory, "hresult")
        this.DeleteHString(hString)
        if (hr != 0 || !pFactory)
            throw Error("RoGetActivationFactory failed for " className " (" Format("0x{:08X}", hr) ")")
        return pFactory
    }
}
