#Requires AutoHotkey v2.0+

/**
 * Scans the Landsraad house grid and updates profile contributions.
 * Callable via scanLandsraadGridScenarioInst.Execute().
 */
class ScanLandsraadGridScenario {
    logger := ""
    anchorMatcher := ""
    profileManager := ""
    stateManager := ""
    gridScanner := ""

    __New(loggerInst := "", anchorMatcherInst := "", profileManagerInst := "", stateManagerInst := "") {
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.profileManager := profileManagerInst
        this.stateManager := stateManagerInst
        this.gridScanner := HouseGridScanner(loggerInst, this.anchorMatcher, stateManagerInst)
    }

    Execute() {
        StatusBar.PinBottomLeft()
        try {
            this.Debug("[ScanLandsraadGrid] Starting...")
            GameWindow.Activate()

            if !this.RunOpenLandsraadGrid()
                return false

            this.Debug("[ScanLandsraadGrid] House grid is open.")

            weekDate := this.GetCurrentWeekDate()
            if (weekDate == "") {
                this.Log("[ScanLandsraadGrid] Error: Could not determine current Landsraad week start date.")
                return false
            }

            this.Log("[ScanLandsraadGrid] Scanning house grid for week " weekDate "...")
            results := this.gridScanner.ScanAllCells()
            if this.IsCancelled() {
                this.Log("[ScanLandsraadGrid] Scan cancelled.")
                return false
            }

            houses := this.BuildHouseEntries(results)
            if !this.SaveScanResults(weekDate, houses) {
                this.Log("[ScanLandsraadGrid] Error: Failed to save scan results to profile.")
                return false
            }

            this.Log("[ScanLandsraadGrid] Grid scan complete (" houses.Length " houses recorded).")
            return houses.Length
        } finally {
            StatusBar.ClearBottomLeftPin()
        }
    }

    BuildHouseEntries(results) {
        houses := []
        for _, result in results {
            if (result.notRevealed) {
                this.Log('"House not yet revealed"')
                continue
            }

            if (result.houseName == "")
                continue

            houseLabel := result.houseName
            if !result.missionsRevealed
                this.Log('"' houseLabel '" : missions not revealed')
            else {
                contribLabel := result.contributionParsed ? result.contribution : "?"
                this.Log('"' houseLabel '" : ' contribLabel)
            }

            rewards := IsObject(result) && result.HasOwnProp("rewards") ? result.rewards : Ocr.MakeEmptyHouseRewardEntries()
            houses.Push(Map(
                "house", result.houseName,
                "cont", (result.missionsRevealed && result.contributionParsed) ? result.contribution : 0,
                "row", result.row,
                "col", result.col,
                "missionsRevealed", result.missionsRevealed ? true : false,
                "rewards", rewards
            ))
        }
        return houses
    }

    GetCurrentWeekDate() {
        global settingsManagerInst
        if IsSet(settingsManagerInst) && IsObject(settingsManagerInst)
            return settingsManagerInst.GetCurrentLandsraadWeekStartDate()
        return ""
    }

    SaveScanResults(weekDate, houses) {
        if !IsObject(this.profileManager)
            return false
        return this.profileManager.SetLandsraadContribution(Map(
            "date", weekDate,
            "houses", houses
        ))
    }

    RunOpenLandsraadGrid() {
        global openLandsraadGridScenarioInst
        if IsSet(openLandsraadGridScenarioInst) && IsObject(openLandsraadGridScenarioInst)
            return openLandsraadGridScenarioInst.Execute()
        this.Log("[ScanLandsraadGrid] Error: OpenLandsraadGrid scenario is unavailable.")
        return false
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
