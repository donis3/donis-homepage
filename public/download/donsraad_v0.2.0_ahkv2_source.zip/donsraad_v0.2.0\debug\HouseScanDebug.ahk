#Requires AutoHotkey v2.0+

/**
 * Debug helper for scanning the Landsraad house grid.
 */
class HouseScanDebug {
    overlays := []
    logger := ""
    scanner := ""
    openLandsraadGridScenario := ""
    debugStartRow := 3

    __New(loggerInst := "", openLandsraadGridScenarioInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.overlays := []
        this.logger := loggerInst
        this.openLandsraadGridScenario := openLandsraadGridScenarioInst
        this.scanner := HouseGridScanner(loggerInst, anchorMatcherInst, stateManagerInst)
        this.scanner.showDebugBoxes := true
    }

    ScanHouseGrid() {
        if IsObject(this.openLandsraadGridScenario)
            this.openLandsraadGridScenario.Execute()

        gridSize := this.scanner.GetGridSize()
        startRow := Max(1, Min(this.debugStartRow, gridSize))
        cellCount := (gridSize - startRow + 1) * gridSize
        this.Log("[House Scan] Scanning " cellCount " cells (row " startRow " to " gridSize ")...")

        results := this.scanner.ScanAllCells(startRow, gridSize)
        for _, result in results {
            if (result.notRevealed) {
                this.Log('"House not yet revealed"')
            } else {
                houseLabel := result.houseName != "" ? result.houseName : "(unknown)"
                if !result.missionsRevealed
                    this.Log('"' houseLabel '" : missions not revealed')
                else {
                    contribLabel := result.contributionParsed ? result.contribution : "?"
                    this.Log('"' houseLabel '" : ' contribLabel)
                }
            }
        }

        this.Hide()
        this.Log("[House Scan] Grid scan complete.")
    }

    ShowTooltipOverlays(areas) {
        this.Hide()

        this.Debug("[House Scan] Right search area ref ("
            areas.right.refX ", " areas.right.refY ", " areas.right.refW ", " areas.right.refH ").")
        this.Debug("[House Scan] Left search area ref ("
            areas.left.refX ", " areas.left.refY ", " areas.left.refW ", " areas.left.refH ").")

        rightOverlay := RectangleOverlay()
        rightOverlay.ShowAt(areas.right.refX, areas.right.refY, areas.right.refW, areas.right.refH)
        this.overlays.Push(rightOverlay)

        leftOverlay := RectangleOverlay()
        leftOverlay.ShowAt(areas.left.refX, areas.left.refY, areas.left.refW, areas.left.refH)
        this.overlays.Push(leftOverlay)
    }

    Hide() {
        for _, overlay in this.overlays {
            if IsObject(overlay)
                overlay.Close()
        }
        this.overlays := []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
