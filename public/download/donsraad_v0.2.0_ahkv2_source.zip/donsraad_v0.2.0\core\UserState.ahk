#Requires AutoHotkey v2.0+

/**
 * In-memory session flags. Not written to player_state.json.
 * Resets when the script reloads.
 */
class UserState {
    initialized := false
    availableTargetedCount := 0
    sessionCompletedCount := 0
    runActive := false
    cancelRequested := false

    /**
     * True after Initialize has finished. While false, only targeted leftover
     * completions count toward SESSION (see StateManager.ShouldCountSessionCompletion).
     */
    IsInitialized() {
        return this.initialized
    }

    SetInitialized(value := true) {
        this.initialized := value ? true : false
    }

    SetAvailableTargetedCount(count) {
        n := Integer(count)
        this.availableTargetedCount := (n < 0) ? 0 : n
    }

    RecordSessionCompletion(count := 1) {
        n := Integer(count)
        if (n < 1)
            n := 1
        this.sessionCompletedCount += n
        return this.sessionCompletedCount
    }

    GetSessionCompletedCount() {
        return this.sessionCompletedCount
    }

    ResetSession() {
        this.initialized := false
        this.availableTargetedCount := 0
        this.runActive := false
        this.cancelRequested := false
        ; Session completes stay until the app reloads.
    }

    BeginRun() {
        this.cancelRequested := false
        this.runActive := true
    }

    EndRun() {
        this.runActive := false
    }

    IsRunActive() {
        return this.runActive
    }

    RequestCancel() {
        this.cancelRequested := true
    }

    IsCancelRequested() {
        return this.cancelRequested
    }

    GetAvailableTargetedCount() {
        return this.availableTargetedCount
    }

    GetProgressText(totalCount := 0) {
        total := Integer(totalCount)
        if (total < 0)
            total := 0
        return this.availableTargetedCount "/" total
    }

    IsProgressComplete(totalCount := 0) {
        total := Integer(totalCount)
        if (total < 1)
            return false
        return this.availableTargetedCount >= total
    }

    GetReadyLabel() {
        return "Ready"
    }
}
