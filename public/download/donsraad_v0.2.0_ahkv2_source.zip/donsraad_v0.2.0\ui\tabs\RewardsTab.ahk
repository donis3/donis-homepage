#Requires AutoHotkey v2.0+

class RewardsTab extends GuiPage {
    rowH := 52
    rowGap := 6
    maxRows := 10
    listTopY := 0
    rowCards := []
    emptyLabel := ""
    weekLabel := ""

    __New(hostGui) {
        super.__New(hostGui, 3)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        infoH := 72
        resetW := 120
        hunterW := 120
        headerBtnH := 28
        btnGap := 10
        helpW := 28
        resetX := m + cardW - resetW
        hunterX := resetX - btnGap - hunterW
        helpX := hunterX - btnGap - helpW

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" m " y" y " w240 h24 BackgroundTrans", "House rewards"))
        this.AddTextButton(3, helpX, y, helpW, headerBtnH, "?", (*) => TabHelpDialog.Show(this.guiObj, "rewards"))
        this.AddBlueTextButton(3, hunterX, y, hunterW, headerBtnH, "Reward Hunter",
            (*) => RewardHunterWindow.Show(this.guiObj, this.profileManager))
        this.AddTextButton(3, resetX, y, resetW, headerBtnH, "Reset rewards", (*) => this.OnResetRewardsClick())
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        weekY := y + headerBtnH + 2
        this.weekLabel := this.PageAdd(3, g.Add("Text",
            "x" m " y" weekY " w" cardW " h18 Right BackgroundTrans", ""))
        y := weekY + 20

        this.PageAdd(3, g.Add("Text", "x" m " y" y " w" cardW " h" infoH " Background" this.surfaceColor))
        this.PageAdd(3, g.Add("Text", "x" m " y" y " w4 h" infoH " BackgroundEAB308"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(3, g.Add("Text",
            "x" (m + 16) " y" (y + 10) " w" (cardW - 32) " h" (infoH - 20) " +0x200 BackgroundTrans Wrap",
            "Rewards earn per Landsraad week and accumulate until you claim them in game. "))
        y += infoH + 12
        this.listTopY := y

        footerH := 36
        bottomPad := 10
        availH := this.winH - footerH - bottomPad - y
        maxRows := availH // (this.rowH + this.rowGap)
        if (maxRows < 4)
            maxRows := 4
        if (maxRows > 12)
            maxRows := 12
        this.maxRows := maxRows

        this.rowCards := []
        loop this.maxRows {
            rowY := y + (A_Index - 1) * (this.rowH + this.rowGap)
            card := this.BuildRowCard(g, m, rowY, cardW)
            this.rowCards.Push(card)
        }

        g.SetFont("s9 c71717A", "Segoe UI")
        this.emptyLabel := this.PageAdd(3, g.Add("Text",
            "x" m " y" y " w" cardW " h24 Center BackgroundTrans Hidden",
            "No house rewards for this week."))

        this.Refresh()
    }

    BuildRowCard(g, x, y, w) {
        pad := 10
        iconSize := 34
        claimW := 72
        seeW := 92
        tierW := 40
        tierGap := 3
        btnGap := 6
        textX := x + pad + iconSize + 12
        rightPad := x + w - pad
        claimX := rightPad - claimW
        seeX := claimX - btnGap - seeW
        tierX := seeX - 8 - (tierW * 5 + tierGap * 4)
        textW := tierX - textX - 8

        bg := this.PageAdd(3, g.Add("Text",
            "x" x " y" y " w" w " h" this.rowH " Hidden Background" this.surfaceColor))
        iconBg := this.PageAdd(3, g.Add("Text",
            "x" (x + pad) " y" (y + ((this.rowH - iconSize) // 2)) " w" iconSize " h" iconSize
            " Hidden Background" this.mutedColor))
        iconPic := this.PageAdd(3, g.Add("Picture",
            "x" (x + pad + 1) " y" (y + ((this.rowH - iconSize) // 2) + 1) " w" (iconSize - 2) " h" (iconSize - 2)
            " Hidden BackgroundTrans", ""))
        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        nameCtrl := this.PageAdd(3, g.Add("Text",
            "x" textX " y" (y + 8) " w" textW " h16 Hidden BackgroundTrans", ""))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        weekCtrl := this.PageAdd(3, g.Add("Text",
            "x" textX " y" (y + 26) " w" textW " h14 Hidden BackgroundTrans", ""))

        tierCtrls := []
        loop 5 {
            tierXPos := tierX + (A_Index - 1) * (tierW + tierGap)
            g.SetFont("s7 bold c52525B", "Segoe UI")
            tierCtrls.Push(this.PageAdd(3, g.Add("Text",
                "x" tierXPos " y" (y + 16) " w" tierW " h18 Center +0x200 Hidden Background27272F",
                "T" A_Index)))
        }

        claimBtn := this.PageAdd(3, g.Add("Text",
            "x" claimX " y" (y + 12) " w" claimW " h28 Center +0x200 Hidden BackgroundEAB308",
            "Claim"))
        claimBtn.SetFont("s9 bold c18181B", "Segoe UI")

        seeBtn := this.PageAdd(3, g.Add("Text",
            "x" seeX " y" (y + 12) " w" seeW " h28 Center +0x200 Hidden Background27272F",
            "See rewards"))
        seeBtn.SetFont("s9 bold cE4E4E7", "Segoe UI")

        card := Map(
            "bg", bg,
            "iconBg", iconBg,
            "iconPic", iconPic,
            "nameCtrl", nameCtrl,
            "weekCtrl", weekCtrl,
            "tierCtrls", tierCtrls,
            "seeBtn", seeBtn,
            "claimBtn", claimBtn,
            "house", "",
            "isClaimed", false,
            "hasIcon", false
        )
        seeBtn.OnEvent("Click", (*) => this.OnSeeRewardsRowCard(card))
        claimBtn.OnEvent("Click", (*) => this.OnClaimRowCard(card))
        return card
    }

    IsTabActive() {
        return IsObject(this.host) && this.host.activeTab == 3
    }

    FormatWeekLabel(weekDate) {
        weekDate := Trim(weekDate)
        if (weekDate == "")
            return "Unknown week"
        try {
            stamp := weekDate
            stamp := StrReplace(stamp, "-", "")
            return "Week of " FormatTime(stamp, "MMM d, yyyy")
        } catch {
            return "Week " weekDate
        }
    }

    FormatRewardWeekLabel(entry) {
        if !(entry is Map)
            return "Unknown week"
        if entry.Has("isClaimed") && entry["isClaimed"]
            return this.FormatWeekLabel(entry.Has("currentWeek") ? entry["currentWeek"] : "")
        oldWeekCount := entry.Has("oldWeekCount") ? Integer(entry["oldWeekCount"]) : 0
        if (oldWeekCount > 0)
            return (oldWeekCount + 1) " weeks unclaimed"
        return this.FormatWeekLabel(entry.Has("currentWeek") ? entry["currentWeek"] : "")
    }

    GetHouseDbEntries() {
        if IsObject(this.stateManager) && (this.stateManager.allHousesList is Array)
        && this.stateManager.allHousesList.Length > 0
            return this.stateManager.allHousesList
        dbPath := A_ScriptDir "\db\landsraad_houses.json"
        if FileExist(dbPath) {
            try {
                parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
                if (parsed is Array)
                    return parsed
            }
        }
        return []
    }

    GetHouseIconPath(houseName) {
        if (houseName == "")
            return ""
        houseEntry := ""
        for _, entry in this.GetHouseDbEntries() {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName) {
                houseEntry := entry
                break
            }
        }
        if !(houseEntry is Map)
            return ""
        slug := houseEntry.Has("iconSlug") ? houseEntry["iconSlug"] : ""
        if (slug != "") {
            scaled := A_ScriptDir "\db\house_icons_scaled\1440p\" slug "_72x72.png"
            if FileExist(scaled)
                return scaled
            raw := A_ScriptDir "\db\house_icons\" slug ".png"
            if FileExist(raw)
                return raw
        }
        if houseEntry.Has("iconFile") {
            path := A_ScriptDir "\db\" houseEntry["iconFile"]
            if FileExist(path)
                return path
        }
        return ""
    }

    ApplyHouseIconPicture(ctrl, path) {
        if !IsObject(ctrl)
            return false
        if (path == "") {
            try ctrl.Value := ""
            return false
        }
        display := "*TransBlack " path
        try ctrl.Value := display
        catch {
            try ctrl.Value := path
        }
        try ctrl.Opt("+BackgroundTrans")
        return true
    }

    SortRewardEntries(entries) {
        sorted := []
        for _, entry in entries
            sorted.Push(entry)
        if (sorted.Length < 2)
            return sorted
        loop sorted.Length - 1 {
            swapped := false
            loop sorted.Length - A_Index {
                i := A_Index
                a := sorted[i]
                b := sorted[i + 1]
                if (this.CompareRewardEntries(a, b) > 0) {
                    sorted[i] := b
                    sorted[i + 1] := a
                    swapped := true
                }
            }
            if !swapped
                break
        }
        return sorted
    }

    CompareRewardEntries(a, b) {
        claimedA := a.Has("isClaimed") && a["isClaimed"]
        claimedB := b.Has("isClaimed") && b["isClaimed"]
        if (claimedA != claimedB)
            return claimedA ? 1 : -1
        tierA := a.Has("highestTier") ? Integer(a["highestTier"]) : 0
        tierB := b.Has("highestTier") ? Integer(b["highestTier"]) : 0
        if (tierA != tierB)
            return tierB - tierA
        houseA := a.Has("house") ? a["house"] : ""
        houseB := b.Has("house") ? b["house"] : ""
        return StrCompare(houseA, houseB, true)
    }

    ApplyClaimButtonStyle(btn, isClaimed) {
        if !IsObject(btn)
            return
        if isClaimed {
            btn.Text := "Claimed"
            btn.Opt("Background3F3F46")
            btn.SetFont("s9 bold c71717A", "Segoe UI")
        } else {
            btn.Text := "Claim"
            btn.Opt("BackgroundEAB308")
            btn.SetFont("s9 bold c18181B", "Segoe UI")
        }
    }

    SetRowVisible(card, show) {
        if !IsObject(card)
            return
        hasIcon := card.Has("hasIcon") ? card["hasIcon"] : false
        card["bg"].Visible := show
        card["iconBg"].Visible := show
        card["iconPic"].Visible := show && hasIcon
        card["nameCtrl"].Visible := show
        card["weekCtrl"].Visible := show
        card["seeBtn"].Visible := show
        card["claimBtn"].Visible := show
        for tierCtrl in card["tierCtrls"]
            tierCtrl.Visible := show
    }

    OnSeeRewardsRowCard(card) {
        if !IsObject(card)
            return
        houseName := card.Has("house") ? Trim(card["house"]) : ""
        if (houseName == "")
            return
        HouseEarnedRewardsWindow.Show(this.guiObj, this.profileManager, houseName)
    }

    OnClaimRowCard(card) {
        if !IsObject(card) || (card.Has("isClaimed") && card["isClaimed"])
            return
        houseName := card.Has("house") ? Trim(card["house"]) : ""
        if (houseName == "")
            return
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("ClaimHouseRewards")
            return
        if !this.profileManager.ClaimHouseRewards(houseName)
            return
        this.Refresh()
        this.SetStatus("Marked " houseName " rewards as claimed.")
        this.Log("Claimed house rewards for " houseName ".")
    }

    OnResetRewardsClick() {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("ResetHouseRewards")
            return

        answer := MsgBox(
            "Clear all tracked house rewards for the current profile?`n`n"
            "Unclaimed and claimed reward tiers will be removed. New tiers will be tracked again as you earn contribution.",
            "Reset rewards",
            "YesNo Icon!")

        if (answer != "Yes")
            return

        if !this.profileManager.ResetHouseRewards()
            return
        this.Refresh()
        this.SetStatus("House rewards reset.")
        this.Log("House rewards cleared for this profile.")
    }

    GetRewardEntries() {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("GetHouseRewardsForTab")
            return []
        return this.SortRewardEntries(this.profileManager.GetHouseRewardsForTab())
    }

    Refresh() {
        if !this.IsTabActive()
            return

        if IsObject(this.weekLabel) && IsObject(this.settingsManager)
            this.weekLabel.Text := this.settingsManager.GetLandsraadWeekLabelText()

        entries := this.GetRewardEntries()
        showEmpty := entries.Length == 0
        if IsObject(this.emptyLabel)
            this.emptyLabel.Visible := showEmpty

        loop this.rowCards.Length {
            idx := A_Index
            card := this.rowCards[idx]
            if (idx > entries.Length) {
                card["hasIcon"] := false
                card["isClaimed"] := false
                this.SetRowVisible(card, false)
                continue
            }
            entry := entries[idx]
            houseName := entry.Has("house") ? entry["house"] : ""
            tiers := entry.Has("tiers") && (entry["tiers"] is Array) ? entry["tiers"] : []
            isClaimed := entry.Has("isClaimed") && entry["isClaimed"]

            card["house"] := houseName
            card["isClaimed"] := isClaimed
            card["nameCtrl"].Text := houseName
            card["weekCtrl"].Text := this.FormatRewardWeekLabel(entry)

            iconPath := this.GetHouseIconPath(houseName)
            card["hasIcon"] := this.ApplyHouseIconPicture(card["iconPic"], iconPath)

            loop card["tierCtrls"].Length {
                tierIdx := A_Index
                tierCtrl := card["tierCtrls"][tierIdx]
                earned := false
                for _, tier in tiers {
                    if (tier = tierIdx) {
                        earned := true
                        break
                    }
                }
                if earned {
                    tierCtrl.Opt("BackgroundEAB308")
                    tierCtrl.SetFont("s7 bold c18181B", "Segoe UI")
                } else {
                    tierCtrl.Opt("Background27272F")
                    tierCtrl.SetFont("s7 bold c52525B", "Segoe UI")
                }
            }

            this.ApplyClaimButtonStyle(card["claimBtn"], isClaimed)
            this.SetRowVisible(card, true)
        }
    }
}
