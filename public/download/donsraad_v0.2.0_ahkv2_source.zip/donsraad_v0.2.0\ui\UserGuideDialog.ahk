#Requires AutoHotkey v2.0+

/**
 * Scrollable getting-started guide (opened from the About tab).
 */
class UserGuideDialog {
    static dlg := ""
    static topicList := ""
    static bodyEdit := ""
    static topics := []

    static Show(ownerGui := "") {
        if IsObject(this.dlg) {
            try {
                this.dlg.Show()
                return
            } catch {
                this.dlg := ""
            }
        }

        this.topics := this.GetTopics()
        pad := 16
        listW := 176
        bodyW := 520
        bodyH := 420
        dlgW := pad + listW + 12 + bodyW + pad
        dlgH := pad + 24 + 8 + bodyH + pad + 36

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "How to use Donsraad")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        dlg.SetFont("s10 bold cEAB308", "Segoe UI")
        dlg.Add("Text", "x" pad " y" pad " w" (dlgW - pad * 2) " h20 BackgroundTrans",
            "Pick a topic on the left. Tab ? buttons explain grid colors on Missions and Landsraad.")

        listX := pad
        listY := pad + 28
        dlg.SetFont("s9 cE4E4E7", "Segoe UI")
        this.topicList := dlg.Add("ListBox",
            "x" listX " y" listY " w" listW " h" bodyH " Background27272F -E0x200")
        this.StyleListBox(this.topicList)

        bodyX := listX + listW + 12
        dlg.SetFont("s9 cA1A1AA", "Segoe UI")
        this.bodyEdit := dlg.Add("Edit",
            "x" bodyX " y" listY " w" bodyW " h" bodyH
            " ReadOnly -E0x200 -WantReturn +VScroll Wrap Background27272F")
        this.StyleEdit(this.bodyEdit)

        loop this.topics.Length
            this.topicList.Add([this.topics[A_Index]["title"]])

        closeY := listY + bodyH + 12
        dlg.SetFont("s9 bold c18181B", "Segoe UI")
        closeBtn := dlg.Add("Text",
            "x" (dlgW - pad - 88) " y" closeY " w88 h28 Center +0x200 BackgroundEAB308", "Close")
        closeBtn.OnEvent("Click", (*) => this.Close())
        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())

        this.topicList.OnEvent("Change", (*) => this.OnTopicSelected())
        this.dlg := dlg
        dlg.Show("w" dlgW " h" dlgH " Center")
        this.topicList.Choose(1)
        this.OnTopicSelected()
    }

    static StyleListBox(ctrl) {
        if !IsObject(ctrl)
            return
        try DllCall("uxtheme\SetWindowTheme", "ptr", ctrl.Hwnd, "wstr", "", "wstr", "")
        ctrl.Opt("-Theme Background27272F")
        ctrl.SetFont("s9 cE4E4E7", "Segoe UI")
    }

    static StyleEdit(ctrl) {
        if !IsObject(ctrl)
            return
        try DllCall("uxtheme\SetWindowTheme", "ptr", ctrl.Hwnd, "wstr", "", "wstr", "")
        ctrl.Opt("-Theme Background27272F")
        ctrl.SetFont("s9 cA1A1AA", "Segoe UI")
    }

    static OnTopicSelected() {
        if !IsObject(this.topicList) || !IsObject(this.bodyEdit)
            return
        idx := this.topicList.Value
        if (idx < 1 || idx > this.topics.Length)
            return
        this.bodyEdit.Value := this.topics[idx]["body"]
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.topicList := ""
        this.bodyEdit := ""
    }

    static GetTopics() {
        topics := []
        topics.Push(Map(
            "title", "Quick start",
            "body",
            "1. Settings — Set character name, guild name, and faction. Guild name is required to refresh the mission board. Enable AutoRun if you want loops to start themselves after a run finishes.`n`n"
            "2. Landsraad — Scan the house grid once per week. Set contribution goals on houses you care about.`n`n"
            "3. Missions — Click the in-game house cell on the board and pick up to three target missions.`n`n"
            "4. Run — Focus Dune: Awakening, pick up to three target missions on the Missions tab, then press Start (or Home). First Start runs setup, then the picker loop.`n`n"
            "5. Play — Complete missions in game. With AutoRun on, leave Travel confirmation open at the ornithopter, or finish until View mission report? appears — either can start the next loop. End stops and pauses the run timer. Delete toggles AutoRun.`n`n"
            "6. Rewards — Claim house tier rewards in game, then mark them claimed on the Rewards tab.`n`n"
            "7. Dashboard — X hides the window. Tray icon or your dashboard hotkey brings it back. Rebind keys in Settings."
        ))
        topics.Push(Map(
            "title", "Missions grid",
            "body",
            "The Missions tab mirrors the 5×5 Landsraad house board in game. After a Landsraad scan, cells show house crests, specialization icons, and contribution progress.`n`n"
            "Click a cell to open mission picks for that house. Green cells are your current targets (up to three total). One specialization per cell — it must match what that house offers.`n`n"
            "Drag a filled cell onto another to swap targets, or onto an empty cell to move them. Click without dragging still selects the cell.`n`n"
            "Landsraad only surfaces a few random offers per specialization. Donsraad fills leftover guild slots, disbands to refresh the board, and repeats until your targets appear, then accepts them.`n`n"
            "Use the ? button on the Missions tab for a color legend."
        ))
        topics.Push(Map(
            "title", "Landsraad & goals",
            "body",
            "Open the Landsraad tab and press Scan grid while the Landsraad house grid is visible in game. The app reads house names and your personal contribution per cell.`n`n"
            "Click any house row to set a weekly contribution goal or mark that you already own its swatch. Tracked houses show green progress; blue means the goal is met for the week.`n`n"
            "When you claim a completed mission, Donsraad OCRs Landsraad contribution from the reward panel and adds it to the matching house. You get a notification with missions remaining to goal when a house is tracked.`n`n"
            "Reset board clears this week's scan data, contributions, and goals for the active profile so you can scan again.`n`n"
            "Use the ? button on the Landsraad tab for row colors and badges."
        ))
        topics.Push(Map(
            "title", "Rewards tab",
            "body",
            "House rewards earn per Landsraad week at 700, 3,500, 7,000, 10,500, and 14,000 contribution. Tier 5 is the house swatch — it is skipped if you already own that swatch on the character.`n`n"
            "The Rewards tab lists one row per house for the current week. Older unclaimed weeks merge into the tier display until you claim.`n`n"
            "Press Claim after collecting rewards in game. That marks the current week claimed and removes prior-week entries from tracking. A gray Claimed button means you already marked this week.`n`n"
            "If you earn a new tier after claiming, the row reopens until you claim again. Reset rewards clears all reward tracking for the profile."
        ))
        topics.Push(Map(
            "title", "Overlay & hotkeys",
            "body",
            "The overlay pins to the game client and hides when you alt-tab away. During picker loops, scans, and claims it moves to the bottom left so Landsraad UI stays clear.`n`n"
            "Default hotkeys: Start Home, Stop End, Toggle AutoRun Delete, Reload PgDn. Rebind them in Settings → Keybinds.`n`n"
            "SESSION on the overlay counts mission completes this app run. Optional notifications include ready-to-run, new best times, goal reached, and missions-left estimates.`n`n"
            "Sound effects for run start and goal reached can be toggled in Settings."
        ))
        topics.Push(Map(
            "title", "Stats & tips",
            "body",
            "Stats shows per-mission completes, best times, and availability. Availability is tracked only when you target exactly one mission from a specialization (two or more targets in the same spec are ignored).`n`n"
            "Mnemonic devices: Start reads remaining tokens from the active-missions HUD on first run. The overlay can show the count; each completed claim subtracts one.`n`n"
            "Profiles keep separate missions, Landsraad data, settings, and reward tracking. Switch profiles in Settings.`n`n"
            "Partial claims are blocked when all your targets are active but not all are complete — finish every targeted mission before the app claims rewards."
        ))
        return topics
    }
}
