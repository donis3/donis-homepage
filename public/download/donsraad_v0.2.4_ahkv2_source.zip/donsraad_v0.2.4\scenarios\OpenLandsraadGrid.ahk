#Requires AutoHotkey v2.0+

/**
 * Opens the Landsraad house grid UI.
 * 1. Ensure the Landsraad tab is visible (press L if needed).
 * 2. Click LandsraadSubGridTabButton to switch to the house grid.
 *
 * Callable via openLandsraadGridScenarioInst.Execute().
 */
class OpenLandsraadGridScenario {
    logger := ""
    anchorMatcher := ""
    imageVariation := 30

    __New(loggerInst := "", anchorMatcherInst := "") {
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
    }

    Execute() {
        StatusBar.PinBottomLeft()
        try {
            this.Debug("[OpenLandsraadGrid] Starting...")
            GameWindow.Activate()

            global GameConstants
            if !IsObject(GameConstants) || !GameConstants.Has("GameUI") {
                this.Log("[OpenLandsraadGrid] Error: GameConstants GameUI is missing.")
                return false
            }

            uiConfig := GameConstants["GameUI"]
            if !this.EnsureLandsraadTab(uiConfig)
                return false
            if !this.ClickUiPoint(uiConfig, "LandsraadSubGridTabButton", "Landsraad grid sub-tab")
                return false

            this.Debug("[OpenLandsraadGrid] House grid is open.")
            return true
        } finally {
            StatusBar.ClearBottomLeftPin()
        }
    }

    EnsureLandsraadTab(uiConfig) {
        if this.IsUiImageVisible(uiConfig, "LandsraadTabButton", "landsraad_button.png") {
            this.Debug("[OpenLandsraadGrid] Landsraad tab already visible.")
            return true
        }

        loop 3 {
            this.Debug("[OpenLandsraadGrid] Opening Landsraad tab (L), attempt " A_Index "...")
            InputHelper.SendGameKey("l")
            if this.WaitForUiImage(uiConfig, "LandsraadTabButton", "landsraad_button.png", 1500)
                return true
        }

        this.Log("[OpenLandsraadGrid] Error: Landsraad tab did not open. Stopping.")
        return false
    }

    ClickUiPoint(uiConfig, keyName, label) {
        if !uiConfig.Has(keyName) {
            this.Log("[OpenLandsraadGrid] Error: " keyName " missing in GameConstants.")
            return false
        }
        cfg := uiConfig[keyName]
        pos := ResolutionManager().coords(cfg.x, cfg.y)
        this.Debug("[OpenLandsraadGrid] Clicking " label " at (" pos.x ", " pos.y ")...")
        InputHelper.FastClick(pos.x, pos.y)
        return true
    }

    IsUiImageVisible(uiConfig, regionKey, imageName) {
        foundX := 0, foundY := 0
        return this.FindUiImage(uiConfig, regionKey, imageName, &foundX, &foundY)
    }

    WaitForUiImage(uiConfig, regionKey, imageName, timeoutMs := 5000) {
        searchArea := this.GetUiSearchArea(uiConfig, regionKey)
        if !IsObject(searchArea)
            return false

        InputHelper.MoveCursorClearOfSearch(searchArea)

        foundX := 0, foundY := 0
        this.Debug("[OpenLandsraadGrid] Waiting up to " timeoutMs "ms for " imageName
            " in [" searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        startTime := A_TickCount
        pollMs := 40
        loop {
            if this.IsCancelled()
                return false
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation) {
                this.Debug("[OpenLandsraadGrid] " imageName " found at (" foundX ", " foundY ").")
                return true
            }
            if (A_TickCount - startTime >= timeoutMs)
                return false
            Sleep(pollMs)
        }
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    FindUiImage(uiConfig, regionKey, imageName, &foundX, &foundY) {
        searchArea := this.GetUiSearchArea(uiConfig, regionKey)
        if !IsObject(searchArea)
            return false
        InputHelper.MoveCursorClearOfSearch(searchArea)
        return this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation)
    }

    GetUiSearchArea(uiConfig, regionKey) {
        if !uiConfig.Has(regionKey) {
            this.Log("[OpenLandsraadGrid] Error: " regionKey " missing in GameConstants.")
            return ""
        }
        btn := uiConfig[regionKey]
        return ResolutionManager().searchFromConfig(btn, 20)
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
