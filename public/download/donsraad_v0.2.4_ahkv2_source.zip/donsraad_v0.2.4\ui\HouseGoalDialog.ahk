#Requires AutoHotkey v2.0+

/**
 * Modal to set weekly Landsraad contribution tracking goal for a house.
 */
class HouseGoalDialog {
    static dlg := ""
    static profileManager := ""
    static houseName := ""
    static onSaved := ""
    static tiers := [700, 3500, 7000, 10500, 14000]
    static contentW := 320
    static pad := 16
    static btnH := 32
    static btnGap := 6
    static bgColor := "0F0F12"
    static panelBg := "18181B"
    static btnBg := "27272F"
    static btnActiveBg := "EAB308"
    static btnText := "E4E4E7"
    static btnActiveText := "18181B"
    static titleText := "E4E4E7"
    static mutedText := "A1A1AA"
    static sectionTitle := "EAB308"
    static tierAmountText := "EAB308"
    static swatchOwnedBg := "14532D"
    static swatchOwnedAccent := "4ADE80"
    static swatchOwnedText := "ECFDF5"
    static swatchUnownedBg := "18181B"
    static stopTrackBg := "3F1721"
    static stopTrackText := "F87171"

    static Show(ownerGui, houseName, profileManagerInst, onSaved := "") {
        if (Trim(houseName) == "" || !IsObject(profileManagerInst))
            return

        this.Close()
        this.profileManager := profileManagerInst
        this.houseName := houseName
        this.onSaved := onSaved

        currentGoal := profileManagerInst.GetHouseGoal(houseName)
        swatchOwned := profileManagerInst.IsHouseSwatchOwned(houseName)
        isTracking := currentGoal > 0

        pad := this.pad
        w := this.contentW
        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "Contribution goal")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := this.bgColor

        y := pad

        dlg.SetFont("s12 bold c" this.titleText, "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" w " h24 BackgroundTrans", houseName)
        y += 28

        dlg.SetFont("s9 c" this.mutedText, "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" w " h34 +0x200 BackgroundTrans Wrap",
            "Pick a contribution tier to track this week. Goals reset when the Landsraad week rolls.")
        y += 38

        swatchH := 30
        dlg.Add("Text",
            "x" pad " y" y " w" w " h" swatchH " Background"
            (swatchOwned ? this.swatchOwnedBg : this.swatchUnownedBg))
        if swatchOwned {
            dlg.Add("Text", "x" pad " y" y " w4 h" swatchH " Background" this.swatchOwnedAccent)
            dlg.SetFont("s9 bold c" this.swatchOwnedText, "Segoe UI")
            dlg.Add("Text",
                "x" (pad + 14) " y" y " w" (w - 28) " h" swatchH " +0x200 BackgroundTrans",
                "✓  House swatch owned")
        } else {
            dlg.SetFont("s9 c" this.mutedText, "Segoe UI")
            dlg.Add("Text",
                "x" (pad + 14) " y" y " w" (w - 28) " h" swatchH " +0x200 BackgroundTrans",
                "House swatch not yet owned")
        }
        y += swatchH + 14

        dlg.SetFont("s9 bold c" this.sectionTitle, "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" w " h18 BackgroundTrans", "Contribution tiers")
        y += 22

        dlg.SetFont("s9 bold c" this.btnText, "Segoe UI")
        loop this.tiers.Length {
            tier := A_Index
            amount := this.tiers[tier]
            label := "Tier " tier "  ·  " this.FormatAmount(amount)
            btn := dlg.Add("Text",
                "x" pad " y" y " w" w " h" this.btnH " Center +0x200 Background" this.btnBg, label)
            btn.OnEvent("Click", this.MakePickHandler(amount))
            this.StyleGoalButton(btn, currentGoal == amount)
            y += this.btnH + this.btnGap
        }

        if isTracking {
            y += 6
            dlg.SetFont("s9 bold c" this.stopTrackText, "Segoe UI")
            stopBtn := dlg.Add("Text",
                "x" pad " y" y " w" w " h" this.btnH " Center +0x200 Background" this.stopTrackBg,
                "Stop tracking")
            stopBtn.OnEvent("Click", (*) => this.OnPick(0))
            y += this.btnH
        }

        y += pad
        dlg.Show("w" (pad * 2 + w) " h" y " Center")
        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
    }

    static StyleGoalButton(btn, selected) {
        if !IsObject(btn)
            return
        if selected {
            btn.Opt("Background" this.btnActiveBg)
            btn.SetFont("s9 bold c" this.btnActiveText, "Segoe UI")
        } else {
            btn.Opt("Background" this.btnBg)
            btn.SetFont("s9 bold c" this.btnText, "Segoe UI")
        }
        btn.Redraw()
    }

    static MakePickHandler(amount) {
        return (*) => this.OnPick(amount)
    }

    static OnPick(goal) {
        if IsObject(this.profileManager) && Trim(this.houseName) != ""
            this.profileManager.SetHouseGoal(this.houseName, goal)
        if IsObject(this.onSaved)
            try this.onSaved.Call()
        this.Close()
    }

    static FormatAmount(value) {
        try {
            return Format("{:L}", Integer(value))
        } catch {
            return String(value)
        }
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.profileManager := ""
        this.houseName := ""
        this.onSaved := ""
    }
}
