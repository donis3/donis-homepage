#Requires AutoHotkey v2.0+

class AboutTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 7)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        pad := 20
        innerW := cardW - pad * 2
        contentBottom := this.winH - 36 - 8
        btnH := 28
        guideW := 120

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(7, g.Add("Text", "x" m " y" y " w240 h24 BackgroundTrans", "About"))
        this.AddTextButton(7, m + cardW - guideW, y, guideW, btnH, "How to use",
            (*) => UserGuideDialog.Show(this.guiObj), true)
        y += 36

        heroH := 122
        this.PageAdd(7, g.Add("Text", "x" m " y" y " w" cardW " h" heroH " Background" this.surfaceColor))
        this.PageAdd(7, g.Add("Text", "x" m " y" y " w4 h" heroH " BackgroundEAB308"))
        g.SetFont("s20 bold cEAB308", "Segoe UI")
        this.PageAdd(7, g.Add("Text", "x" (m + pad) " y" (y + 14) " w" innerW " h36 BackgroundTrans",
            "DONSRAAD"))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(7, g.Add("Text", "x" (m + pad) " y" (y + 52) " w" innerW " h20 BackgroundTrans",
            "Easy Mission Picker for Dune: Awakening"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(7, g.Add("Text", "x" (m + pad) " y" (y + 74) " w" innerW " h18 BackgroundTrans",
            "Version " this.GetAppVersion() "  ·  Landsraad mission companion"))
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        projectLink := this.PageAdd(7, g.Add("Text",
            "x" (m + pad) " y" (y + 96) " w" innerW " h18 BackgroundTrans",
            "donis.dev/projects/donsraad"))
        projectLink.OnEvent("Click", (*) => this.OpenProjectSite())
        y += heroH + 12

        colGap := 12
        colW := (cardW - colGap) // 2
        col1 := m
        col2 := m + colW + colGap
        midH := 304

        this.BuildInfoCard(g, col1, y, colW, midH, pad)

        this.BuildLinksCard(g, col2, y, colW, midH, pad)
        y += midH + 12

        devH := contentBottom - y
        if (devH < 176)
            devH := 176
        this.BuildDeveloperCard(g, m, y, cardW, devH, pad, innerW)
    }

    AddWrappedLabel(page, x, yPos, w, h, text, fontSize := 8, color := "A1A1AA", bold := false) {
        g := this.guiObj
        weight := bold ? "bold " : ""
        g.SetFont("s" fontSize " " weight "c" color, "Segoe UI")
        return this.PageAdd(page, g.Add("Text",
            "x" x " y" yPos " w" w " h" h " Wrap BackgroundTrans", text))
    }

    BuildInfoCard(g, x, y, w, h, pad) {
        innerW := w - pad * 2
        textX := x + pad
        this.PageAdd(7, g.Add("Text", "x" x " y" y " w" w " h" h " Background" this.surfaceColor))
        this.AddWrappedLabel(7, textX, y + 12, innerW, 20, "What it does", 10, "EAB308", true)

        lineY := y + 36
        lineY += this.AddIntroLine(textX, lineY, innerW,
            "Random Landsraad missions scatter you across the map.")
        lineY += this.AddIntroLine(textX, lineY, innerW,
            "Donsraad keeps your picks in one area so you travel less.")

        bullets := [
            "Scan the Landsraad grid and track weekly contribution goals",
            "Pick up to three missions and refresh the board until they appear",
            "Claim completed actives and read Landsraad contribution from claims",
            "Track house reward tiers and run stats per profile"
        ]
        lineY += 6
        g.SetFont("s8 cE4E4E7", "Segoe UI")
        for _, line in bullets {
            this.AddWrappedLabel(7, textX, lineY, innerW, 40, "·  " line, 8, "E4E4E7")
            lineY += 42
        }
    }

    AddIntroLine(x, yPos, w, text) {
        this.AddWrappedLabel(7, x, yPos, w, 30, text, 8, "A1A1AA")
        return 32
    }

    BuildLinksCard(g, x, y, w, h, pad) {
        innerW := w - pad * 2
        textX := x + pad
        this.PageAdd(7, g.Add("Text", "x" x " y" y " w" w " h" h " Background" this.surfaceColor))
        this.AddWrappedLabel(7, textX, y + 12, innerW, 20, "Learn more", 10, "EAB308", true)

        lineY := y + 36
        lineY += this.AddIntroLine(textX, lineY, innerW,
            "Open the guide for walkthroughs, hotkeys, and tab notes.")
        lineY += this.AddIntroLine(textX, lineY, innerW,
            "Color legends are on the Missions and Landsraad tabs.")

        btnW := innerW
        btnX := textX
        btnY := y + 104
        btnH := 28
        gap := 8
        this.AddTextButton(7, btnX, btnY, btnW, btnH, "Open how-to guide",
            (*) => UserGuideDialog.Show(this.guiObj), true)
        btnY += btnH + gap
        this.AddTextButton(7, btnX, btnY, btnW, btnH, "Missions tab legend",
            (*) => TabHelpDialog.Show(this.guiObj, "missions"))
        btnY += btnH + gap
        this.AddTextButton(7, btnX, btnY, btnW, btnH, "Landsraad tab legend",
            (*) => TabHelpDialog.Show(this.guiObj, "landsraad"))
        btnY += btnH + gap
        this.AddTextButton(7, btnX, btnY, btnW, btnH, "Disclaimer & terms",
            (*) => LegalDialog.Show(this.guiObj))
    }

    BuildDeveloperCard(g, x, y, w, h, pad, innerW) {
        this.PageAdd(7, g.Add("Text", "x" x " y" y " w" w " h" h " Background" this.surfaceColor))
        this.PageAdd(7, g.Add("Text", "x" x " y" y " w4 h" h " BackgroundEAB308"))
        this.AddWrappedLabel(7, x + pad, y + 14, innerW, 20, "Developer", 10, "EAB308", true)

        picSize := 72
        picX := x + pad
        picY := y + 42
        photoPath := A_ScriptDir "\ui\donis.png"
        textX := picX
        nameW := innerW
        if FileExist(photoPath) {
            this.PageAdd(7, g.Add("Text",
                "x" (picX - 2) " y" (picY - 2) " w" (picSize + 4) " h" (picSize + 4) " BackgroundEAB308"))
            this.PageAdd(7, g.Add("Picture", "x" picX " y" picY " w" picSize " h" picSize, photoPath))
            textX := picX + picSize + 16
            nameW := innerW - picSize - 16
        }

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(7, g.Add("Text", "x" textX " y" (y + 44) " w" nameW " h24 BackgroundTrans", "Deniz Özkan"))

        noteY := y + 72
        this.AddWrappedLabel(7, textX, noteY, nameW, 28,
            "Personal learning project. Unofficial — not affiliated with Funcom.", 9, "A1A1AA")
        noteY += 32
        this.AddWrappedLabel(7, textX, noteY, nameW, 44,
            "Do not rely on this for live play. Using macros or bots in Dune: Awakening may violate the Terms of Service. You assume all risk.",
            9, "F87171", true)
        noteY += 48

        g.SetFont("s9 bold cEAB308", "Segoe UI")
        siteLink := this.PageAdd(7, g.Add("Text", "x" textX " y" noteY " w" nameW " h18 BackgroundTrans", "donis.dev"))
        siteLink.OnEvent("Click", (*) => this.OpenDeveloperSite())

        g.SetFont("s8 c52525B", "Segoe UI")
        this.PageAdd(7, g.Add("Text",
            "x" (x + pad) " y" (y + h - 24) " w" innerW " h16 BackgroundTrans",
            "© 2026 Deniz Özkan. All rights reserved.  ·  v" this.GetAppVersion()))
    }
}
