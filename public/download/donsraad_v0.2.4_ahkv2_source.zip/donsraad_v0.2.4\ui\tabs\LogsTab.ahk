#Requires AutoHotkey v2.0+

class LogsTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 6)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(6, g.Add("Text", "x" m " y" y " w" (this.contentW - 290) " h28 +0x200 BackgroundTrans", "Logs"))

        this.AddTextButton(6, m + this.contentW - 262, y, 136, 28, "Open log file", (*) => this.OpenLogFile())
        this.AddTextButton(6, m + this.contentW - 120, y, 120, 28, "Clear", (*) => this.ClearLogs())

        g.SetFont("s8 c71717A", "Segoe UI")
        logPath := IsObject(this.logger) ? this.logger.GetLogFilePath() : ""
        logHint := (logPath != "") ? "Full log: " logPath : "Scenario and OCR output while the app is running."
        this.PageAdd(6, g.Add("Text", "x" m " y" (y + 28) " w" this.contentW " h16 BackgroundTrans", logHint))

        logBox := this.PageAdd(6, this.StyleEdit(g.Add("Edit",
            "x" m " y" (y + 50) " w" this.contentW " h" (this.winH - y - 50 - 52)
            " +ReadOnly +HScroll -Wrap -Theme Background" this.inputBgColor, ""),
            "Consolas", 9))
        logBox.Opt("-Tabstop")
        if (IsObject(this.logger))
            this.logger.BindGui(this.guiObj, logBox)
    }
}
