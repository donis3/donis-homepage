#Requires AutoHotkey v2.0+

/**
 * Global status-bar API. Call from anywhere after the overlay is created:
 *   StatusBar.SetStatus("Ready")
 *   StatusBar.SetStatus("Initialize", "working")
 *   StatusBar.Refresh()
 *   StatusBar.RestoreIdle()
 */
class StatusBar {
    static overlay := ""

    static Attach(overlayInst) {
        StatusBar.overlay := overlayInst
    }

    static SetStatus(text, kind := "") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.SetStatus(text, kind)
    }

    static SetHotkeyHint(text := "") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.SetHotkeyHint(text)
    }

    static ShowCancelHint() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.ShowCancelHint()
    }

    static SetCount(current := "", total := "") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.SetCount(current, total)
    }

    static SetProfile(name := "") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.SetProfile(name)
    }

    static Refresh() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.Refresh()
    }

    static RestoreIdle() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.RestoreSessionState()
    }

    static ApplyVisibility(show) {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.ApplyVisibility(show)
    }

    static Toggle() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.Toggle()
    }

    static Notify(message, kind := "info") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.Notify(message, kind)
    }

    static NotifyGoalReached(houseName, iconPath := "") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.NotifyGoalReached(houseName, iconPath)
    }

    static NotifyGoalProgress(houseName, missionsLeft, currentCont := 0, goal := 0, iconPath := "") {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.NotifyGoalProgress(houseName, missionsLeft, currentCont, goal, iconPath)
    }

    static PinBottomLeft() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.PinBottomLeft()
    }

    static ClearBottomLeftPin() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.ClearBottomLeftPin()
    }

    static PinForPickerLoop() {
        StatusBar.PinBottomLeft()
    }

    static ClearPickerPin() {
        StatusBar.ClearBottomLeftPin()
    }

    static RebuildLayout() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.RebuildLayout()
    }

    static Close() {
        overlay := StatusBar.overlay
        if IsObject(overlay)
            overlay.Close()
        StatusBar.overlay := ""
    }
}

/**
 * Always-on-top HUD pinned to the Dune game client.
 * Hides when the game is unfocused. Click-through so it does not steal input.
 */
class StatusOverlay {
    guiObj := ""
    statusCaption := ""
    statusValue := ""
    hotkeyCaption := ""
    hotkeyValue := ""
    progressCaption := ""
    progressValue := ""
    sessionCaption := ""
    sessionValue := ""
    profileCaption := ""
    profileValue := ""
    currentRunCaption := ""
    currentRunValue := ""
    lastRunCaption := ""
    lastRunValue := ""
    mnemonicCaption := ""
    mnemonicValue := ""
    autoRunCaption := ""
    autoRunValue := ""
    boundTick := ""
    splashGui := ""
    splashText := ""
    splashTitle := ""
    splashSubtext := ""
    splashHousePic := ""
    splashAccent := ""
    splashMode := "simple"
    splashAlpha := 0
    splashPhase := "hidden"
    splashHoldUntil := 0
    boundSplashTick := ""
    progressToastMax := 4
    progressToastW := 420
    progressToastH := 64
    progressToastGap := 6
    progressToastHoldMs := 6500
    progressToasts := []
    boundProgressToastTick := ""

    forcePosition := ""
    bottomLeftPinCount := 0
    lastClientSig := ""
    edgePad := 4

    stateManager := ""
    userState := ""
    profileManager := ""
    settingsManager := ""

    statusText := "Ready"
    statusKind := "idle"
    hotkeyHint := ""
    profileOverride := ""

    visible := false
    overlayW := 900
    overlayH := 42
    progressCompleteColor := "4ADE80"
    progressDefaultColor := "EAB308"
    readyColor := "4ADE80"
    idleColor := "EAB308"
    workingColor := "E4E4E7"
    errorColor := "F87171"

    __New(stateManagerInst := "", userStateInst := "", profileManagerInst := "", settingsManagerInst := "") {
        this.stateManager := stateManagerInst
        this.userState := userStateInst
        this.profileManager := profileManagerInst
        this.settingsManager := settingsManagerInst
        this.statusText := this.GetIdleStatusText()
        this.statusKind := "ready"

        this.guiObj := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        this.guiObj.BackColor := "0F0F12"
        this.guiObj.MarginX := 0
        this.guiObj.MarginY := 0
        this.BuildSections()
        this.EnsureSplashGui()
        StatusBar.Attach(this)
        this.StartRunTimer()
        this.Show()
    }

    BuildSections() {
        g := this.guiObj
        h := this.overlayH
        divW := 1
        padX := 12
        capY := 4
        valY := 18
        capH := 12
        valH := 18

        this.statusCaption := ""
        this.statusValue := ""
        this.hotkeyCaption := ""
        this.hotkeyValue := ""
        this.progressCaption := ""
        this.progressValue := ""
        this.sessionCaption := ""
        this.sessionValue := ""
        this.profileCaption := ""
        this.profileValue := ""
        this.currentRunCaption := ""
        this.currentRunValue := ""
        this.lastRunCaption := ""
        this.lastRunValue := ""
        this.mnemonicCaption := ""
        this.mnemonicValue := ""
        this.autoRunCaption := ""
        this.autoRunValue := ""

        sections := this.GetVisibleSections()
        totalW := 0
        for idx, sec in sections {
            if (idx > 1)
                totalW += divW
            totalW += sec.w
        }
        if (totalW < 200)
            totalW := 200
        this.overlayW := totalW

        if this.IsBottomPosition()
            g.Add("Text", "x0 y" (h - 2) " w" totalW " h2 BackgroundEAB308")
        else
            g.Add("Text", "x0 y0 w" totalW " h2 BackgroundEAB308")

        x := 0
        for idx, sec in sections {
            if (idx > 1) {
                g.Add("Text", "x" x " y6 w" divW " h" (h - 10) " Background3F3F46")
                x += divW
            }
            this.AddSectionBackground(g, x, sec.w, h)
            if (sec.kind == "autorun") {
                g.SetFont("s7 c52525B", "Segoe UI")
                caption := g.Add("Text",
                    "x" x " y" capY " w" sec.w " h" capH " Center BackgroundTrans",
                    sec.caption)
                g.SetFont("s11 bold c52525B", "Segoe UI")
                value := g.Add("Text",
                    "x" x " y14 w" sec.w " h24 Center +0x200 BackgroundTrans",
                    "")
            } else {
                center := (sec.kind == "targets" || sec.kind == "session" || sec.kind == "current"
                    || sec.kind == "last" || sec.kind == "mnemonic")
                capOpt := center ? " Center" : ""
                innerPad := center ? 8 : padX
                g.SetFont("s7 c52525B", "Segoe UI")
                caption := g.Add("Text",
                    "x" (x + innerPad) " y" capY " w" (sec.w - innerPad * 2) " h" capH capOpt " BackgroundTrans",
                    sec.caption)
                g.SetFont("s9 bold cEAB308", "Segoe UI")
                value := g.Add("Text",
                    "x" (x + innerPad) " y" valY " w" (sec.w - innerPad * 2) " h" valH capOpt " BackgroundTrans",
                    "")
            }
            this.AssignSectionControls(sec.kind, caption, value)
            x += sec.w
        }
    }

    GetVisibleSections() {
        defs := []
        defs.Push({ kind: "autorun", setting: "", caption: "AUTO", w: 52 })
        defs.Push({ kind: "status", setting: "overlayShowStatus", caption: "STATUS", w: 228 })
        defs.Push({ kind: "run", setting: "overlayShowRun", caption: "RUN", w: 268 })
        defs.Push({ kind: "current", setting: "overlayShowCurrentRun", caption: "CURRENT", w: 88 })
        defs.Push({ kind: "last", setting: "overlayShowLastRun", caption: "LAST", w: 88 })
        defs.Push({ kind: "targets", setting: "overlayShowTargets", caption: "TARGETS", w: 88 })
        defs.Push({ kind: "session", setting: "overlayShowSession", caption: "SESSION", w: 88 })
        defs.Push({ kind: "mnemonic", setting: "overlayShowMnemonic", caption: "MNEMONIC DEVICE", w: 148 })
        defs.Push({ kind: "profile", setting: "overlayShowProfile", caption: "PROFILE", w: 128 })
        visible := []
        for _, def in defs {
            if (def.setting == "" || this.IsSectionEnabled(def.setting))
                visible.Push(def)
        }
        return visible
    }

    IsSectionEnabled(settingKey) {
        if !IsObject(this.settingsManager)
            return true
        return this.settingsManager.GetBool(settingKey, true)
    }

    AssignSectionControls(kind, caption, value) {
        if (kind == "status") {
            this.statusCaption := caption
            this.statusValue := value
        } else if (kind == "run") {
            this.hotkeyCaption := caption
            this.hotkeyValue := value
        } else if (kind == "current") {
            this.currentRunCaption := caption
            this.currentRunValue := value
        } else if (kind == "last") {
            this.lastRunCaption := caption
            this.lastRunValue := value
        } else if (kind == "targets") {
            this.progressCaption := caption
            this.progressValue := value
        } else if (kind == "session") {
            this.sessionCaption := caption
            this.sessionValue := value
        } else if (kind == "profile") {
            this.profileCaption := caption
            this.profileValue := value
        } else if (kind == "mnemonic") {
            this.mnemonicCaption := caption
            this.mnemonicValue := value
        } else if (kind == "autorun") {
            this.autoRunCaption := caption
            this.autoRunValue := value
        }
    }

    AddSectionBackground(g, x, w, h) {
        if this.IsBottomPosition()
            g.Add("Text", "x" x " y0 w" w " h" (h - 2) " Background18181F")
        else
            g.Add("Text", "x" x " y2 w" w " h" (h - 2) " Background18181F")
    }

    GetPositionKey() {
        if (this.forcePosition != "")
            return this.forcePosition
        key := "topLeft"
        if IsObject(this.settingsManager)
            key := this.settingsManager.Get("overlayPosition", "topLeft")
        if (key != "topLeft" && key != "topMiddle" && key != "bottomLeft"
            && key != "topRight" && key != "bottomRight")
            return "topLeft"
        return key
    }

    IsBottomPosition(key := "") {
        if (key == "")
            key := this.GetPositionKey()
        return (key == "bottomLeft" || key == "bottomRight")
    }

    IsMiddlePosition(key := "") {
        if (key == "")
            key := this.GetPositionKey()
        return (key == "topMiddle")
    }

    GetAnchorArea() {
        client := GameWindow.GetClient()
        if IsObject(client)
            return {
                left: client.x,
                top: client.y,
                right: client.x + client.w,
                bottom: client.y + client.h,
                fromGame: true
            }
        left := 0
        top := 0
        right := A_ScreenWidth
        bottom := A_ScreenHeight
        try MonitorGetWorkArea(, &left, &top, &right, &bottom)
        return { left: left, top: top, right: right, bottom: bottom, fromGame: false }
    }

    GetOverlayRect() {
        w := this.overlayW
        h := this.overlayH
        area := this.GetAnchorArea()
        pos := this.GetPositionKey()
        pad := this.edgePad
        x := area.left + pad
        y := area.top + pad
        if this.IsMiddlePosition(pos)
            x := area.left + ((area.right - area.left - w) // 2)
        else if (pos == "topRight" || pos == "bottomRight")
            x := area.right - w - pad
        if this.IsBottomPosition(pos)
            y := area.bottom - h - pad
        return { x: x, y: y, w: w, h: h }
    }

    PinBottomLeft() {
        this.bottomLeftPinCount++
        if (this.bottomLeftPinCount == 1)
            this.DebugOverlay("Pinned overlay to bottom left.")
        this.forcePosition := "bottomLeft"
        this.RepositionToGame()
    }

    ClearBottomLeftPin() {
        if (this.bottomLeftPinCount > 0)
            this.bottomLeftPinCount--
        if (this.bottomLeftPinCount == 0) {
            this.forcePosition := ""
            this.DebugOverlay("Restored overlay to Settings position.")
        }
        this.RepositionToGame()
    }

    PinForPickerLoop() {
        this.PinBottomLeft()
    }

    ClearPickerPin() {
        this.ClearBottomLeftPin()
    }

    WantsOverlayVisible() {
        if !IsObject(this.settingsManager)
            return true
        return this.settingsManager.GetBool("showOverlay", true)
    }

    RepositionToGame() {
        if !IsObject(this.guiObj)
            return
        rect := this.GetOverlayRect()
        try this.guiObj.Move(rect.x, rect.y, rect.w, rect.h)
        this.lastClientSig := this.GetClientSignature()
        this.PositionSplash()
        this.PositionGoalProgressToasts()
    }

    GetClientSignature() {
        client := GameWindow.GetClient()
        if !IsObject(client)
            return ""
        return client.x "|" client.y "|" client.w "|" client.h
    }

    SyncGameFocus() {
        if !this.WantsOverlayVisible() {
            if this.visible
                this.Hide()
            return
        }

        if !GameWindow.IsActive() {
            if this.visible
                this.Hide()
            return
        }

        sig := this.GetClientSignature()
        if !this.visible {
            this.Show()
            return
        }
        if (sig != "" && sig != this.lastClientSig)
            this.RepositionToGame()
    }

    DebugOverlay(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[StatusOverlay] " message)
    }

    ApplyVisibility(show) {
        if (show)
            this.Show()
        else {
            this.HideSplash()
            this.Hide()
        }
    }

    SetStatus(text, kind := "") {
        this.statusText := (text != "") ? text : this.GetIdleStatusText()
        this.statusKind := (kind != "") ? kind : this.InferKind(this.statusText)
        this.PaintStatus()
    }

    SetState(stateLabel) {
        this.SetStatus(stateLabel)
    }

    SetHotkeyHint(text := "") {
        this.hotkeyHint := text
        this.PaintHotkey()
    }

    ShowCancelHint() {
        this.SetHotkeyHint(this.GetStopHotkeyName() " to stop")
    }

    SetCount(current := "", total := "") {
        if (current != "" && IsObject(this.userState))
            this.userState.SetAvailableTargetedCount(current)
        this.PaintProgress()
    }

    SetAvailableCount(availableCount) {
        this.SetCount(availableCount)
    }

    SetProfile(name := "") {
        this.profileOverride := name
        this.PaintProfile()
    }

    RestoreSessionState() {
        this.statusText := this.GetIdleStatusText()
        this.statusKind := "ready"
        this.Refresh()
    }

    RebuildLayout() {
        wasVisible := this.visible
        this.StopRunTimer()
        this.DestroyGoalProgressToasts()
        if IsObject(this.guiObj) {
            try this.guiObj.Destroy()
        }
        this.guiObj := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        this.guiObj.BackColor := "0F0F12"
        this.guiObj.MarginX := 0
        this.guiObj.MarginY := 0
        this.BuildSections()
        this.EnsureSplashGui()
        StatusBar.Attach(this)
        this.StartRunTimer()
        showOverlay := !IsObject(this.settingsManager) || this.settingsManager.GetBool("showOverlay", true)
        if (wasVisible && showOverlay)
            this.Show()
        else if showOverlay
            this.Show()
        else {
            this.HideSplash()
            this.Hide()
        }
    }

    Toggle() {
        if !IsObject(this.settingsManager)
            return
        show := !this.settingsManager.GetBool("showOverlay", true)
        this.settingsManager.Set("showOverlay", show)
        this.ApplyVisibility(show)
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SyncOverlayEnabledCheckbox"))
            mainGuiInst.SyncOverlayEnabledCheckbox()
    }

    Refresh() {
        this.PaintStatus()
        this.PaintHotkey()
        this.PaintProgress()
        this.PaintSession()
        this.PaintMnemonic()
        this.PaintProfile()
        this.PaintAutoRun()
        this.PaintRunTimes()
    }

    PaintStatus() {
        if !IsObject(this.statusValue)
            return
        this.statusValue.Text := this.StatusIcon() "  " this.statusText
        this.statusValue.SetFont("s9 bold c" this.StatusColor(), "Segoe UI")
    }

    PaintHotkey() {
        if !IsObject(this.hotkeyValue)
            return
        this.hotkeyValue.Text := Chr(0x25B6) "  " this.GetHotkeyHintText()
        this.hotkeyValue.SetFont("s9 bold cA1A1AA", "Segoe UI")
    }

    PaintProgress() {
        if !IsObject(this.progressValue)
            return
        this.progressValue.Text := this.GetProgressText()
        color := this.IsProgressComplete() ? this.progressCompleteColor : this.progressDefaultColor
        this.progressValue.SetFont("s9 bold c" color, "Segoe UI")
    }

    PaintSession() {
        if !IsObject(this.sessionValue)
            return
        this.sessionValue.Text := this.GetSessionCompletedText()
        this.sessionValue.SetFont("s9 bold cE4E4E7", "Segoe UI")
    }

    PaintMnemonic() {
        if !IsObject(this.mnemonicValue)
            return
        this.mnemonicValue.Text := this.GetMnemonicDeviceText()
        color := this.IsMnemonicDepleted() ? this.progressDefaultColor : this.progressCompleteColor
        if this.IsMnemonicUnknown()
            color := "A1A1AA"
        this.mnemonicValue.SetFont("s9 bold c" color, "Segoe UI")
    }

    PaintAutoRun() {
        if !IsObject(this.autoRunValue)
            return
        this.autoRunValue.Text := Chr(0x21BB)
        color := this.IsAutoRunSettingOn() ? this.progressCompleteColor : "52525B"
        this.autoRunValue.SetFont("s11 bold c" color, "Segoe UI")
    }

    IsAutoRunSettingOn() {
        if TravelAutoRun.IsSuppressed()
            return false
        if !IsObject(this.settingsManager)
            return false
        return this.settingsManager.GetBool("autoRunOnTravelConfirmation", false)
    }

    PaintProfile() {
        if !IsObject(this.profileValue)
            return
        name := this.GetProfileText()
        this.profileValue.Text := Chr(0x25C6) "  " ((name != "") ? name : "—")
        this.profileValue.SetFont("s9 bold cE4E4E7", "Segoe UI")
    }

    PaintRunTimes() {
        if IsObject(this.currentRunValue) {
            this.currentRunValue.Text := this.FormatRunClock(this.GetCurrentRunSeconds())
            this.currentRunValue.SetFont("s9 bold cE4E4E7", "Segoe UI")
        }
        if IsObject(this.lastRunValue) {
            this.lastRunValue.Text := this.FormatLastRunClock(this.GetLastRunSeconds())
            this.lastRunValue.SetFont("s9 bold cA1A1AA", "Segoe UI")
        }
    }

    FormatLastRunClock(totalSeconds) {
        if (totalSeconds == "" || totalSeconds == 0)
            return "--:--"
        return this.FormatRunClock(totalSeconds)
    }

    FormatRunClock(totalSeconds) {
        sec := Integer(totalSeconds)
        if (sec < 0)
            sec := 0
        minutes := sec // 60
        seconds := Mod(sec, 60)
        return this.Pad2(minutes) ":" this.Pad2(seconds)
    }

    Pad2(n) {
        n := Integer(n)
        return (n < 10) ? "0" n : n
    }

    GetCurrentRunSeconds() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetCurrentRunElapsed")
            return this.stateManager.GetCurrentRunElapsed()
        return 0
    }

    GetLastRunSeconds() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetLastRunDuration")
            return this.stateManager.GetLastRunDuration()
        return 0
    }

    StartRunTimer() {
        this.StopRunTimer()
        this.boundTick := ObjBindMethod(this, "TickRunTimes")
        SetTimer(this.boundTick, 1000)
    }

    StopRunTimer() {
        if (this.boundTick != "") {
            try SetTimer(this.boundTick, 0)
        }
        this.boundTick := ""
    }

    TickRunTimes() {
        this.SyncGameFocus()
        if this.visible {
            this.PaintRunTimes()
            this.PaintAutoRun()
        }
    }

    StatusIcon() {
        if (this.statusKind == "idle")
            return Chr(0x25CB)
        return Chr(0x25CF)
    }

    StatusColor() {
        if (this.statusKind == "ready" || this.statusKind == "success")
            return this.readyColor
        if (this.statusKind == "error")
            return this.errorColor
        if (this.statusKind == "working")
            return this.workingColor
        return this.idleColor
    }

    InferKind(text) {
        lower := StrLower(text)
        if (lower == "ready")
            return "ready"
        if (InStr(lower, "success"))
            return "success"
        if (InStr(lower, "await") || InStr(lower, "wait"))
            return "idle"
        if (InStr(lower, "error") || InStr(lower, "fail") || InStr(lower, "wrong")
            || InStr(lower, "could not") || InStr(lower, "cannot") || InStr(lower, "no target"))
            return "error"
        return "working"
    }

    GetIdleStatusText() {
        return "Ready"
    }

    GetHotkeyHintText() {
        if (this.hotkeyHint != "")
            return this.hotkeyHint
        startName := this.GetStartHotkeyName()
        stopName := this.GetStopHotkeyName()
        return startName " to run · " stopName " to stop"
    }

    GetStartHotkeyName() {
        startKey := "Home"
        if IsObject(this.settingsManager)
            startKey := this.settingsManager.Get("hotkeyStart", "Home")
        name := this.FormatHotkeyName(startKey)
        return (name != "") ? name : "Home"
    }

    GetStopHotkeyName() {
        stopKey := "End"
        if IsObject(this.settingsManager)
            stopKey := this.settingsManager.Get("hotkeyStop", "End")
        name := this.FormatHotkeyName(stopKey)
        return (name != "") ? name : "End"
    }

    FormatHotkeyName(hotkey) {
        raw := Trim(hotkey)
        if (raw == "")
            return ""
        mods := ""
        key := raw
        loop {
            first := SubStr(key, 1, 1)
            if (first == "^") {
                mods .= "Ctrl+"
                key := SubStr(key, 2)
            } else if (first == "!") {
                mods .= "Alt+"
                key := SubStr(key, 2)
            } else if (first == "+") {
                mods .= "Shift+"
                key := SubStr(key, 2)
            } else if (first == "#") {
                mods .= "Win+"
                key := SubStr(key, 2)
            } else
                break
        }
        if (key == "")
            return Trim(raw)
        return mods . key
    }

    GetProfileText() {
        if (this.profileOverride != "")
            return this.profileOverride
        if IsObject(this.profileManager)
            return this.profileManager.GetCurrentName()
        return ""
    }

    GetProgressText() {
        if IsObject(this.userState)
            return this.userState.GetProgressText(this.GetTargetedCount())
        return "0/0"
    }

    GetSessionCompletedText() {
        if IsObject(this.userState) && this.userState.HasMethod("GetSessionCompletedCount")
            return String(this.userState.GetSessionCompletedCount())
        return "0"
    }

    GetMnemonicDeviceText() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetMnemonicDeviceText")
            return this.stateManager.GetMnemonicDeviceText()
        return "—"
    }

    IsMnemonicUnknown() {
        if !IsObject(this.stateManager)
            return true
        if this.stateManager.HasMethod("HasMnemonicDeviceReading")
            return !this.stateManager.HasMnemonicDeviceReading()
        if this.stateManager.HasMethod("GetMnemonicDeviceMax")
            return this.stateManager.GetMnemonicDeviceMax() < 1
        return true
    }

    IsMnemonicDepleted() {
        if this.IsMnemonicUnknown()
            return false
        return this.stateManager.GetMnemonicDeviceCurrent() < 1
    }

    IsProgressComplete() {
        if IsObject(this.userState)
            return this.userState.IsProgressComplete(this.GetTargetedCount())
        return false
    }

    GetTargetedCount() {
        if !IsObject(this.stateManager)
            return 0
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return 0
        return targeted.Length
    }

    IsSessionReady() {
        return IsObject(this.userState) && this.userState.IsInitialized()
    }

    GetReadyLabel() {
        return this.GetIdleStatusText()
    }

    Show() {
        if !this.WantsOverlayVisible() {
            this.Hide()
            return
        }
        if !GameWindow.IsActive() {
            this.Hide()
            return
        }
        rect := this.GetOverlayRect()
        this.guiObj.Show("x" rect.x " y" rect.y " w" rect.w " h" rect.h " NoActivate")
        try WinSetTransparent(220, this.guiObj)
        this.visible := true
        this.lastClientSig := this.GetClientSignature()
        this.PositionSplash()
        this.PositionGoalProgressToasts()
        this.Refresh()
    }

    Hide() {
        if IsObject(this.guiObj)
            this.guiObj.Hide()
        this.visible := false
        this.HideSplash()
        this.HideGoalProgressToasts()
    }

    Close() {
        this.StopRunTimer()
        this.HideSplash()
        this.DestroyGoalProgressToasts()
        this.DestroySplashGui()
        this.Hide()
        if IsObject(this.guiObj) {
            try this.guiObj.Destroy()
        }
        this.guiObj := ""
        if (StatusBar.overlay == this)
            StatusBar.overlay := ""
    }

    NotificationsEnabled() {
        if !this.visible
            return false
        if !GameWindow.IsActive()
            return false
        if IsObject(this.settingsManager) && !this.settingsManager.GetBool("showOverlay", true)
            return false
        if IsObject(this.settingsManager) && !this.settingsManager.GetBool("overlayShowNotifications", true)
            return false
        return true
    }

    Notify(message, kind := "info") {
        text := Trim(message)
        if (text == "")
            return
        if !this.NotificationsEnabled()
            return
        this.EnsureSplashGui()
        if !IsObject(this.splashGui)
            return
        this.splashMode := "simple"
        this.ApplySplashLayout()
        this.splashText.Text := text
        color := (kind == "best" || kind == "success") ? this.progressCompleteColor : this.idleColor
        this.splashText.SetFont("s16 bold c" color, "Segoe UI")
        if IsObject(this.splashAccent)
            this.splashAccent.Opt("Background" color)
        this.ShowSplash()
    }

    NotifyGoalReached(houseName, iconPath := "") {
        label := Trim(houseName)
        if (label == "")
            return
        if !this.NotificationsEnabled()
            return
        if (iconPath == "")
            iconPath := this.GetHouseIconPath(label)
        this.EnsureSplashGui()
        if !IsObject(this.splashGui)
            return
        this.splashMode := "goal"
        this.ApplySplashLayout()
        if IsObject(this.splashHousePic) {
            if (iconPath != "" && FileExist(iconPath))
                this.splashHousePic.Value := iconPath
            else
                this.splashHousePic.Value := ""
        }
        this.splashTitle.Text := label
        this.splashSubtext.Text := "Goal reached"
        color := this.progressCompleteColor
        this.splashTitle.SetFont("s14 bold c" color, "Segoe UI")
        this.splashSubtext.SetFont("s11 cA1A1AA", "Segoe UI")
        if IsObject(this.splashAccent)
            this.splashAccent.Opt("Background" color)
        this.ShowSplash()
    }

    NotifyGoalProgress(houseName, missionsLeft, currentCont := 0, goal := 0, iconPath := "") {
        label := Trim(houseName)
        if (label == "")
            return
        try {
            missionsLeft := Integer(missionsLeft)
        } catch {
            return
        }
        if (missionsLeft < 1)
            return
        if !this.NotificationsEnabled()
            return
        if (iconPath == "")
            iconPath := this.GetHouseIconPath(label)
        missionsText := (missionsLeft = 1) ? "1 mission left" : (missionsLeft " missions left")
        subtext := missionsText
        if (goal > 0)
            subtext := this.FormatContributionAmount(currentCont) " / " this.FormatContributionAmount(goal) " · " missionsText
        this.PushGoalProgressToast(label, subtext, iconPath)
    }

    PushGoalProgressToast(houseName, subtext, iconPath := "") {
        houseName := Trim(houseName)
        subtext := Trim(subtext)
        if (houseName == "" || subtext == "")
            return

        for _, toast in this.progressToasts {
            if (toast["houseName"] == houseName) {
                toast["subtext"].Text := subtext
                toast["phase"] := "hold"
                toast["alpha"] := 230
                toast["holdUntil"] := A_TickCount + this.progressToastHoldMs
                if (iconPath != "" && FileExist(iconPath))
                    toast["housePic"].Value := iconPath
                try WinSetTransparent(toast["alpha"], toast["toastGui"])
                this.PositionGoalProgressToasts()
                return
            }
        }

        while (this.progressToasts.Length >= this.progressToastMax)
            this.DestroyGoalProgressToastAt(1)

        toast := this.CreateGoalProgressToast(houseName, subtext, iconPath)
        if !IsObject(toast)
            return
        this.progressToasts.Push(toast)
        this.PositionGoalProgressToasts()
        this.StartProgressToastAnim()
    }

    CreateGoalProgressToast(houseName, subtext, iconPath := "") {
        toastGui := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        toastGui.BackColor := "0F0F12"
        toastGui.MarginX := 0
        toastGui.MarginY := 0
        w := this.progressToastW
        h := this.progressToastH
        accent := toastGui.Add("Text", "x0 y0 w" w " h3 BackgroundEAB308")
        housePic := toastGui.Add("Picture", "x12 y10 w44 h44 BackgroundTrans", "")
        toastGui.SetFont("s14 bold cEAB308", "Segoe UI")
        title := toastGui.Add("Text", "x64 y12 w" (w - 76) " h20 BackgroundTrans", houseName)
        toastGui.SetFont("s11 cA1A1AA", "Segoe UI")
        subtextCtrl := toastGui.Add("Text", "x64 y34 w" (w - 76) " h18 BackgroundTrans", subtext)
        if (iconPath != "" && FileExist(iconPath))
            housePic.Value := iconPath
        try WinSetTransparent(0, toastGui)
        return Map(
            "houseName", houseName,
            "toastGui", toastGui,
            "accent", accent,
            "housePic", housePic,
            "title", title,
            "subtext", subtextCtrl,
            "alpha", 0,
            "phase", "in",
            "holdUntil", 0
        )
    }

    GetGoalProgressToastAnchor() {
        overlay := this.GetOverlayRect()
        w := this.progressToastW
        h := this.progressToastH
        pos := this.GetPositionKey()
        x := overlay.x
        if (pos == "topRight" || pos == "bottomRight")
            x := overlay.x + overlay.w - w
        else if this.IsMiddlePosition(pos)
            x := overlay.x + ((overlay.w - w) // 2)
        if this.IsBottomPosition(pos)
            y := overlay.y - h - 4
        else
            y := overlay.y + overlay.h + 4
        return { x: x, y: y, w: w, h: h, stackUp: this.IsBottomPosition(pos) }
    }

    PositionGoalProgressToasts() {
        if (this.progressToasts.Length == 0)
            return
        anchor := this.GetGoalProgressToastAnchor()
        if !IsObject(anchor)
            return
        step := this.progressToastH + this.progressToastGap
        splashOffset := 0
        if IsObject(this.splashGui) && this.splashPhase != "hidden" && this.splashAlpha > 0
            splashOffset := (this.splashMode == "goal") ? 64 : 52
        if (splashOffset > 0)
            splashOffset += 4
        count := this.progressToasts.Length
        loop count {
            i := A_Index
            toast := this.progressToasts[i]
            if !IsObject(toast) || !toast.Has("toastGui") || !IsObject(toast["toastGui"])
                continue
            slot := count - i
            if anchor.stackUp
                y := anchor.y - splashOffset - slot * step
            else
                y := anchor.y + splashOffset + slot * step
            accentY := anchor.stackUp ? (this.progressToastH - 3) : 0
            try toast["toastGui"].Move(anchor.x, y, anchor.w, anchor.h)
            if toast.Has("accent") && IsObject(toast["accent"])
                try toast["accent"].Move(0, accentY, anchor.w, 3)
            if toast["phase"] != "hidden" && toast["phase"] != "out"
                try toast["toastGui"].Show("NoActivate")
        }
    }

    StartProgressToastAnim() {
        if (this.boundProgressToastTick != "")
            return
        this.boundProgressToastTick := ObjBindMethod(this, "TickGoalProgressToasts")
        SetTimer(this.boundProgressToastTick, 30)
    }

    StopProgressToastAnim() {
        if (this.boundProgressToastTick != "") {
            try SetTimer(this.boundProgressToastTick, 0)
        }
        this.boundProgressToastTick := ""
    }

    TickGoalProgressToasts() {
        if (this.progressToasts.Length == 0) {
            this.StopProgressToastAnim()
            return
        }
        if !this.NotificationsEnabled() {
            this.HideGoalProgressToasts()
            return
        }

        removeIdx := 0
        loop this.progressToasts.Length {
            i := A_Index
            toast := this.progressToasts[i]
            if !IsObject(toast)
                continue
            phase := toast.Has("phase") ? toast["phase"] : "hidden"
            alpha := toast.Has("alpha") ? toast["alpha"] : 0

            if (phase == "in") {
                alpha += 28
                if (alpha >= 230) {
                    alpha := 230
                    toast["phase"] := "hold"
                    toast["holdUntil"] := A_TickCount + this.progressToastHoldMs
                }
            } else if (phase == "hold") {
                holdUntil := toast.Has("holdUntil") ? toast["holdUntil"] : 0
                if (A_TickCount >= holdUntil)
                    toast["phase"] := "out"
            } else if (phase == "out") {
                alpha -= 18
                if (alpha <= 0) {
                    removeIdx := i
                    break
                }
            } else {
                removeIdx := i
                break
            }

            toast["alpha"] := alpha
            if IsObject(toast["toastGui"])
                try WinSetTransparent(alpha, toast["toastGui"])
        }

        if (removeIdx > 0)
            this.DestroyGoalProgressToastAt(removeIdx)

        if (this.progressToasts.Length == 0)
            this.StopProgressToastAnim()
        else
            this.PositionGoalProgressToasts()
    }

    HideGoalProgressToasts() {
        for _, toast in this.progressToasts {
            if IsObject(toast) && toast.Has("toastGui") && IsObject(toast["toastGui"]) {
                toast["phase"] := "hidden"
                toast["alpha"] := 0
                try toast["toastGui"].Hide()
            }
        }
    }

    DestroyGoalProgressToastAt(idx) {
        if (idx < 1 || idx > this.progressToasts.Length)
            return
        toast := this.progressToasts[idx]
        if IsObject(toast) && toast.Has("toastGui") && IsObject(toast["toastGui"]) {
            try toast["toastGui"].Destroy()
        }
        this.progressToasts.RemoveAt(idx)
    }

    DestroyGoalProgressToasts() {
        this.StopProgressToastAnim()
        while (this.progressToasts.Length > 0)
            this.DestroyGoalProgressToastAt(1)
        this.progressToasts := []
    }

    FormatContributionAmount(amount) {
        try {
            n := Integer(amount)
        } catch {
            return "0"
        }
        if (n < 0)
            n := 0
        return Format("{:L}", n)
    }

    ShowSplash() {
        pos := this.PositionSplash()
        this.splashAlpha := 0
        this.splashPhase := "in"
        this.splashHoldUntil := 0
        if IsObject(pos)
            this.splashGui.Show("x" pos.x " y" pos.y " w" pos.w " h" pos.h " NoActivate")
        else
            this.splashGui.Show("NoActivate")
        try WinSetTransparent(0, this.splashGui)
        this.StartSplashAnim()
        this.PositionGoalProgressToasts()
    }

    EnsureSplashGui() {
        if IsObject(this.splashGui)
            return
        splash := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        splash.BackColor := "0F0F12"
        splash.MarginX := 0
        splash.MarginY := 0
        this.splashAccent := splash.Add("Text", "x0 y0 w640 h3 BackgroundEAB308")
        this.splashHousePic := splash.Add("Picture",
            "x12 y10 w44 h44 BackgroundTrans Hidden", "")
        splash.SetFont("s14 bold c4ADE80", "Segoe UI")
        this.splashTitle := splash.Add("Text", "x64 y12 w560 h20 BackgroundTrans Hidden", "")
        splash.SetFont("s11 cA1A1AA", "Segoe UI")
        this.splashSubtext := splash.Add("Text", "x64 y34 w560 h18 BackgroundTrans Hidden", "")
        splash.SetFont("s16 bold cEAB308", "Segoe UI")
        this.splashText := splash.Add("Text", "x16 y10 w600 h36 BackgroundTrans", "")
        this.splashGui := splash
    }

    ApplySplashLayout() {
        if !IsObject(this.splashGui)
            return
        goalMode := (this.splashMode == "goal")
        if IsObject(this.splashText)
            this.splashText.Visible := !goalMode
        if IsObject(this.splashHousePic)
            this.splashHousePic.Visible := goalMode
        if IsObject(this.splashTitle)
            this.splashTitle.Visible := goalMode
        if IsObject(this.splashSubtext)
            this.splashSubtext.Visible := goalMode
    }

    GetHouseIconPath(houseName) {
        if (houseName == "" || !IsObject(this.stateManager) || !(this.stateManager.allHousesList is Array))
            return ""
        for _, entry in this.stateManager.allHousesList {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] != houseName)
                continue
            slug := entry.Has("iconSlug") ? entry["iconSlug"] : ""
            if (slug != "") {
                scaled := A_ScriptDir "\db\house_icons_scaled\1440p\" slug "_72x72.png"
                if FileExist(scaled)
                    return scaled
                raw := A_ScriptDir "\db\house_icons\" slug ".png"
                if FileExist(raw)
                    return raw
            }
            break
        }
        return ""
    }

    DestroySplashGui() {
        this.StopSplashAnim()
        if IsObject(this.splashGui) {
            try this.splashGui.Destroy()
        }
        this.splashGui := ""
        this.splashText := ""
        this.splashTitle := ""
        this.splashSubtext := ""
        this.splashHousePic := ""
        this.splashAccent := ""
        this.splashPhase := "hidden"
    }

    PositionSplash() {
        if !IsObject(this.splashGui)
            return ""
        overlay := this.GetOverlayRect()
        w := overlay.w
        if (w < 420)
            w := 420
        h := (this.splashMode == "goal") ? 64 : 52
        pos := this.GetPositionKey()
        x := overlay.x
        if (pos == "topRight" || pos == "bottomRight")
            x := overlay.x + overlay.w - w
        else if this.IsMiddlePosition(pos)
            x := overlay.x
        y := overlay.y + overlay.h + 4
        if this.IsBottomPosition(pos)
            y := overlay.y - h - 4
        try this.splashGui.Move(x, y, w, h)
        accentY := this.IsBottomPosition(pos) ? (h - 3) : 0
        if IsObject(this.splashAccent)
            try this.splashAccent.Move(0, accentY, w, 3)
        if IsObject(this.splashText)
            try this.splashText.Move(16, 10, w - 32, 36)
        if IsObject(this.splashHousePic)
            try this.splashHousePic.Move(12, 10, 44, 44)
        if IsObject(this.splashTitle)
            try this.splashTitle.Move(64, 12, w - 76, 20)
        if IsObject(this.splashSubtext)
            try this.splashSubtext.Move(64, 34, w - 76, 18)
        return { x: x, y: y, w: w, h: h }
    }

    HideSplash() {
        this.StopSplashAnim()
        this.splashPhase := "hidden"
        this.splashAlpha := 0
        if IsObject(this.splashGui)
            this.splashGui.Hide()
        this.PositionGoalProgressToasts()
    }

    StartSplashAnim() {
        this.StopSplashAnim()
        this.boundSplashTick := ObjBindMethod(this, "TickSplash")
        SetTimer(this.boundSplashTick, 30)
    }

    StopSplashAnim() {
        if (this.boundSplashTick != "") {
            try SetTimer(this.boundSplashTick, 0)
        }
        this.boundSplashTick := ""
    }

    TickSplash() {
        if (this.splashPhase == "in") {
            this.splashAlpha += 28
            if (this.splashAlpha >= 230) {
                this.splashAlpha := 230
                this.splashPhase := "hold"
                this.splashHoldUntil := A_TickCount + 2800
            }
        } else if (this.splashPhase == "hold") {
            if (A_TickCount >= this.splashHoldUntil)
                this.splashPhase := "out"
        } else if (this.splashPhase == "out") {
            this.splashAlpha -= 18
            if (this.splashAlpha <= 0) {
                this.HideSplash()
                return
            }
        } else {
            this.HideSplash()
            return
        }
        if IsObject(this.splashGui) {
            try WinSetTransparent(this.splashAlpha, this.splashGui)
        }
        this.PositionGoalProgressToasts()
    }
}
