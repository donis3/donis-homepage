#Requires AutoHotkey v2.0+

/**
 * Character profiles. Each profile has its own player state and settings
 * (guild name, faction, overlay, delays, etc.). Hotkeys stay global in settings.json.
 */
class ProfileManager {
    workspaceRoot := ""
    profilesPath := ""
    currentId := "default"
    profiles := []
    skipProfilesPersist := false

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        this.workspaceRoot := rootDir
        this.profilesPath := rootDir . "\profiles.json"
        this.profiles := []
        this.currentId := "default"
    }

    /**
     * Loads profiles.json, or creates a default profile from existing player state.
     */
    Initialize(stateManagerInst, settingsManagerInst) {
        if !this.LoadProfilesFile(settingsManagerInst) {
            defaultProfilesPath := this.workspaceRoot . "\defaults\profiles.json"
            if !(FileExist(defaultProfilesPath) && this.LoadProfilesFile(settingsManagerInst, defaultProfilesPath)) {
                charName := "player"
                if IsObject(settingsManagerInst)
                    charName := settingsManagerInst.Get("characterName", "player")
                if (Trim(charName) == "")
                    charName := "player"
                this.profiles := []
                profileSettings := IsObject(settingsManagerInst)
                    ? settingsManagerInst.ExportProfileSettings()
                    : Map()
                this.profiles.Push(this.MakeProfile("default", charName, stateManagerInst.ClonePlayerState(), profileSettings, settingsManagerInst))
                this.currentId := "default"
            }
            this.SaveProfilesFile()
        }

        savedId := ""
        if IsObject(settingsManagerInst)
            savedId := settingsManagerInst.Get("currentProfileId", this.currentId)
        if (savedId != "" && this.FindIndexById(savedId) > 0)
            this.currentId := savedId
        else
            this.currentId := this.profiles[1]["id"]

        this.ApplyCurrentToState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.ApplyCurrentSettings(settingsManagerInst)
        this.SyncSettings(settingsManagerInst)
        if this.EnsureRewardsWeekRollover()
            this.SaveProfilesFile()
    }

    LoadProfilesFile(settingsManagerInst := "", sourcePath := "") {
        this.profiles := []
        if (sourcePath == "")
            sourcePath := this.profilesPath
        if !FileExist(sourcePath)
            return false
        try {
            parsed := JSON.Parse(FileRead(sourcePath, "UTF-8"))
            if !this.IsValidProfilesPayload(parsed)
                return false
            if parsed.Has("currentId") && parsed["currentId"] != ""
                this.currentId := parsed["currentId"]
            savedProfileId := ""
            if IsObject(settingsManagerInst)
                savedProfileId := settingsManagerInst.Get("currentProfileId", this.currentId)
            for _, entry in parsed["profiles"] {
                if !(entry is Map)
                    continue
                id := entry.Has("id") ? entry["id"] : ""
                name := entry.Has("characterName") ? entry["characterName"] : "player"
                state := entry.Has("state") && (entry["state"] is Map)
                    ? entry["state"]
                    : Map()
                if (id == "" || Trim(name) == "")
                    continue
                profileSettings := Map()
                if entry.Has("settings") && (entry["settings"] is Map)
                    profileSettings := entry["settings"]
                else if IsObject(settingsManagerInst) {
                    if (id == savedProfileId || id == this.currentId)
                        profileSettings := settingsManagerInst.ExportProfileSettings()
                    else
                        profileSettings := settingsManagerInst.GetDefaultProfileSettings()
                }
                landsraadContribution := entry.Has("landsraad_contribution")
                    ? entry["landsraad_contribution"]
                    : Map()
                lastLandsraadScan := entry.Has("lastLandsraadScan") ? entry["lastLandsraadScan"] : ""
                unclaimedRewards := entry.Has("unclaimedHouseRewards") ? entry["unclaimedHouseRewards"] : []
                rewardsLastKnownWeek := entry.Has("rewardsLastKnownWeek") ? entry["rewardsLastKnownWeek"] : ""
                huntedRewards := entry.Has("huntedRewards") ? entry["huntedRewards"] : []
                this.profiles.Push(this.MakeProfile(id, name, state, profileSettings, settingsManagerInst,
                    landsraadContribution, lastLandsraadScan, unclaimedRewards, rewardsLastKnownWeek, huntedRewards))
            }
            if (this.profiles.Length < 1)
                return false
            return true
        } catch {
            this.profiles := []
            return false
        }
    }

    IsValidProfilesPayload(parsed) {
        if !(parsed is Map)
            return false
        if !parsed.Has("profiles") || !(parsed["profiles"] is Array)
            return false
        if (parsed["profiles"].Length < 1)
            return false
        return true
    }

    SaveProfilesFile() {
        if (this.skipProfilesPersist)
            return false
        payload := Map(
            "currentId", this.currentId,
            "profiles", this.profiles
        )
        jsonString := JSON.Stringify(payload, 2)
        fileObj := FileOpen(this.profilesPath, "w", "UTF-8")
        fileObj.Write(jsonString)
        fileObj.Close()
        return true
    }

    MakeProfile(id, characterName, stateMap, settingsMap := "", settingsManagerInst := "", landsraadContribution := "",
        lastLandsraadScan := "", unclaimedHouseRewards := "", rewardsLastKnownWeek := "", huntedRewards := "") {
        contrib := this.NormalizeLandsraadContribution(landsraadContribution)
        scanDate := Trim(lastLandsraadScan)
        if (scanDate == "")
            scanDate := Trim(contrib["date"])
        return Map(
            "id", id,
            "characterName", characterName,
            "state", (stateMap is Map) ? stateMap : Map(),
            "settings", this.NormalizeProfileSettings(settingsMap, settingsManagerInst),
            "lastLandsraadScan", scanDate,
            "landsraad_contribution", contrib,
            "unclaimedHouseRewards", this.NormalizeUnclaimedHouseRewards(unclaimedHouseRewards),
            "rewardsLastKnownWeek", Trim(rewardsLastKnownWeek),
            "huntedRewards", this.NormalizeHuntedRewards(huntedRewards)
        )
    }

    GetDefaultLandsraadContribution() {
        return Map("date", "", "houses", [], "goals", [], "swatchOwned", [])
    }

    swatchContributionThreshold := 14000

    GetLandsraadContributionTiers() {
        return [700, 3500, 7000, 10500, 14000]
    }

    NormalizeLandsraadContribution(raw) {
        out := this.GetDefaultLandsraadContribution()
        if !(raw is Map)
            return out
        if raw.Has("date") && raw["date"] != ""
            out["date"] := String(raw["date"])
        if raw.Has("houses") && (raw["houses"] is Array)
            out["houses"] := this.NormalizeLandsraadHouses(raw["houses"])
        if raw.Has("goals") && (raw["goals"] is Array)
            out["goals"] := this.NormalizeLandsraadGoals(raw["goals"])
        if raw.Has("swatchOwned") && (raw["swatchOwned"] is Array)
            out["swatchOwned"] := this.NormalizeLandsraadSwatchOwned(raw["swatchOwned"])
        return out
    }

    NormalizeLandsraadHouses(rawHouses) {
        out := []
        if !(rawHouses is Array)
            return out
        for _, entry in rawHouses {
            normalized := this.NormalizeLandsraadHouseEntry(entry)
            if IsObject(normalized)
                out.Push(normalized)
        }
        return out
    }

    NormalizeLandsraadHouseEntry(raw) {
        if !(raw is Map) || !raw.Has("house")
            return ""
        houseName := Trim(raw["house"])
        if (houseName == "")
            return ""

        try {
            row := Integer(raw.Has("row") ? raw["row"] : 0)
        } catch {
            row := 0
        }
        try {
            col := Integer(raw.Has("col") ? raw["col"] : 0)
        } catch {
            col := 0
        }
        try {
            cont := Integer(raw.Has("cont") ? raw["cont"] : 0)
        } catch {
            cont := 0
        }

        missionsRevealed := false
        if raw.Has("missionsRevealed") {
            try {
                val := raw["missionsRevealed"]
                missionsRevealed := (val = true || val = 1 || Integer(val) = 1)
            } catch {
                missionsRevealed := false
            }
        }

        return Map(
            "house", houseName,
            "cont", cont,
            "row", row,
            "col", col,
            "missionsRevealed", missionsRevealed,
            "rewards", this.NormalizeHouseRewardEntries(raw.Has("rewards") ? raw["rewards"] : [])
        )
    }

    NormalizeHouseRewardEntries(rawRewards) {
        out := []
        if (rawRewards is Array) {
            for _, entry in rawRewards {
                if !(entry is Map)
                    continue
                itemId := this.RewardItemFieldValue(entry.Has("item_id") ? entry["item_id"] : "")
                itemName := this.RewardItemFieldValue(entry.Has("item_name") ? entry["item_name"] : "")
                out.Push(Map("item_id", itemId, "item_name", itemName))
                if (out.Length >= 4)
                    break
            }
        }
        while (out.Length < 4)
            out.Push(Map("item_id", "", "item_name", ""))
        return out
    }

    NormalizeLandsraadSwatchOwned(rawSwatches) {
        out := []
        if !(rawSwatches is Array)
            return out
        for _, entry in rawSwatches {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            if (houseName == "")
                continue
            owned := false
            if entry.Has("isSwatchOwned") {
                try {
                    owned := (entry["isSwatchOwned"] = true || Integer(entry["isSwatchOwned"]) = 1)
                } catch {
                    owned := false
                }
            }
            if owned
                out.Push(Map("house", houseName, "isSwatchOwned", true))
        }
        return out
    }

    NormalizeLandsraadGoals(rawGoals) {
        out := []
        if !(rawGoals is Array)
            return out
        for _, entry in rawGoals {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            if (houseName == "")
                continue
            goal := 0
            try {
                goal := Integer(entry.Has("goal") ? entry["goal"] : 0)
            } catch {
                goal := 0
            }
            if (goal < 0)
                goal := 0
            out.Push(Map("house", houseName, "goal", goal))
        }
        return out
    }

    GetCurrentLandsraadWeekDate() {
        global settingsManagerInst
        if IsSet(settingsManagerInst) && IsObject(settingsManagerInst)
            return settingsManagerInst.GetCurrentLandsraadWeekStartDate()
        return ""
    }

    IsLandsraadWeekCurrent(weekDate) {
        currentWeek := this.GetCurrentLandsraadWeekDate()
        weekDate := Trim(weekDate)
        if (weekDate == "" || currentWeek == "")
            return false
        return (weekDate == currentWeek)
    }

    GetLastLandsraadScan() {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return ""
        if profile.Has("lastLandsraadScan")
            return Trim(profile["lastLandsraadScan"])
        return Trim(this.GetLandsraadContribution()["date"])
    }

    IsLandsraadScannedForCurrentWeek() {
        scanDate := this.GetLastLandsraadScan()
        if (scanDate == "")
            return false
        global settingsManagerInst
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        currentWeek := settingsManagerInst.GetCurrentLandsraadWeekStartDate()
        if (currentWeek == "")
            return false
        return (scanDate == currentWeek)
    }

    HasLandsraadGridScanData() {
        contrib := this.GetLandsraadContribution()
        houses := contrib.Has("houses") ? contrib["houses"] : []
        return (houses is Array) && houses.Length > 0
    }

    GetRevealedHouseNameSet() {
        return this.GetGridScannedHouseNameSet()
    }

  /** House names found on the Landsraad grid during the current week's scan. */
    GetGridScannedHouseNameSet() {
        out := Map()
        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"])
            return out
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return out
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            name := Trim(entry["house"])
            if (name != "")
                out[StrLower(name)] := true
        }
        return out
    }

    /** House names with missions revealed on the grid (MissionPicker active cells). */
    GetMissionsRevealedHouseNameSet() {
        out := Map()
        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"])
            return out
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return out
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            if !this.EntryMissionsRevealed(entry)
                continue
            name := Trim(entry["house"])
            if (name != "")
                out[StrLower(name)] := true
        }
        return out
    }

    IsHouseOnGrid(houseName) {
        houseName := Trim(houseName)
        if (houseName == "")
            return false
        return this.GetGridScannedHouseNameSet().Has(StrLower(houseName))
    }

    IsHouseMissionsRevealed(houseName) {
        houseName := Trim(houseName)
        if (houseName == "")
            return false
        return this.GetMissionsRevealedHouseNameSet().Has(StrLower(houseName))
    }

    /** Same house names as MissionPickerGridTab.GetScannedCellMap (grid scan entries only). */
    GetOnBoardHouseNameSet() {
        return this.GetGridScannedHouseNameSet()
    }

    IsHouseOnBoard(houseName) {
        return this.IsHouseOnGrid(houseName)
    }

    IsHouseRevealedOnGrid(houseName) {
        return this.IsHouseMissionsRevealed(houseName)
    }

    GetLandsraadContribution() {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return this.GetDefaultLandsraadContribution()
        if profile.Has("landsraad_contribution")
            return this.NormalizeLandsraadContribution(profile["landsraad_contribution"])
        return this.GetDefaultLandsraadContribution()
    }

    GetHouseContribution(houseName) {
        contrib := this.GetLandsraadContribution()
        weekDate := Trim(contrib["date"])
        currentWeek := ""
        global settingsManagerInst
        if IsSet(settingsManagerInst) && IsObject(settingsManagerInst)
            currentWeek := settingsManagerInst.GetCurrentLandsraadWeekStartDate()
        if (weekDate == "" || currentWeek == "" || weekDate != currentWeek)
            return 0
        houses := contrib["houses"]
        if !(houses is Array)
            return 0
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName) {
                try {
                    return Integer(entry.Has("cont") ? entry["cont"] : 0)
                } catch {
                    return 0
                }
            }
        }
        return 0
    }

    GetScannedHouseEntry(houseName) {
        houseName := Trim(houseName)
        if (houseName == "")
            return ""
        if !this.IsLandsraadScannedForCurrentWeek()
            return ""
        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"])
            return ""
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return ""
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName)
                return entry
        }
        return ""
    }

    GetScannedHouseAtCell(gridRow, gridCol) {
        if !this.IsLandsraadScannedForCurrentWeek()
            return ""
        try {
            row := Integer(gridRow)
            col := Integer(gridCol)
        } catch {
            return ""
        }
        if (row < 1 || col < 1)
            return ""

        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"])
            return ""
        houses := contrib["houses"]
        if !(houses is Array)
            return ""
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            try {
                entryRow := Integer(entry.Has("row") ? entry["row"] : 0)
                entryCol := Integer(entry.Has("col") ? entry["col"] : 0)
            } catch {
                continue
            }
            if (entryRow == row && entryCol == col)
                return Trim(entry["house"])
        }
        return ""
    }

    GetScannedHouseForTargetedMission(missionName, stateManagerInst) {
        name := Trim(missionName)
        if (name == "" || !IsObject(stateManagerInst) || !stateManagerInst.HasMethod("GetTargetedMissions"))
            return ""
        if !this.IsLandsraadScannedForCurrentWeek()
            return ""
        for _, targeted in stateManagerInst.GetTargetedMissions() {
            if !(IsObject(targeted))
                continue
            tName := targeted.HasOwnProp("missionName") ? Trim(targeted.missionName) : ""
            if (tName == "" || StrCompare(tName, name, false) != 0)
                continue
            row := targeted.HasOwnProp("gridRow") ? targeted.gridRow : 0
            col := targeted.HasOwnProp("gridCol") ? targeted.gridCol : 0
            houseName := this.GetScannedHouseAtCell(row, col)
            if (houseName != "")
                return houseName
        }
        return ""
    }

    ResolveHouseForActiveMission(missionName, stateManagerInst := "") {
        name := Trim(missionName)
        if (name == "")
            return ""
        if IsObject(stateManagerInst) {
            if stateManagerInst.HasMethod("GetActiveMissionHouse") {
                houseName := Trim(stateManagerInst.GetActiveMissionHouse(name))
                if (houseName != "")
                    return houseName
            }
            houseName := this.GetScannedHouseForTargetedMission(name, stateManagerInst)
            if (houseName != "")
                return houseName
        }
        return ""
    }

    AddHouseContribution(houseName, amount) {
        failed := Map(
            "success", false,
            "previousCont", 0,
            "newCont", 0,
            "goalJustReached", false,
            "swatchJustOwned", false
        )
        houseName := Trim(houseName)
        if (houseName == "")
            return failed
        try {
            amount := Integer(amount)
        } catch {
            return failed
        }
        if (amount <= 0)
            return failed
        if !this.IsLandsraadScannedForCurrentWeek()
            return failed

        weekDate := this.GetCurrentLandsraadWeekDate()
        if (weekDate == "")
            return failed

        previousCont := this.GetHouseContribution(houseName)
        goal := this.GetHouseGoal(houseName)
        hadSwatch := this.IsHouseSwatchOwned(houseName)

        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"]) {
            contrib["date"] := weekDate
            contrib["houses"] := []
            contrib["goals"] := []
        } else if (Trim(contrib["date"]) == "") {
            contrib["date"] := weekDate
        }

        houses := contrib.Has("houses") && (contrib["houses"] is Array) ? contrib["houses"] : []
        updated := false
        newCont := previousCont
        newHouses := []
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName) {
                try {
                    current := Integer(entry.Has("cont") ? entry["cont"] : 0)
                } catch {
                    current := 0
                }
                newCont := current + amount
                newHouses.Push(this.NormalizeLandsraadHouseEntry(Map(
                    "house", houseName,
                    "cont", newCont,
                    "row", entry.Has("row") ? entry["row"] : 0,
                    "col", entry.Has("col") ? entry["col"] : 0,
                    "missionsRevealed", entry.Has("missionsRevealed") ? entry["missionsRevealed"] : true,
                    "rewards", entry.Has("rewards") ? entry["rewards"] : []
                )))
                updated := true
            } else {
                newHouses.Push(this.NormalizeLandsraadHouseEntry(entry))
            }
        }
        if !updated
            return failed

        contrib["houses"] := newHouses
        if !this.SetLandsraadContribution(contrib)
            return failed

        goalJustReached := goal > 0 && previousCont < goal && newCont >= goal
        swatchJustOwned := false
        if (newCont >= this.swatchContributionThreshold && !hadSwatch) {
            if this.SetHouseSwatchOwned(houseName, true)
                swatchJustOwned := true
        }

        this.SyncHouseRewardTiers(houseName, newCont, weekDate, hadSwatch)

        return Map(
            "success", true,
            "previousCont", previousCont,
            "newCont", newCont,
            "goalJustReached", goalJustReached,
            "swatchJustOwned", swatchJustOwned
        )
    }

    GetGridSlotForScannedHouse(houseName) {
        houseName := Trim(houseName)
        if (houseName == "")
            return 0
        if !this.IsLandsraadScannedForCurrentWeek()
            return 0
        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"])
            return 0
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return 0
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] != houseName)
                continue
            try {
                row := Integer(entry.Has("row") ? entry["row"] : 0)
                col := Integer(entry.Has("col") ? entry["col"] : 0)
            } catch {
                continue
            }
            if (row < 1 || col < 1)
                continue
            return (row - 1) * 5 + col
        }
        return 0
    }

    IsHouseSwatchOwned(houseName) {
        contrib := this.GetLandsraadContribution()
        swatches := contrib["swatchOwned"]
        if !(swatches is Array)
            return false
        for _, entry in swatches {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName)
                return true
        }
        return false
    }

    SetHouseSwatchOwned(houseName, owned) {
        houseName := Trim(houseName)
        if (houseName == "")
            return false
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false

        contrib := this.NormalizeLandsraadContribution(this.profiles[idx]["landsraad_contribution"])
        swatches := []
        for _, entry in contrib["swatchOwned"] {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName)
                continue
            swatches.Push(entry)
        }
        if owned
            swatches.Push(Map("house", houseName, "isSwatchOwned", true))

        contrib["swatchOwned"] := swatches
        this.profiles[idx]["landsraad_contribution"] := contrib
        this.SaveProfilesFile()
        return true
    }

    MergeAutoSwatchOwnedFromScan(contrib) {
        houses := contrib["houses"]
        if !(houses is Array)
            return
        swatches := this.NormalizeLandsraadSwatchOwned(contrib["swatchOwned"])
        ownedHouses := Map()
        for _, entry in swatches
            ownedHouses[entry["house"]] := true
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            if (houseName == "")
                continue
            try {
                cont := Integer(entry.Has("cont") ? entry["cont"] : 0)
            } catch {
                cont := 0
            }
            if (cont > this.swatchContributionThreshold)
                ownedHouses[houseName] := true
        }
        merged := []
        for houseName, _ in ownedHouses
            merged.Push(Map("house", houseName, "isSwatchOwned", true))
        contrib["swatchOwned"] := merged
    }

    GetHouseGoal(houseName) {
        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"])
            return 0
        goals := contrib["goals"]
        if !(goals is Array)
            return 0
        for _, entry in goals {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName) {
                try {
                    return Integer(entry.Has("goal") ? entry["goal"] : 0)
                } catch {
                    return 0
                }
            }
        }
        return 0
    }

    SetHouseGoal(houseName, goal) {
        houseName := Trim(houseName)
        if (houseName == "")
            return false
        try {
            goal := Integer(goal)
        } catch {
            goal := 0
        }
        if (goal < 0)
            goal := 0

        weekDate := this.GetCurrentLandsraadWeekDate()
        if (weekDate == "")
            return false

        contrib := this.GetLandsraadContribution()
        if !this.IsLandsraadWeekCurrent(contrib["date"]) {
            contrib["date"] := weekDate
            contrib["houses"] := []
            contrib["goals"] := []
        } else if (Trim(contrib["date"]) == "") {
            contrib["date"] := weekDate
        }

        goals := []
        for _, entry in contrib["goals"] {
            if !(entry is Map) || !entry.Has("house")
                continue
            if (entry["house"] == houseName)
                continue
            goals.Push(entry)
        }
        if (goal > 0)
            goals.Push(Map("house", houseName, "goal", goal))

        contrib["goals"] := goals
        return this.SetLandsraadContribution(contrib)
    }

    SetLandsraadContribution(contribMap) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false

        existing := this.NormalizeLandsraadContribution(
            this.profiles[idx].Has("landsraad_contribution")
                ? this.profiles[idx]["landsraad_contribution"]
                : "")
        contrib := this.NormalizeLandsraadContribution(contribMap)
        newDate := Trim(contrib["date"])
        oldDate := Trim(existing["date"])

        if !contribMap.Has("goals") {
            if (newDate != "" && newDate == oldDate)
                contrib["goals"] := existing["goals"]
            else
                contrib["goals"] := []
        }
        if !contribMap.Has("swatchOwned")
            contrib["swatchOwned"] := existing["swatchOwned"]
        if contribMap.Has("houses")
            contrib["houses"] := this.NormalizeLandsraadHouses(contribMap["houses"])
        else if (newDate == oldDate)
            contrib["houses"] := existing["houses"]
        else
            contrib["houses"] := []

        if contribMap.Has("houses")
            this.MergeAutoSwatchOwnedFromScan(contrib)

        this.profiles[idx]["landsraad_contribution"] := contrib
        if (Trim(contrib["date"]) != "")
            this.profiles[idx]["lastLandsraadScan"] := Trim(contrib["date"])

        if contribMap.Has("houses") && this.IsLandsraadWeekCurrent(contrib["date"])
            this.SyncAllHouseRewardTiersFromContribution(contrib)

        this.SaveProfilesFile()
        return true
    }

    NormalizeUnclaimedHouseRewards(rawRewards) {
        out := []
        if !(rawRewards is Array)
            return out
        for _, entry in rawRewards {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            weekDate := entry.Has("week") ? Trim(entry["week"]) : ""
            if (houseName == "" || weekDate == "")
                continue
            tiers := []
            if entry.Has("tiers") && (entry["tiers"] is Array) {
                for _, tier in entry["tiers"] {
                    try {
                        tierNum := Integer(tier)
                    } catch {
                        continue
                    }
                    if (tierNum >= 1 && tierNum <= 5 && !this.ArrayContains(tiers, tierNum))
                        tiers.Push(tierNum)
                }
            }
            if (tiers.Length == 0)
                continue
            claimed := false
            if entry.Has("isClaimed") {
                try {
                    claimed := (entry["isClaimed"] = true || Integer(entry["isClaimed"]) = 1)
                } catch {
                    claimed := false
                }
            }
            out.Push(Map(
                "house", houseName,
                "week", weekDate,
                "tiers", tiers,
                "items", this.NormalizeWeekRewardItems(entry.Has("items") ? entry["items"] : [], tiers, houseName,
                    weekDate),
                "isClaimed", claimed
            ))
        }
        return out
    }

    CanResolveRewardItemsForWeek(weekDate) {
        weekDate := Trim(weekDate)
        if (weekDate == "")
            return false
        currentWeek := this.GetCurrentLandsraadWeekDate()
        return currentWeek != "" && weekDate == currentWeek && this.IsLandsraadScannedForCurrentWeek()
    }

    NormalizeWeekRewardItems(rawItems, tiers := "", houseName := "", weekDate := "") {
        out := []
        seen := Map()
        canResolve := (tiers is Array) && (houseName != "") && this.CanResolveRewardItemsForWeek(weekDate)
        if (rawItems is Array) {
            for _, entry in rawItems {
                if !(entry is Map)
                    continue
                try {
                    tierNum := Integer(entry.Has("tier") ? entry["tier"] : 0)
                } catch {
                    continue
                }
                if (tierNum < 1 || tierNum > 5 || seen.Has(tierNum))
                    continue
                itemId := this.RewardItemFieldValue(entry.Has("item_id") ? entry["item_id"] : "")
                itemName := this.RewardItemFieldValue(entry.Has("item_name") ? entry["item_name"] : "")
                if (canResolve && this.IsUnresolvedRewardItem(Map("tier", tierNum, "item_id", itemId, "item_name", itemName))) {
                    resolved := this.ResolveHouseTierRewardItem(houseName, tierNum)
                    if (resolved is Map) {
                        itemId := this.RewardItemFieldValue(resolved.Has("item_id") ? resolved["item_id"] : "")
                        itemName := this.RewardItemFieldValue(resolved.Has("item_name") ? resolved["item_name"] : "")
                    }
                }
                if (itemName == "")
                    itemName := this.DefaultRewardItemName(tierNum)
                seen[tierNum] := true
                out.Push(Map("tier", tierNum, "item_id", itemId, "item_name", itemName))
            }
        }
        if canResolve {
            for _, tier in tiers {
                try {
                    tierNum := Integer(tier)
                } catch {
                    continue
                }
                if (tierNum < 1 || tierNum > 5 || seen.Has(tierNum))
                    continue
                resolved := this.ResolveHouseTierRewardItem(houseName, tierNum)
                if (resolved is Map) {
                    seen[tierNum] := true
                    out.Push(resolved)
                }
            }
        }
        return this.SortRewardItemsByTier(out)
    }

    SortRewardItemsByTier(items) {
        if !(items is Array) || items.Length < 2
            return items
        out := []
        for _, item in items
            out.Push(item)
        loop out.Length - 1 {
            swapped := false
            loop out.Length - A_Index {
                i := A_Index
                aTier := out[i].Has("tier") ? Integer(out[i]["tier"]) : 0
                bTier := out[i + 1].Has("tier") ? Integer(out[i + 1]["tier"]) : 0
                if (aTier > bTier) {
                    temp := out[i]
                    out[i] := out[i + 1]
                    out[i + 1] := temp
                    swapped := true
                }
            }
            if !swapped
                break
        }
        return out
    }

    SortRewardDisplayItems(items) {
        if !(items is Array) || items.Length < 2
            return items
        out := []
        for _, item in items
            out.Push(item)
        loop out.Length - 1 {
            swapped := false
            loop out.Length - A_Index {
                i := A_Index
                aWeek := out[i].Has("week") ? out[i]["week"] : ""
                bWeek := out[i + 1].Has("week") ? out[i + 1]["week"] : ""
                weekCmp := StrCompare(aWeek, bWeek)
                if (weekCmp > 0) {
                    shouldSwap := true
                } else if (weekCmp < 0) {
                    shouldSwap := false
                } else {
                    aTier := out[i].Has("tier") ? Integer(out[i]["tier"]) : 0
                    bTier := out[i + 1].Has("tier") ? Integer(out[i + 1]["tier"]) : 0
                    shouldSwap := aTier > bTier
                }
                if shouldSwap {
                    temp := out[i]
                    out[i] := out[i + 1]
                    out[i + 1] := temp
                    swapped := true
                }
            }
            if !swapped
                break
        }
        return out
    }

    FormatRewardWeekLabel(weekDate) {
        weekDate := Trim(weekDate)
        if (weekDate == "")
            return "Unknown week"
        try {
            stamp := StrReplace(weekDate, "-", "")
            return FormatTime(stamp, "MMM d, yyyy")
        } catch {
            return "Week " weekDate
        }
    }

    FormatRelativeRewardWeekLabel(weekDate) {
        weekDate := Trim(weekDate)
        if (weekDate == "")
            return ""
        currentWeek := this.GetCurrentLandsraadWeekDate()
        if (currentWeek == "")
            return this.FormatRewardWeekLabel(weekDate)
        if (weekDate = currentWeek)
            return "This week"
        if (StrCompare(weekDate, currentWeek) > 0)
            return "Upcoming week"
        weeksAgo := this.CountLandsraadWeeksBetween(weekDate, currentWeek)
        if (weeksAgo == 1)
            return "1 week ago"
        if (weeksAgo > 1)
            return weeksAgo " weeks ago"
        return this.FormatRewardWeekLabel(weekDate)
    }

    CountLandsraadWeeksBetween(earlierWeek, laterWeek) {
        earlierWeek := Trim(earlierWeek)
        laterWeek := Trim(laterWeek)
        if (earlierWeek == "" || laterWeek == "" || StrCompare(earlierWeek, laterWeek) >= 0)
            return 0
        try {
            earlierStamp := StrReplace(earlierWeek, "-", "") . "000000"
            laterStamp := StrReplace(laterWeek, "-", "") . "000000"
            days := DateDiff(laterStamp, earlierStamp, "Days")
        } catch {
            return 0
        }
        if (days < 1)
            return 0
        return days // 7
    }

    DefaultRewardItemName(tierIndex) {
        if (tierIndex == 5)
            return "House Swatch"
        return "Unknown reward"
    }

    IsUnresolvedRewardItem(item) {
        if !(item is Map)
            return true
        try {
            tierNum := Integer(item.Has("tier") ? item["tier"] : 0)
        } catch {
            return true
        }
        if (tierNum < 1 || tierNum > 5)
            return true
        itemId := this.RewardItemFieldValue(item.Has("item_id") ? item["item_id"] : "")
        if (itemId != "")
            return false
        itemName := this.RewardItemFieldValue(item.Has("item_name") ? item["item_name"] : "")
        if (tierNum == 5)
            return (itemName == "" || itemName = "House Swatch")
        return (itemName == "" || itemName = this.DefaultRewardItemName(tierNum))
    }

    ResolveHouseTierRewardItem(houseName, tierIndex) {
        try {
            tierIndex := Integer(tierIndex)
        } catch {
            return ""
        }
        if (tierIndex < 1 || tierIndex > 5)
            return ""
        if (tierIndex == 5)
            return Map("tier", 5, "item_id", "", "item_name", "House Swatch")

        houseEntry := this.GetScannedHouseEntry(houseName)
        itemId := ""
        itemName := ""
        if (houseEntry is Map) {
            rewards := houseEntry.Has("rewards") ? houseEntry["rewards"] : []
            if (rewards is Array) && (tierIndex <= rewards.Length) {
                reward := rewards[tierIndex]
                if (reward is Map) {
                    itemId := this.RewardItemFieldValue(reward.Has("item_id") ? reward["item_id"] : "")
                    itemName := this.RewardItemFieldValue(reward.Has("item_name") ? reward["item_name"] : "")
                }
            }
        }
        if (itemName == "")
            itemName := this.DefaultRewardItemName(tierIndex)
        return Map("tier", tierIndex, "item_id", itemId, "item_name", itemName)
    }

    SyncEarnedRewardItems(entry, houseName, earnedTiers, weekDate := "") {
        if !(entry is Map) || !(earnedTiers is Array)
            return
        if (weekDate == "")
            weekDate := entry.Has("week") ? Trim(entry["week"]) : ""
        items := this.NormalizeWeekRewardItems(entry.Has("items") ? entry["items"] : [], "", "", "")
        tiersPresent := Map()
        for _, item in items {
            if (item is Map) && item.Has("tier")
                tiersPresent[item["tier"]] := true
        }
        canResolve := this.CanResolveRewardItemsForWeek(weekDate)
        for _, tier in earnedTiers {
            try {
                tierNum := Integer(tier)
            } catch {
                continue
            }
            if (tierNum < 1 || tierNum > 5 || tiersPresent.Has(tierNum))
                continue
            if canResolve
                resolved := this.ResolveHouseTierRewardItem(houseName, tierNum)
            else
                resolved := Map("tier", tierNum, "item_id", "", "item_name", this.DefaultRewardItemName(tierNum))
            if (resolved is Map) {
                items.Push(resolved)
                tiersPresent[tierNum] := true
            }
        }
        if canResolve
            entry["items"] := this.NormalizeWeekRewardItems(items, earnedTiers, houseName, weekDate)
        else
            entry["items"] := this.SortRewardItemsByTier(items)
    }

    GetHouseEarnedRewardItems(houseName) {
        houseName := Trim(houseName)
        if (houseName == "")
            return []

        tierThresholds := this.GetLandsraadContributionTiers()
        out := []
        changed := false
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return out

        rewards := this.NormalizeUnclaimedHouseRewards(this.profiles[idx]["unclaimedHouseRewards"])
        for entryIdx, entry in rewards {
            if !(entry is Map) || Trim(entry["house"]) != houseName
                continue
            if entry.Has("isClaimed") && entry["isClaimed"]
                continue

            weekDate := entry.Has("week") ? Trim(entry["week"]) : ""
            earnedTiers := entry.Has("tiers") && (entry["tiers"] is Array) ? entry["tiers"] : []
            canResolve := this.CanResolveRewardItemsForWeek(weekDate)
            items := this.NormalizeWeekRewardItems(entry.Has("items") ? entry["items"] : [],
                canResolve ? earnedTiers : "", canResolve ? houseName : "", weekDate)
            prevJson := ""
            try prevJson := JSON.Stringify(entry.Has("items") ? entry["items"] : [])
            newJson := ""
            try newJson := JSON.Stringify(items)
            if (prevJson != newJson) {
                entry["items"] := items
                rewards[entryIdx] := entry
                changed := true
            }

            weekLabel := this.FormatRelativeRewardWeekLabel(weekDate)
            for _, item in items {
                tierNum := item.Has("tier") ? Integer(item["tier"]) : 0
                contribution := (tierNum >= 1 && tierNum <= tierThresholds.Length) ? tierThresholds[tierNum] : 0
                out.Push(Map(
                    "tier", tierNum,
                    "item_id", item.Has("item_id") ? item["item_id"] : "",
                    "item_name", item.Has("item_name") ? item["item_name"] : "",
                    "week", weekDate,
                    "weekLabel", weekLabel,
                    "contribution", contribution
                ))
            }
        }
        if changed {
            this.profiles[idx]["unclaimedHouseRewards"] := rewards
            this.SaveProfilesFile()
        }
        return this.SortRewardDisplayItems(out)
    }

    NormalizeHuntedRewards(rawRewards) {
        out := []
        if !(rawRewards is Array)
            return out
        seen := Map()
        for _, entry in rawRewards {
            itemId := ""
            if (entry is String)
                itemId := Trim(entry)
            else if (entry is Map) && entry.Has("item_id")
                itemId := Trim(entry["item_id"])
            if (itemId == "" || seen.Has(itemId))
                continue
            seen[itemId] := true
            out.Push(itemId)
        }
        return out
    }

    /** huntedRewards template for new profiles — default profile, else defaults/profiles.json */
    GetDefaultProfileHuntedRewards() {
        defaultIdx := this.FindIndexById("default")
        if (defaultIdx > 0) {
            profile := this.profiles[defaultIdx]
            if profile.Has("huntedRewards")
                return this.NormalizeHuntedRewards(profile["huntedRewards"])
        }
        return this.LoadHuntedRewardsFromDefaultsFile()
    }

    LoadHuntedRewardsFromDefaultsFile() {
        defaultProfilesPath := this.workspaceRoot . "\defaults\profiles.json"
        if !FileExist(defaultProfilesPath)
            return []
        try {
            parsed := JSON.Parse(FileRead(defaultProfilesPath, "UTF-8"))
            if !this.IsValidProfilesPayload(parsed)
                return []
            for _, entry in parsed["profiles"] {
                if !(entry is Map)
                    continue
                id := entry.Has("id") ? entry["id"] : ""
                if (id != "default")
                    continue
                if entry.Has("huntedRewards")
                    return this.NormalizeHuntedRewards(entry["huntedRewards"])
                break
            }
        } catch {
        }
        return []
    }

    RewardItemFieldValue(raw) {
        if (raw = "")
            return ""
        try {
            text := Trim(String(raw))
        } catch {
            return ""
        }
        if (text == "" || StrLower(text) = "null")
            return ""
        return text
    }

    GetBoardAvailableRewardIds() {
        ids := Map()
        if !this.IsLandsraadScannedForCurrentWeek()
            return ids

        contrib := this.GetLandsraadContribution()
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return ids

        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            if !this.EntryMissionsRevealed(entry)
                continue
            rewards := entry.Has("rewards") ? entry["rewards"] : []
            if !(rewards is Array)
                continue
            for _, reward in rewards {
                if !(reward is Map)
                    continue
                itemId := this.RewardItemFieldValue(reward.Has("item_id") ? reward["item_id"] : "")
                if (itemId != "")
                    ids[itemId] := true
            }
        }
        return ids
    }

    EntryMissionsRevealed(entry) {
        if !(entry is Map) || !entry.Has("missionsRevealed")
            return false
        try {
            val := entry["missionsRevealed"]
            return (val = true || val = 1 || Integer(val) = 1)
        } catch {
            return false
        }
    }

    GetHuntedRewards() {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return []
        if profile.Has("huntedRewards")
            return this.NormalizeHuntedRewards(profile["huntedRewards"])
        return []
    }

    IsHuntedReward(itemId) {
        itemId := Trim(itemId)
        if (itemId == "")
            return false
        for _, huntedId in this.GetHuntedRewards() {
            if (huntedId = itemId)
                return true
        }
        return false
    }

    HouseHasHuntedReward(houseEntry) {
        if !(houseEntry is Map) || !this.EntryMissionsRevealed(houseEntry)
            return false
        rewards := houseEntry.Has("rewards") ? houseEntry["rewards"] : []
        if !(rewards is Array)
            return false
        for _, reward in rewards {
            if !(reward is Map)
                continue
            itemId := this.RewardItemFieldValue(reward.Has("item_id") ? reward["item_id"] : "")
            if (itemId != "" && this.IsHuntedReward(itemId))
                return true
        }
        return false
    }

    ToggleHuntedReward(itemId) {
        itemId := Trim(itemId)
        if (itemId == "")
            return false
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false

        hunted := this.NormalizeHuntedRewards(this.profiles[idx].Has("huntedRewards")
            ? this.profiles[idx]["huntedRewards"] : [])
        updated := []
        wasHunted := false
        for _, huntedId in hunted {
            if (huntedId = itemId) {
                wasHunted := true
                continue
            }
            updated.Push(huntedId)
        }
        if !wasHunted
            updated.Push(itemId)
        this.profiles[idx]["huntedRewards"] := updated
        this.SaveProfilesFile()
        return !wasHunted
    }

    ArrayContains(arr, value) {
        if !(arr is Array)
            return false
        for _, item in arr {
            if (item = value)
                return true
        }
        return false
    }

    GetUnclaimedHouseRewards() {
        this.EnsureRewardsWeekRollover()
        profile := this.GetCurrent()
        if !IsObject(profile)
            return []
        if profile.Has("unclaimedHouseRewards")
            return this.NormalizeUnclaimedHouseRewards(profile["unclaimedHouseRewards"])
        return []
    }

    GetPendingHouseRewards() {
        pending := []
        for _, entry in this.GetUnclaimedHouseRewards() {
            if !(entry is Map) || entry.Has("isClaimed") && entry["isClaimed"]
                continue
            pending.Push(entry)
        }
        return pending
    }

    /**
     * Houses with a current-week reward entry for the Rewards tab.
     * Merges older unclaimed weeks into tier display until the user claims.
     */
    GetHouseRewardsForTab() {
        currentWeek := this.GetCurrentLandsraadWeekDate()
        if (currentWeek == "")
            return []

        byHouse := Map()
        for _, entry in this.GetUnclaimedHouseRewards() {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            weekDate := entry.Has("week") ? Trim(entry["week"]) : ""
            if (houseName == "" || weekDate == "")
                continue

            if !byHouse.Has(houseName)
                byHouse[houseName] := Map("house", houseName, "currentWeekEntry", "", "olderEntries", [])

            grouped := byHouse[houseName]
            if (weekDate == currentWeek)
                grouped["currentWeekEntry"] := entry
            else if (StrCompare(weekDate, currentWeek) < 0)
                grouped["olderEntries"].Push(entry)
        }

        display := []
        for _, grouped in byHouse {
            currentEntry := grouped["currentWeekEntry"]
            if !(currentEntry is Map)
                continue

            isClaimed := currentEntry.Has("isClaimed") && currentEntry["isClaimed"]
            highestTier := this.GetHighestRewardTier(currentEntry.Has("tiers") ? currentEntry["tiers"] : [])
            oldWeekCount := 0

            if !isClaimed {
                for _, oldEntry in grouped["olderEntries"] {
                    if oldEntry.Has("isClaimed") && oldEntry["isClaimed"]
                        continue
                    oldWeekCount += 1
                    oldHigh := this.GetHighestRewardTier(oldEntry.Has("tiers") ? oldEntry["tiers"] : [])
                    if (oldHigh > highestTier)
                        highestTier := oldHigh
                }
            }

            if (highestTier < 1)
                continue

            earnedTiers := []
            loop highestTier
                earnedTiers.Push(A_Index)

            display.Push(Map(
                "house", grouped["house"],
                "isClaimed", isClaimed,
                "highestTier", highestTier,
                "tiers", earnedTiers,
                "currentWeek", currentWeek,
                "oldWeekCount", oldWeekCount
            ))
        }
        return display
    }

    GetHighestRewardTier(tiers) {
        highest := 0
        if !(tiers is Array)
            return highest
        for _, tier in tiers {
            try {
                tierNum := Integer(tier)
            } catch {
                continue
            }
            if (tierNum > highest)
                highest := tierNum
        }
        return highest
    }

    EnsureRewardsWeekRollover() {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false
        currentWeek := this.GetCurrentLandsraadWeekDate()
        if (currentWeek == "")
            return false
        lastKnown := this.profiles[idx].Has("rewardsLastKnownWeek")
            ? Trim(this.profiles[idx]["rewardsLastKnownWeek"]) : ""
        if (lastKnown == currentWeek)
            return false
        if (lastKnown != "")
            this.PruneClaimedHouseRewardsBeforeWeek(currentWeek, idx)
        this.profiles[idx]["rewardsLastKnownWeek"] := currentWeek
        this.SaveProfilesFile()
        return true
    }

    PruneClaimedHouseRewardsBeforeWeek(currentWeek, profileIdx := 0) {
        if (profileIdx < 1)
            profileIdx := this.FindIndexById(this.currentId)
        if (profileIdx < 1)
            return false
        rewards := this.NormalizeUnclaimedHouseRewards(this.profiles[profileIdx]["unclaimedHouseRewards"])
        kept := []
        for _, entry in rewards {
            weekDate := entry.Has("week") ? Trim(entry["week"]) : ""
            if (entry.Has("isClaimed") && entry["isClaimed"] && weekDate != "" && StrCompare(weekDate, currentWeek) < 0)
                continue
            kept.Push(entry)
        }
        this.profiles[profileIdx]["unclaimedHouseRewards"] := kept
        return true
    }

    GetEarnedTierIndices(contribution) {
        earned := []
        try {
            cont := Integer(contribution)
        } catch {
            return earned
        }
        if (cont < 0)
            cont := 0
        tiers := this.GetLandsraadContributionTiers()
        loop tiers.Length {
            if (cont >= tiers[A_Index])
                earned.Push(A_Index)
        }
        return earned
    }

    FindHouseRewardEntry(rewards, houseName, weekDate) {
        for idx, entry in rewards {
            if !(entry is Map)
                continue
            if (entry["house"] == houseName && entry["week"] == weekDate)
                return idx
        }
        return 0
    }

    SyncHouseRewardTiers(houseName, contribution, weekDate, skipSwatchTier := false) {
        houseName := Trim(houseName)
        weekDate := Trim(weekDate)
        if (houseName == "" || weekDate == "")
            return false
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false
        this.EnsureRewardsWeekRollover()

        earned := this.GetEarnedTierIndices(contribution)
        if (skipSwatchTier) {
            filtered := []
            for _, tier in earned {
                if (tier != 5)
                    filtered.Push(tier)
            }
            earned := filtered
        }
        if (earned.Length == 0)
            return false

        rewards := this.NormalizeUnclaimedHouseRewards(this.profiles[idx]["unclaimedHouseRewards"])
        entryIdx := this.FindHouseRewardEntry(rewards, houseName, weekDate)
        changed := false
        if (entryIdx > 0) {
            entry := rewards[entryIdx]
            tiers := entry.Has("tiers") && (entry["tiers"] is Array) ? entry["tiers"] : []
            for _, tier in earned {
                if !this.ArrayContains(tiers, tier) {
                    tiers.Push(tier)
                    changed := true
                    if entry.Has("isClaimed") && entry["isClaimed"]
                        entry["isClaimed"] := false
                }
            }
            if changed
                entry["tiers"] := tiers
            prevItems := entry.Has("items") && (entry["items"] is Array) ? entry["items"].Length : 0
            this.SyncEarnedRewardItems(entry, houseName, tiers, weekDate)
            if (entry.Has("items") && (entry["items"] is Array) && entry["items"].Length != prevItems)
                changed := true
        } else {
            rewards.Push(Map(
                "house", houseName,
                "week", weekDate,
                "tiers", earned,
                "items", [],
                "isClaimed", false
            ))
            this.SyncEarnedRewardItems(rewards[rewards.Length], houseName, earned, weekDate)
            changed := true
        }
        if !changed
            return false
        this.profiles[idx]["unclaimedHouseRewards"] := rewards
        this.SaveProfilesFile()
        return true
    }

    SyncAllHouseRewardTiersFromContribution(contrib) {
        if !(contrib is Map)
            return false
        weekDate := contrib.Has("date") ? Trim(contrib["date"]) : ""
        if (weekDate == "" || !this.IsLandsraadWeekCurrent(weekDate))
            return false
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return false
        for _, entry in houses {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            if (houseName == "")
                continue
            try {
                cont := Integer(entry.Has("cont") ? entry["cont"] : 0)
            } catch {
                cont := 0
            }
            this.SyncHouseRewardTiers(houseName, cont, weekDate, this.IsHouseSwatchOwned(houseName))
        }
        return true
    }

    ClaimHouseRewards(houseName, weekDate := "") {
        houseName := Trim(houseName)
        if (houseName == "")
            return false
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false
        currentWeek := this.GetCurrentLandsraadWeekDate()
        if (currentWeek == "")
            return false

        rewards := this.NormalizeUnclaimedHouseRewards(this.profiles[idx]["unclaimedHouseRewards"])
        newRewards := []
        changed := false
        foundCurrentWeek := false

        for _, entry in rewards {
            if !(entry is Map) {
                continue
            }
            entryHouse := Trim(entry["house"])
            entryWeek := entry.Has("week") ? Trim(entry["week"]) : ""

            if (entryHouse != houseName) {
                newRewards.Push(entry)
                continue
            }

            if (weekDate != "" && entryWeek != weekDate) {
                newRewards.Push(entry)
                continue
            }

            if (entryWeek == currentWeek) {
                foundCurrentWeek := true
                if !(entry.Has("isClaimed") && entry["isClaimed"]) {
                    entry["isClaimed"] := true
                    changed := true
                }
                newRewards.Push(entry)
            } else if (entryWeek != "" && StrCompare(entryWeek, currentWeek) < 0) {
                changed := true
            } else {
                newRewards.Push(entry)
            }
        }

        if !foundCurrentWeek
            return false
        if !changed
            return false

        this.profiles[idx]["unclaimedHouseRewards"] := newRewards
        this.SaveProfilesFile()
        return true
    }

    ResetHouseRewards() {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false
        this.profiles[idx]["unclaimedHouseRewards"] := []
        this.profiles[idx]["rewardsLastKnownWeek"] := ""
        this.SaveProfilesFile()
        return true
    }

    FormatRewardTierLabel(tierIndex) {
        tiers := this.GetLandsraadContributionTiers()
        try {
            idx := Integer(tierIndex)
        } catch {
            return "T?"
        }
        if (idx < 1 || idx > tiers.Length)
            return "T?"
        return "T" idx " (" this.FormatContributionAmount(tiers[idx]) ")"
    }

    FormatContributionAmount(amount) {
        try {
            n := Integer(amount)
        } catch {
            return "0"
        }
        if (n < 0)
            n := 0
        return Format("{:L}", n)
    }

    ClearLandsraadWeeklyData() {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false
        existing := this.NormalizeLandsraadContribution(
            this.profiles[idx].Has("landsraad_contribution")
                ? this.profiles[idx]["landsraad_contribution"]
                : "")
        swatchOwned := existing["swatchOwned"]
        this.profiles[idx]["landsraad_contribution"] := this.GetDefaultLandsraadContribution()
        this.profiles[idx]["landsraad_contribution"]["swatchOwned"] := swatchOwned
        this.profiles[idx]["lastLandsraadScan"] := ""
        this.SaveProfilesFile()
        return true
    }

    NormalizeProfileSettings(settingsMap, settingsManagerInst) {
        if !IsObject(settingsManagerInst)
            return Map()
        return settingsManagerInst.MergeProfileSettings((settingsMap is Map) ? settingsMap : Map())
    }

    GetCurrent() {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1 && this.profiles.Length > 0)
            return this.profiles[1]
        if (idx < 1)
            return ""
        return this.profiles[idx]
    }

    GetCurrentName() {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return "Default"
        name := profile["characterName"]
        return (name != "") ? name : "Default"
    }

    GetProfileNames() {
        names := []
        for _, profile in this.profiles
            names.Push(profile["characterName"])
        return names
    }

    GetCurrentIndex() {
        idx := this.FindIndexById(this.currentId)
        return (idx > 0) ? idx : 1
    }

    FindIndexById(id) {
        for idx, profile in this.profiles {
            if (profile["id"] == id)
                return idx
        }
        return 0
    }

    FindIndexByName(characterName) {
        needle := StrLower(Trim(characterName))
        for idx, profile in this.profiles {
            if (StrLower(profile["characterName"]) == needle)
                return idx
        }
        return 0
    }

    CaptureCurrentState(stateManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return
        this.profiles[idx]["state"] := stateManagerInst.ClonePlayerState()
    }

    CaptureCurrentSettings(settingsManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1 || !IsObject(settingsManagerInst))
            return
        this.profiles[idx]["settings"] := settingsManagerInst.ExportProfileSettings()
        this.SaveProfilesFile()
    }

    ApplyCurrentToState(stateManagerInst) {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return
        state := profile.Has("state") ? profile["state"] : Map()
        stateManagerInst.ApplyPlayerState((state is Map) ? JSON.Parse(JSON.Stringify(state)) : Map())
    }

    ApplyCurrentSettings(settingsManagerInst) {
        profile := this.GetCurrent()
        if !IsObject(profile) || !IsObject(settingsManagerInst)
            return
        settings := profile.Has("settings") ? profile["settings"] : Map()
        settingsManagerInst.ImportProfileSettings((settings is Map) ? settings : Map())
    }

    SyncSettings(settingsManagerInst) {
        if !IsObject(settingsManagerInst)
            return
        settingsManagerInst.settings["currentProfileId"] := this.currentId
        settingsManagerInst.settings["characterName"] := this.GetCurrentName()
        settingsManagerInst.SaveSettings()
    }

    SaveAll(stateManagerInst, settingsManagerInst := "") {
        this.CaptureCurrentState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.CaptureCurrentSettings(settingsManagerInst)
        this.SaveProfilesFile()
        stateManagerInst.SavePlayerState()
    }

    SwitchToIndex(index, stateManagerInst, settingsManagerInst) {
        if (index < 1 || index > this.profiles.Length)
            return false
        this.CaptureCurrentState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.CaptureCurrentSettings(settingsManagerInst)
        this.currentId := this.profiles[index]["id"]
        this.ApplyCurrentToState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.ApplyCurrentSettings(settingsManagerInst)
        this.SyncSettings(settingsManagerInst)
        stateManagerInst.SavePlayerState()
        this.SaveProfilesFile()
        return true
    }

    RenameCurrent(newName, settingsManagerInst) {
        name := Trim(newName)
        if (name == "")
            return false
        other := this.FindIndexByName(name)
        currentIdx := this.FindIndexById(this.currentId)
        if (other > 0 && other != currentIdx)
            return false
        if (currentIdx < 1)
            return false
        this.profiles[currentIdx]["characterName"] := name
        this.SyncSettings(settingsManagerInst)
        this.SaveProfilesFile()
        return true
    }

    CreateProfile(characterName, stateManagerInst, settingsManagerInst) {
        name := Trim(characterName)
        if (name == "")
            return false
        if (this.FindIndexByName(name) > 0)
            return false

        this.CaptureCurrentState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.CaptureCurrentSettings(settingsManagerInst)

        newId := "p" FormatTime(A_Now, "yyyyMMddHHmmss") A_TickCount
        emptyState := stateManagerInst.GetDefaultPlayerState()
        defaultSettings := IsObject(settingsManagerInst)
            ? settingsManagerInst.GetFreshProfileSettings()
            : Map()
        huntedRewards := this.GetDefaultProfileHuntedRewards()
        this.profiles.Push(this.MakeProfile(newId, name, emptyState, defaultSettings, settingsManagerInst,
            "", "", "", "", huntedRewards))
        this.currentId := newId
        this.ApplyCurrentToState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.ApplyCurrentSettings(settingsManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveAll(stateManagerInst, settingsManagerInst)
        return true
    }

    CreateDefaultProfile(stateManagerInst, settingsManagerInst) {
        defaultSettings := IsObject(settingsManagerInst)
            ? settingsManagerInst.GetFreshProfileSettings()
            : Map()
        charName := defaultSettings.Has("characterName") ? Trim(defaultSettings["characterName"]) : "player"
        if (charName == "")
            charName := "player"
        defaultSettings["characterName"] := charName

        emptyState := stateManagerInst.GetDefaultPlayerState()
        huntedRewards := this.LoadHuntedRewardsFromDefaultsFile()
        this.profiles.Push(this.MakeProfile("default", charName, emptyState, defaultSettings, settingsManagerInst,
            "", "", "", "", huntedRewards))
        this.currentId := "default"
    }

    DeleteCurrentProfile(stateManagerInst, settingsManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return { success: false, createdDefault: false }

        this.CaptureCurrentState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.CaptureCurrentSettings(settingsManagerInst)

        this.profiles.RemoveAt(idx)
        createdDefault := false
        if (this.profiles.Length == 0) {
            this.CreateDefaultProfile(stateManagerInst, settingsManagerInst)
            createdDefault := true
        } else {
            newIndex := Min(idx, this.profiles.Length)
            if (newIndex < 1)
                newIndex := 1
            this.currentId := this.profiles[newIndex]["id"]
        }

        this.ApplyCurrentToState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.ApplyCurrentSettings(settingsManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveAll(stateManagerInst, settingsManagerInst)
        return { success: true, createdDefault: createdDefault }
    }

    ResetCurrentProfileSettings(settingsManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1 || !IsObject(settingsManagerInst))
            return false
        this.profiles[idx]["settings"] := settingsManagerInst.GetFreshProfileSettings()
        settingsManagerInst.ImportProfileSettings(this.profiles[idx]["settings"])
        this.SaveProfilesFile()
        return true
    }

    ResetCurrent(stateManagerInst, settingsManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false

        name := "player"
        n := 2
        while (this.FindIndexByName(name) > 0 && this.FindIndexByName(name) != idx) {
            name := "player " n
            n++
        }
        this.profiles[idx]["characterName"] := name
        this.profiles[idx]["state"] := stateManagerInst.GetDefaultPlayerState()
        if IsObject(settingsManagerInst)
            this.profiles[idx]["settings"] := settingsManagerInst.GetFreshProfileSettings()
        this.ApplyCurrentToState(stateManagerInst)
        if IsObject(settingsManagerInst)
            this.ApplyCurrentSettings(settingsManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveAll(stateManagerInst, settingsManagerInst)
        return true
    }
}
