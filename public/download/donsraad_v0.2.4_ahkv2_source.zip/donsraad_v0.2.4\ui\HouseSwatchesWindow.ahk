#Requires AutoHotkey v2.0+

/**
 * Browse all houses and mark which cosmetic swatches are already owned.
 */
class HouseSwatchesWindow {
    static dlg := ""
    static profileManager := ""
    static houseChecks := Map()
    static onChanged := ""
    static pad := 16
    static cols := 3
    static colGap := 12
    static rowGap := 4
    static rowH := 22

    static Show(ownerGui := "", profileManagerInst := "", stateManagerInst := "", onChanged := "") {
        this.profileManager := profileManagerInst
        this.onChanged := onChanged

        if IsObject(this.dlg) {
            try {
                this.RefreshChecks()
                this.dlg.Show()
                return
            } catch {
                this.Close()
            }
        }

        houses := this.GetHouseNames(stateManagerInst)
        if (houses.Length == 0)
            return

        pad := this.pad
        cols := this.cols
        colGap := this.colGap
        rowH := this.rowH
        rowGap := this.rowGap
        winW := 680
        contentW := winW - (pad * 2)
        colW := (contentW - (colGap * (cols - 1))) // cols
        footerH := 40

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "House Swatches")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        dlg.SetFont("s12 bold cE4E4E7", "Segoe UI")
        dlg.Add("Text", "x" pad " y" pad " w" contentW " h24 BackgroundTrans", "Owned house swatches")
        dlg.SetFont("s9 cA1A1AA", "Segoe UI")
        dlg.Add("Text", "x" pad " y" (pad + 26) " w" contentW " h18 BackgroundTrans",
            houses.Length " houses · check each swatch you already own")

        gridY := pad + 52
        this.houseChecks := Map()
        col := 0
        row := 0
        dlg.SetFont("s9 cE4E4E7", "Segoe UI")
        for _, houseName in houses {
            x := pad + col * (colW + colGap)
            y := gridY + row * (rowH + rowGap)
            checked := this.IsSwatchOwned(houseName) ? 1 : 0
            box := dlg.Add("Checkbox", "x" x " y" y " w" colW " h" rowH " Checked" checked, houseName)
            box.Value := checked
            box.OnEvent("Click", this.MakeToggleHandler(houseName))
            this.houseChecks[houseName] := box

            col++
            if (col >= cols) {
                col := 0
                row++
            }
        }

        rows := row + (col > 0 ? 1 : 0)
        gridH := rows > 0 ? rows * (rowH + rowGap) - rowGap : 0
        footerY := gridY + gridH + 12

        dlg.Add("Text", "x" pad " y" footerY " w" contentW " h" footerH " +0x200 BackgroundTrans",
            "Reaching 14,000 contribution with a house automatically marks its swatch as owned.")

        winH := footerY + footerH + pad
        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("w" winW " h" winH " Center")
    }

    static GetHouseNames(stateManagerInst) {
        entries := []
        if IsObject(stateManagerInst) && (stateManagerInst.allHousesList is Array)
        && stateManagerInst.allHousesList.Length > 0
            entries := stateManagerInst.allHousesList
        else {
            dbPath := A_ScriptDir "\db\landsraad_houses.json"
            if FileExist(dbPath) {
                try {
                    parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
                    if (parsed is Array)
                        entries := parsed
                }
            }
        }

        names := []
        for _, entry in entries {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := Trim(entry["house"])
            if (houseName != "")
                names.Push(houseName)
        }
        if (names.Length < 2)
            return names

        loop names.Length - 1 {
            swapped := false
            loop names.Length - A_Index {
                i := A_Index
                if (StrCompare(names[i], names[i + 1], true) > 0) {
                    temp := names[i]
                    names[i] := names[i + 1]
                    names[i + 1] := temp
                    swapped := true
                }
            }
            if !swapped
                break
        }
        return names
    }

    static IsSwatchOwned(houseName) {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("IsHouseSwatchOwned")
            return false
        return this.profileManager.IsHouseSwatchOwned(houseName)
    }

    static MakeToggleHandler(houseName) {
        return (ctrl, *) => this.OnToggle(houseName, ctrl)
    }

    static OnToggle(houseName, ctrl) {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("SetHouseSwatchOwned")
            return
        owned := IsObject(ctrl) && ctrl.Value
        this.profileManager.SetHouseSwatchOwned(houseName, owned)
        if IsObject(this.onChanged) {
            try this.onChanged.Call()
            catch {
            }
        }
    }

    static RefreshChecks() {
        for houseName, box in this.houseChecks {
            if !IsObject(box)
                continue
            checked := this.IsSwatchOwned(houseName) ? 1 : 0
            box.Value := checked
        }
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.profileManager := ""
        this.houseChecks := Map()
        this.onChanged := ""
    }
}
