#Requires AutoHotkey v2.0+

; Single source of truth for the app version.
; Bump AppInfo.Version when releasing. build.ps1 reads it for dist\Donsraad-<version>\
; and for the compiled exe file version.
;@Ahk2Exe-SetVersion 0.2.4
class AppInfo {
    static Version := "0.2.4"
}
