#Requires AutoHotkey v2.0+

/**
 * Debug helper: read the Landsraad contribution value from the mission
 * complete / claim reward panel.
 *
 * Assumes the reward panel is ALREADY open — this debug does no navigation
 * and no clicks. Bound to Numpad0 (see main.ahk).
 *
 * Mirrors AcceptCompleteMissionsScenario.ReadClaimContribution():
 *   1. ImageSearch landsraad_contribution_icon.png (tan-glyph mask) inside
 *      ClaimMissionContributionIconSearchArea only.
 *   2. OCR box = icon match top-left + ClaimMissionContributionTextOffset,
 *      sized by ClaimMissionContributionTextArea.
 *   3. Ocr.FromHudRect -> Ocr.NormalizeText -> Ocr.ParseLandsraadContribution.
 *
 * Extra diagnostics beyond the production path (because "not found" is opaque):
 *   - logs scale / anchor folder / client rect and the REAL screen-pixel search box
 *   - logs template size + whether the cached *_masked.png is stale or reused
 *   - regenerates the mask (forceFreshMask) so a bad cached mask cannot hide the icon
 *   - retries the plain (unmasked) PNG if the masked search misses
 *   - retries the whole client area if the configured search box misses,
 *     and reports where the icon actually is
 *   - saves crop PNGs to debug_out\ so the region can be inspected visually
 */
class ClaimContributionDebug {
    overlays := []
    logger := ""
    anchorMatcher := ""
    contributionIconImage := "landsraad_contribution_icon.png"
    contributionIconVariation := 50
    forceFreshMask := true
    dumpCrops := true
    outputDir := ""

    __New(loggerInst := "", anchorMatcherInst := "") {
        this.overlays := []
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
    }

    Execute(*) {
        this.ClearOverlays()
        this.Log("[Claim Contribution] Reading contribution (assuming mission complete UI is open)...")

        try {
            area := this.GetIconSearchAreaConfig()
            if !IsObject(area) {
                this.Log("[Claim Contribution] ClaimMissionContribution constants are missing.")
                return false
            }

            this.LogLayout()
            this.LogTemplateInfo()
            maskPath := this.GetFreshMaskPath()

            searchArea := ResolutionManager().searchRect(area.x, area.y, area.w, area.h, 0)
            this.LogSearchArea(searchArea)
            this.ShowScreenOverlay(searchArea.x1, searchArea.y1
                , searchArea.x2 - searchArea.x1, searchArea.y2 - searchArea.y1)
            this.DumpCrop("1_configured_search_area", searchArea.x1, searchArea.y1
                , searchArea.x2 - searchArea.x1, searchArea.y2 - searchArea.y1)

            match := this.FindContributionIcon(searchArea, maskPath)

            if !IsObject(match) {
                fullArea := ResolutionManager().clientSearchArea()
                this.Log("[Claim Contribution] Not in configured area. Retrying whole client area...")
                match := this.FindContributionIcon(fullArea, maskPath)
                if IsObject(match)
                    this.Log("[Claim Contribution] Icon found OUTSIDE the configured area at ("
                        match.x ", " match.y ") via " match.source
                        " - the ClaimMissionContributionIconSearchArea constant is stale.")
            }

            if !IsObject(match) {
                this.Log("[Claim Contribution] Contribution icon NOT found anywhere (masked or plain).")
                this.Log("[Claim Contribution] Crop saved to debug_out - check whether the icon is visible at all.")
                return false
            }

            this.Debug("[Claim Contribution] Icon found at (" match.x ", " match.y ") via " match.source ".")
            iconSize := this.GetImageSize(this.contributionIconImage)
            if IsObject(iconSize)
                this.ShowScreenOverlay(match.x, match.y, iconSize.w, iconSize.h)
            this.DumpCrop("2_icon_match", match.x - 10, match.y - 10
                , (IsObject(iconSize) ? iconSize.w : 30) + 20, (IsObject(iconSize) ? iconSize.h : 30) + 20)

            box := this.BuildContributionTextBox(match.x, match.y)
            if !IsObject(box) {
                this.Log("[Claim Contribution] Could not build contribution OCR box.")
                return false
            }

            this.Debug("[Claim Contribution] OCR box [" box.screenX ", " box.screenY ", "
                box.screenW "x" box.screenH "].")
            this.ShowScreenOverlay(box.screenX, box.screenY, box.screenW, box.screenH)
            this.DumpCrop("3_ocr_box", box.screenX, box.screenY, box.screenW, box.screenH)

            ocrResult := Ocr.FromHudRect(box.screenX, box.screenY, box.screenW, box.screenH, this.GetOcrLanguage())
            rawText := ocrResult.text
            normalized := Ocr.NormalizeText(rawText)
            parsed := Ocr.ParseLandsraadContribution(normalized)

            this.Debug("[Claim Contribution] OCR raw: `"" rawText "`"")
            this.Debug("[Claim Contribution] OCR normalized: `"" normalized "`"")

            if parsed.found {
                this.Log("[Claim Contribution] cont: " parsed.value)
                this.Debug("[Claim Contribution] number=" parsed.number " value=" parsed.value)
                return true
            }

            this.Log("[Claim Contribution] failed to read cont.")
            this.LogOcrWordBreakdown(ocrResult)
            return false
        } catch as err {
            this.Log("[Claim Contribution] failed to read cont.")
            this.Debug("[Claim Contribution] Error: " err.Message " (" err.What ")")
            return false
        }
    }

    ; ------------------------------------------------------------------
    ; Search
    ; ------------------------------------------------------------------

    /**
     * Tries the masked glyph first (production path), then the plain PNG.
     * @returns {Object} { x, y, source } or "" when nothing matched.
     */
    FindContributionIcon(searchArea, maskPath) {
        foundX := 0, foundY := 0

        if (maskPath != "" && this.anchorMatcher.FindAnchor(maskPath, &foundX, &foundY
            , searchArea, this.contributionIconVariation, "White", false))
            return { x: foundX, y: foundY, source: "masked" }

        if this.anchorMatcher.FindAnchor(this.contributionIconImage, &foundX, &foundY
            , searchArea, this.contributionIconVariation, "Black", false)
            return { x: foundX, y: foundY, source: "plain TransBlack" }

        if this.anchorMatcher.FindAnchor(this.contributionIconImage, &foundX, &foundY
            , searchArea, this.contributionIconVariation, "White", false)
            return { x: foundX, y: foundY, source: "plain TransWhite" }

        return ""
    }

    GetIconSearchAreaConfig() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""
        ui := GameConstants["GameUI"]
        if !ui.Has("ClaimMissionContributionIconSearchArea")
            return ""
        return ui["ClaimMissionContributionIconSearchArea"]
    }

    BuildContributionTextBox(iconScreenX, iconScreenY) {
        global GameConstants
        ui := GameConstants["GameUI"]
        if !ui.Has("ClaimMissionContributionTextOffset") || !ui.Has("ClaimMissionContributionTextArea")
            return ""

        offset := ui["ClaimMissionContributionTextOffset"]
        area := ui["ClaimMissionContributionTextArea"]
        offsetX := offset.HasOwnProp("x") ? offset.x : offset["x"]
        offsetY := offset.HasOwnProp("y") ? offset.y : offset["y"]
        areaW := area.HasOwnProp("w") ? area.w : area["w"]
        areaH := area.HasOwnProp("h") ? area.h : area["h"]

        rm := ResolutionManager()
        textStart := rm.add(iconScreenX, iconScreenY, offsetX, offsetY)
        size := rm.dimensions(areaW, areaH)

        screenX := textStart.x
        screenY := textStart.y
        screenW := Max(1, Round(size.w))
        screenH := Max(1, Round(size.h))
        rm.ClampCapture(&screenX, &screenY, &screenW, &screenH)

        return {
            screenX: screenX,
            screenY: screenY,
            screenW: screenW,
            screenH: screenH
        }
    }

    ; ------------------------------------------------------------------
    ; Mask handling
    ; ------------------------------------------------------------------

    GetFreshMaskPath() {
        if this.forceFreshMask {
            maskedPath := this.GetCachedMaskPath()
            if (maskedPath != "" && FileExist(maskedPath)) {
                try FileDelete(maskedPath)
                this.Debug("[Claim Contribution] Deleted cached mask, regenerating: " maskedPath)
            }
        }
        maskPath := this.anchorMatcher.PrepareTanGlyphMask(this.contributionIconImage, "FFFFFF")
        if (maskPath == "")
            this.Log("[Claim Contribution] Mask preparation FAILED - production would never search a plain fallback here.")
        return maskPath
    }

    GetCachedMaskPath() {
        sourcePath := this.anchorMatcher.ResolveImagePath(this.contributionIconImage)
        if !FileExist(sourcePath)
            return ""
        SplitPath(sourcePath, &fileName, &dir, &ext, &nameNoExt)
        return dir "\" nameNoExt "_masked." ext
    }

    ; ------------------------------------------------------------------
    ; Logging
    ; ------------------------------------------------------------------

    LogLayout() {
        rm := ResolutionManager()
        client := rm.clientSearchArea()
        this.Debug("[Claim Contribution] Client [" client.x1 ", " client.y1 ", "
            client.x2 ", " client.y2 "] anchors=" rm.AnchorFolder()
            " scale=" rm.scale " leftPad=" rm.leftPad " origin=(" rm.originX ", " rm.originY ")")
    }

    LogTemplateInfo() {
        sourcePath := this.anchorMatcher.ResolveImagePath(this.contributionIconImage)
        if !FileExist(sourcePath) {
            this.Log("[Claim Contribution] Template MISSING: " sourcePath)
            return
        }

        size := this.GetImageSize(this.contributionIconImage)
        sizeLabel := IsObject(size) ? (size.w "x" size.h) : "?"
        this.Debug("[Claim Contribution] Template: " sourcePath " (" sizeLabel ")")

        maskedPath := this.GetCachedMaskPath()
        if (maskedPath != "" && FileExist(maskedPath)) {
            srcTime := FileGetTime(sourcePath, "M")
            maskTime := FileGetTime(maskedPath, "M")
            state := (maskTime >= srcTime) ? "would be reused" : "stale, would be regenerated"
            this.Debug("[Claim Contribution] Cached mask: " maskedPath
                " (source mtime " srcTime ", mask mtime " maskTime " -> " state ")")
        } else
            this.Debug("[Claim Contribution] Cached mask: (none on disk)")
    }

    LogSearchArea(searchArea) {
        w := searchArea.x2 - searchArea.x1
        h := searchArea.y2 - searchArea.y1
        this.Debug("[Claim Contribution] Icon search area (screen px): ["
            searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "] (" w "x" h ")")
    }

    LogOcrWordBreakdown(ocrResult) {
        if !IsObject(ocrResult)
            return
        if (ocrResult.HasProp("lines") && ocrResult.lines is Array) {
            loop ocrResult.lines.Length
                this.Debug("[Claim Contribution] OCR line " A_Index ": `"" ocrResult.lines[A_Index] "`"")
        }
        if (ocrResult.HasProp("words") && ocrResult.words is Array) {
            for _, word in ocrResult.words {
                if !(word is Map) && !IsObject(word)
                    continue
                wText := word.HasProp("text") ? word.text : (word.Has("text") ? word["text"] : "")
                wx := word.HasProp("x") ? word.x : (word.Has("x") ? word["x"] : 0)
                wy := word.HasProp("y") ? word.y : (word.Has("y") ? word["y"] : 0)
                this.Debug("[Claim Contribution] OCR word: `"" wText "`" @ (" Round(wx) ", " Round(wy) ")")
            }
        }
    }

    ; ------------------------------------------------------------------
    ; Overlays & crops
    ; ------------------------------------------------------------------

    DumpCrop(label, x, y, w, h) {
        if !this.dumpCrops
            return

        targetX := Round(x)
        targetY := Round(y)
        targetW := Max(1, Round(w))
        targetH := Max(1, Round(h))
        ResolutionManager().ClampCapture(&targetX, &targetY, &targetW, &targetH)

        pBitmap := Gdip_BitmapFromScreen(targetX, targetY, targetW, targetH)
        if !pBitmap
            return

        if (this.outputDir == "")
            this.outputDir := A_ScriptDir "\debug_out"
        ; Keep 1080p and 1440p captures apart so one session cannot clobber the other.
        folder := ResolutionManager().AnchorFolder()
        outDir := this.outputDir "\" folder
        DirCreate(outDir)

        outPath := outDir "\" label ".png"
        try FileDelete(outPath)
        Gdip_SaveBitmapToFile(pBitmap, outPath)
        Gdip_DisposeImage(pBitmap)
        this.Debug("[Claim Contribution] Crop saved: " outPath " [" targetX ", " targetY ", " targetW "x" targetH "]")
    }

    GetImageSize(imageName) {
        imagePath := this.anchorMatcher.ResolveImagePath(imageName)
        if !FileExist(imagePath)
            return ""

        pBitmap := Gdip_BitmapFromFile(imagePath)
        if !pBitmap
            return ""

        size := { w: Gdip_GetImageWidth(pBitmap), h: Gdip_GetImageHeight(pBitmap) }
        Gdip_DisposeImage(pBitmap)
        return size
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    ShowScreenOverlay(x, y, w, h) {
        overlay := RectangleOverlay()
        overlay.ShowAtScreen(x, y, w, h)
        this.overlays.Push(overlay)
    }

    ClearOverlays() {
        for _, overlay in this.overlays {
            if IsObject(overlay)
                overlay.Close()
        }
        this.overlays := []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
