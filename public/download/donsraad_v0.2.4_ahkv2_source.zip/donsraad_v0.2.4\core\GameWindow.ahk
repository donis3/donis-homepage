#Requires AutoHotkey v2.0+

/**
 * Locates the Dune: Awakening client. ImageSearch, OCR, and clicks use the
 * client rectangle (not the monitor), so windowed 1080p on a larger display works.
 */
class GameWindow {
    ; Process-name matchers, most specific first. The shipping client is
    ; DuneSandbox-Win64-Shipping.exe (verified on a live client); the others are kept as
    ; fallbacks for other builds. Process names cannot be spoofed by a window whose
    ; *text* merely contains a substring.
    static processTitles := [
        "ahk_exe DuneSandbox-Win64-Shipping.exe",
        "ahk_exe Dune-Win64-Shipping.exe",
        "ahk_exe Dune.exe"
    ]

    ; Whole-title fallback for builds whose exe name differs. The title is Trimmed before
    ; comparing: the live client's title is "Dune: Awakening  " with trailing spaces, so a
    ; raw "=" comparison against "Dune: Awakening" fails. Never match a substring instead -
    ; AHK's default title mode is substring, and a loose "Dune" matcher really does hit
    ; other windows (a live check found "dunetools [WSL: ubuntu] - Cursor" and
    ; "Diagonal Items | duners.win - Google Chrome"), which silently retargets ImageSearch,
    ; coordinate conversion and clicks at the wrong window.
    static exactTitles := [
        "Dune: Awakening",
        "Dune"
    ]

    static FindTitle() {
        ; A fullscreen game hides its window when it loses focus, and DetectHiddenWindows
        ; defaults to off - so without this the game cannot be found at the exact moment it
        ; needs re-activating. The setting is thread-local, so restoring it is safe.
        prevDetect := A_DetectHiddenWindows
        DetectHiddenWindows(true)
        try {
            for _, winTitle in this.processTitles {
                if WinExist(winTitle)
                    return winTitle
            }

            for hwnd in WinGetList() {
                try {
                    title := Trim(WinGetTitle("ahk_id " hwnd))
                    if (title == "")
                        continue
                    ; Only consider windows whose process is actually the game, so a window
                    ; that merely happens to be titled "Dune" can never be adopted.
                    if !InStr(WinGetProcessName("ahk_id " hwnd), "dune", false)
                        continue
                    for _, exactTitle in this.exactTitles {
                        if (title = exactTitle) {
                            this.LogFallback(title)
                            return "ahk_id " hwnd
                        }
                    }
                } catch {
                    continue
                }
            }
            return ""
        } finally {
            DetectHiddenWindows(prevDetect)
        }
    }

    /**
     * The process-name matchers missed, i.e. the exe name changed. Worth a log line
     * because every image search and click depends on resolving the right window.
     */
    static LogFallback(title) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[GameWindow] No process-name match; fell back to window title `""
                title "`". Update GameWindow.processTitles with the client's exe name.")
    }

    static GetHwnd() {
        title := this.FindTitle()
        if (title == "")
            return 0
        return WinExist(title)
    }

    /**
     * Client area in screen pixels (excludes title bar and borders).
     */
    static GetClient() {
        hwnd := this.GetHwnd()
        if !hwnd
            return ""
        x := 0, y := 0, w := 0, h := 0
        try {
            WinGetClientPos(&x, &y, &w, &h, hwnd)
        } catch {
            return ""
        }
        if (w < 2 || h < 2)
            return ""
        return {
            hwnd: hwnd,
            x: x,
            y: y,
            w: w,
            h: h
        }
    }

    static Activate(timeoutMs := 5000) {
        title := this.FindTitle()
        if (title == "")
            return false

        ; Verify rather than assume: a fullscreen mode switch can take a while to regain
        ; focus, and WinActivate only *requests* the switch, so a single WinWaitActive with
        ; a short timeout can report failure while the activation is still in flight. Every
        ; click depends on the game actually being foreground.
        deadline := A_TickCount + timeoutMs
        loop {
            try WinActivate(title)
            if this.IsActive()
                return true
            if (A_TickCount >= deadline)
                return false
            Sleep(100)
        }
    }

    /**
     * True when the Dune client exists and is the foreground window.
     */
    static IsActive() {
        hwnd := this.GetHwnd()
        if !hwnd
            return false
        try {
            return (WinGetID("A") == hwnd)
        } catch {
            return false
        }
    }

    /**
     * Foreground window as `"title" (process)` for failure logs. A click is lost when
     * focus moved elsewhere, and the log should show that directly rather than leaving
     * it to be inferred from a 27-second timeout.
     */
    static DescribeActiveWindow() {
        try {
            hwnd := WinGetID("A")
            if !hwnd
                return "(none)"
            return "`"" WinGetTitle("ahk_id " hwnd) "`" (" WinGetProcessName("ahk_id " hwnd) ")"
        } catch {
            return "(unavailable)"
        }
    }
}
