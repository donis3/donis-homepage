#Requires AutoHotkey v2.0+

/**
 * Debug helper: scan Landsraad house grid tooltips, OCR house rewards per cell,
 * match reward lines against db/landsraad_rewards.json, and log results.
 */
class HouseTooltipDebug {
    debugOverlays := []
    logger := ""
    scanner := ""
    openLandsraadGridScenario := ""
    gridSettleMs := 300
    tooltipWaitMs := 150
    houseTextMaxRetries := 2
    rewardsBandOcrMaxRetries := 2
    rewardsBandOcrRetryMs := 100
    debugTargetRow := 3
    debugTargetCol := 3

    __New(loggerInst := "", openLandsraadGridScenarioInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.logger := loggerInst
        this.openLandsraadGridScenario := openLandsraadGridScenarioInst
        this.scanner := HouseGridScanner(loggerInst, anchorMatcherInst, stateManagerInst)
        this.scanner.showDebugBoxes := false
    }

    ScanHouseGrid() {
        if IsObject(this.openLandsraadGridScenario)
            this.openLandsraadGridScenario.Execute()

        if (this.gridSettleMs > 0)
            Sleep(this.gridSettleMs)

        this.HideDebugOverlays()
        GameWindow.Activate()

        gridSize := this.scanner.GetGridSize()
        cellCount := gridSize * gridSize
        this.Log("[House Tooltip] Scanning " cellCount " cells...")

        loop gridSize {
            row := A_Index
            loop gridSize {
                col := A_Index
                this.ScanCellAt(row, col, false)
            }
        }

        this.HideDebugOverlays()
        this.Log("[House Tooltip] Grid scan complete.")
    }

    ScanFirstCell() {
        this.ScanHouseGrid()
    }

    ScanDebugTargetCell() {
        if IsObject(this.openLandsraadGridScenario)
            this.openLandsraadGridScenario.Execute()

        if (this.gridSettleMs > 0)
            Sleep(this.gridSettleMs)

        this.HideDebugOverlays()
        GameWindow.Activate()
        this.Log("[House Tooltip] Scanning debug cell (row " this.debugTargetRow ", col " this.debugTargetCol ")...")
        this.ScanCellAt(this.debugTargetRow, this.debugTargetCol, true)
    }

    ScanCellAt(gridRow, gridCol, showOverlay := false) {
        cell := this.scanner.GetGridCell(gridRow, gridCol)
        if !IsObject(cell) {
            this.Log("[House Tooltip] Slot ? (row " gridRow ", col " gridCol "): cell coordinates unavailable")
            return
        }

        slotLabel := "Slot " cell.slot " (row " cell.row ", col " cell.col ")"
        areas := this.scanner.GetTooltipSearchAreas(cell)
        if !IsObject(areas) {
            this.Log("[House Tooltip] " slotLabel ": tooltip search areas unavailable")
            return
        }

        match := this.FindHouseTextWithRetries(cell, areas)
        if !match.found {
            this.Log("[House Tooltip] " slotLabel ': "House not yet revealed"')
            return
        }

        houseResult := this.scanner.ReadHouseName(cell, match.foundX, match.foundY)
        houseLabel := this.FormatHouseLabel(houseResult)
        anchorX := match.foundX
        anchorY := match.foundY

        personalSearchBox := this.GetPersonalTextSearchBox(anchorX, anchorY)
        if !IsObject(personalSearchBox) {
            this.Log("[House Tooltip] " slotLabel ': "' houseLabel '" : personal search box unavailable')
            return
        }

        foundX := 0, foundY := 0
        if !this.scanner.FindPersonalTextInArea(personalSearchBox.searchArea, &foundX, &foundY) {
            this.Log("[House Tooltip] " slotLabel ': "' houseLabel '" : missions not revealed')
            if showOverlay
                this.ShowDebugBox(personalSearchBox.screenX, personalSearchBox.screenY
                    , personalSearchBox.screenW, personalSearchBox.screenH)
            return
        }

        rewardsBandBox := this.scanner.BuildRewardsBandBox(personalSearchBox, foundY)
        if !IsObject(rewardsBandBox) {
            this.Log("[House Tooltip] " slotLabel ': "' houseLabel '" : rewards band box unavailable')
            return
        }

        contribRowBox := this.scanner.BuildPersonalContributionRowBox(anchorX, foundY)
        contribResult := IsObject(contribRowBox) ? this.scanner.ReadOcrFromBox(contribRowBox) : ""
        contribLabel := this.FormatContributionLabel(contribResult)

        bandResult := this.scanner.ReadRewardsBandWithRetries(rewardsBandBox)
        bandOcr := bandResult.ocr
        this.Log("[House Tooltip] " slotLabel ': "' houseLabel '" : ' contribLabel)
        if showOverlay
            this.LogRewardsBandOcr(bandOcr)
        this.LogParsedHouseRewards(bandResult.parsed, "  ")

        if showOverlay {
            this.ShowDebugBox(rewardsBandBox.screenX, rewardsBandBox.screenY, rewardsBandBox.screenW, rewardsBandBox.screenH)
            this.Debug("[House Tooltip] Rewards band box ["
                rewardsBandBox.screenX ", " rewardsBandBox.screenY ", "
                rewardsBandBox.screenW ", " rewardsBandBox.screenH "] (personal match Y " foundY ").")
        }
    }

    FindHouseTextWithRetries(cell, areas) {
        match := { found: false }
        maxAttempts := this.houseTextMaxRetries + 1

        loop maxAttempts {
            if (A_Index > 1)
                this.Debug("[House Tooltip] Slot " cell.slot ": house text not found, retry "
                    (A_Index - 1) "/" this.houseTextMaxRetries " (right then left)...")
            this.HoverCellForTooltip(cell)
            match := this.scanner.TryFindHouseText(cell, areas)
            if match.found
                return match
        }
        return match
    }

    HoverCellForTooltip(cell) {
        this.Debug("[House Tooltip] Hovering cell row " cell.row " col " cell.col
            " (slot " cell.slot ") at (" cell.hoverX ", " cell.hoverY ").")
        InputHelper.FastMove(cell.hoverX, cell.hoverY)
        if (this.tooltipWaitMs > 0)
            Sleep(this.tooltipWaitMs)
    }

    FormatHouseLabel(houseResult) {
        if !IsObject(houseResult)
            return "(unknown)"

        if (houseResult.matchedName != "" && houseResult.confidence >= 0.4)
            return houseResult.matchedName
        if (houseResult.normalizedText != "")
            return houseResult.normalizedText
        return "(unknown)"
    }

    FormatContributionLabel(ocrResult) {
        if !IsObject(ocrResult)
            return "?"
        parsed := this.scanner.ParsePersonalContributionNumber(ocrResult.normalizedText)
        if parsed.found
            return parsed.value
        if (ocrResult.normalizedText != "")
            return "?"
        return "?"
    }

    GetPersonalTextSearchBox(anchorScreenX, anchorScreenY) {
        return this.scanner.BuildPersonalTextSearchBox(anchorScreenX, anchorScreenY)
    }

    LogRewardsBandOcr(ocrResult) {
        if !IsObject(ocrResult) {
            this.Log("[House Tooltip] Rewards band OCR: (error)")
            return
        }
        if (ocrResult.normalizedText == "") {
            this.Log("[House Tooltip] Rewards band OCR: (no text)")
            this.Debug("[House Tooltip] Rewards band raw OCR: (empty)")
            return
        }
        this.Debug("[House Tooltip] Rewards band OCR:`n" ocrResult.normalizedText)
        if (ocrResult.rawText != ocrResult.normalizedText)
            this.Debug("[House Tooltip] Rewards band raw OCR:`n" ocrResult.rawText)
    }

    LogParsedHouseRewards(parsedOrOcr, linePrefix := "[House Tooltip] ") {
        parsed := ""
        if IsObject(parsedOrOcr) && parsedOrOcr.HasProp("tiers")
            parsed := parsedOrOcr
        else if IsObject(parsedOrOcr) && parsedOrOcr.HasProp("normalizedText")
            parsed := Ocr.ParseHouseRewardTiers(parsedOrOcr.normalizedText)

        if !IsObject(parsed) || !parsed.found {
            if IsObject(parsedOrOcr) && parsedOrOcr.HasProp("normalizedText") && parsedOrOcr.normalizedText != ""
                this.Log(linePrefix "House rewards: (could not parse tiers from OCR)")
            return
        }

        for _, tier in parsed.tiers {
            if tier.matched
                this.Log(linePrefix "Tier " tier.reward_tier ": " tier.item_name " (" tier.item_id ")")
            else if (Trim(tier.ocrText) != "")
                this.Log(linePrefix "Tier " tier.reward_tier ": (unmatched) " tier.ocrText)
            else
                this.Log(linePrefix "Tier " tier.reward_tier ": (missing)")
        }

        if (parsed.tiers.Length < 4)
            loop (4 - parsed.tiers.Length)
                this.Log(linePrefix "Tier " (parsed.tiers.Length + A_Index) ": (missing)")
    }

    ShowDebugBox(screenX, screenY, screenW, screenH) {
        overlay := RectangleOverlay()
        overlay.ShowAtScreen(screenX, screenY, screenW, screenH)
        this.debugOverlays.Push(overlay)
    }

    HideDebugOverlays() {
        for _, overlay in this.debugOverlays {
            if IsObject(overlay)
                overlay.Close()
        }
        this.debugOverlays := []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
