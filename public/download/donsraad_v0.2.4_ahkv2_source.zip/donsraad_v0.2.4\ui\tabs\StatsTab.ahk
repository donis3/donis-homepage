#Requires AutoHotkey v2.0+

class StatsTab extends GuiPage {
    specs := ["Crafting", "Gathering", "Exploration", "Combat", "Sabotage"]
    specButtons := []
    activeSpec := "Crafting"
    summaryText := ""
    statsAbandons := ""
    statsAccepts := ""
    statsMnemonic := ""
    rowCards := []
    maxRows := 10
    pageIndex := 1
    pageLabel := ""
    prevPageBtn := ""
    nextPageBtn := ""

    __New(hostGui) {
        super.__New(hostGui, 4)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        headerBtnH := 28
        resetW := 120
        helpW := 28
        btnGap := 10
        resetX := m + cardW - resetW
        helpX := resetX - btnGap - helpW
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" (helpX - m - 8) " h28 +0x200 BackgroundTrans", "Mission stats"))
        this.AddTextButton(4, helpX, y, helpW, headerBtnH, "?", (*) => TabHelpDialog.Show(this.guiObj, "stats"))
        this.AddTextButton(4, resetX, y, resetW, headerBtnH, "Reset stats", (*) => this.OnResetStats())
        y += 32

        totalsH := 56
        gap := 12
        thirdW := (cardW - gap * 2) // 3
        col2 := m + thirdW + gap
        col3 := col2 + thirdW + gap
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" thirdW " h" totalsH " Background" this.surfaceColor))
        this.PageAdd(4, g.Add("Text", "x" col2 " y" y " w" thirdW " h" totalsH " Background" this.surfaceColor))
        this.PageAdd(4, g.Add("Text", "x" col3 " y" y " w" thirdW " h" totalsH " Background" this.surfaceColor))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(4, g.Add("Text",
            "x" (m + 16) " y" (y + 10) " w" (thirdW - 32) " h16 BackgroundTrans", "Total abandons"))
        this.PageAdd(4, g.Add("Text",
            "x" (col2 + 16) " y" (y + 10) " w" (thirdW - 32) " h16 BackgroundTrans", "Target missions accepted"))
        this.PageAdd(4, g.Add("Text",
            "x" (col3 + 16) " y" (y + 10) " w" (thirdW - 32) " h16 BackgroundTrans", "Mnemonic devices spent"))
        g.SetFont("s12 bold cEAB308", "Segoe UI")
        this.statsAbandons := this.PageAdd(4, g.Add("Text",
            "x" (m + 16) " y" (y + 28) " w" (thirdW - 32) " h22 BackgroundTrans", "0"))
        this.statsAccepts := this.PageAdd(4, g.Add("Text",
            "x" (col2 + 16) " y" (y + 28) " w" (thirdW - 32) " h22 BackgroundTrans", "0"))
        this.statsMnemonic := this.PageAdd(4, g.Add("Text",
            "x" (col3 + 16) " y" (y + 28) " w" (thirdW - 32) " h22 BackgroundTrans", "0"))
        y += totalsH + 12

        btnGap := 8
        btnW := (cardW - (this.specs.Length - 1) * btnGap) // this.specs.Length
        this.specButtons := []
        loop this.specs.Length {
            idx := A_Index
            spec := this.specs[idx]
            x := m + (idx - 1) * (btnW + btnGap)
            g.SetFont("s9 cA1A1AA", "Segoe UI")
            btn := this.PageAdd(4, g.Add("Text",
                "x" x " y" y " w" btnW " h30 Center +0x200 Background" this.surfaceColor, spec))
            btn.OnEvent("Click", this.MakeSpecHandler(spec))
            this.specButtons.Push({ spec: spec, btn: btn })
        }
        y += 42

        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" cardW " h48 Background" this.surfaceColor))
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w4 h48 BackgroundEAB308"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.summaryText := this.PageAdd(4, g.Add("Text",
            "x" (m + 16) " y" (y + 14) " w" (cardW - 28) " h20 BackgroundTrans", ""))
        y += 60

        g.SetFont("s8 bold c52525B", "Segoe UI")
        colW := 72
        availW := 108
        colGap := 12
        rightEdge := m + cardW - 16
        revealX := rightEdge - availW
        bestX := revealX - colGap - colW
        doneX := bestX - colGap - colW
        nameW := doneX - (m + 16) - colGap
        this.PageAdd(4, g.Add("Text", "x" (m + 16) " y" y " w" nameW " h16 BackgroundTrans", "MISSION"))
        this.PageAdd(4, g.Add("Text", "x" doneX " y" y " w" colW " h16 +0x2 BackgroundTrans", "DONE"))
        this.PageAdd(4, g.Add("Text", "x" bestX " y" y " w" colW " h16 +0x2 BackgroundTrans", "BEST"))
        this.PageAdd(4, g.Add("Text", "x" revealX " y" y " w" availW " h16 +0x2 BackgroundTrans", "AVAILABILITY"))
        y += 22

        rowH := 38
        rowGap := 5
        pagerH := 34
        footerTop := this.winH - 36
        rowsStartY := y
        availRowsH := footerTop - 10 - pagerH - rowsStartY
        rowUnit := rowH + rowGap
        this.maxRows := availRowsH // rowUnit
        if (this.maxRows < 4)
            this.maxRows := 4
        if (this.maxRows > 10)
            this.maxRows := 10

        this.rowCards := []
        loop this.maxRows {
            ry := y + (A_Index - 1) * (rowH + rowGap)
            bg := this.PageAdd(4, g.Add("Text",
                "x" m " y" ry " w" cardW " h" rowH " Background" this.surfaceColor))
            g.SetFont("s10 bold cE4E4E7", "Segoe UI")
            nameCtl := this.PageAdd(4, g.Add("Text",
                "x" (m + 16) " y" (ry + 10) " w" nameW " h20 BackgroundTrans", ""))
            g.SetFont("s10 bold cEAB308", "Segoe UI")
            doneCtl := this.PageAdd(4, g.Add("Text",
                "x" doneX " y" (ry + 10) " w" colW " h20 +0x2 BackgroundTrans", ""))
            g.SetFont("s10 bold cA1A1AA", "Segoe UI")
            bestCtl := this.PageAdd(4, g.Add("Text",
                "x" bestX " y" (ry + 10) " w" colW " h20 +0x2 BackgroundTrans", ""))
            g.SetFont("s10 bold cA1A1AA", "Segoe UI")
            huntCtl := this.PageAdd(4, g.Add("Text",
                "x" revealX " y" (ry + 10) " w" availW " h20 +0x2 BackgroundTrans", ""))
            this.rowCards.Push({ bg: bg, name: nameCtl, done: doneCtl, best: bestCtl, hunt: huntCtl })
        }

        pagerY := y + this.maxRows * (rowH + rowGap) - rowGap + 8
        pagerBtnW := 72
        this.prevPageBtn := this.AddTextButton(4, m + cardW - 232, pagerY, pagerBtnW, 26,
            "Prev", (*) => this.OnPrevPage())
        g.SetFont("s9 bold cA1A1AA", "Segoe UI")
        this.pageLabel := this.PageAdd(4, g.Add("Text",
            "x" (m + cardW - 152) " y" pagerY " w68 h26 Center +0x200 BackgroundTrans", "1 / 1"))
        this.nextPageBtn := this.AddTextButton(4, m + cardW - pagerBtnW, pagerY, pagerBtnW, 26,
            "Next", (*) => this.OnNextPage())

        this.PaintSpecButtons()
        this.Refresh()
    }

    MakeSpecHandler(spec) {
        return (*) => this.ShowSpec(spec)
    }

    OnResetStats() {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("ResetStats")
            return
        this.stateManager.ResetStats()
        this.Refresh()
        this.ShowSessionHint()
        this.SetStatus("Stats reset.")
    }

    ShowSpec(spec) {
        this.activeSpec := spec
        this.pageIndex := 1
        this.PaintSpecButtons()
        this.Refresh()
    }

    OnPrevPage() {
        if (this.pageIndex <= 1)
            return
        this.pageIndex -= 1
        this.Refresh()
    }

    OnNextPage() {
        if (this.pageIndex >= this.PageCount(this.CurrentRowCount()))
            return
        this.pageIndex += 1
        this.Refresh()
    }

    CurrentRowCount() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetMissionStatsForSpec")
            return this.stateManager.GetMissionStatsForSpec(this.activeSpec).Length
        return 0
    }

    PageCount(totalRows) {
        if (totalRows <= 0)
            return 1
        return (totalRows + this.maxRows - 1) // this.maxRows
    }

    PaintSpecButtons() {
        for _, entry in this.specButtons {
            btn := entry.btn
            if (entry.spec == this.activeSpec) {
                btn.Opt("BackgroundEAB308")
                btn.SetFont("s9 bold c18181B", "Segoe UI")
            } else {
                btn.Opt("Background" this.surfaceColor)
                btn.SetFont("s9 cA1A1AA", "Segoe UI")
            }
            btn.Redraw()
        }
    }

    Refresh() {
        rows := []
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetMissionStatsForSpec")
            rows := this.stateManager.GetMissionStatsForSpec(this.activeSpec)

        totalDone := 0
        withBest := 0
        withHunt := 0
        for _, entry in rows {
            done := 0
            best := 0
            try done := Integer(entry.Has("completedCount") ? entry["completedCount"] : 0)
            try best := Integer(entry.Has("bestRunTime") ? entry["bestRunTime"] : 0)
            totalDone += done
            if (best > 0)
                withBest += 1
            if (this.HuntSampleCount(entry) > 0)
                withHunt += 1
        }

        if IsObject(this.summaryText) {
            this.summaryText.Text := this.activeSpec "  ·  " rows.Length " missions  ·  "
                . totalDone " completes  ·  " withBest " with a best time  ·  "
                . withHunt " with availability"
            this.summaryText.SetFont("s9 bold cE4E4E7", "Segoe UI")
        }

        abandons := 0
        accepts := 0
        mnemonicSpent := 0
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetStat") {
            abandons := this.stateManager.GetStat("guildAbandons")
            accepts := this.stateManager.GetStat("targettedAccepts")
            mnemonicSpent := this.stateManager.GetStat("mnemonicDevicesSpent")
        }
        if IsObject(this.statsAbandons)
            this.statsAbandons.Text := abandons
        if IsObject(this.statsAccepts)
            this.statsAccepts.Text := accepts
        if IsObject(this.statsMnemonic)
            this.statsMnemonic.Text := mnemonicSpent

        pageCount := this.PageCount(rows.Length)
        if (this.pageIndex > pageCount)
            this.pageIndex := pageCount
        if (this.pageIndex < 1)
            this.pageIndex := 1
        start := (this.pageIndex - 1) * this.maxRows

        if IsObject(this.pageLabel)
            this.pageLabel.Text := this.pageIndex " / " pageCount
        this.SetTextButtonState(this.prevPageBtn, this.pageIndex > 1)
        this.SetTextButtonState(this.nextPageBtn, this.pageIndex < pageCount)

        loop this.maxRows {
            idx := A_Index
            card := this.rowCards[idx]
            srcIdx := start + idx
            if (srcIdx > rows.Length) {
                card.bg.Visible := false
                card.name.Visible := false
                card.done.Visible := false
                card.best.Visible := false
                card.hunt.Visible := false
                continue
            }
            entry := rows[srcIdx]
            name := entry.Has("name") ? entry["name"] : ""
            done := 0
            best := 0
            try done := Integer(entry.Has("completedCount") ? entry["completedCount"] : 0)
            try best := Integer(entry.Has("bestRunTime") ? entry["bestRunTime"] : 0)
            huntText := this.FormatAvailability(entry)
            card.name.Text := name
            card.done.Text := done
            card.best.Text := this.FormatBest(best)
            card.hunt.Text := huntText
            if (done > 0)
                card.done.SetFont("s10 bold cEAB308", "Segoe UI")
            else
                card.done.SetFont("s10 bold c52525B", "Segoe UI")
            if (best > 0)
                card.best.SetFont("s10 bold c4ADE80", "Segoe UI")
            else
                card.best.SetFont("s10 bold c52525B", "Segoe UI")
            if (huntText != "--")
                card.hunt.SetFont("s10 bold c38BDF8", "Segoe UI")
            else
                card.hunt.SetFont("s10 bold c52525B", "Segoe UI")
            show := (this.activeTab == this.pageId)
            card.bg.Visible := show
            card.name.Visible := show
            card.done.Visible := show
            card.best.Visible := show
            card.hunt.Visible := show
        }
    }

    HuntSampleCount(entry) {
        if !(entry is Map) || !entry.Has("abandonsUntilReveal")
            return 0
        history := entry["abandonsUntilReveal"]
        if !(history is Array)
            return 0
        return history.Length
    }

    FormatAvailability(entry) {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetMissionAvailabilityText") {
            text := this.stateManager.GetMissionAvailabilityText(entry)
            if (text != "")
                return text
        }
        return "--"
    }

    FormatBest(totalSeconds) {
        sec := Integer(totalSeconds)
        if (sec <= 0)
            return "--:--"
        minutes := sec // 60
        seconds := Mod(sec, 60)
        minText := (minutes < 10) ? "0" minutes : minutes
        secText := (seconds < 10) ? "0" seconds : seconds
        return minText ":" secText
    }
}
