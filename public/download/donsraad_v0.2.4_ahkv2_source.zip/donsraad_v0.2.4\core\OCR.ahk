#Requires AutoHotkey v2.0+

/**
 * Ultra-high-performance Windows 10/11 native WinRT OCR engine for AutoHotkey v2.
 * 
 * Uses Windows.Media.Ocr via direct WinRT COM interfaces with zero external CLI dependencies.
 * Passes in-memory screen buffers directly to the WinRT pipeline for sub-millisecond to low-millisecond execution.
 */
class Ocr {
    static isInitialized := false
    static cachedEngine := 0
    static cachedLang := ""

    ; Benchmark counters. Cheap A_TickCount bookkeeping; callers reset them per scan
    ; cell (Ocr.BenchReset) and read the delta so cost can be attributed to a phase.
    static benchEnabled := true
    static benchCallCount := 0
    static benchTotalMs := 0
    static benchPrepareMs := 0
    static benchRecognizeMs := 0

    /**
     * Initializes WinRT COM runtime if not already initialized.
     */
    static Init() {
        if (this.isInitialized)
            return
        ; RO_INIT_MULTITHREADED = 1
        DllCall("combase\RoInitialize", "int", 1)
        this.isInitialized := true
    }

    /**
     * Gets or creates a singleton IOcrEngine instance for the specified language tag.
     * @param {String} lang - e.g. "en-US", "en", or "" for user profile languages.
     * @returns {Ptr} - Pointer to IOcrEngine COM interface.
     */
    static GetEngine(lang := "en-US") {
        this.Init()

        if (this.cachedEngine && this.cachedLang == lang)
            return this.cachedEngine

        if (this.cachedEngine) {
            ObjRelease(this.cachedEngine)
            this.cachedEngine := 0
        }

        pOcrEngineStatics := this.GetActivationFactory("Windows.Media.Ocr.OcrEngine", "{5bffa85a-3384-3540-9940-699120d428a8}")
        pOcrEngine := 0

        if (lang != "") {
            try {
                pLangFactory := this.GetActivationFactory("Windows.Globalization.Language", "{9b0252ac-0c27-44f8-b792-9793fb66c63e}")
                hLangTag := this.CreateHString(lang)
                pLanguage := 0
                ; ILanguageFactory::CreateLanguage (Slot 6)
                ComCall(6, pLangFactory, "ptr", hLangTag, "ptr*", &pLanguage)
                this.DeleteHString(hLangTag)
                ObjRelease(pLangFactory)

                if (pLanguage) {
                    ; IOcrEngineStatics::TryCreateFromLanguage (Slot 9)
                    ComCall(9, pOcrEngineStatics, "ptr", pLanguage, "ptr*", &pOcrEngine)
                    ObjRelease(pLanguage)
                }
            } catch {
                pOcrEngine := 0
            }
        }

        ; Fallback to user profile languages if specific language not available
        usedProfileFallback := false
        if (!pOcrEngine) {
            usedProfileFallback := true
            ; IOcrEngineStatics::TryCreateFromUserProfileLanguages (Slot 10)
            ComCall(10, pOcrEngineStatics, "ptr*", &pOcrEngine)
        }

        ObjRelease(pOcrEngineStatics)

        if (!pOcrEngine)
            throw Error("Failed to initialize Windows OCR Engine. Please ensure Windows English OCR language pack is installed.")

        if (usedProfileFallback)
            this.Log("Language pack '" lang "' is unavailable, so the user-profile OCR language is "
                "being used instead. It can return non-English letters for English text (a Turkish "
                "profile reads capital 'I' as dotted capital I, U+0130); those are folded to ASCII "
                "by FoldLookalikeLetters, but installing the '" lang "' OCR language pack gives the "
                "most accurate reads.")

        this.cachedEngine := pOcrEngine
        this.cachedLang := lang
        return pOcrEngine
    }

    /**
     * Records one OCR call for the benchmark.
     * @param {Integer} start - Tick before the screen capture.
     * @param {Integer} captureEnd - Tick after capture + upscale/threshold (prepare).
     * @param {Integer} end - Tick after WinRT recognition.
     */
    static BenchRecord(start, captureEnd, end) {
        if !this.benchEnabled
            return
        this.benchCallCount++
        this.benchTotalMs += end - start
        this.benchPrepareMs += captureEnd - start
        this.benchRecognizeMs += end - captureEnd
    }

    static BenchReset() {
        this.benchCallCount := 0
        this.benchTotalMs := 0
        this.benchPrepareMs := 0
        this.benchRecognizeMs := 0
    }

    static BenchSnapshot() {
        return {
            calls: this.benchCallCount,
            totalMs: this.benchTotalMs,
            prepareMs: this.benchPrepareMs,
            recognizeMs: this.benchRecognizeMs
        }
    }

    /**
     * Performs OCR directly on a specific screen bounding box.
     * Captures only the targeted area into memory and runs WinRT OCR.
     * 
     * @param {Integer} x - Screen X coordinate.
     * @param {Integer} y - Screen Y coordinate.
     * @param {Integer} w - Width in pixels.
     * @param {Integer} h - Height in pixels.
     * @param {String} lang - Language tag (default "en-US").
     * @returns {Object} - { text: String, lines: Array, words: Array }
     */
    static FromRect(x, y, w, h, lang := "en-US") {
        benchStart := A_TickCount

        targetX := Round(x)
        targetY := Round(y)
        targetW := Max(1, Round(w))
        targetH := Max(1, Round(h))
        ResolutionManager().ClampCapture(&targetX, &targetY, &targetW, &targetH)

        pBitmap := Gdip_BitmapFromScreen(targetX, targetY, targetW, targetH)
        captureEnd := A_TickCount
        if (!pBitmap) {
            this.BenchRecord(benchStart, captureEnd, A_TickCount)
            return { text: "", lines: [], words: [] }
        }

        result := this.FromBitmap(pBitmap, lang)
        Gdip_DisposeImage(pBitmap)
        this.BenchRecord(benchStart, captureEnd, A_TickCount)
        return result
    }

    /**
     * OCR for small gold-on-dark HUD text. Pads, upscales, then thresholds to black-on-white.
     */
    static FromHudRect(x, y, w, h, lang := "en-US", scale := 4, pad := 10, lumaMin := 90) {
        benchStart := A_TickCount

        prepared := this.PrepareHudRect(x, y, w, h, scale, pad, lumaMin)
        prepareEnd := A_TickCount
        if (prepared == "") {
            this.BenchRecord(benchStart, prepareEnd, A_TickCount)
            return { text: "", lines: [], words: [] }
        }

        result := this.FromBitmap(prepared.pBitmap, lang)
        this.DisposePreparedHudRect(prepared)
        this.BenchRecord(benchStart, prepareEnd, A_TickCount)
        return result
    }

    /**
     * Screen rect actually captured for a HUD OCR read: the caller's box grown by
     * `pad` and clamped to the client. Single source of truth for both the capture
     * and the debug overlay, so a red box drawn on screen corresponds 1:1 to the
     * pixels the recognizer sees (the caller's box is NOT that region).
     */
    static HudCaptureRect(x, y, w, h, pad := 10) {
        targetX := Round(x) - pad
        targetY := Round(y) - pad
        targetW := Max(1, Round(w) + (pad * 2))
        targetH := Max(1, Round(h) + (pad * 2))
        ResolutionManager().ClampCapture(&targetX, &targetY, &targetW, &targetH)
        return { x: targetX, y: targetY, w: targetW, h: targetH }
    }

    /**
     * Captures a HUD rect, upscales it and thresholds it to black-on-white.
     * Shared by FromHudRect and DumpHudRect so the image written to disk is
     * produced by the same pipeline as the image the recognizer reads.
     * @returns {Object|String} - { pBitmap, pRaw, rect } or "" on failure.
     */
    static PrepareHudRect(x, y, w, h, scale := 4, pad := 10, lumaMin := 90) {
        rect := this.HudCaptureRect(x, y, w, h, pad)

        pRaw := Gdip_BitmapFromScreen(rect.x, rect.y, rect.w, rect.h)
        if (!pRaw)
            return ""

        pScaled := Gdip_ResizeBitmap(pRaw, scale)
        if (!pScaled) {
            Gdip_DisposeImage(pRaw)
            return ""
        }

        Gdip_PrepareHudTextForOcr(pScaled, lumaMin)
        return {
            pBitmap: pScaled,
            pRaw: pRaw,
            rect: rect
        }
    }

    static DisposePreparedHudRect(prepared) {
        if !IsObject(prepared)
            return
        if prepared.HasProp("pBitmap")
            Gdip_DisposeImage(prepared.pBitmap)
        if prepared.HasProp("pRaw")
            Gdip_DisposeImage(prepared.pRaw)
    }

    /**
     * Saves exactly what the OCR engine is fed for a HUD rect. Two stages, because
     * either can be the problem: <prefix>_raw.png is the padded screen capture, and
     * <prefix>_prep.png is the upscaled/thresholded image the recognizer reads. A
     * clipped digit or glyph lost to the luma threshold shows up here, and no amount
     * of retrying or re-parsing would have recovered it.
     * @returns {Boolean} - True when both stages were written.
     */
    static DumpHudRect(x, y, w, h, prefix, scale := 4, pad := 10, lumaMin := 90) {
        prepared := this.PrepareHudRect(x, y, w, h, scale, pad, lumaMin)
        if (prepared == "")
            return false

        try FileDelete(prefix "_raw.png")
        try FileDelete(prefix "_prep.png")
        rawOk := (Gdip_SaveBitmapToFile(prepared.pRaw, prefix "_raw.png") = 0)
        prepOk := (Gdip_SaveBitmapToFile(prepared.pBitmap, prefix "_prep.png") = 0)
        this.DisposePreparedHudRect(prepared)
        return rawOk && prepOk
    }

    /**
     * Performs OCR from a GDI+ Bitmap pointer.
     * @param {Ptr} pBitmap - GDI+ bitmap pointer.
     * @param {String} lang - Language tag (default "en-US").
     * @returns {Object} - { text: String, lines: Array, words: Array }
     */
    static FromBitmap(pBitmap, lang := "en-US") {
        if (!pBitmap)
            return { text: "", lines: [], words: [] }

        pSoftwareBitmap := this.CreateSoftwareBitmapFromGdiplusBitmap(pBitmap)
        if (!pSoftwareBitmap)
            return { text: "", lines: [], words: [] }

        return this.RecognizeSoftwareBitmap(pSoftwareBitmap, lang)
    }

    /**
     * Performs OCR from a Windows HBITMAP handle.
     */
    static FromHBitmap(hBitmap, lang := "en-US") {
        if (!hBitmap)
            return { text: "", lines: [], words: [] }

        pBitmap := 0
        DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hBitmap, "ptr", 0, "uptr*", &pBitmap)
        if (!pBitmap)
            return { text: "", lines: [], words: [] }

        result := this.FromBitmap(pBitmap, lang)
        DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)
        return result
    }

    /**
     * Converts a GDI+ Bitmap into a WinRT ISoftwareBitmap via in-memory stream and BitmapDecoder.
     */
    static CreateSoftwareBitmapFromGdiplusBitmap(pBitmap) {
        this.Init()

        ; 1. Create IStream on HGlobal
        pStream := 0
        hr := DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", 1, "ptr*", &pStream, "hresult")
        if (hr != 0 || !pStream)
            throw Error("CreateStreamOnHGlobal failed (" Format("0x{:08X}", hr) ")")

        ; 2. Save GDI+ bitmap as BMP into IStream
        CLSID_BMP := this.GUIDFromString("{557CF400-1A04-11D3-9A73-0000F81EF32E}")
        status := DllCall("gdiplus\GdipSaveImageToStream", "ptr", pBitmap, "ptr", pStream, "ptr", CLSID_BMP, "ptr", 0)
        if (status != 0) {
            ObjRelease(pStream)
            throw Error("GdipSaveImageToStream failed with status: " status)
        }

        ; 3. Rewind IStream to beginning (IStream::Seek - Slot 5)
        ComCall(5, pStream, "int64", 0, "uint", 0, "ptr", 0)

        ; 4. Wrap IStream as WinRT IRandomAccessStream
        guidIRAS := this.GUIDFromString("{905A0FE1-BC53-11DF-8C49-001E4FC686DA}")
        pRandomAccessStream := 0
        hr := DllCall("shcore\CreateRandomAccessStreamOverStream", "ptr", pStream, "uint", 0, "ptr", guidIRAS, "ptr*", &pRandomAccessStream, "hresult")
        ObjRelease(pStream)

        if (hr != 0 || !pRandomAccessStream)
            throw Error("CreateRandomAccessStreamOverStream failed (" Format("0x{:08X}", hr) ")")

        ; 5. Get BitmapDecoderStatics and create BitmapDecoder
        pDecoderStatics := this.GetActivationFactory("Windows.Graphics.Imaging.BitmapDecoder", "{438ccb26-bcef-4e95-bad6-23a822e58d01}")
        pAsyncDecoder := 0
        ; IBitmapDecoderStatics::CreateAsync (Slot 14)
        ComCall(14, pDecoderStatics, "ptr", pRandomAccessStream, "ptr*", &pAsyncDecoder)
        ObjRelease(pDecoderStatics)
        ObjRelease(pRandomAccessStream)

        if (!pAsyncDecoder)
            throw Error("BitmapDecoder::CreateAsync failed")

        this.WaitForAsync(pAsyncDecoder)

        ; IAsyncOperation<BitmapDecoder>::GetResults (Slot 8)
        pDecoder := 0
        ComCall(8, pAsyncDecoder, "ptr*", &pDecoder)
        ObjRelease(pAsyncDecoder)

        if (!pDecoder)
            throw Error("Failed to obtain BitmapDecoder results")

        ; 6. Query IBitmapFrameWithSoftwareBitmap to access GetSoftwareBitmapAsync
        iidFrameWithSB := this.GUIDFromString("{fe287c9a-420c-4963-87ad-691436e08383}")
        pFrameWithSB := 0
        ComCall(0, pDecoder, "ptr", iidFrameWithSB, "ptr*", &pFrameWithSB)
        ObjRelease(pDecoder)

        if (!pFrameWithSB)
            throw Error("QueryInterface IBitmapFrameWithSoftwareBitmap failed")

        pAsyncSoftwareBitmap := 0
        ; IBitmapFrameWithSoftwareBitmap::GetSoftwareBitmapAsync (Slot 6)
        ComCall(6, pFrameWithSB, "ptr*", &pAsyncSoftwareBitmap)
        ObjRelease(pFrameWithSB)

        if (!pAsyncSoftwareBitmap)
            throw Error("BitmapDecoder::GetSoftwareBitmapAsync failed")

        this.WaitForAsync(pAsyncSoftwareBitmap)

        ; IAsyncOperation<SoftwareBitmap>::GetResults (Slot 8)
        pSoftwareBitmap := 0
        ComCall(8, pAsyncSoftwareBitmap, "ptr*", &pSoftwareBitmap)
        ObjRelease(pAsyncSoftwareBitmap)

        return pSoftwareBitmap
    }

    /**
     * Recognizes text from an initialized ISoftwareBitmap COM object.
     */
    static RecognizeSoftwareBitmap(pSoftwareBitmap, lang := "en-US") {
        if (!pSoftwareBitmap)
            return { text: "", lines: [], words: [] }

        pOcrEngine := this.GetEngine(lang)

        ; IOcrEngine::RecognizeAsync (Slot 6)
        pAsyncOp := 0
        ComCall(6, pOcrEngine, "ptr", pSoftwareBitmap, "ptr*", &pAsyncOp)
        ObjRelease(pSoftwareBitmap)

        if (!pAsyncOp)
            return { text: "", lines: [], words: [] }

        this.WaitForAsync(pAsyncOp)

        ; IAsyncOperation<OcrResult>::GetResults (Slot 8)
        pOcrResult := 0
        ComCall(8, pAsyncOp, "ptr*", &pOcrResult)
        ObjRelease(pAsyncOp)

        if (!pOcrResult)
            return { text: "", lines: [], words: [] }

        ; IOcrResult::get_Text (Slot 8)
        hResultText := 0
        ComCall(8, pOcrResult, "ptr*", &hResultText)
        fullText := this.HStringToString(hResultText)
        this.DeleteHString(hResultText)

        ; IOcrResult::get_Lines (Slot 6)
        pLines := 0
        ComCall(6, pOcrResult, "ptr*", &pLines)

        linesArray := []
        wordsArray := []

        if (pLines) {
            lineCount := 0
            ; IVectorView<OcrLine>::get_Size (Slot 7)
            ComCall(7, pLines, "uint*", &lineCount)

            loop lineCount {
                lineIdx := A_Index - 1
                pLine := 0
                ; IVectorView<OcrLine>::GetAt (Slot 6)
                ComCall(6, pLines, "uint", lineIdx, "ptr*", &pLine)

                if (pLine) {
                    hLineText := 0
                    ; IOcrLine::get_Text (Slot 7)
                    ComCall(7, pLine, "ptr*", &hLineText)
                    lineText := this.HStringToString(hLineText)
                    this.DeleteHString(hLineText)
                    linesArray.Push(lineText)

                    ; IOcrLine::get_Words (Slot 6)
                    pWords := 0
                    ComCall(6, pLine, "ptr*", &pWords)
                    if (pWords) {
                        wordCount := 0
                        ComCall(7, pWords, "uint*", &wordCount)

                        loop wordCount {
                            wordIdx := A_Index - 1
                            pWord := 0
                            ComCall(6, pWords, "uint", wordIdx, "ptr*", &pWord)
                            if (pWord) {
                                hWordText := 0
                                ; IOcrWord::get_Text (Slot 7)
                                ComCall(7, pWord, "ptr*", &hWordText)
                                wText := this.HStringToString(hWordText)
                                this.DeleteHString(hWordText)

                                rectBuf := Buffer(16, 0)
                                ; IOcrWord::get_BoundingRect (Slot 6)
                                ComCall(6, pWord, "ptr", rectBuf)

                                rx := NumGet(rectBuf, 0, "float")
                                ry := NumGet(rectBuf, 4, "float")
                                rw := NumGet(rectBuf, 8, "float")
                                rh := NumGet(rectBuf, 12, "float")

                                wordsArray.Push({
                                    text: wText,
                                    x: rx,
                                    y: ry,
                                    w: rw,
                                    h: rh
                                })

                                ObjRelease(pWord)
                            }
                        }
                        ObjRelease(pWords)
                    }
                    ObjRelease(pLine)
                }
            }
            ObjRelease(pLines)
        }

        ObjRelease(pOcrResult)

        return {
            text: Trim(fullText),
            lines: linesArray,
            words: wordsArray
        }
    }

    /**
     * Join WinRT OCR line texts into a single rewards-band string.
     */
    static JoinOcrLines(lines, separator := " ") {
        if !(lines is Array) || lines.Length == 0
            return ""
        parts := []
        for _, line in lines {
            t := Trim(line)
            if (t != "")
                parts.Push(t)
        }
        if (parts.Length == 0)
            return ""
        joined := parts[1]
        if (parts.Length == 1)
            return joined
        loop parts.Length - 1
            joined .= separator parts[A_Index + 1]
        return joined
    }

    /**
     * Normalizes multi-line raw OCR text into a single clean line.
     */
    static NormalizeText(rawText) {
        if (!rawText)
            return ""
        ; Replace newlines with spaces and condense multiple whitespaces
        cleaned := RegExReplace(rawText, "[\r\n]+", " ")
        cleaned := RegExReplace(cleaned, "\s+", " ")
        cleaned := this.FoldLookalikeLetters(cleaned)
        return Trim(cleaned)
    }

    /**
     * Folds non-ASCII letters that stand in for ASCII ones back to their ASCII
     * spelling, before any matching happens.
     *
     * Windows OCR silently falls back to the user-profile language when the
     * requested language pack is missing (see GetEngine). On a Turkish profile the
     * engine decodes the game's capital "I" glyph as "İ" (U+0130), "i" as "ı"
     * (U+0131), and can add a cedilla/diaeresis to S/G/C/O/U.
     *
     * Those characters are not matched by the "[^a-z0-9 ]" filter in FindBestMatch,
     * so they used to be DELETED instead of folded: "TESTİNG STATİON CLEANUP"
     * became "testng staton cleanup", its token overlap fell to 0.267 against
     * "testing station cleanup" (threshold 0.4) and the mission came back
     * unrecognized even though the read was correct apart from the letter form.
     * Folding keeps the letter, so FindBestMatch's exact-match path still fires.
     *
     * Codepoints are used deliberately rather than literals so the mapping cannot
     * break if this file is ever saved in a non-UTF-8 encoding.
     */
    static FoldLookalikeLetters(text) {
        static lookalikes := Map(
            Chr(0x0130), "I",   ; İ  Latin capital I with dot above (Turkish OCR of "I")
            Chr(0x0131), "i",   ; ı  Latin small dotless i (Turkish OCR of "i")
            Chr(0x015E), "S",   ; Ş
            Chr(0x015F), "s",   ; ş
            Chr(0x011E), "G",   ; Ğ
            Chr(0x011F), "g",   ; ğ
            Chr(0x00C7), "C",   ; Ç
            Chr(0x00E7), "c",   ; ç
            Chr(0x00D6), "O",   ; Ö
            Chr(0x00F6), "o",   ; ö
            Chr(0x00DC), "U",   ; Ü
            Chr(0x00FC), "u",   ; ü
            Chr(0x00C2), "A",   ; Â
            Chr(0x00E2), "a",   ; â
            Chr(0x00CE), "I",   ; Î
            Chr(0x00EE), "i",   ; î
            Chr(0x00DB), "U",   ; Û
            Chr(0x00FB), "u")   ; û

        for from, to in lookalikes {
            if InStr(text, from)
                text := StrReplace(text, from, to)
        }
        return text
    }

    /**
     * Logs through the global logger when one is available. Never throws, so an
     * early call from OCR engine setup cannot break startup.
     */
    static Log(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Log")
            loggerInst.Log("[OCR] " message)
    }

    /**
     * Parse Landsraad contribution from reward-line HUD OCR, e.g.
     * "1 ,200 Landsraad Contribution" -> 1200
     */
    static ParseLandsraadContribution(text) {
        norm := this.NormalizeText(text)
        if (norm == "")
            return { found: false, number: "", value: 0, rawText: norm }

        if RegExMatch(norm, "i)([\d,OolI|][\d,OolI|,\s]*)\s+Landsraad", &m) {
            numberStr := this.NormalizeHudNumberText(m[1])
            if (numberStr != "")
                return {
                    found: true,
                    number: numberStr,
                    value: this.ParseHudDigits(numberStr),
                    rawText: norm
                }
        }

        bestValue := 0
        bestNumber := ""
        pos := 1
        while RegExMatch(norm, "([\d,OolI|][\d,OolI|,\s]*)", &m, pos) {
            numberStr := this.NormalizeHudNumberText(m[1])
            pos := m.Pos(0) + m.Len(0)
            if (numberStr == "")
                continue
            value := this.ParseHudDigits(numberStr)
            if (value > bestValue) {
                bestValue := value
                bestNumber := numberStr
            }
        }

        if (bestNumber != "")
            return {
                found: true,
                number: bestNumber,
                value: bestValue,
                rawText: norm
            }

        return { found: false, number: "", value: 0, rawText: norm }
    }

    static NormalizeHudNumberText(text) {
        s := Trim(text)
        if (s == "")
            return ""

        s := StrReplace(s, "O", "0")
        s := StrReplace(s, "o", "0")
        s := StrReplace(s, "l", "1")
        s := StrReplace(s, "I", "1")
        s := StrReplace(s, "|", "1")
        s := RegExReplace(s, "\s+", "")
        s := RegExReplace(s, "[^\d,]", "")
        return s
    }

    static ParseHudDigits(numberStr) {
        digits := StrReplace(numberStr, ",", "")
        if (digits == "")
            return 0
        try {
            return Integer(digits)
        } catch {
            return 0
        }
    }

    /**
     * Matches raw OCR text against an array of known mission names/objects.
     * Supports exact case-insensitive match, substring match, and token-overlap scoring.
     */
    static FindBestMatch(rawText, candidateList) {
        norm := this.NormalizeText(rawText)
        if (norm == "" || !IsObject(candidateList) || candidateList.Length == 0)
            return { matchedName: norm, confidence: 0.0, raw: rawText, item: "" }

        normLower := StrLower(norm)
        ; Clean punctuation for comparison (keep letters and digits)
        cleanNorm := RegExReplace(normLower, "[^a-z0-9 ]", "")
        cleanNorm := RegExReplace(cleanNorm, "\s+", " ")
        cleanNorm := Trim(cleanNorm)

        bestName := norm
        bestItem := ""
        bestScore := 0.0

        for _, item in candidateList {
            nameStr := (item is String) ? item : (item.HasOwnProp("name") ? item.name : (item.Has("name") ? item["name"] : String(item)))
            nameLower := StrLower(nameStr)
            cleanCandidate := RegExReplace(nameLower, "[^a-z0-9 ]", "")
            cleanCandidate := RegExReplace(cleanCandidate, "\s+", " ")
            cleanCandidate := Trim(cleanCandidate)

            ; 1. Exact match
            if (cleanNorm == cleanCandidate) {
                return {
                    matchedName: nameStr,
                    item: item,
                    confidence: 1.0,
                    raw: rawText
                }
            }

            ; 2. Substring match
            if (InStr(cleanCandidate, cleanNorm) || InStr(cleanNorm, cleanCandidate)) {
                score := 0.85
                if (score > bestScore) {
                    bestScore := score
                    bestName := nameStr
                    bestItem := item
                }
            }

            ; 3. Token overlap match (handles multi-line word wrapping)
            normTokens := StrSplit(cleanNorm, " ")
            candTokens := StrSplit(cleanCandidate, " ")
            if (normTokens.Length > 0 && candTokens.Length > 0) {
                matchCount := 0
                for _, token in normTokens {
                    if (token == "")
                        continue
                    for _, cToken in candTokens {
                        if (token == cToken) {
                            matchCount++
                            break
                        }
                    }
                }
                overlapScore := (matchCount / Max(normTokens.Length, candTokens.Length)) * 0.8
                if (overlapScore > bestScore) {
                    bestScore := overlapScore
                    bestName := nameStr
                    bestItem := item
                }
            }
        }

        return {
            matchedName: (bestScore >= 0.4) ? bestName : norm,
            item: bestItem,
            confidence: bestScore,
            raw: rawText
        }
    }

    /**
     * Extract tier 1–4 house reward item names from rewards-band tooltip OCR.
     * Rewards appear in order as "amount - item name". Tier 5 (swatch) is ignored.
     * Matches OCR names to db/landsraad_rewards.json using characters 3–10 of the normalized name.
     */
    static ParseHouseRewardTiers(text, rewardDb := "") {
        norm := this.NormalizeText(text)
        empty := { found: false, tiers: [], ocrTexts: [], rawText: norm }

        if (norm == "")
            return empty

        ocrTexts := this.ExtractHouseRewardOcrNames(norm)
        if (ocrTexts.Length == 0)
            return empty

        if !IsObject(rewardDb) || rewardDb.Length == 0
            rewardDb := this.LoadLandsraadRewardsDb()

        tiers := []
        loop Min(4, ocrTexts.Length) {
            rewardTier := A_Index
            ocrText := ocrTexts[A_Index]
            match := this.MatchHouseRewardName(ocrText, rewardDb)
            tiers.Push({
                reward_tier: rewardTier,
                ocrText: ocrText,
                item_id: match.item_id,
                item_name: match.item_name,
                matched: match.matched
            })
        }

        return {
            found: tiers.Length > 0,
            tiers: tiers,
            ocrTexts: ocrTexts,
            rawText: norm
        }
    }

    static MakeEmptyHouseRewardEntries() {
        entries := []
        loop 4
            entries.Push(Map("item_id", "", "item_name", ""))
        return entries
    }

    static FormatHouseRewardEntries(parsed) {
        entries := this.MakeEmptyHouseRewardEntries()
        if !IsObject(parsed) || !parsed.found || !IsObject(parsed.tiers)
            return entries

        loop Min(4, parsed.tiers.Length) {
            tier := parsed.tiers[A_Index]
            if !IsObject(tier)
                continue
            itemId := ""
            itemName := ""
            if tier.matched {
                itemId := tier.item_id
                itemName := tier.item_name
            } else if (Trim(tier.ocrText) != "") {
                itemName := Trim(tier.ocrText)
            }
            entries[A_Index] := Map("item_id", itemId, "item_name", itemName)
        }
        return entries
    }

    static ExtractHouseRewardOcrNames(text) {
        norm := this.NormalizeText(text)
        if RegExMatch(norm, "i)House Rewards:\s*(.*)", &section)
            norm := Trim(section[1])
        if (norm == "")
            return []

        delims := this.FindHouseRewardDelimiters(norm)
        if (delims.Length == 0)
            return []

        names := []
        loop delims.Length {
            nameStart := delims[A_Index].nameStart
            if (A_Index < delims.Length)
                nameEnd := delims[A_Index + 1].pos - 1
            else
                nameEnd := StrLen(norm)
            if (nameEnd < nameStart)
                continue

            name := this.CleanHouseRewardOcrName(SubStr(norm, nameStart, nameEnd - nameStart + 1))
            if (name != "" && !this.IsHouseRewardSwatch(name))
                names.Push(name)
        }
        return names
    }

    static FindHouseRewardDelimiters(norm) {
        delims := []
        pos := 1
        while RegExMatch(norm, "(\d+(?:,\d+)*)\s*-\s*", &m, pos) {
            delims.Push({ pos: m.Pos(0), nameStart: m.Pos(0) + m.Len(0) })
            pos := m.Pos(0) + 1
        }
        pos := 1
        while RegExMatch(norm, "(?<!\d)\s+-\s+", &m, pos) {
            nameStart := m.Pos(0) + m.Len(0)
            duplicate := false
            for _, delim in delims {
                if (Abs(delim.nameStart - nameStart) <= 2) {
                    duplicate := true
                    break
                }
            }
            if !duplicate
                delims.Push({ pos: m.Pos(0), nameStart: nameStart })
            pos := m.Pos(0) + 1
        }

        if (delims.Length == 0)
            return delims

        loop delims.Length - 1 {
            i := A_Index
            loop delims.Length - i {
                j := A_Index
                if (delims[j].pos > delims[j + 1].pos) {
                    temp := delims[j]
                    delims[j] := delims[j + 1]
                    delims[j + 1] := temp
                }
            }
        }
        return delims
    }

    static CleanHouseRewardOcrName(name) {
        s := Trim(name)
        if (s == "")
            return ""
        s := RegExReplace(s, "^\s*-\s*", "")
        s := RegExReplace(s, "\s+0+\s*$", "")
        return Trim(s)
    }

    static IsHouseRewardSwatch(name) {
        return RegExMatch(Trim(name), "i)placeables\s+swatch")
    }

    static CountMatchedHouseRewardTiers(parsed) {
        if !IsObject(parsed) || !parsed.found
            return 0
        matched := 0
        for _, tier in parsed.tiers {
            if tier.matched
                matched++
        }
        return matched
    }

    static HouseRewardParseNeedsRetry(parsed) {
        if !IsObject(parsed) || !parsed.found
            return false

        matched := 0
        hasUnmatched := false
        for _, tier in parsed.tiers {
            if tier.matched
                matched++
            else if (Trim(tier.ocrText) != "")
                hasUnmatched := true
        }

        if (matched == 0)
            return false
        if (parsed.tiers.Length < 4 || hasUnmatched)
            return true
        return matched < 4
    }

    static MatchHouseRewardName(ocrText, rewardDb) {
        unmatched := { item_id: "", item_name: ocrText, matched: false }
        if (Trim(ocrText) == "" || !IsObject(rewardDb))
            return unmatched
        if this.IsHouseRewardSwatch(ocrText)
            return unmatched

        candidates := []
        names := []
        for _, entry in rewardDb {
            if !(entry is Map)
                continue
            itemName := entry.Has("item_name") ? entry["item_name"] : ""
            if (itemName == "")
                continue
            if !this.RewardPrefixMatches(ocrText, itemName)
                continue
            candidates.Push(entry)
            names.Push(itemName)
        }

        if (candidates.Length == 0) {
            for _, entry in rewardDb {
                if !(entry is Map)
                    continue
                itemName := entry.Has("item_name") ? entry["item_name"] : ""
                if (itemName == "")
                    continue
                candidates.Push(entry)
                names.Push(itemName)
            }
            if (candidates.Length == 0)
                return unmatched
        }

        if (candidates.Length == 1) {
            entry := candidates[1]
            return {
                item_id: entry.Has("item_id") ? entry["item_id"] : "",
                item_name: entry.Has("item_name") ? entry["item_name"] : ocrText,
                matched: true
            }
        }

        best := this.FindBestMatch(ocrText, names)
        if (best.confidence < 0.4)
            return unmatched

        for _, entry in candidates {
            if (entry.Has("item_name") && entry["item_name"] == best.matchedName)
                return {
                    item_id: entry.Has("item_id") ? entry["item_id"] : "",
                    item_name: entry["item_name"],
                    matched: true
                }
        }
        return unmatched
    }

    static RewardPrefixMatches(ocrText, dbName) {
        ocrKey := this.RewardMatchKey(ocrText)
        dbKey := this.RewardMatchKey(dbName)
        if (ocrKey == "" || dbKey == "")
            return false
        if (ocrKey == dbKey)
            return true

        ocrNorm := this.RewardNormalizedName(ocrText)
        dbNorm := this.RewardNormalizedName(dbName)
        if (StrLen(ocrKey) < 8 && InStr(dbNorm, ocrKey, , 3))
            return true
        if (StrLen(dbKey) < 8 && InStr(ocrNorm, dbKey, , 3))
            return true
        return false
    }

    static RewardMatchKey(name) {
        s := this.RewardNormalizedName(name)
        if (StrLen(s) < 3)
            return s
        return SubStr(s, 3, Min(8, StrLen(s) - 2))
    }

    static RewardNormalizedName(name) {
        return RegExReplace(StrLower(this.NormalizeText(name)), "[^a-z0-9]", "")
    }

    static RewardNameKey(name, limit := true) {
        s := this.RewardNormalizedName(name)
        return limit ? SubStr(s, 1, 10) : s
    }

    static LoadLandsraadRewardsDb() {
        static cached := ""
        if (cached is Array)
            return cached

        cached := []
        dbPath := A_ScriptDir "\db\landsraad_rewards.json"
        if !FileExist(dbPath)
            return cached

        try {
            parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
            if (parsed is Array)
                cached := parsed
        }
        return cached
    }

    ; ==============================================================================
    ; INTERNAL WINRT & COM HELPERS
    ; ==============================================================================

    static WaitForAsync(pAsyncOp) {
        iidAsyncInfo := this.GUIDFromString("{00000036-0000-0000-C000-000000000046}")
        pAsyncInfo := 0
        ComCall(0, pAsyncOp, "ptr", iidAsyncInfo, "ptr*", &pAsyncInfo)

        if (!pAsyncInfo)
            return

        status := 0
        loop {
            ; IAsyncInfo::get_Status (Slot 7)
            ComCall(7, pAsyncInfo, "int*", &status)
            if (status != 0) ; 0 = Started
                break
            Sleep(1)
        }

        ObjRelease(pAsyncInfo)
    }

    static CreateHString(str) {
        hString := 0
        hr := DllCall("combase\WindowsCreateString", "wstr", str, "uint", StrLen(str), "ptr*", &hString, "hresult")
        if (hr != 0)
            throw Error("WindowsCreateString failed for: " str " (" Format("0x{:08X}", hr) ")")
        return hString
    }

    static DeleteHString(hString) {
        if (hString)
            DllCall("combase\WindowsDeleteString", "ptr", hString)
    }

    static HStringToString(hString) {
        if (!hString)
            return ""
        length := 0
        pBuf := DllCall("combase\WindowsGetStringRawBuffer", "ptr", hString, "uint*", &length, "ptr")
        return StrGet(pBuf, length, "UTF-16")
    }

    static GUIDFromString(guidStr) {
        buf := Buffer(16, 0)
        DllCall("ole32\CLSIDFromString", "wstr", guidStr, "ptr", buf, "hresult")
        return buf
    }

    static GetActivationFactory(className, iidStr) {
        hString := this.CreateHString(className)
        iidBuf := this.GUIDFromString(iidStr)
        pFactory := 0
        hr := DllCall("combase\RoGetActivationFactory", "ptr", hString, "ptr", iidBuf, "ptr*", &pFactory, "hresult")
        this.DeleteHString(hString)
        if (hr != 0 || !pFactory)
            throw Error("RoGetActivationFactory failed for " className " (" Format("0x{:08X}", hr) ")")
        return pFactory
    }
}
