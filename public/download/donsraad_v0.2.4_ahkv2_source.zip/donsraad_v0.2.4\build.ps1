#Requires -Version 5.1
<#
.SYNOPSIS
  Compile Donsraad into a portable standalone folder.

.DESCRIPTION
  Produces dist\Donsraad-<version>\Donsraad.exe plus databases and PNG assets.
  User JSON (settings, profiles, player_state) is not copied: the app creates
  those files if they are missing, so an update extract cannot overwrite them.
  Also regenerates core\RuntimeFileInstall.ahk for exe FileInstall seeding.
#>
[CmdletBinding()]
param(
    [switch]$SkipCompile
)

$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot

function Get-AppVersion {
    $versionFile = Join-Path $Root "core\Version.ahk"
    if (-not (Test-Path $versionFile)) {
        throw "Missing version file: core\Version.ahk"
    }
    $text = Get-Content -Path $versionFile -Raw
    if ($text -match 'static Version\s*:=\s*"([^"]+)"') {
        return $Matches[1]
    }
    throw "Could not read AppInfo.Version from core\Version.ahk"
}

$AppVersion = Get-AppVersion
$OutDir = Join-Path $Root "dist\Donsraad-$AppVersion"
$ToolsDir = Join-Path $Root "tools"
$Ahk64 = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"

function Get-Ahk2Exe {
    $cached = Join-Path $ToolsDir "Ahk2Exe\Ahk2Exe.exe"
    if (Test-Path $cached) {
        return $cached
    }

    $known = @(
        "$env:ProgramFiles\AutoHotkey\Compiler\Ahk2Exe.exe",
        "${env:ProgramFiles(x86)}\AutoHotkey\Compiler\Ahk2Exe.exe"
    )
    foreach ($path in $known) {
        if (Test-Path $path) {
            return $path
        }
    }

    Write-Host "Downloading Ahk2Exe..."
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $release = Invoke-RestMethod -Uri "https://api.github.com/repos/AutoHotkey/Ahk2Exe/releases/latest"
    $asset = $release.assets | Where-Object { $_.name -like "*.zip" } | Select-Object -First 1
    if (-not $asset) {
        throw "Could not find an Ahk2Exe zip on GitHub."
    }

    $zipPath = Join-Path $ToolsDir "Ahk2Exe.zip"
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zipPath
    $extractDir = Join-Path $ToolsDir "Ahk2Exe"
    if (Test-Path $extractDir) {
        Remove-Item $extractDir -Recurse -Force
    }
    Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
    Remove-Item $zipPath -Force

    $found = Get-ChildItem -Path $extractDir -Filter Ahk2Exe.exe -Recurse | Select-Object -First 1
    if (-not $found) {
        throw "Ahk2Exe.exe was not in the downloaded zip."
    }
    return $found.FullName
}

function ConvertTo-Ico {
    param(
        [Parameter(Mandatory = $true)][string]$PngPath,
        [Parameter(Mandatory = $true)][string]$IcoPath
    )

    Add-Type -AssemblyName System.Drawing
    $src = [System.Drawing.Image]::FromFile((Resolve-Path $PngPath))
    try {
        $size = 256
        $bmp = New-Object System.Drawing.Bitmap $size, $size
        try {
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            try {
                $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $g.Clear([System.Drawing.Color]::Transparent)
                $g.DrawImage($src, 0, 0, $size, $size)
            } finally {
                $g.Dispose()
            }

            $ms = New-Object System.IO.MemoryStream
            try {
                $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
                $pngBytes = $ms.ToArray()
            } finally {
                $ms.Dispose()
            }
        } finally {
            $bmp.Dispose()
        }
    } finally {
        $src.Dispose()
    }

    $fs = [System.IO.File]::Create($IcoPath)
    $bw = New-Object System.IO.BinaryWriter $fs
    try {
        $bw.Write([uint16]0)
        $bw.Write([uint16]1)
        $bw.Write([uint16]1)
        $bw.Write([byte]0)
        $bw.Write([byte]0)
        $bw.Write([byte]0)
        $bw.Write([byte]0)
        $bw.Write([uint16]1)
        $bw.Write([uint16]32)
        $bw.Write([uint32]$pngBytes.Length)
        $bw.Write([uint32]22)
        $bw.Write($pngBytes)
    } finally {
        $bw.Dispose()
        $fs.Dispose()
    }
}

if (-not (Test-Path $Ahk64)) {
    throw "AutoHotkey v2 64-bit not found at $Ahk64"
}

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$exePath = Join-Path $OutDir "Donsraad.exe"

if (-not $SkipCompile) {
    $ahk2exe = Get-Ahk2Exe
    $icoPath = Join-Path $ToolsDir "donsraad.ico"
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
    ConvertTo-Ico -PngPath (Join-Path $Root "ui\donsraad_icon.png") -IcoPath $icoPath

    Write-Host "Compiling $exePath"
    $canCompile = $true
    if (Test-Path $exePath) {
        try {
            Remove-Item $exePath -Force -ErrorAction Stop
        } catch {
            Write-Warning "Donsraad.exe is in use. Data files will still be copied. Close the app and run build.ps1 again to refresh the exe."
            $canCompile = $false
        }
    }
    if ($canCompile) {
        $inPath = Join-Path $Root "main.ahk"
        $compileArgs = @(
            "/in", "`"$inPath`"",
            "/out", "`"$exePath`"",
            "/base", "`"$Ahk64`"",
            "/icon", "`"$icoPath`"",
            "/compress", "0"
        )
        $proc = Start-Process -FilePath $ahk2exe -WorkingDirectory $Root -ArgumentList $compileArgs -Wait -PassThru -NoNewWindow
        if (-not (Test-Path $exePath)) {
            throw "Ahk2Exe did not produce $exePath (exit $($proc.ExitCode))"
        }
        Write-Host "Compiled $exePath"
    }
}

function Copy-RuntimeFile {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath
    )
    $src = Join-Path $Root $RelativePath
    $dest = Join-Path $OutDir $RelativePath
    $destDir = Split-Path $dest -Parent
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null
    Copy-Item -Path $src -Destination $dest -Force
}

function Copy-RuntimeDirectory {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath
    )
    $src = Join-Path $Root $RelativePath
    if (-not (Test-Path $src)) {
        Write-Warning "Missing runtime directory: $RelativePath"
        return
    }
    Get-ChildItem -Path $src -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($src.Length).TrimStart("\", "/")
        if (Test-IsGeneratedMask -RelativePath $rel) {
            return
        }
        $dest = Join-Path $OutDir (Join-Path $RelativePath $rel)
        $destDir = Split-Path $dest -Parent
        New-Item -ItemType Directory -Force -Path $destDir | Out-Null
        Copy-Item -Path $_.FullName -Destination $dest -Force
    }
}

function Get-RuntimeManifest {
    $files = @(
        "DISCLAIMER.txt",
        "TERMS.txt",
        "db\landsraad_houses.json",
        "db\landsraad_missions.json",
        "db\landsraad_rewards.json",
        "ui\donis.png",
        "ui\donsraad_icon.png"
    )
    $dirs = @(
        "sfx",
        "db\house_icons",
        "db\house_icons_scaled",
        "db\spec_icons",
        "db\reward_icons",
        "anchors\1080p",
        "anchors\1440p"
    )
    return @{ Files = $files; Dirs = $dirs }
}

function Test-IsGeneratedMask {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath
    )
    # ImageSearch masks are recreated at runtime from their source PNG by
    # AnchorMatcher.PrepareTanGlyphMask, so they are build inputs, never build
    # outputs. Shipping them risks FileInstall pointing at a stale/deleted file.
    return [bool]($RelativePath -match '(?i)_masked(_e\d+)?\.png$')
}

function Get-RuntimeRelativeFiles {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Manifest
    )
    $paths = [System.Collections.Generic.List[string]]::new()
    foreach ($rel in $Manifest.Files) {
        $paths.Add(($rel -replace '/', '\'))
    }
    foreach ($dir in $Manifest.Dirs) {
        $src = Join-Path $Root ($dir -replace '/', '\')
        if (-not (Test-Path $src)) {
            continue
        }
        Get-ChildItem -Path $src -Recurse -File | ForEach-Object {
            $rel = $_.FullName.Substring($Root.Length).TrimStart("\", "/") -replace '/', '\'
            if (-not (Test-IsGeneratedMask -RelativePath $rel)) {
                $paths.Add($rel)
            }
        }
    }
    return ($paths | Sort-Object -Unique)
}

function Write-RuntimeFileInstallScript {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Manifest
    )
    $outPath = Join-Path $Root "core\RuntimeFileInstall.ahk"
    $lines = @(
        "#Requires AutoHotkey v2.0+",
        "",
        "; Auto-generated by build.ps1. Do not edit by hand.",
        "InstallBundledRuntimeFiles() {"
    )
    foreach ($rel in (Get-RuntimeRelativeFiles -Manifest $Manifest)) {
        $src = Join-Path $Root $rel
        if (-not (Test-Path $src)) {
            Write-Warning "Skipping FileInstall source missing from repo: $rel"
            continue
        }
        $lines += "    dest := A_ScriptDir `"\$rel`""
        $lines += "    if !FileExist(dest)"
        $lines += "        FileInstall `"$rel`", dest, 0"
    }
    $lines += "}"
    Set-Content -Path $outPath -Value ($lines -join "`r`n") -Encoding UTF8
    Write-Host "Updated core\RuntimeFileInstall.ahk ($((Get-RuntimeRelativeFiles -Manifest $Manifest).Count) files)"
}

$manifest = Get-RuntimeManifest

foreach ($rel in $manifest.Files) {
    $src = Join-Path $Root $rel
    if (Test-Path $src) {
        Copy-RuntimeFile $rel
    } else {
        Write-Warning "Missing runtime file: $rel"
    }
}

foreach ($rel in $manifest.Dirs) {
    Copy-RuntimeDirectory $rel
}

Write-RuntimeFileInstallScript -Manifest $manifest

$readme = @"
Donsraad v$AppVersion — portable build

Run Donsraad.exe. AutoHotkey does not need to be installed.

Keep this folder together. The exe reads and writes next to itself.

This zip does not include settings.json, profiles.json, or player_state.json.
On first run the app creates them. Updating over an existing folder leaves
those files alone. Missing keys from older versions are filled in on load;
your existing values are kept.

Shipped with the build:
  DISCLAIMER.txt
  TERMS.txt
  db\landsraad_houses.json
  db\landsraad_missions.json
  db\landsraad_rewards.json
  db\house_icons\*.png
  db\house_icons_scaled\**\*.png
  db\spec_icons\*.png
  db\reward_icons\*.png
  sfx\*.wav
  sfx\*.mp3
  ui\donis.png
  ui\donsraad_icon.png
  anchors\1080p\*.png
  anchors\1440p\*.png
"@
Set-Content -Path (Join-Path $OutDir "README.txt") -Value $readme -Encoding UTF8

Write-Host "Portable build ready: $OutDir (v$AppVersion)"
Get-ChildItem $OutDir -Recurse | Select-Object FullName, Length
