#Requires AutoHotkey v2.0+

/**
 * Reward Hunter — browse landsraad_rewards.json and pick hunted target items per profile.
 */
class RewardHunterWindow {
    static dlg := ""
    static profileManager := ""
    static summaryLabel := ""
    static itemEntries := Map()
    static boardRewardIds := Map()
    static rewardCount := 0
    static barW := 4
    static btnBg := "27272F"
    static btnText := "E4E4E7"
    static huntedBg := "2563EB"
    static huntedText := "FFFFFF"
    static boardBarColor := "EAB308"

    static onHuntedChanged := ""

    static Show(ownerGui := "", profileManagerInst := "", onHuntedChanged := "") {
        this.profileManager := profileManagerInst
        this.onHuntedChanged := onHuntedChanged
        this.RefreshBoardRewardIds()

        if IsObject(this.dlg) {
            try {
                this.RefreshBoardRewardIds()
                this.RefreshAllButtons()
                this.dlg.Show()
                return
            } catch {
                this.Close()
            }
        }

        rewards := Ocr.LoadLandsraadRewardsDb()
        if !IsObject(rewards) || rewards.Length == 0
            return

        this.rewardCount := rewards.Length

        pad := 16
        cols := 5
        colGap := 8
        rowGap := 6
        btnH := 30
        legendH := 22
        legendGap := 12
        winW := 1180
        contentW := winW - (pad * 2)
        btnW := (contentW - (colGap * (cols - 1))) // cols
        labelW := btnW - this.barW

        dlg := Gui("+Resize -MaximizeBox -MinimizeBox", "Reward Hunter")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        dlg.SetFont("s12 bold cE4E4E7", "Segoe UI")
        dlg.Add("Text", "x" pad " y" pad " w" contentW " h24 BackgroundTrans", "Reward database")
        dlg.SetFont("s9 cA1A1AA", "Segoe UI")
        this.summaryLabel := dlg.Add("Text", "x" pad " y" (pad + 26) " w" contentW " h18 BackgroundTrans", "")
        this.UpdateSummary()

        gridY := pad + 52
        this.itemEntries := Map()
        col := 0
        row := 0
        for _, entry in rewards {
            if !(entry is Map)
                continue
            itemName := entry.Has("item_name") ? entry["item_name"] : ""
            itemId := entry.Has("item_id") ? entry["item_id"] : ""
            if (itemName == "" || itemId == "")
                continue

            x := pad + col * (btnW + colGap)
            y := gridY + row * (btnH + rowGap)
            clickHandler := this.MakeItemClickHandler(itemId)

            bar := dlg.Add("Text",
                "x" x " y" y " w" this.barW " h" btnH " Hidden Background" this.boardBarColor)
            bar.OnEvent("Click", clickHandler)

            dlg.SetFont("s9 bold c" this.btnText, "Segoe UI")
            btn := dlg.Add("Text",
                "x" (x + this.barW) " y" y " w" labelW " h" btnH " Center +0x200 Background" this.btnBg, itemName)
            btn.OnEvent("Click", clickHandler)

            this.itemEntries[itemId] := { btn: btn, bar: bar, name: itemName }
            this.StyleItemButton(itemId)

            col++
            if (col >= cols) {
                col := 0
                row++
            }
        }

        rows := row + (col > 0 ? 1 : 0)
        gridH := rows > 0 ? rows * (btnH + rowGap) - rowGap : 0
        legendY := gridY + gridH + legendGap

        dlg.Add("Text", "x" pad " y" (legendY + 3) " w14 h14 Background" this.boardBarColor)
        dlg.SetFont("s9 cA1A1AA", "Segoe UI")
        dlg.Add("Text", "x" (pad + 22) " y" legendY " w" (contentW - 22) " h" legendH " +0x200 BackgroundTrans",
            "Reward available in board")

        winH := legendY + legendH + pad

        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("w" winW " h" winH " Center")
    }

    static MakeItemClickHandler(itemId) {
        return (*) => this.OnItemClick(itemId)
    }

    static OnItemClick(itemId) {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("ToggleHuntedReward")
            return
        this.profileManager.ToggleHuntedReward(itemId)
        this.StyleItemButton(itemId)
        this.UpdateSummary()
        if IsObject(this.onHuntedChanged) {
            try this.onHuntedChanged.Call()
            catch {
            }
        }
    }

    static RefreshBoardRewardIds() {
        this.boardRewardIds := Map()
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("GetBoardAvailableRewardIds")
            return
        this.boardRewardIds := this.profileManager.GetBoardAvailableRewardIds()
    }

    static IsItemHunted(itemId) {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("IsHuntedReward")
            return false
        return this.profileManager.IsHuntedReward(itemId)
    }

    static IsItemOnBoard(itemId) {
        return this.boardRewardIds.Has(itemId)
    }

    static StyleItemButton(itemId) {
        if !this.itemEntries.Has(itemId)
            return
        entry := this.itemEntries[itemId]
        btn := entry.btn
        bar := entry.bar
        if !IsObject(btn) || !IsObject(bar)
            return

        hunted := this.IsItemHunted(itemId)
        onBoard := this.IsItemOnBoard(itemId)
        btn.Text := entry.name

        if hunted {
            btn.Opt("Background" this.huntedBg)
            btn.SetFont("s9 bold c" this.huntedText, "Segoe UI")
        } else {
            btn.Opt("Background" this.btnBg)
            btn.SetFont("s9 bold c" this.btnText, "Segoe UI")
        }

        if onBoard {
            bar.Visible := true
            bar.Opt("Background" this.boardBarColor)
        } else {
            bar.Visible := false
        }

        btn.Redraw()
        bar.Redraw()
    }

    static RefreshAllButtons() {
        this.RefreshBoardRewardIds()
        for itemId, entry in this.itemEntries
            this.StyleItemButton(itemId)
        this.UpdateSummary()
    }

    static CountBoardRewards() {
        return this.boardRewardIds.Count
    }

    static UpdateSummary() {
        if !IsObject(this.summaryLabel)
            return
        huntedCount := 0
        if IsObject(this.profileManager) && this.profileManager.HasMethod("GetHuntedRewards")
            huntedCount := this.profileManager.GetHuntedRewards().Length
        boardCount := this.CountBoardRewards()
        boardLabel := boardCount > 0 ? (" · " boardCount " on board") : ""
        this.summaryLabel.Text := this.rewardCount " items · " huntedCount " hunted" boardLabel
    }

    static Close() {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.summaryLabel := ""
        this.itemEntries := Map()
        this.boardRewardIds := Map()
        this.rewardCount := 0
        this.onHuntedChanged := ""
    }
}
