#Requires AutoHotkey v2.0+

/**
 * Lists earned reward items for a house (from unclaimedHouseRewards tracking).
 */
class HouseEarnedRewardsWindow {
    static dlg := ""
    static profileManager := ""
    static houseName := ""
    static rowEntries := []

    static winW := 500
    static pad := 16
    static rowH := 30
    static rowGap := 4
    static huntedDiamondSize := 14
    static huntedIconPath := ""
    static panelBg := "18181B"
    static titleColor := "E4E4E7"
    static mutedText := "A1A1AA"
    static subtleText := "71717A"
    static goalText := "EAB308"
    static checkDoneColor := "4ADE80"
    static checkPendingColor := "3F3F46"
    static huntedRowBg := "3B1736"
    static huntedTextColor := "F9A8D4"
    static claimedText := "52525B"

    static Show(ownerGui := "", profileManagerInst := "", houseName := "") {
        houseName := Trim(houseName)
        if (houseName == "" || !IsObject(profileManagerInst))
            return

        this.Close()
        this.profileManager := profileManagerInst
        this.houseName := houseName

        items := []
        if profileManagerInst.HasMethod("GetHouseEarnedRewardItems")
            items := profileManagerInst.GetHouseEarnedRewardItems(houseName)

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "Earned rewards")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        pad := this.pad
        w := this.winW
        y := pad

        dlg.SetFont("s12 bold c" this.titleColor, "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" (w - pad * 2) " h24 BackgroundTrans", houseName)
        y += 26
        dlg.SetFont("s9 c" this.mutedText, "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" (w - pad * 2) " h18 BackgroundTrans",
            "Pending rewards from this week and any earlier unclaimed weeks.")
        y += 24

        if (items.Length == 0) {
            dlg.SetFont("s9 c" this.subtleText, "Segoe UI")
            dlg.Add("Text", "x" pad " y" y " w" (w - pad * 2) " h40 Center +0x200 BackgroundTrans",
                "No pending rewards for this house.")
            dlg.OnEvent("Close", (*) => this.Close())
            dlg.OnEvent("Escape", (*) => this.Close())
            this.dlg := dlg
            dlg.Show("AutoSize Center")
            return
        }

        panelH := items.Length * this.rowH + (items.Length - 1) * this.rowGap + 12
        dlg.Add("Text", "x" pad " y" y " w" (w - pad * 2) " h" panelH " Background" this.panelBg)

        rowInnerX := pad + 8
        rowInnerW := w - pad * 2 - 16
        checkW := 18
        goalW := 56
        diamondPad := 4
        weekLabelW := 84
        nameX := rowInnerX + checkW + goalW + 6
        diamondX := rowInnerX + rowInnerW - this.huntedDiamondSize
        weekX := diamondX - weekLabelW - diamondPad
        nameW := weekX - nameX - 6
        if (nameW < 80)
            nameW := 80
        rowY := y + 6

        this.rowEntries := []
        diamondPath := this.GetHuntedDiamondPath()
        showWeekLabels := false
        weekKeys := Map()
        for _, item in items {
            weekDate := item.Has("week") ? Trim(item["week"]) : ""
            if (weekDate != "")
                weekKeys[weekDate] := true
        }
        if (weekKeys.Count > 1)
            showWeekLabels := true

        loop items.Length {
            item := items[A_Index]
            itemId := item.Has("item_id") ? item["item_id"] : ""
            itemName := item.Has("item_name") ? item["item_name"] : ""
            tierNum := item.Has("tier") ? Integer(item["tier"]) : 0
            weekDate := item.Has("week") ? Trim(item["week"]) : ""
            relativeWeek := ""
            if profileManagerInst.HasMethod("FormatRelativeRewardWeekLabel")
                relativeWeek := profileManagerInst.FormatRelativeRewardWeekLabel(weekDate)
            else if item.Has("weekLabel")
                relativeWeek := item["weekLabel"]
            isHunted := false
            if (itemId != "" && profileManagerInst.HasMethod("IsHuntedReward"))
                isHunted := profileManagerInst.IsHuntedReward(itemId)
            isSwatch := tierNum == 5
            swatchOwned := false
            if isSwatch && profileManagerInst.HasMethod("IsHouseSwatchOwned")
                swatchOwned := profileManagerInst.IsHouseSwatchOwned(this.houseName)
            if isSwatch && swatchOwned
                itemName := "House Swatch Obtained"

            rowBgColor := isHunted && !isSwatch ? this.huntedRowBg : this.panelBg
            dlg.Add("Text", "x" rowInnerX " y" rowY " w" rowInnerW " h" this.rowH " Background" rowBgColor)

            dlg.SetFont("s9 c" this.checkDoneColor, "Segoe UI")
            dlg.Add("Text", "x" rowInnerX " y" rowY " w" checkW " h" this.rowH " Center +0x200 BackgroundTrans", "✓")

            dlg.SetFont("s9 bold c" this.goalText, "Segoe UI")
            contribution := item.Has("contribution") ? item["contribution"] : 0
            dlg.Add("Text",
                "x" (rowInnerX + checkW) " y" rowY " w" goalW " h" this.rowH
                " Right +0x200 BackgroundTrans", this.FormatContribution(contribution))

            if isSwatch && swatchOwned {
                dlg.SetFont("s9 c" this.subtleText, "Segoe UI")
            } else if isHunted {
                dlg.SetFont("s9 bold c" this.huntedTextColor, "Segoe UI")
            } else {
                dlg.SetFont("s9 c" this.titleColor, "Segoe UI")
            }
            dlg.Add("Text",
                "x" nameX " y" rowY " w" nameW " h" this.rowH " +0x200 BackgroundTrans", itemName)

            if showWeekLabels && (relativeWeek != "") {
                dlg.SetFont("s8 c" this.subtleText, "Segoe UI")
                dlg.Add("Text",
                    "x" weekX " y" rowY " w" weekLabelW " h" this.rowH " Right +0x200 BackgroundTrans", relativeWeek)
            }

            if isHunted && !isSwatch
                this.AddDiamondIcon(dlg, diamondX, rowY, diamondPath)

            rowY += this.rowH + this.rowGap
        }

        y += panelH + 12
        dlg.SetFont("s9 bold cE4E4E7", "Segoe UI")
        closeBtn := dlg.Add("Text",
            "x" pad " y" y " w" (w - pad * 2) " h30 Center +0x200 Background27272F", "Close")
        closeBtn.OnEvent("Click", (*) => this.Close())

        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("AutoSize Center")
    }

    static AddDiamondIcon(dlg, x, rowY, path) {
        if !IsObject(dlg)
            return
        picY := rowY + ((this.rowH - this.huntedDiamondSize) // 2)
        if (path != "") {
            try {
                pic := dlg.Add("Picture",
                    "x" x " y" picY " w" this.huntedDiamondSize " h" this.huntedDiamondSize " BackgroundTrans")
                pic.Value := "*TransBlack " path
                return
            } catch {
            }
        }
        dlg.SetFont("s9 c" this.huntedTextColor, "Segoe UI")
        dlg.Add("Text",
            "x" x " y" rowY " w" this.huntedDiamondSize " h" this.rowH " Center +0x200 BackgroundTrans", "◆")
    }

    static GetHuntedDiamondPath() {
        if (this.huntedIconPath != "")
            return this.huntedIconPath
        path := A_ScriptDir "\db\reward_icons\diamond.png"
        if FileExist(path) {
            this.huntedIconPath := path
            return path
        }
        return ""
    }

    static FormatContribution(value) {
        try {
            n := Integer(value)
        } catch {
            return "0"
        }
        if (n < 0)
            n := 0
        return Format("{:L}", n)
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.profileManager := ""
        this.houseName := ""
        this.rowEntries := []
    }
}
