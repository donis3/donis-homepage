#Requires AutoHotkey v2.0+

/**
 * Non-blocking sound effects for run-start, goal-reach, and completion cues.
 * Prefers WAV (reliable with SoundPlay); converts MP3 to WAV via ffmpeg when needed.
 */
class SfxPlayer {
    static rootDir := A_ScriptDir
    static resolvedCache := Map()

    static PlayRunStart() {
        this.Play("run-start")
    }

    static PlayGoalReach() {
        this.Play("goal-reach")
    }

    static PlayWin() {
        this.Play("win")
    }

    static SoundsEnabled() {
        global settingsManagerInst
        if IsSet(settingsManagerInst) && IsObject(settingsManagerInst)
            return settingsManagerInst.GetBool("soundsEnabled", true)
        return true
    }

    static Play(name) {
        if !this.SoundsEnabled()
            return
        path := this.ResolvePath(name)
        if (path == "")
            return
        try SoundPlay(path)
    }

    static ResolvePath(name) {
        if this.resolvedCache.Has(name)
            return this.resolvedCache[name]

        dir := this.rootDir "\sfx"
        wavPath := dir "\" name ".wav"
        mp3Path := dir "\" name ".mp3"

        if FileExist(wavPath) {
            this.resolvedCache[name] := wavPath
            return wavPath
        }
        if FileExist(mp3Path) {
            if this.TryConvertToWav(mp3Path, wavPath) && FileExist(wavPath) {
                this.resolvedCache[name] := wavPath
                return wavPath
            }
            this.resolvedCache[name] := mp3Path
            return mp3Path
        }

        this.resolvedCache[name] := ""
        return ""
    }

    static TryConvertToWav(mp3Path, wavPath) {
        ffmpeg := this.FindFfmpeg()
        if (ffmpeg == "")
            return false
        cmd := Format('"{1}" -y -i "{2}" -acodec pcm_s16le -ar 44100 "{3}"',
            ffmpeg, mp3Path, wavPath)
        try RunWait(cmd, "", "Hide")
        catch {
            return false
        }
        return FileExist(wavPath)
    }

    static FindFfmpeg() {
        static cached := unset
        if IsSet(cached)
            return cached

        for candidate in ["ffmpeg", "ffmpeg.exe"] {
            try {
                if FileExist(candidate) {
                    cached := candidate
                    return cached
                }
            }
        }

        try {
            shell := ComObject("WScript.Shell")
            path := Trim(shell.ExpandEnvironmentStrings("%PATH%"))
            for part in StrSplit(path, ";") {
                part := Trim(part)
                if (part == "")
                    continue
                exe := part "\ffmpeg.exe"
                if FileExist(exe) {
                    cached := exe
                    return cached
                }
            }
        }

        localAppData := EnvGet("LOCALAPPDATA")
        if (localAppData != "") {
            wingetRoot := localAppData "\Microsoft\WinGet\Packages"
            if DirExist(wingetRoot) {
                loop Files wingetRoot "\*\ffmpeg.exe", "R" {
                    cached := A_LoopFileFullPath
                    return cached
                }
            }
        }

        cached := ""
        return cached
    }
}
