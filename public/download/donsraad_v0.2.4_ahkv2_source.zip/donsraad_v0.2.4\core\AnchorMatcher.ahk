#Requires AutoHotkey v2.0+

/**
 * Anchor point and image matching helper for AutoHotkey v2.
 * Uses ImageSearch with variation tolerance and computes relative UI offsets.
 */
class AnchorMatcher {
    rootDir := ""
    defaultVariation := 25

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        this.rootDir := rootDir
    }

    /**
     * Searches the screen for an anchor image.
     * @param {String} imageName - File name or path relative to anchors\{1080p|1440p}\
     * @param {VarRef} foundX - Output variable for matched X coordinate
     * @param {VarRef} foundY - Output variable for matched Y coordinate
     * @param {Object} searchArea - Optional bounding box {x1: 0, y1: 0, x2: 1920, y2: 1080}
     * @param {Integer} variation - Color variation tolerance (default 25)
     * @param {String} transColor - Optional ImageSearch Trans color (e.g. "Black") so PNG alpha/black is ignored
     * @returns {Boolean} - True if found, false otherwise.
     */
    FindAnchor(imageName, &foundX, &foundY, searchArea := "", variation := 25, transColor := "", clearCursor := true) {
        imagePath := this.ResolveImagePath(imageName)
        if !FileExist(imagePath) {
            this.Debug("Image file not found: " imagePath)
            return false
        }

        if (variation <= 0)
            variation := this.defaultVariation

        bounds := ResolutionManager().clientSearchArea()
        x1 := bounds.x1, y1 := bounds.y1, x2 := bounds.x2, y2 := bounds.y2
        if (IsObject(searchArea)) {
            x1 := searchArea.HasOwnProp("x1") ? searchArea.x1 : bounds.x1
            y1 := searchArea.HasOwnProp("y1") ? searchArea.y1 : bounds.y1
            x2 := searchArea.HasOwnProp("x2") ? searchArea.x2 : bounds.x2
            y2 := searchArea.HasOwnProp("y2") ? searchArea.y2 : bounds.y2
        }

        ; Menu ImageSearch: move cursor out of the box so Unreal hover does not tint buttons.
        ; AutoRun HUD polls must NOT move the mouse — that yanks the gameplay camera.
        if (clearCursor)
            InputHelper.MoveCursorClearOfSearch({ x1: x1, y1: y1, x2: x2, y2: y2 })

        searchOption := "*" . variation
        if (transColor != "")
            searchOption .= " *Trans" transColor
        searchOption .= " " . imagePath

        prevCoordMode := A_CoordModePixel
        CoordMode("Pixel", "Screen")
        
        found := false
        outX := 0, outY := 0
        try {
            if ImageSearch(&outX, &outY, x1, y1, x2, y2, searchOption) {
                foundX := outX
                foundY := outY
                found := true
            }
        } catch as err {
            this.Debug("ImageSearch failed for " imagePath ": " err.Message)
            found := false
        }

        CoordMode("Pixel", prevCoordMode)
        return found
    }

    /**
     * Builds a sibling *_masked.png: keep tan HUD glyphs (+ interior black "!"),
     * paint everything else white for ImageSearch *TransWhite.
     */
    PrepareTanGlyphMask(imageName, transHex := "FFFFFF") {
        sourcePath := this.ResolveImagePath(imageName)
        if !FileExist(sourcePath)
            return ""

        SplitPath(sourcePath, &fileName, &dir, &ext, &nameNoExt)
        maskedPath := dir "\" nameNoExt "_masked." ext
        if this.IsMaskedImageFresh(sourcePath, maskedPath)
            return maskedPath

        pBitmap := Gdip_BitmapFromFile(sourcePath)
        if !pBitmap {
            this.Debug("Could not load image for masking: " sourcePath)
            return ""
        }

        ok := this.PaintNonGlyphPixelsTrans(pBitmap, transHex)
        if (ok)
            ok := (Gdip_SaveBitmapToFile(pBitmap, maskedPath) = 0)
        Gdip_DisposeImage(pBitmap)

        if !ok {
            this.Debug("Could not write masked image: " maskedPath)
            return ""
        }
        return maskedPath
    }

    IsMaskedImageFresh(sourcePath, maskedPath) {
        if !FileExist(maskedPath)
            return false
        srcTime := FileGetTime(sourcePath, "M")
        maskTime := FileGetTime(maskedPath, "M")
        return (maskTime != "" && srcTime != "" && maskTime >= srcTime)
    }

    /**
     * Builds a sibling *_edgesafe.png for panel anchors: keep only pixels whose local
     * neighbourhood is flat, and paint everything close to a strong edge transHex.
     *
     * Why: ImageSearch compares pixel for pixel, so a 1px-wide anti-aliased border baked
     * into an anchor flips value the moment the game renders that panel a hair off the
     * pixel grid - and a single flipped 1px border is enough on its own to defeat the
     * search. Measured on accept_mission_anchor.png (the offer window's gold button
     * plate): at the true match position the plate's border differed by up to 113 luma
     * while every other pixel matched within 15, so the raw PNG needed *140 before
     * ImageSearch would report it, and the configured *30 never could. Dropping the edge
     * band leaves a mask that matches at *10 with the mask still ~50% populated by the
     * plate interior and the glyph cores, so it stays discriminative.
     *
     * @param {String} imageName - File name or path relative to anchors\{1080p|1440p}\
     * @param {String} transHex - Hex colour painted over dropped pixels (matched with *Trans)
     * @param {Integer} radius - Neighbourhood radius that counts as "close to an edge"
     * @param {Integer} flatRange - Largest luma spread still considered flat
     * @param {Float} minKeptRatio - Below this kept fraction the mask is unusable, because
     *   an almost-empty *Trans image matches anywhere and would silently become a false
     *   positive; the method returns "" instead.
     * @returns {String} - Path to the mask, or "" if it could not be built/used.
     */
    PrepareEdgeSafeMask(imageName, transHex := "FFFFFF", radius := 2, flatRange := 90, minKeptRatio := 0.2) {
        sourcePath := this.ResolveImagePath(imageName)
        if !FileExist(sourcePath)
            return ""

        SplitPath(sourcePath, &fileName, &dir, &ext, &nameNoExt)
        ; Parameters are part of the name: tuning radius/flatRange must not silently keep
        ; reusing a mask built with the old values, which IsMaskedImageFresh would allow.
        maskedPath := dir "\" nameNoExt "_edgesafe_r" radius "_f" flatRange "." ext
        if this.IsMaskedImageFresh(sourcePath, maskedPath)
            return maskedPath

        pBitmap := Gdip_BitmapFromFile(sourcePath)
        if !pBitmap {
            this.Debug("Could not load image for edge-safe masking: " sourcePath)
            return ""
        }

        ok := this.PaintEdgeBandTrans(pBitmap, transHex, radius, flatRange, minKeptRatio)
        if (ok)
            ok := (Gdip_SaveBitmapToFile(pBitmap, maskedPath) = 0)
        Gdip_DisposeImage(pBitmap)

        if !ok {
            this.Debug("Could not build edge-safe mask for " sourcePath)
            return ""
        }
        return maskedPath
    }

    PaintEdgeBandTrans(pBitmap, transHex, radius, flatRange, minKeptRatio) {
        w := Gdip_GetImageWidth(pBitmap)
        h := Gdip_GetImageHeight(pBitmap)
        if (w < 4 || h < 4 || w <= radius * 2 || h <= radius * 2)
            return false

        transR := Integer("0x" SubStr(transHex, 1, 2))
        transG := Integer("0x" SubStr(transHex, 3, 2))
        transB := Integer("0x" SubStr(transHex, 5, 2))

        bitmapData := ""
        if Gdip_LockBits(pBitmap, 0, 0, w, h, &bitmapData, 0x26200A, 3)
            return false

        stride := NumGet(bitmapData, 8, "int")
        scan0 := NumGet(bitmapData, 16, "ptr")
        keep := Buffer(w * h, 0)

        ; Pass 1: luma of every pixel, so the flatness test reads one cheap buffer.
        lumaBuf := Buffer(w * h * 4, 0)
        loop h {
            y := A_Index - 1
            row := scan0 + (y * stride)
            loop w {
                x := A_Index - 1
                px := row + (x * 4)
                b := NumGet(px, 0, "uchar")
                gVal := NumGet(px, 1, "uchar")
                r := NumGet(px, 2, "uchar")
                NumPut("int", Integer(Round(0.299 * r + 0.587 * gVal + 0.114 * b)), lumaBuf, (y * w + x) * 4)
            }
        }

        ; Pass 2: keep only pixels whose neighbourhood is flat, i.e. renders the same
        ; wherever the panel lands relative to the pixel grid.
        kept := 0
        loop h {
            y := A_Index - 1
            loop w {
                x := A_Index - 1
                if this.IsFlatNeighbourhood(lumaBuf, w, h, x, y, radius, flatRange) {
                    NumPut("uchar", 1, keep, y * w + x)
                    kept++
                }
            }
        }

        ; Pass 3: paint everything else to the Trans colour.
        loop h {
            y := A_Index - 1
            row := scan0 + (y * stride)
            loop w {
                x := A_Index - 1
                if NumGet(keep, y * w + x, "uchar")
                    continue
                px := row + (x * 4)
                NumPut("uchar", transB, px, 0)
                NumPut("uchar", transG, px, 1)
                NumPut("uchar", transR, px, 2)
                NumPut("uchar", 255, px, 3)
            }
        }

        Gdip_UnlockBits(pBitmap, &bitmapData)

        total := w * h
        if (kept < total * minKeptRatio) {
            this.Debug("Edge-safe mask kept only " kept "/" total " pixels; discarding it.")
            return false
        }
        return true
    }

    /**
     * True when every pixel within radius of (x,y) sits inside flatRange of the darkest
     * pixel in that square. Such a neighbourhood is invariant to sub-pixel placement;
     * anything straddling a strong edge is not.
     */
    IsFlatNeighbourhood(lumaBuf, w, h, x, y, radius, flatRange) {
        y0 := Max(0, y - radius)
        y1 := Min(h - 1, y + radius)
        x0 := Max(0, x - radius)
        x1 := Min(w - 1, x + radius)
        lo := 255, hi := 0
        yy := y0
        while (yy <= y1) {
            base := yy * w
            xx := x0
            while (xx <= x1) {
                v := NumGet(lumaBuf, (base + xx) * 4, "int")
                if (v < lo)
                    lo := v
                if (v > hi)
                    hi := v
                if (hi - lo > flatRange)
                    return false
                xx++
            }
            yy++
        }
        return true
    }

    PaintNonGlyphPixelsTrans(pBitmap, transHex) {
        w := Gdip_GetImageWidth(pBitmap)
        h := Gdip_GetImageHeight(pBitmap)
        if (w < 4 || h < 4)
            return false

        transR := Integer("0x" SubStr(transHex, 1, 2))
        transG := Integer("0x" SubStr(transHex, 3, 2))
        transB := Integer("0x" SubStr(transHex, 5, 2))

        bitmapData := ""
        if Gdip_LockBits(pBitmap, 0, 0, w, h, &bitmapData, 0x26200A, 3)
            return false

        stride := NumGet(bitmapData, 8, "int")
        scan0 := NumGet(bitmapData, 16, "ptr")
        keep := Buffer(w * h, 0)

        ; Pass 1: tan / gold / brown outline
        loop h {
            y := A_Index - 1
            row := scan0 + (y * stride)
            loop w {
                x := A_Index - 1
                px := row + (x * 4)
                b := NumGet(px, 0, "uchar")
                gVal := NumGet(px, 1, "uchar")
                r := NumGet(px, 2, "uchar")
                if this.IsHudGlyphPixel(r, gVal, b)
                    NumPut("uchar", 1, keep, y * w + x)
            }
        }

        ; Pass 2: keep near-black only when enclosed by tan on N/S/E/W (the "!").
        ; Square bbox corners outside the diamond fail this and become Trans.
        loop h {
            y := A_Index - 1
            row := scan0 + (y * stride)
            loop w {
                x := A_Index - 1
                idx := y * w + x
                if NumGet(keep, idx, "uchar")
                    continue
                px := row + (x * 4)
                b := NumGet(px, 0, "uchar")
                gVal := NumGet(px, 1, "uchar")
                r := NumGet(px, 2, "uchar")
                if !this.IsNearBlackPixel(r, gVal, b)
                    continue
                if this.IsEnclosedByKept(keep, w, h, x, y, 24)
                    NumPut("uchar", 1, keep, idx)
            }
        }

        ; Pass 2b: erode tan/gold edges by 1px (keep black "!"). Outer AA blends
        ; into rocky ground and breaks ImageSearch; solid interior stays stable.
        eroded := Buffer(w * h, 0)
        loop h {
            y := A_Index - 1
            row := scan0 + (y * stride)
            loop w {
                x := A_Index - 1
                idx := y * w + x
                if !NumGet(keep, idx, "uchar")
                    continue
                px := row + (x * 4)
                b := NumGet(px, 0, "uchar")
                gVal := NumGet(px, 1, "uchar")
                r := NumGet(px, 2, "uchar")
                if this.IsNearBlackPixel(r, gVal, b) {
                    NumPut("uchar", 1, eroded, idx)
                    continue
                }
                if (this.CountKeptNeighbors(keep, w, h, x, y, 1) >= 8)
                    NumPut("uchar", 1, eroded, idx)
            }
        }
        keep := eroded

        ; Pass 3: paint non-glyphs to Trans color (white by default)
        loop h {
            y := A_Index - 1
            row := scan0 + (y * stride)
            loop w {
                x := A_Index - 1
                if NumGet(keep, y * w + x, "uchar")
                    continue
                px := row + (x * 4)
                NumPut("uchar", transB, px, 0)
                NumPut("uchar", transG, px, 1)
                NumPut("uchar", transR, px, 2)
                NumPut("uchar", 255, px, 3)
            }
        }

        Gdip_UnlockBits(pBitmap, &bitmapData)
        return true
    }

    IsNearBlackPixel(r, gVal, b) {
        return (r <= 55 && gVal <= 50 && b <= 45)
    }

    CountKeptNeighbors(keep, w, h, x, y, radius := 1) {
        count := 0
        loop (radius * 2 + 1) {
            dy := A_Index - 1 - radius
            ny := y + dy
            if (ny < 0 || ny >= h)
                continue
            loop (radius * 2 + 1) {
                dx := A_Index - 1 - radius
                if (dx == 0 && dy == 0)
                    continue
                nx := x + dx
                if (nx < 0 || nx >= w)
                    continue
                if NumGet(keep, ny * w + nx, "uchar")
                    count += 1
            }
        }
        return count
    }

    /**
     * True if walking N/S/E/W from (x,y) each hits a kept (tan) pixel before
     * leaving the image — i.e. the pixel sits inside a tan glyph like the "!".
     */
    IsEnclosedByKept(keep, w, h, x, y, maxDist := 24) {
        static dirs := [[1, 0], [-1, 0], [0, 1], [0, -1]]
        for _, d in dirs {
            found := false
            nx := x, ny := y
            loop maxDist {
                nx += d[1]
                ny += d[2]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h)
                    break
                if NumGet(keep, ny * w + nx, "uchar") {
                    found := true
                    break
                }
            }
            if !found
                return false
        }
        return true
    }

    IsHudGlyphPixel(r, gVal, b) {
        ; Tan/gold fill + brown outlines. Near-black "!" is kept only inside tan bbox.

        ; Light tan / gold glyphs (text + diamond fill). Wide tolerance for blended in-game HUD.
        if (r >= 115 && gVal >= 80 && b <= 170 && r > b + 10 && gVal > b + 4)
            return true

        ; Brighter yellow-gold diamond highlights (HDR / sky-backed HUD)
        if (r >= 155 && gVal >= 120 && b <= 140 && r >= gVal - 8)
            return true

        ; Pale tan text/glyphs when backlit by bright sky
        if (r >= 165 && gVal >= 130 && b <= 155 && r >= gVal - 12 && gVal >= b + 8)
            return true

        ; Mid/dark brown outline ring around glyphs
        if (r >= 45 && r <= 135 && gVal >= 32 && gVal <= 110 && b >= 12 && b <= 90
            && r >= gVal - 10 && gVal >= b - 4 && (r - b) >= 10)
            return true

        return false
    }

    /**
     * Finds an anchor image and calculates an interactable point offset from it.
     * @param {String} imageName - Anchor image file
     * @param {Integer} offsetX - Pixel offset X from anchor top-left
     * @param {Integer} offsetY - Pixel offset Y from anchor top-left
     * @param {VarRef} targetX - Output calculated X coordinate
     * @param {VarRef} targetY - Output calculated Y coordinate
     * @param {Object} searchArea - Optional search bounding box
     * @param {Integer} variation - Color variation tolerance
     * @returns {Boolean} - True if anchor found and offset calculated
     */
    FindAnchorOffset(imageName, offsetX, offsetY, &targetX, &targetY, searchArea := "", variation := 25) {
        anchorX := 0, anchorY := 0
        if this.FindAnchor(imageName, &anchorX, &anchorY, searchArea, variation) {
            rm := ResolutionManager()
            targetX := anchorX + Round(offsetX * rm.scale)
            targetY := anchorY + Round(offsetY * rm.scale)
            return true
        }
        targetX := 0
        targetY := 0
        return false
    }

    /**
     * Finds an anchor image and returns a relative bounding rectangle for scanning/cropping.
     */
    FindRelativeRegion(imageName, relX, relY, relW, relH, searchArea := "", variation := 25) {
        anchorX := 0, anchorY := 0
        if this.FindAnchor(imageName, &anchorX, &anchorY, searchArea, variation) {
            rm := ResolutionManager()
            return {
                x: anchorX + Round(relX * rm.scale),
                y: anchorY + Round(relY * rm.scale),
                w: Round(relW * rm.scale),
                h: Round(relH * rm.scale)
            }
        }
        return ""
    }

    /**
     * Waits for an anchor to appear on screen within a timeout.
     */
    WaitForAnchor(imageName, &foundX, &foundY, timeoutMs := 3000, variation := 25) {
        startTime := A_TickCount
        while (A_TickCount - startTime < timeoutMs) {
            if this.FindAnchor(imageName, &foundX, &foundY, "", variation)
                return true
            Sleep(50)
        }
        return false
    }

    ResolveImagePath(imageName) {
        if FileExist(imageName)
            return imageName

        folder := ResolutionManager().AnchorFolder()
        candidate := this.rootDir "\anchors\" folder "\" imageName
        if FileExist(candidate)
            return candidate

        return imageName
    }

    Debug(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[AnchorMatcher] " message)
    }
}
