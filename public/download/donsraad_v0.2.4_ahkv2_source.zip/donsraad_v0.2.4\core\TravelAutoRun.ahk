#Requires AutoHotkey v2.0+

/**
 * When AutoRun is enabled and a play timer is running, poll the Travel
 * confirmation window with ImageSearch. 1000ms is enough: the dialog stays
 * until dismissed, and a cropped ImageSearch is a few milliseconds.
 */
class TravelAutoRun {
    static intervalMs := 1000
    static boundTick := ""
    static busy := false
    static suppressed := false
    static leftoverDismissUntil := 0
    static leftoverDismissMs := 10000
    static leftoverReadyAfter := 0
    static leftoverReadyDelayMs := 800
    static leftoverConfirmMs := 450
    static leftoverSettleMs := 1000
    static leftoverDismissCount := 0
    ; Minimum gap between two Esc sends. The leftover indicators stack and the HUD
    ; never goes fully clear between them, so without this the next Esc can be sent
    ; before the UI has registered the previous one.
    static leftoverMinEscGapMs := 2000
    ; Upper bound on Esc sends for one watch. One indicator exists per completed
    ; mission, so this is seeded from the run's claimed count; -1 means uncapped.
    static leftoverMaxEscs := -1
    static leftoverEscsSent := 0
    static leftoverLastEscAt := 0
    static leftoverWindowEndedLogged := false

    static Start() {
        if (this.boundTick != "")
            return
        this.boundTick := ObjBindMethod(this, "Tick")
        SetTimer(this.boundTick, this.intervalMs)
    }

    static Stop() {
        if (this.boundTick != "") {
            try SetTimer(this.boundTick, 0)
        }
        this.boundTick := ""
    }

    static IsActive() {
        return this.busy || (this.boundTick != "")
    }

    static IsSuppressed() {
        return this.suppressed
    }

    static Suppress() {
        this.suppressed := true
        this.Stop()
        StatusBar.Refresh()
    }

    static ClearSuppress() {
        if !this.suppressed
            return
        this.suppressed := false
        this.Sync()
    }

    static Sync() {
        if this.ShouldWatch()
            this.Start()
        else
            this.Stop()
        StatusBar.Refresh()
    }

    static ShouldBlockForMnemonicDepletion() {
        global settingsManagerInst, stateManagerInst
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        return settingsManagerInst.ShouldStopAutomationForMnemonicDepletion(stateManagerInst)
    }

    static IsAutoRunEnabled() {
        global settingsManagerInst
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        return settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false)
    }

    static ResetLeftoverDismiss() {
        this.leftoverReadyAfter := 0
        this.leftoverDismissUntil := 0
        this.leftoverDismissCount := 0
        this.leftoverMaxEscs := -1
        this.leftoverEscsSent := 0
        this.leftoverLastEscAt := 0
        this.leftoverWindowEndedLogged := false
    }

    static ShouldWatch() {
        global userStateInst, stateManagerInst
        if this.busy
            return false
        if this.suppressed
            return false
        if !this.IsAutoRunEnabled() {
            if (this.leftoverReadyAfter > 0 || this.leftoverDismissUntil > 0)
                this.ResetLeftoverDismiss()
            return false
        }
        if this.ShouldBlockForMnemonicDepletion()
            return false
        if !IsSet(userStateInst) || !IsObject(userStateInst)
            return false
        if userStateInst.IsRunActive()
            return false
        if !userStateInst.IsInitialized()
            return false
        if !IsSet(stateManagerInst) || !IsObject(stateManagerInst)
            return false
        if !stateManagerInst.HasMethod("HasActiveRunTimer")
            return false
        return stateManagerInst.HasActiveRunTimer()
    }

    /**
     * Arms the leftover-indicator watch.
     * @param {Integer} expectedEscs - How many indicators to expect, i.e. the number of
     *   missions completed this run (one indicator each). This is the hard cap on Esc
     *   sends. 0 means send none; -1 means uncapped.
     */
    static ArmLeftoverDismiss(expectedEscs := -1) {
        if !this.IsAutoRunEnabled()
            return
        this.leftoverReadyAfter := A_TickCount + this.leftoverReadyDelayMs
        this.leftoverMaxEscs := (expectedEscs is Integer) ? expectedEscs : -1

        ; A multi-completion run needs several paced sends. Without stretching the
        ; window the watch would end while indicators are still on screen, so size it
        ; to fit the cap (the cap still bounds the work).
        watchMs := this.leftoverDismissMs
        if (this.leftoverMaxEscs > 1) {
            needed := this.leftoverMaxEscs * (this.leftoverConfirmMs + this.leftoverMinEscGapMs)
            if (needed > watchMs)
                watchMs := needed
        }
        this.leftoverDismissUntil := this.leftoverReadyAfter + watchMs

        this.leftoverEscsSent := 0
        this.leftoverLastEscAt := 0
        this.leftoverDismissCount := 0
        this.leftoverWindowEndedLogged := false

        capInfo := (this.leftoverMaxEscs >= 0)
            ? "; at most " this.leftoverMaxEscs " Esc(s) for " this.leftoverMaxEscs " completed mission(s)."
            : "."
        this.Debug("Armed leftover View mission report? watch for "
            Integer(watchMs / 1000) " seconds after ready (starts in "
            Integer(this.leftoverReadyDelayMs) " ms). Each leftover will be confirmed before Esc"
            capInfo)
    }

    static QuietMissionCompleteFor(ms := "") {
        this.ArmLeftoverDismiss()
    }

    static IsLeftoverDismissWindow() {
        return (this.leftoverDismissUntil > 0
            && A_TickCount >= this.leftoverReadyAfter
            && A_TickCount < this.leftoverDismissUntil)
    }

    static IsMissionCompleteQuiet() {
        if !this.IsAutoRunEnabled()
            return false
        return this.IsLeftoverDismissWindow()
            || (this.leftoverReadyAfter > 0 && A_TickCount < this.leftoverReadyAfter)
    }

    static MaybeLogLeftoverWindowEnded() {
        if this.leftoverWindowEndedLogged
            return
        if (this.leftoverDismissUntil <= 0 || A_TickCount < this.leftoverDismissUntil)
            return
        this.leftoverWindowEndedLogged := true
        this.leftoverDismissUntil := 0
        if (this.leftoverDismissCount > 0)
            this.Debug("Leftover watch ended. Dismissed " this.leftoverDismissCount " leftover report(s). Mission-complete watch is active.")
        else
            this.Debug("No leftover View mission report? in the first 10 seconds. Mission-complete watch is active.")
    }

    static ReportIsVisible() {
        global masterScenarioInst
        return (IsSet(masterScenarioInst) && IsObject(masterScenarioInst)
            && masterScenarioInst.HasMethod("IsMissionCompleteIndicatorVisible")
            && masterScenarioInst.IsMissionCompleteIndicatorVisible())
    }

    static Tick() {
        if !this.ShouldWatch() {
            this.Stop()
            return
        }

        ; Screen capture sees whatever is on top. Alt-tabbed / covered game must not poll.
        if !GameWindow.IsActive()
            return

        global masterScenarioInst
        if !IsSet(masterScenarioInst) || !IsObject(masterScenarioInst)
            return

        autoRunOn := this.IsAutoRunEnabled()

        travelVisible := false
        if autoRunOn {
            travelVisible := (masterScenarioInst.HasMethod("IsTravelConfirmationVisible")
                && masterScenarioInst.IsTravelConfirmationVisible())
        }
        if travelVisible {
            this.StartPickerFromPrompt("Travel confirmation")
            return
        }

        if (this.leftoverReadyAfter > 0 && A_TickCount < this.leftoverReadyAfter)
            return

        reportVisible := this.ReportIsVisible()

        if this.IsLeftoverDismissWindow() {
            if autoRunOn && reportVisible
                this.DismissLeftoverMissionReport()
            return
        }

        this.MaybeLogLeftoverWindowEnded()

        if !autoRunOn
            return

        if !reportVisible
            return

        this.StartPickerFromPrompt("Mission complete prompt")
    }

    /**
     * Confirm the leftover HUD is still there after a short wait, then Esc.
     * Skip Esc if it vanished — a false send can open the system menu.
     * Stacked leftovers (multiple finished missions) are dismissed one by one until the
     * leftover window ends, paced so each Esc has registered before the next is sent,
     * and capped at the number of missions completed this run (one indicator each).
     */
    static DismissLeftoverMissionReport() {
        this.busy := true
        this.Stop()
        try {
            ; Pace the sends before confirming, so the visibility check stays fresh and
            ; the previous Esc has had time to register in the UI.
            this.WaitForLeftoverEscGap()

            this.Debug("Possible leftover View mission report? Waiting "
                this.leftoverConfirmMs " ms to confirm before Esc.")
            Sleep(this.leftoverConfirmMs)

            if !GameWindow.IsActive() {
                this.Debug("Game is not focused after confirm wait. Skipping Esc.")
                return
            }
            if !this.ReportIsVisible() {
                this.Debug("Leftover icon was gone on confirm. Skipping Esc.")
                return
            }
            if !this.CanSendLeftoverEsc() {
                ; One indicator per completed mission. Hitting the cap means detection is
                ; stuck, or matched something that is not an indicator, and every extra Esc
                ; lands in the world where Esc toggles the system menu. End the watch rather
                ; than retry.
                if (this.leftoverMaxEscs > 0)
                    this.Log("Leftover Esc cap reached (" this.leftoverEscsSent " of "
                        this.leftoverMaxEscs " completed mission(s)). Stopping the leftover watch; "
                        "an indicator may still be on screen.")
                else
                    this.Debug("Leftover Esc cap is 0 for this run. Skipping Esc.")
                this.leftoverDismissUntil := A_TickCount
                return
            }

            GameWindow.Activate()
            this.Debug("Leftover View mission report? confirmed. Sending Esc ("
                this.leftoverEscsSent + 1 "/"
                (this.leftoverMaxEscs >= 0 ? this.leftoverMaxEscs : "uncapped") ").")
            InputHelper.SendGameKey("Esc")
            this.leftoverEscsSent += 1
            this.leftoverLastEscAt := A_TickCount
            this.Debug("Waiting 1 second for the leftover icon to clear.")
            Sleep(this.leftoverSettleMs)

            if this.ReportIsVisible() {
                this.Debug("Icon still visible after the 1 second wait. Will confirm again before the next Esc.")
                return
            }

            this.leftoverDismissCount += 1
            this.Debug("Leftover prompt closed after Esc (" this.leftoverDismissCount " dismissed). Watching for more leftovers until the window ends.")
        } catch as err {
            this.Debug("Failed to dismiss leftover View mission report?: " err.Message)
        } finally {
            this.busy := false
            this.Sync()
        }
    }

    static CanSendLeftoverEsc() {
        if (this.leftoverMaxEscs < 0)
            return true
        return (this.leftoverEscsSent < this.leftoverMaxEscs)
    }

    /**
     * Enforces a minimum gap between Esc sends so the UI has registered the previous one.
     */
    static WaitForLeftoverEscGap() {
        if (this.leftoverLastEscAt <= 0)
            return
        elapsed := A_TickCount - this.leftoverLastEscAt
        if (elapsed >= this.leftoverMinEscGapMs)
            return
        wait := this.leftoverMinEscGapMs - elapsed
        this.Debug("Waiting " wait " ms before the next Esc so the UI can register the last one.")
        Sleep(wait)
    }

    static StartPickerFromPrompt(reason) {
        global loggerInst
        if this.ShouldBlockForMnemonicDepletion() {
            this.Debug("Skipping AutoRun start — mnemonic recollections ran out.")
            StatusBar.Notify("Mnemonic recollections ran out", "info")
            return
        }
        this.busy := true
        this.Stop()
        try {
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(reason " detected. AutoRun starting the picker.")
            StatusBar.SetStatus("AutoRun", "working")
            StartPickerRun()
        } finally {
            this.busy := false
            this.Sync()
        }
    }

    static Debug(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[TravelAutoRun] " message)
    }

    static Log(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Log")
            loggerInst.Log("[TravelAutoRun] " message)
    }
}
