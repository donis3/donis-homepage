#Requires AutoHotkey v2.0+

/**
 * Debug helper: open Landsraad house grid and read house name + personal
 * contribution for a single cell (default row 3, col 4).
 * Leaves a red overlay on the personal contribution OCR region.
 */
class PersonalContributionDebug {
    debugOverlays := []
    logger := ""
    scanner := ""
    openLandsraadGridScenario := ""
    gridSettleMs := 300
    tooltipWaitMs := 150
    houseTextMaxRetries := 2
    debugTargetRow := 3
    debugTargetCol := 4

    __New(loggerInst := "", openLandsraadGridScenarioInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.logger := loggerInst
        this.openLandsraadGridScenario := openLandsraadGridScenarioInst
        this.scanner := HouseGridScanner(loggerInst, anchorMatcherInst, stateManagerInst)
        this.scanner.showDebugBoxes := false
    }

    Execute(*) {
        if IsObject(this.openLandsraadGridScenario)
            this.openLandsraadGridScenario.Execute()

        if (this.gridSettleMs > 0)
            Sleep(this.gridSettleMs)

        this.HideDebugOverlays()
        GameWindow.Activate()

        row := this.debugTargetRow
        col := this.debugTargetCol
        this.Log("[Personal Contribution] Scanning row " row ", col " col "...")
        this.ScanCellAt(row, col)
        this.Log("[Personal Contribution] Done.")
    }

    ScanCellAt(gridRow, gridCol) {
        cell := this.scanner.GetGridCell(gridRow, gridCol)
        if !IsObject(cell) {
            this.Log("[Personal Contribution] Row " gridRow ", col " gridCol ": cell coordinates unavailable")
            return
        }

        slotLabel := "Slot " cell.slot " (row " cell.row ", col " cell.col ")"
        areas := this.scanner.GetTooltipSearchAreas(cell)
        if !IsObject(areas) {
            this.Log("[Personal Contribution] " slotLabel ": tooltip search areas unavailable")
            return
        }

        match := this.FindHouseTextWithRetries(cell, areas)
        if !match.found {
            this.Log("[Personal Contribution] " slotLabel ': "House not yet revealed"')
            return
        }

        anchorX := match.foundX
        anchorY := match.foundY
        houseResult := this.scanner.ReadHouseName(cell, anchorX, anchorY)
        houseLabel := this.FormatHouseLabel(houseResult)
        this.LogHouseOcr(slotLabel, houseResult)

        personalSearchBox := this.scanner.BuildPersonalTextSearchBox(anchorX, anchorY)
        if !IsObject(personalSearchBox) {
            this.Log("[Personal Contribution] " slotLabel ': "' houseLabel '" : personal search box unavailable')
            return
        }

        foundX := 0, foundY := 0
        if !this.scanner.FindPersonalTextInArea(personalSearchBox.searchArea, &foundX, &foundY) {
            this.Log("[Personal Contribution] " slotLabel ': "' houseLabel '" : missions not revealed')
            this.ShowDebugBox(personalSearchBox.screenX, personalSearchBox.screenY
                , personalSearchBox.screenW, personalSearchBox.screenH)
            this.Debug("[Personal Contribution] Personal text search box ["
                personalSearchBox.screenX ", " personalSearchBox.screenY ", "
                personalSearchBox.screenW ", " personalSearchBox.screenH "].")
            return
        }

        this.Debug("[Personal Contribution] " slotLabel ": personal text at (" foundX ", " foundY ").")

        contribRowBox := this.scanner.BuildPersonalContributionRowBox(anchorX, foundY)
        valueBox := this.scanner.BuildPersonalContributionValueBox(anchorX, foundY)
        if !IsObject(contribRowBox) && !IsObject(valueBox) {
            this.Log("[Personal Contribution] " slotLabel ': "' houseLabel '" : contribution OCR boxes unavailable')
            return
        }

        if IsObject(contribRowBox) {
            this.Debug("[Personal Contribution] " slotLabel " contribution row area ["
                contribRowBox.screenX ", " contribRowBox.screenY ", "
                contribRowBox.screenW ", " contribRowBox.screenH "].")
        }
        if IsObject(valueBox) {
            this.Debug("[Personal Contribution] " slotLabel " contribution value area ["
                valueBox.screenX ", " valueBox.screenY ", "
                valueBox.screenW ", " valueBox.screenH "].")
        }

        ocrRun := this.scanner.ReadPersonalContributionOcrCandidates(anchorX, foundY)
        for _, candidate in ocrRun.candidates {
            if !IsObject(candidate)
                continue
            modeLabel := candidate.region "/" candidate.mode
            if (candidate.mode == "hud")
                modeLabel .= " luma" candidate.lumaMin
            parsedLabel := candidate.parsed.found ? candidate.parsed.value : "?"
            this.Debug("[Personal Contribution] OCR try " modeLabel ": raw `"" candidate.rawText
                "`" -> " parsedLabel)
            if IsObject(candidate.ocrResult)
                this.LogOcrWordBreakdown(candidate.ocrResult, modeLabel)
        }

        best := ocrRun.best
        overlayBox := IsObject(best) ? best.box : (IsObject(valueBox) ? valueBox : contribRowBox)
        this.ShowDebugBox(overlayBox.screenX, overlayBox.screenY, overlayBox.screenW, overlayBox.screenH)

        ocrResult := IsObject(best)
            ? { rawText: best.rawText, normalizedText: best.normalizedText }
            : { rawText: "", normalizedText: "" }
        contribLabel := this.FormatContributionLabel(ocrResult)
        if IsObject(best) && best.parsed.found {
            modeLabel := best.region "/" best.mode
            if (best.mode == "hud")
                modeLabel .= " luma" best.lumaMin
            this.Debug("[Personal Contribution] OCR winner: " modeLabel)
        }
        this.Log("[Personal Contribution] " slotLabel ': "' houseLabel '" : ' contribLabel)
    }

    LogOcrWordBreakdown(ocrResult, prefix := "") {
        label := prefix != "" ? (" (" prefix ")") : ""
        if !IsObject(ocrResult)
            return
        if (ocrResult.HasProp("lines") && ocrResult.lines is Array) {
            loop ocrResult.lines.Length
                this.Debug("[Personal Contribution] Contribution OCR line " A_Index label ": `"" ocrResult.lines[A_Index] "`"")
        }
        if (ocrResult.HasProp("words") && ocrResult.words is Array) {
            for _, word in ocrResult.words {
                if !(word is Map) && !IsObject(word)
                    continue
                wText := word.HasProp("text") ? word.text : (word.Has("text") ? word["text"] : "")
                wx := word.HasProp("x") ? word.x : (word.Has("x") ? word["x"] : 0)
                wy := word.HasProp("y") ? word.y : (word.Has("y") ? word["y"] : 0)
                this.Debug("[Personal Contribution] Contribution OCR word [" prefix "]: `"" wText "`" @ ("
                    Round(wx) ", " Round(wy) ")")
            }
        }
    }

    ShowDebugBox(screenX, screenY, screenW, screenH) {
        overlay := RectangleOverlay()
        overlay.ShowAtScreen(screenX, screenY, screenW, screenH)
        this.debugOverlays.Push(overlay)
    }

    FindHouseTextWithRetries(cell, areas) {
        match := { found: false }
        maxAttempts := this.houseTextMaxRetries + 1

        loop maxAttempts {
            if (A_Index > 1)
                this.Debug("[Personal Contribution] " cell.slot ": house text not found, retry "
                    (A_Index - 1) "/" this.houseTextMaxRetries " (right then left)...")
            this.HoverCellForTooltip(cell)
            match := this.scanner.TryFindHouseText(cell, areas)
            if match.found
                return match
        }
        return match
    }

    HoverCellForTooltip(cell) {
        this.Debug("[Personal Contribution] Hovering cell row " cell.row " col " cell.col
            " (slot " cell.slot ") at (" cell.hoverX ", " cell.hoverY ").")
        InputHelper.FastMove(cell.hoverX, cell.hoverY)
        if (this.tooltipWaitMs > 0)
            Sleep(this.tooltipWaitMs)
    }

    FormatHouseLabel(houseResult) {
        if !IsObject(houseResult)
            return "(unknown)"

        if (houseResult.matchedName != "" && houseResult.confidence >= 0.4)
            return houseResult.matchedName
        if (houseResult.normalizedText != "")
            return houseResult.normalizedText
        return "(unknown)"
    }

    FormatContributionLabel(ocrResult) {
        if !IsObject(ocrResult)
            return "?"
        parsed := this.scanner.ParsePersonalContributionNumber(ocrResult.normalizedText)
        if parsed.found
            return parsed.value
        if (ocrResult.normalizedText != "")
            return "?"
        return "?"
    }

    LogHouseOcr(slotLabel, houseResult) {
        if !IsObject(houseResult)
            return
        if (houseResult.normalizedText != "")
            this.Debug("[Personal Contribution] " slotLabel " house OCR: `"" houseResult.normalizedText "`"")
        if (houseResult.rawText != "" && houseResult.rawText != houseResult.normalizedText)
            this.Debug("[Personal Contribution] " slotLabel " house raw OCR: `"" houseResult.rawText "`"")
    }

    HideDebugOverlays() {
        for _, overlay in this.debugOverlays {
            if IsObject(overlay)
                overlay.Close()
        }
        this.debugOverlays := []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
