#Requires AutoHotkey v2.0+

/**
 * Accept Missions Scenario
 * On each house the player has targetted, accept offered missions that are NOT
 * in the targetted list (Space). Targetted offers are left untouched.
 * Stops after 3 accepts (game active-mission cap). If every targetted mission
 * for a house is already in that house's offers, skip the house (Esc) and mark
 * the grid cell done for the rest of this hunt sequence.
 *
 * Done cells are not rescanned on later hunt passes (including after disband)
 * until every targeted cell is ready or the pick sequence ends.
 *
 * After Execute(), GetStatus() reports the last run:
 *   error — empty when the loop finished without a hard stop
 *   missingTargettedMissionCount — targetted missions not seen in that house's offers
 * If missingTargettedMissionCount is 0 and error is empty, every targetted
 * mission was available to pick up.
 *
 * Callable via acceptMissionsScenarioInst.Execute().
 *
 * Assumes the Landsraad house grid tab is already open.
 */
class AcceptMissionsScenario {
    stateManager := ""
    logger := ""
    anchorMatcher := ""
    lastStatus := ""
    sessionAcceptedNames := ""
    sessionAcceptedCount := 0
    huntDoneCells := ""
    houseOpenWaitMs := 100
    ; The offer window can take several seconds to render after the click (game hitch,
    ; Landsraad menu still fading in, slow disk). Budget it generously: a too-short wait
    ; is indistinguishable from "the window never opened" and hard-stops the whole loop.
    offerWindowWaitMs := 15000
    ; Cheap last-chance poll after the (expensive) full-client fallback: the window can
    ; finish opening while that scan is still running.
    offerWindowFinalGraceMs := 2000
    offerWindowClickSettleMs := 200
    offerWindowImage := "accept_mission_anchor.png"
    offerWindowSearchPadding := 60
    offerWindowMaskedVariation := 45
    offerWindowMaskedPath := ""
    offerWindowMaskResolved := false
    minReadConfidence := 0.4
    imageVariation := 30
    soloTargetBySpec := ""
    recordedSoloSpecs := ""
    huntAbandonStart := 0
    currentAcceptHouse := ""

    profileManager := ""

    __New(stateManagerInst := "", loggerInst := "", anchorMatcherInst := "", profileManagerInst := "") {
        this.stateManager := stateManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.profileManager := profileManagerInst
        this.ResetSession()
    }

    /**
     * Clears filler-accept tracking for the current board. Called after
     * RemoveActiveMissions; does not clear hunt done-cell markers.
     */
    ResetSession() {
        this.sessionAcceptedNames := Map()
        this.sessionAcceptedCount := 0
    }

    ClearHuntDoneCells() {
        this.huntDoneCells := Map()
    }

    IsHuntCellDone(slotIdx) {
        return IsObject(this.huntDoneCells) && this.huntDoneCells.Has(slotIdx)
    }

    MarkHuntCellDone(slotIdx) {
        if (slotIdx < 1)
            return
        if !IsObject(this.huntDoneCells)
            this.huntDoneCells := Map()
        if this.huntDoneCells.Has(slotIdx)
            return
        this.huntDoneCells[slotIdx] := true
        this.Debug("[AcceptMissions] Marked cell " slotIdx " done (all targets in offers).")
    }

    AllHuntCellsDone(houses) {
        if !IsObject(houses) || houses.Length == 0
            return false
        for _, house in houses {
            if !this.IsHuntCellDone(house.gridLocation)
                return false
        }
        return true
    }

    /**
     * Start of a full pick sequence (before leftover disbands).
     * Solo-spec targets record abandonsUntilReveal when they appear.
     */
    BeginHunt() {
        this.ClearHuntDoneCells()
        this.ResetSession()
        this.recordedSoloSpecs := Map()
        this.huntAbandonStart := this.GetGuildAbandonTotal()
        this.RefreshSoloSpecTargets()
    }

    GetGuildAbandonTotal() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetStat")
            return Integer(this.stateManager.GetStat("guildAbandons"))
        return 0
    }

    RefreshSoloSpecTargets() {
        this.soloTargetBySpec := Map()
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("GetTargetedMissions")
            return
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return

        bySpec := Map()
        for _, mission in targeted {
            if !IsObject(mission)
                continue
            name := mission.HasOwnProp("missionName") ? Trim(mission.missionName) : ""
            spec := mission.HasOwnProp("specialization") ? Trim(mission.specialization) : ""
            if (spec == "" && name != "" && this.stateManager.HasMethod("GetMissionSpecialization"))
                spec := this.stateManager.GetMissionSpecialization(name)
            if (name == "" || spec == "")
                continue
            specKey := StrLower(spec)
            if !bySpec.Has(specKey)
                bySpec[specKey] := []
            bySpec[specKey].Push(name)
        }

        for specKey, names in bySpec {
            if (names.Length == 1)
                this.soloTargetBySpec[specKey] := names[1]
        }
    }

    IsAlreadyAccepted(missionName) {
        if (missionName == "" || !IsObject(this.sessionAcceptedNames))
            return false
        return this.sessionAcceptedNames.Has(StrLower(missionName))
    }

    MarkAccepted(missionName, houseName := "") {
        if (missionName == "")
            return
        if !IsObject(this.sessionAcceptedNames)
            this.sessionAcceptedNames := Map()
        key := StrLower(missionName)
        if this.sessionAcceptedNames.Has(key)
            return
        this.sessionAcceptedNames[key] := true
        this.sessionAcceptedCount++
        house := Trim(houseName)
        if (house == "" && IsObject(this.currentAcceptHouse))
            house := this.ResolveScannedHouseName(this.currentAcceptHouse)
        if IsObject(this.stateManager) && this.stateManager.HasMethod("RecordAcceptedActiveMission")
            this.stateManager.RecordAcceptedActiveMission(missionName, house)
    }

    ResolveScannedHouseName(house) {
        if !IsObject(house)
            return ""
        pm := this.profileManager
        if !IsObject(pm) {
            global profileManagerInst
            if IsSet(profileManagerInst) && IsObject(profileManagerInst)
                pm := profileManagerInst
        }
        if !IsObject(pm) || !pm.HasMethod("GetScannedHouseAtCell")
            return ""
        row := house.HasOwnProp("gridRow") ? house.gridRow : 0
        col := house.HasOwnProp("gridCol") ? house.gridCol : 0
        return pm.GetScannedHouseAtCell(row, col)
    }

    EnsureGameActive() {
        return GameWindow.Activate()
    }

    /**
     * Last-run result for orchestration.
     * error is empty when the loop finished without a hard stop.
     * missingTargettedMissionCount is 0 when every targetted mission was seen
     * in that house's offers (and can be picked up).
     */
    GetStatus() {
        if IsObject(this.lastStatus)
            return this.lastStatus
        return this.MakeStatus()
    }

    /**
     * @returns {Boolean} - True when the house loop finishes, false on a hard stop.
     */
    Execute() {
        this.lastStatus := this.MakeStatus()
        this.Debug("[AcceptMissions] Starting scenario...")
        this.EnsureGameActive()

        if !IsObject(this.stateManager) {
            this.SetStatus(0, "State manager is unavailable.")
            this.Log("[AcceptMissions] Error: State manager is unavailable.")
            return false
        }

        targeted := this.stateManager.GetTargetedMissions()
        if (targeted.Length == 0) {
            this.SetStatus(0, "No targetted missions were found.")
            this.Log("[AcceptMissions] No targeted missions selected.")
            return false
        }

        targetedNames := this.BuildTargetedNameMap(targeted)
        this.RefreshSoloSpecTargets()
        houses := this.GetTargetedHouses(targeted)
        acceptedCount := this.sessionAcceptedCount
        newAccepted := 0
        maxActive := 3
        missingCount := 0
        visitedSlots := Map()
        pendingHouses := this.CountPendingHuntCells(houses)
        this.Debug("[AcceptMissions] Looping " houses.Length " targetted house(s), "
            pendingHouses " pending scan(s). Session accepted=" acceptedCount "/" maxActive ".")

        if this.AllHuntCellsDone(houses) {
            this.Debug("[AcceptMissions] All targeted cells already have offers ready. Skipping scan pass.")
            this.SetStatus(0, "", acceptedCount, newAccepted)
            return true
        }

        for houseIdx, house in houses {
            if this.IsCancelled() {
                this.Debug("[AcceptMissions] Cancelled.")
                this.SetStatus(missingCount, "", acceptedCount, newAccepted)
                return false
            }
            if (acceptedCount >= maxActive) {
                this.Debug("[AcceptMissions] Reached " maxActive " accepted missions (global cap). Stopping.")
                break
            }

            if this.IsHuntCellDone(house.gridLocation) {
                this.Debug("[AcceptMissions] Cell " house.gridLocation
                    " already has all targets in offers. Skipping scan.")
                continue
            }

            this.currentAcceptHouse := house
            this.Debug("[AcceptMissions] House cell " house.gridLocation
                " (row " house.gridRow ", col " house.gridCol ").")

            if !this.OpenHouse(house) {
                this.FailOfferWindow(house)
                remaining := this.CountTargetsFromHouseIndex(houses, houseIdx)
                this.SetStatus(missingCount + remaining,
                    "Offer window did not open at grid " house.gridLocation ".", acceptedCount, newAccepted)
                return false
            }

            offered := this.ReadOfferedMissions()
            recognized := this.GetRecognizedMissions(offered)
            this.LogOfferedMissions(offered)

            if (recognized.Length != 3) {
                this.FailMissionRead(house, offered)
                remaining := this.CountTargetsFromHouseIndex(houses, houseIdx)
                this.SetStatus(missingCount + remaining,
                    "Failed to read offered missions at grid " house.gridLocation ".", acceptedCount, newAccepted)
                return false
            }

            if !this.HouseSpecializationMatches(house, recognized) {
                remaining := this.CountTargetsFromHouseIndex(houses, houseIdx)
                this.SetStatus(missingCount + remaining, "Wrong specialization", acceptedCount, newAccepted)
                return false
            }

            missingHere := this.CountMissingTargetsForHouse(house, recognized)
            missingCount += missingHere
            visitedSlots[house.gridLocation] := true

            if this.HouseTargetsAreOffered(house, recognized) {
                this.MarkHuntCellDone(house.gridLocation)
                this.Debug("[AcceptMissions] All targetted missions for house " house.gridLocation
                    " are in the offers. Skipping.")
                this.RecordSoloSpecHuntIfReady(house)
                this.CloseOfferWindowIfOpen()
                if this.AllHuntCellsDone(houses)
                    break
                continue
            }

            nonTargeted := this.GetNonTargetedOffers(recognized, targetedNames)
            if (nonTargeted.Length == 0) {
                this.Debug("[AcceptMissions] No non-targetted offers on house " house.gridLocation ".")
                this.CloseOfferWindowIfOpen()
                continue
            }

            this.Debug("[AcceptMissions] " nonTargeted.Length " non-targetted offer(s) on house "
                house.gridLocation ".")

            stopHouses := false
            for offerIdx, offer in nonTargeted {
                if (acceptedCount >= maxActive) {
                    stopHouses := true
                    break
                }

                if (offerIdx > 1) {
                    this.Debug("[AcceptMissions] Re-opening house " house.gridLocation
                        " for the next non-targetted mission.")
                    if !this.OpenHouse(house) {
                        this.FailOfferWindow(house)
                        remaining := this.CountTargetsFromHouseIndex(houses, houseIdx + 1)
                        this.SetStatus(missingCount + remaining,
                            "Offer window did not open at grid " house.gridLocation ".", acceptedCount, newAccepted)
                        return false
                    }
                }

                this.Debug("[AcceptMissions] Accepting non-targetted " offer.matchedName
                    " on house " house.gridLocation " slot " offer.index ".")
                this.ClickMissionOffer(offer)
                InputHelper.SendGameKey("Space")
                this.MarkAccepted(offer.matchedName)
                newAccepted++
                acceptedCount := this.sessionAcceptedCount
                this.Debug("[AcceptMissions] Accepted count: " acceptedCount "/" maxActive " (global).")
                InputHelper.MoveCursorClearOfSearch()
                userDelay(this.houseOpenWaitMs)

                if (acceptedCount >= maxActive) {
                    this.Debug("[AcceptMissions] Reached " maxActive " accepted missions (global cap). Stopping.")
                    stopHouses := true
                    break
                }
            }

            this.Debug("[AcceptMissions] Finished non-targetted accepts for house "
                house.gridLocation ".")
            this.CloseOfferWindowIfOpen()
            if (stopHouses)
                break
        }

        for _, house in houses {
            if this.IsHuntCellDone(house.gridLocation)
                continue
            if !visitedSlots.Has(house.gridLocation)
                missingCount += this.CountHouseTargets(house)
        }

        if this.AllHuntCellsDone(houses)
            missingCount := 0

        this.SetStatus(missingCount, "", acceptedCount, newAccepted)
        this.Debug("[AcceptMissions] Finished. accepted=" acceptedCount
            " newAccepted=" newAccepted " missingTargettedMissionCount=" missingCount ".")
        return true
    }

    OpenHouse(house) {
        clickPos := this.GetHouseClickPos(house.gridLocation)
        if (!IsObject(clickPos)) {
            this.Log("[AcceptMissions] Error: House grid coordinates missing in GameConstants.")
            return false
        }

        this.ClickHouseCell(house, clickPos)

        ; One click only. The offer window opens over the grid cell, so a second
        ; click would land inside the open window. Give it a moment to start
        ; rendering before the first search, then keep polling.
        Sleep(this.offerWindowClickSettleMs)
        if this.WaitForOfferWindow(this.offerWindowWaitMs, true)
            return true

        this.Log("[AcceptMissions] Error: Offer window did not open at grid "
            house.gridLocation " (row " house.gridRow ", col " house.gridCol ").")
        this.DumpOfferWindowCrop("offer_window_fail_" house.gridLocation)
        return false
    }

    ClickHouseCell(house, clickPos) {
        this.Debug("[AcceptMissions] Clicking house cell " house.gridLocation
            " at (" clickPos.x ", " clickPos.y ")...")
        InputHelper.SendGameClick(clickPos.x, clickPos.y)
        InputHelper.MoveCursorClearOfSearch()
    }

    /**
     * If the offer window is still open, close it with Esc before the next house.
     */
    CloseOfferWindowIfOpen() {
        if !this.IsOfferWindowOpen()
            return

        this.Debug("[AcceptMissions] Offer window still open. Sending Esc.")
        InputHelper.SendGameKey("Esc")
        InputHelper.MoveCursorClearOfSearch()
    }

    IsOfferWindowOpen() {
        foundX := 0, foundY := 0
        return this.FindOfferWindow(&foundX, &foundY)
    }

    /**
     * Detects the offer window within a search area (the configured box by default).
     * The raw PNG is tried first (fast, strict), then the background-free tan-glyph
     * mask: the raw PNG carries the panel's dark background around the tan glyphs,
     * so the same translucent window over a different backdrop (or mid-fade) can
     * miss even though it is plainly on screen.
     */
    FindOfferWindow(&foundX, &foundY, searchArea := "") {
        if !IsObject(searchArea) {
            searchArea := this.GetOfferWindowSearchArea()
            if (!IsObject(searchArea))
                return false
        }

        if this.anchorMatcher.FindAnchor(this.offerWindowImage, &foundX, &foundY, searchArea, this.imageVariation)
            return true

        maskedPath := this.GetOfferWindowMaskedPath()
        if (maskedPath == "")
            return false

        return this.anchorMatcher.FindAnchor(maskedPath, &foundX, &foundY, searchArea, this.offerWindowMaskedVariation, "White")
    }

    /**
     * Last-resort search across the whole game client, used only after the configured
     * box has timed out for the full wait.
     *
     * The window's absolute position is not stable - it moves with game patches and UI
     * scale - so a window that is on screen can sit entirely outside a box that was
     * measured on another build. This costs one full-client ImageSearch, paid at most
     * once per house and only when the boxed search failed, and it converts "offer
     * window did not open" into a recovery plus a warning that the constant is stale.
     *
     * Masked first: the tan-glyph shape survives a different backdrop and the faded
     * first frames of the open animation, where the raw PNG does not.
     * @param {VarRef} how - Which image matched, for logging.
     * @returns {Boolean} - True if the window was found anywhere in the client.
     */
    FindOfferWindowAnywhere(&foundX, &foundY, &how) {
        how := ""

        maskedPath := this.GetOfferWindowMaskedPath()
        if (maskedPath != "" && this.anchorMatcher.FindAnchor(maskedPath, &foundX, &foundY, "", this.offerWindowMaskedVariation, "White")) {
            how := "masked tan-glyph"
            return true
        }

        if this.anchorMatcher.FindAnchor(this.offerWindowImage, &foundX, &foundY, "", this.imageVariation) {
            how := "raw image"
            return true
        }

        return false
    }

    /**
     * Tan-glyph mask for the offer window, built once per session: the raw PNG
     * carries the panel's dark background, so only the glyph shape is stable.
     */
    GetOfferWindowMaskedPath() {
        ; Retry while the mask is unavailable: it can fail transiently (folder locked,
        ; disk full) and it is the search that survives a different backdrop, so caching
        ; an empty result would silently disable the fallback for the rest of the session.
        if (this.offerWindowMaskResolved && this.offerWindowMaskedPath != "")
            return this.offerWindowMaskedPath

        this.offerWindowMaskedPath := this.anchorMatcher.PrepareTanGlyphMask(this.offerWindowImage, "FFFFFF")
        this.offerWindowMaskResolved := true
        return this.offerWindowMaskedPath
    }

    GetOfferWindowSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("AcceptMissionAnchor")
            return ""

        btn := GameConstants["GameUI"]["AcceptMissionAnchor"]
        return ResolutionManager().searchFromConfig(btn, this.offerWindowSearchPadding)
    }

    /**
     * Confirms the accept-mission window via accept_mission_anchor.png in AcceptMissionAnchor.
     */
    WaitForOfferWindow(timeoutMs := 15000, logMiss := false) {
        searchArea := this.GetOfferWindowSearchArea()
        if (!IsObject(searchArea)) {
            this.Log("[AcceptMissions] Error: AcceptMissionAnchor missing in GameConstants.")
            return false
        }

        foundX := 0, foundY := 0
        this.Debug("[AcceptMissions] Waiting up to " timeoutMs "ms for " this.offerWindowImage
            " in [" searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        startTime := A_TickCount
        while (A_TickCount - startTime < timeoutMs) {
            if this.FindOfferWindow(&foundX, &foundY) {
                this.Debug("[AcceptMissions] Offer window confirmed at (" foundX ", " foundY ") after "
                    (A_TickCount - startTime) "ms.")
                return true
            }
            Sleep(100)
            if this.IsCancelled()
                return false
        }
        boxedElapsed := A_TickCount - startTime

        ; The box failed for the whole timeout, but the window may still be on screen
        ; at a position this build did not expect. Search the whole client before
        ; declaring it missing, so a stale constant costs a warning, not a failed run.
        how := ""
        anywhereStart := A_TickCount
        if this.FindOfferWindowAnywhere(&foundX, &foundY, &how) {
            this.Log("[AcceptMissions] Offer window found at (" foundX ", " foundY ") by the full-client "
                how " search, i.e. outside AcceptMissionAnchor ["
                searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2
                "]. Detection stays slow until that constant is recalibrated.")
            return true
        }
        anywhereElapsed := A_TickCount - anywhereStart

        ; The full-client pass is expensive and can itself outlast the window's opening
        ; animation, so give the cheap boxed search one last chance before failing. A window
        ; that finishes opening during that scan is caught here instead of aborting the loop.
        graceStart := A_TickCount
        while (A_TickCount - graceStart < this.offerWindowFinalGraceMs) {
            if this.FindOfferWindow(&foundX, &foundY) {
                this.Log("[AcceptMissions] Offer window opened late at (" foundX ", " foundY ") after "
                    (A_TickCount - startTime) "ms (boxed " boxedElapsed "ms + full-client "
                    anywhereElapsed "ms). Consider raising offerWindowWaitMs.")
                return true
            }
            Sleep(100)
            if this.IsCancelled()
                return false
        }

        if (logMiss)
            this.Log("[AcceptMissions] Offer window not matched in ["
                searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2
                "] by raw or masked search after " timeoutMs "ms (boxed " boxedElapsed
                "ms + full-client " anywhereElapsed "ms + grace " this.offerWindowFinalGraceMs
                "ms), nor anywhere in the client.")
        return false
    }

    /**
     * Saves the offer-window search box (plus a margin) to debug_out so a failed
     * detection can be inspected visually instead of guessed at.
     */
    DumpOfferWindowCrop(label) {
        searchArea := this.GetOfferWindowSearchArea()
        if (!IsObject(searchArea))
            return

        margin := 120
        x := searchArea.x1 - margin
        y := searchArea.y1 - margin
        w := (searchArea.x2 - searchArea.x1) + (margin * 2)
        h := (searchArea.y2 - searchArea.y1) + (margin * 2)
        ResolutionManager().ClampCapture(&x, &y, &w, &h)
        if (w < 2 || h < 2)
            return

        pBitmap := Gdip_BitmapFromScreen(x, y, w, h)
        if !pBitmap
            return

        folder := ResolutionManager().AnchorFolder()
        outDir := A_ScriptDir "\debug_out\" folder
        DirCreate(outDir)
        outPath := outDir "\" label ".png"
        try FileDelete(outPath)
        saved := (Gdip_SaveBitmapToFile(pBitmap, outPath) = 0)
        Gdip_DisposeImage(pBitmap)
        if saved
            this.Log("[AcceptMissions] Crop saved to debug_out\" folder "\" label ".png")
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    ClickMissionOffer(offer) {
        box := offer.box
        clickX := box.screenX + (box.screenW // 2)
        clickY := box.screenY + (box.screenH // 2)
        this.Debug("[AcceptMissions] Clicking offer slot " offer.index
            " at (" clickX ", " clickY ")...")
        InputHelper.SendGameClick(clickX, clickY)
    }

    FailOfferWindow(house) {
        posInfo := "grid " house.gridLocation " (row " house.gridRow ", col " house.gridCol ")"
        this.SetOverlayState("mission window error")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("mission window error")
    }

    FailMissionRead(house, offered := "") {
        posInfo := "grid " house.gridLocation " (row " house.gridRow ", col " house.gridCol ")"
        this.Log("[AcceptMissions] Error: Failed to read offered missions at " posInfo ".")
        if IsObject(offered) {
            for _, entry in offered {
                text := (entry.HasOwnProp("normalizedText") && entry.normalizedText != "")
                    ? entry.normalizedText : "(no text detected)"
                this.Log("[AcceptMissions]   Slot " entry.index ": OCR read `"" text "`" (match confidence "
                    Round(entry.confidence, 2) ").")
            }
        }
        this.SetOverlayState("mission read error")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("mission read error")
    }

    HouseSpecializationMatches(house, recognized) {
        targetSpec := this.GetHouseTargetSpecialization(house)
        offeredSpec := this.GetOfferedSpecialization(recognized)
        if (targetSpec == "" || offeredSpec == "")
            return true
        if (StrLower(targetSpec) == StrLower(offeredSpec))
            return true

        this.FailSpecializationMismatch(house, targetSpec, offeredSpec)
        return false
    }

    GetHouseTargetSpecialization(house) {
        if !IsObject(house.missions)
            return ""
        for _, mission in house.missions {
            spec := ""
            if IsObject(mission) && mission.HasOwnProp("specialization")
                spec := mission.specialization
            if (spec == "" && IsObject(mission) && mission.HasOwnProp("missionName") && mission.missionName != "" && IsObject(this.stateManager))
                spec := this.stateManager.GetMissionSpecialization(mission.missionName)
            if (spec != "")
                return spec
        }
        return ""
    }

    GetOfferedSpecialization(recognized) {
        counts := Map()
        for _, entry in recognized {
            spec := ""
            if IsObject(entry) && entry.HasOwnProp("specialization")
                spec := entry.specialization
            if (spec == "" && IsObject(entry) && entry.HasOwnProp("matchedName") && entry.matchedName != "" && IsObject(this.stateManager))
                spec := this.stateManager.GetMissionSpecialization(entry.matchedName)
            if (spec == "")
                continue
            key := StrLower(spec)
            if !counts.Has(key)
                counts[key] := { name: spec, n: 0 }
            item := counts[key]
            item.n++
            counts[key] := item
        }

        bestName := ""
        bestN := 0
        for _, item in counts {
            if (item.n > bestN) {
                bestN := item.n
                bestName := item.name
            }
        }
        return bestName
    }

    RecordSoloSpecHuntIfReady(house) {
        specKey := StrLower(this.GetHouseTargetSpecialization(house))
        if (specKey == "" || !IsObject(this.soloTargetBySpec) || !this.soloTargetBySpec.Has(specKey))
            return
        if IsObject(this.recordedSoloSpecs) && this.recordedSoloSpecs.Has(specKey)
            return

        missionName := this.soloTargetBySpec[specKey]
        count := this.GetGuildAbandonTotal() - Integer(this.huntAbandonStart)
        if (count < 0)
            count := 0
        if !IsObject(this.recordedSoloSpecs)
            this.recordedSoloSpecs := Map()
        this.recordedSoloSpecs[specKey] := true

        if IsObject(this.stateManager) && this.stateManager.HasMethod("RecordAbandonsUntilReveal")
            this.stateManager.RecordAbandonsUntilReveal(missionName, count)
        this.Debug("[AcceptMissions] Solo " specKey " hunt: " count
            " abandon(s) until `"" missionName "`" showed.")
    }

    FailSpecializationMismatch(house, targetSpec, offeredSpec) {
        this.CloseOfferWindowIfOpen()
        this.Log("[AcceptMissions] Error: House cell " house.gridLocation
            " offers " offeredSpec ", but the targetted mission is " targetSpec ". Stopping.")
        this.SetOverlayState("Wrong specialization")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("Wrong specialization")
    }

    SetOverlayState(label) {
        StatusBar.SetStatus(label)
    }

    BuildTargetedNameMap(targeted) {
        names := Map()
        for _, mission in targeted {
            if (mission.missionName != "")
                names[StrLower(mission.missionName)] := true
        }
        return names
    }

    GetTargetedHouses(targeted) {
        bySlot := Map()
        for _, mission in targeted {
            slotIdx := mission.gridLocation
            if (slotIdx < 1)
                continue
            if (!bySlot.Has(slotIdx)) {
                bySlot[slotIdx] := {
                    gridLocation: slotIdx,
                    gridRow: mission.gridRow,
                    gridCol: mission.gridCol,
                    missions: []
                }
            }
            bySlot[slotIdx].missions.Push(mission)
        }

        houses := []
        loop 25 {
            if bySlot.Has(A_Index)
                houses.Push(bySlot[A_Index])
        }
        return houses
    }

    GetRecognizedMissions(offered) {
        recognized := []
        for _, entry in offered {
            if (entry.matchedName != "" && entry.confidence >= this.minReadConfidence)
                recognized.Push(entry)
        }
        return recognized
    }

    GetNonTargetedOffers(recognized, targetedNames) {
        nonTargeted := []
        for _, entry in recognized {
            if targetedNames.Has(StrLower(entry.matchedName))
                continue
            if this.IsAlreadyAccepted(entry.matchedName) {
                this.Debug("[AcceptMissions] Skipping already-accepted " entry.matchedName
                    " (slot " entry.index ").")
                continue
            }
            nonTargeted.Push(entry)
        }
        return nonTargeted
    }

    /**
     * Last-run status object. Property names are unquoted per project rules.
     */
    MakeStatus(missingTargettedMissionCount := 0, error := "", acceptedCount := 0, newAcceptedCount := 0) {
        return {
            error: error,
            missingTargettedMissionCount: missingTargettedMissionCount,
            acceptedCount: acceptedCount,
            newAcceptedCount: newAcceptedCount
        }
    }

    SetStatus(missingTargettedMissionCount := 0, error := "", acceptedCount := 0, newAcceptedCount := 0) {
        this.lastStatus := this.MakeStatus(missingTargettedMissionCount, error, acceptedCount, newAcceptedCount)
        if (error != "")
            this.Debug("[AcceptMissions] Status error: " error
                " missingTargettedMissionCount=" missingTargettedMissionCount
                " acceptedCount=" acceptedCount)
        else
            this.Debug("[AcceptMissions] Status: missingTargettedMissionCount="
                missingTargettedMissionCount " acceptedCount=" acceptedCount
                " newAcceptedCount=" newAcceptedCount)
    }

    CountHouseTargets(house) {
        count := 0
        if !IsObject(house.missions)
            return 0
        for _, mission in house.missions {
            if (mission.missionName != "")
                count++
        }
        return count
    }

    CountPendingHuntCells(houses) {
        pending := 0
        if !IsObject(houses)
            return 0
        for _, house in houses {
            if !this.IsHuntCellDone(house.gridLocation)
                pending++
        }
        return pending
    }

    CountTargetsFromHouseIndex(houses, startIdx) {
        total := 0
        for idx, house in houses {
            if (idx >= startIdx)
                total += this.CountHouseTargets(house)
        }
        return total
    }

    CountMissingTargetsForHouse(house, recognized) {
        if (!IsObject(house.missions) || house.missions.Length == 0)
            return 0

        offeredNames := Map()
        for _, entry in recognized {
            if (entry.matchedName != "")
                offeredNames[StrLower(entry.matchedName)] := true
        }

        missing := 0
        for _, mission in house.missions {
            if (mission.missionName == "")
                continue
            if !offeredNames.Has(StrLower(mission.missionName))
                missing++
        }
        return missing
    }

    /**
     * True when every targetted mission for this house appears in the offered list.
     */
    HouseTargetsAreOffered(house, recognized) {
        if (!IsObject(house.missions) || house.missions.Length == 0)
            return false

        offeredNames := Map()
        for _, entry in recognized {
            if (entry.matchedName != "")
                offeredNames[StrLower(entry.matchedName)] := true
        }

        for _, mission in house.missions {
            if (mission.missionName == "")
                continue
            if !offeredNames.Has(StrLower(mission.missionName))
                return false
        }
        return true
    }

    LogOfferedMissions(offered) {
        this.Debug("[AcceptMissions] Offered missions:")
        for _, entry in offered {
            if (entry.matchedName != "" && entry.confidence >= this.minReadConfidence) {
                specInfo := entry.specialization != "" ? " [" entry.specialization "]" : ""
                this.Debug("[AcceptMissions]   Slot " entry.index ": " entry.matchedName specInfo)
            } else if (entry.normalizedText != "") {
                this.Debug("[AcceptMissions]   Slot " entry.index ": " entry.normalizedText " (unrecognized)")
            } else {
                this.Debug("[AcceptMissions]   Slot " entry.index ": (empty)")
            }
        }
    }

    GetHouseClickPos(slotIdx) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("FirstGridPosition") || !uiConfig.Has("GridCellSize") || !uiConfig.Has("GridSpacing")
            return ""

        gridSize := uiConfig.Has("HouseGridSize") ? uiConfig["HouseGridSize"] : 5
        firstPos := uiConfig["FirstGridPosition"]
        cellSize := uiConfig["GridCellSize"]
        spacing := uiConfig["GridSpacing"]

        col := Mod(slotIdx - 1, gridSize)
        row := (slotIdx - 1) // gridSize
        cellX := firstPos.x + (col * (cellSize.x + spacing.x))
        cellY := firstPos.y + (row * (cellSize.y + spacing.y))
        centerX := cellX + (cellSize.x / 2)
        centerY := cellY + (cellSize.y / 2)

        return ResolutionManager().coords(centerX, centerY)
    }

    ReadOfferedMissions() {
        reader := MissionHandlerDebug(this.logger, this.stateManager)
        return reader.ReadMissions()
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
