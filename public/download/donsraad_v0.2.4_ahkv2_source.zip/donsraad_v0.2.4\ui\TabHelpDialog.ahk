#Requires AutoHotkey v2.0+

/**
 * Per-tab legend / help dialog with color swatches.
 */
class TabHelpDialog {
    static dlg := ""
    static statsBodyEdit := ""
    static pad := 16
    static rowW := 520
    static swatchSize := 18
    static circleCache := Map()

    static Show(ownerGui := "", tabKey := "missions") {
        if IsObject(this.dlg) {
            try {
                this.dlg.Show()
                return
            } catch {
                this.dlg := ""
            }
        }

        if (tabKey == "stats") {
            this.ShowStatsExplanation(ownerGui)
            return
        }

        title := this.GetTitle(tabKey)
        sections := this.GetSections(tabKey)
        showCodes := false
        pad := this.pad
        rowW := this.rowW

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", title)
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        y := pad
        dlg.SetFont("s10 bold cEAB308", "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" rowW " h20 BackgroundTrans", this.GetSubtitle(tabKey))
        y += 24

        dlg.SetFont("s8 c71717A", "Segoe UI")
        dlg.Add("Text", "x" pad " y" y " w" rowW " h34 +0x200 BackgroundTrans Wrap", this.GetIntroText(tabKey))
        y += 40

        for _, section in sections {
            if (section.Has("title") && section["title"] != "") {
                dlg.SetFont("s9 bold cE4E4E7", "Segoe UI")
                dlg.Add("Text", "x" pad " y" y " w" rowW " h18 BackgroundTrans", section["title"])
                y += 22
            }
            for _, item in section["items"] {
                y := this.AddLegendRow(dlg, y, item, showCodes)
            }
            y += 8
        }

        dlg.SetFont("s9 cE4E4E7", "Segoe UI")
        ok := dlg.Add("Button", "x" (pad + rowW - 88) " y" (y + 4) " w88 h28 Default", "OK")
        ok.OnEvent("Click", (*) => this.Close())
        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("w" (pad * 2 + rowW) " h" (y + 48) " Center")
    }

    static ShowStatsExplanation(ownerGui := "") {
        pad := this.pad
        rowW := this.rowW
        bodyH := 400
        dlgW := pad * 2 + rowW
        bodyY := pad + 28
        dlgH := bodyY + bodyH + 52

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", this.GetTitle("stats"))
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.BackColor := "0F0F12"

        dlg.SetFont("s10 bold cEAB308", "Segoe UI")
        dlg.Add("Text", "x" pad " y" pad " w" rowW " h22 +0x200 BackgroundTrans",
            "Mission stats and availability")

        dlg.SetFont("s9 cA1A1AA", "Segoe UI")
        this.statsBodyEdit := dlg.Add("Edit",
            "x" pad " y" bodyY " w" rowW " h" bodyH
            " ReadOnly -E0x200 -WantReturn +VScroll Wrap Background18181B")
        this.StyleStatsEdit(this.statsBodyEdit)
        this.statsBodyEdit.Value := this.GetStatsHelpText()

        okY := bodyY + bodyH + 12
        dlg.SetFont("s9 cE4E4E7", "Segoe UI")
        ok := dlg.Add("Button", "x" (pad + rowW - 88) " y" okY " w88 h28 Default", "OK")
        ok.OnEvent("Click", (*) => this.Close())
        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("w" dlgW " h" dlgH " Center")
    }

    static StyleStatsEdit(ctrl) {
        if !IsObject(ctrl)
            return
        try DllCall("uxtheme\SetWindowTheme", "ptr", ctrl.Hwnd, "wstr", "", "wstr", "")
        ctrl.Opt("-Theme Background18181B")
        ctrl.SetFont("s9 cE4E4E7", "Segoe UI")
    }

    static GetStatsHelpText() {
        return "OVERVIEW`n`n"
            . "The Stats tab records mission-picker activity for the active profile. "
            . "Switch profiles in Settings to see a different character's stats.`n`n"
            . "SPECIALIZATION TABS`n`n"
            . "Crafting, Gathering, Exploration, Combat, and Sabotage filter the mission list. "
            . "Each tab shows only missions from that specialization.`n`n"
            . "TOTALS`n`n"
            . "Total abandons`n"
            . "Guild board abandons recorded while the picker refreshes the mission board.`n`n"
            . "Target missions accepted`n"
            . "How many times the picker accepted one of your targeted missions.`n`n"
            . "Mnemonic devices spent`n"
            . "Mnemonic devices used when accepting targeted missions from the board.`n`n"
            . "SUMMARY BAR`n`n"
            . "Below the specialization tabs, a one-line summary shows the active spec, "
            . "how many missions are listed, total completes, how many have a best time, "
            . "and how many have availability data.`n`n"
            . "MISSION ROWS`n`n"
            . "Mission`n"
            . "The mission name.`n`n"
            . "Done`n"
            . "How many times you completed this mission.`n`n"
            . "Best`n"
            . "Your fastest completion time, shown as mm:ss. Blank if you have not finished it yet.`n`n"
            . "Availability`n"
            . "Estimated chance this mission appears in its specialization pool, shown as a percentage. "
            . "Blank until enough solo-spec history is recorded.`n`n"
            . "HOW AVAILABILITY WORKS`n`n"
            . "Availability is tracked only when you target exactly one mission from a specialization. "
            . "If two or more targets share the same spec, those cycles are ignored.`n`n"
            . "Each qualifying picker cycle records how many guild abandons it took before that mission appeared. "
            . "The app keeps the last 30 cycles (newest first).`n`n"
            . "Formula: 1 / (average abandons + 1)`n`n"
            . "Example: ten abandons on average means about 1 in 11 appearances, or roughly 9%.`n`n"
            . "PAGING`n`n"
            . "Use Prev and Next at the bottom when a specialization has more missions than fit on one page.`n`n"
            . "RESET STATS`n`n"
            . "Clears totals, every mission row, and all availability history for the active profile."
    }

    static AddLegendRow(dlg, y, item, showCodes := true) {
        x := this.pad
        shape := item.Has("shape") ? item["shape"] : "rect"
        if (shape == "circle")
            this.AddCircleIndicator(dlg, x, y, item)
        else if (shape == "vbars")
            this.AddMissionSlotsIndicator(dlg, x, y, item)
        else
            this.AddRectIndicator(dlg, x, y, item)

        textX := x + this.swatchSize + 10
        textW := this.rowW - (textX - x)
        name := item.Has("name") ? item["name"] : ""
        desc := item.Has("desc") ? item["desc"] : ""
        code := showCodes ? this.FormatColorCode(item) : ""

        dlg.SetFont("s9 bold cE4E4E7", "Segoe UI")
        dlg.Add("Text", "x" textX " y" y " w" textW " h16 BackgroundTrans", name)
        dlg.SetFont("s8 cA1A1AA", "Segoe UI")
        dlg.Add("Text", "x" textX " y" (y + 18) " w" textW " h36 +0x200 BackgroundTrans Wrap", desc)
        rowH := 56
        if (code != "") {
            dlg.SetFont("s7 c71717A", "Segoe UI")
            dlg.Add("Text", "x" textX " y" (y + 54) " w" textW " h14 BackgroundTrans", code)
            rowH := 72
        }
        return y + rowH
    }

    static AddRectIndicator(dlg, x, y, item) {
        fill := item.Has("color") ? item["color"] : "18181F"
        border := item.Has("border") ? item["border"] : ""
        if (border != "") {
            dlg.Add("Text", "x" x " y" y " w" this.swatchSize " h" this.swatchSize " Background" border)
            inner := this.swatchSize - 4
            dlg.Add("Text", "x" (x + 2) " y" (y + 2) " w" inner " h" inner " Background" fill)
        } else {
            dlg.Add("Text", "x" x " y" y " w" this.swatchSize " h" this.swatchSize " Background" fill)
        }
    }

    static AddCircleIndicator(dlg, x, y, item) {
        fill := item.Has("color") ? item["color"] : "4ADE80"
        size := this.swatchSize
        path := this.GetCirclePath(fill, size)
        offsetY := y + ((this.swatchSize - size) // 2)
        if (path != "")
            dlg.Add("Picture", "x" x " y" offsetY " w" size " h" size, path)
        else
            dlg.Add("Text", "x" x " y" y " w" size " h" size " Background" fill)
    }

    static AddMissionSlotsIndicator(dlg, x, y, item) {
        active := item.Has("color") ? item["color"] : "EAB308"
        empty := item.Has("accent") ? item["accent"] : "27272F"
        barW := 5
        barH := 12
        gap := 3
        totalW := barW * 3 + gap * 2
        startX := x + ((this.swatchSize - totalW) // 2)
        startY := y + ((this.swatchSize - barH) // 2)
        loop 3 {
            color := (A_Index <= 2) ? active : empty
            barX := startX + (A_Index - 1) * (barW + gap)
            dlg.Add("Text", "x" barX " y" startY " w" barW " h" barH " Background" color)
        }
    }

    static GetCirclePath(colorHex, size) {
        key := colorHex "_" size
        if this.circleCache.Has(key)
            return this.circleCache[key]

        pBitmap := Gdip_CreateBlankBitmap(size, size)
        if !pBitmap
            return ""

        g := Gdip_GraphicsFromImage(pBitmap)
        if !g {
            Gdip_DisposeImage(pBitmap)
            return ""
        }

        Gdip_SetSmoothingMode(g, 4)
        brush := Gdip_CreateSolidBrush(this.HexToArgb(colorHex))
        Gdip_FillEllipse(g, brush, 0, 0, size, size)
        Gdip_DeleteBrush(brush)
        Gdip_DeleteGraphics(g)

        path := A_Temp "\donsraad_help_circle_" key ".png"
        if (Gdip_SaveBitmapToFile(pBitmap, path) != 0) {
            Gdip_DisposeImage(pBitmap)
            return ""
        }
        Gdip_DisposeImage(pBitmap)
        this.circleCache[key] := path
        return path
    }

    static HexToArgb(hex, alpha := 255) {
        hex := StrReplace(hex, "#", "")
        if (StrLen(hex) != 6)
            return 0xFF000000
        return (alpha << 24) | Integer("0x" hex)
    }

    static FormatColorCode(item) {
        parts := []
        if item.Has("color") && item["color"] != ""
            parts.Push("#" item["color"])
        if item.Has("border") && item["border"] != ""
            parts.Push("border #" item["border"])
        if item.Has("accent") && item["accent"] != ""
            parts.Push("accent #" item["accent"])
        if (parts.Length == 0)
            return ""
        out := "("
        loop parts.Length {
            if (A_Index > 1)
                out .= " · "
            out .= parts[A_Index]
        }
        return out ")"
    }

    static GetTitle(tabKey) {
        if (tabKey == "landsraad")
            return "Landsraad — Help"
        if (tabKey == "stats")
            return "Stats — Help"
        return "Missions — Help"
    }

    static GetSubtitle(tabKey) {
        if (tabKey == "landsraad")
            return "Contribution list colors and indicators"
        return "Grid cell colors and indicators"
    }

    static GetIntroText(tabKey) {
        return "Colors match the UI."
    }

    static GetSections(tabKey) {
        if (tabKey == "landsraad")
            return this.GetLandsraadSections()
        return this.GetMissionsSections()
    }

    static GetMissionsSections() {
        return [
            Map("title", "Grid cells", "items", [
                Map("name", "Targeted house", "color", "14532D", "border", "3D3420",
                    "desc", "At least one mission is assigned to this cell. These are the jobs the picker will hunt for."),
                Map("name", "Selected cell", "color", "141418", "border", "EAB308",
                    "desc", "Gold frame on the cell you clicked to open the mission picker dialog."),
                Map("name", "Missions not revealed", "color", "141418", "border", "3D3420",
                    "desc", "House name is known from scan but missions are not unlocked yet. A 50% dark overlay dims the whole cell; click is disabled until missions appear in game.")
            ]),
            Map("title", "In-cell indicators", "items", [
                Map("name", "Mission slots", "shape", "vbars", "color", "EAB308", "accent", "27272F",
                    "desc", "Represents targeted mission slots."),
                Map("name", "Track badge", "shape", "circle", "color", "4ADE80",
                    "desc", "Green badge at the top-right when this house has a weekly contribution goal."),
                Map("name", "Progress bar (in progress)", "color", "4ADE80", "accent", "27272F",
                    "desc", "Green fill on a dark track. Width shows contribution toward your weekly goal."),
                Map("name", "Progress bar (goal reached)", "color", "3B82F6", "accent", "27272F",
                    "desc", "Blue fill when your tracked contribution goal is complete for the week."),
                Map("name", "House name", "color", "EAB308",
                    "desc", "Gold abbreviated house label along the bottom of revealed cells.")
            ]),            Map("title", "Toolbar", "items", [
                Map("name", "Selected missions counter", "color", "EAB308",
                    "desc", "Shows how many of your 3 mission slots are filled."),
                Map("name", "Start", "color", "EAB308",
                    "desc", "Runs setup if needed, then claims, refreshes, and accepts your targeted missions.")
            ])
        ]
    }

    static GetLandsraadSections() {
        return [
            Map("title", "House rows", "items", [
                Map("name", "Default row", "color", "18181F",
                    "desc", "House with no weekly tracking goal set."),
                Map("name", "Not available", "color", "0F0F12",
                    "desc", "Grayed row before you scan, for houses not on this week's grid, or when missions are not yet revealed on the grid."),
                Map("name", "Tracked house", "color", "14532D", "accent", "4ADE80",
                    "desc", "Green row background when a weekly contribution goal is active. Contribution text is green."),
                Map("name", "Goal reached", "color", "1E3A5F", "accent", "EAB308",
                    "desc", "Blue row when the weekly goal is met. A gold Done badge appears on the right."),
                Map("name", "Swatch owned", "color", "F87171",
                    "desc", "Red bar on the left edge marks houses where you own the cosmetic house swatch (14,000+ contribution).")
            ]),
            Map("title", "Progress bars", "items", [
                Map("name", "Tracking progress", "color", "4ADE80", "accent", "134E32",
                    "desc", "Green fill toward your goal. Contribution line shows current / goal when tracking."),
                Map("name", "Goal complete", "color", "EAB308", "accent", "172554",
                    "desc", "Gold fill on the blue goal-reached row.")
            ]),
            Map("title", "Actions", "items", [
                Map("name", "Scan grid", "color", "EAB308",
                    "desc", "Reads the in-game 5×5 house grid and updates contribution totals."),
                Map("name", "Reset board", "color", "27272F",
                    "desc", "Clears this week's scan data, contributions, and goals for the active profile."),
                Map("name", "House tracking", "color", "EAB308",
                    "desc", "After scanning, click a house with revealed missions to set a weekly contribution goal.")
            ])
        ]
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
        this.statsBodyEdit := ""
    }
}
