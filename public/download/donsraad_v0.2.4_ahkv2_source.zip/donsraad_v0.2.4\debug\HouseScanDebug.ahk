#Requires AutoHotkey v2.0+

/**
 * Debug helper: scan one Landsraad house cell using the production HouseGridScanner path.
 */
class HouseScanDebug {
    overlays := []
    logger := ""
    scanner := ""
    openLandsraadGridScenario := ""
    debugTargetRow := 2
    debugTargetCol := 1

    __New(loggerInst := "", openLandsraadGridScenarioInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.overlays := []
        this.logger := loggerInst
        this.openLandsraadGridScenario := openLandsraadGridScenarioInst
        this.scanner := HouseGridScanner(loggerInst, anchorMatcherInst, stateManagerInst)
        this.scanner.showDebugBoxes := true
    }

    Execute(*) {
        row := this.debugTargetRow
        col := this.debugTargetCol
        StatusBar.PinBottomLeft()
        try {
            this.Log("[House Scan] Scanning row " row ", col " col "...")
            GameWindow.Activate()

            if IsObject(this.openLandsraadGridScenario) && !this.openLandsraadGridScenario.Execute() {
                this.Log("[House Scan] Error: Could not open Landsraad house grid.")
                return
            }

            result := this.scanner.ScanCell(row, col)
            if this.IsCancelled() {
                this.Log("[House Scan] Scan cancelled.")
                return
            }

            this.LogScanResult(result)
            this.LogRawOcr(result)
            this.Log("[House Scan] Cell scan complete.")
        } finally {
            this.Hide()
            StatusBar.ClearBottomLeftPin()
        }
    }

    LogScanResult(result) {
        if (result.notRevealed) {
            this.Log('"House not yet revealed"')
            return
        }

        if (result.houseName == "")
            return

        houseLabel := result.houseName
        if !result.missionsRevealed
            this.Log('"' houseLabel '" : missions not revealed')
        else {
            contribLabel := result.contributionParsed ? result.contribution : "?"
            this.Log('"' houseLabel '" : ' contribLabel)
        }
    }

    LogRawOcr(result) {
        if IsObject(result.houseResult) {
            this.Log("[House Scan] House name raw OCR: `"" result.houseResult.rawText "`"")
            if (result.houseResult.normalizedText != result.houseResult.rawText)
                this.Log("[House Scan] House name normalized: `"" result.houseResult.normalizedText "`"")
        }

        if !result.missionsRevealed
            return

        if IsObject(result.personalResult) {
            rawText := result.personalResult.HasOwnProp("rawText") ? result.personalResult.rawText : ""
            normalizedText := result.personalResult.HasOwnProp("normalizedText") ? result.personalResult.normalizedText : ""
            if (rawText != "")
                this.Log("[House Scan] Personal contribution raw OCR: `"" rawText "`"")
            if (normalizedText != "" && normalizedText != rawText)
                this.Log("[House Scan] Personal contribution normalized: `"" normalizedText "`"")
        }

        if IsObject(result.rewardsBandBox) {
            box := result.rewardsBandBox
            this.Log("[House Scan] Rewards band OCR box: ["
                box.screenX ", " box.screenY ", " box.screenW ", " box.screenH "]")
        }

        if IsObject(result.rewardsBandOcr) {
            source := result.rewardsBandOcr.HasOwnProp("source") ? result.rewardsBandOcr.source : ""
            if (source != "")
                this.Log("[House Scan] Rewards band OCR source: " source)
            winRtRaw := result.rewardsBandOcr.HasOwnProp("rawText") ? result.rewardsBandOcr.rawText : ""
            if (winRtRaw != "")
                this.Log("[House Scan] Rewards band WinRT raw OCR: `"" winRtRaw "`"")
            if (result.rewardsBandOcr.HasOwnProp("normalizedText")
                && result.rewardsBandOcr.normalizedText != ""
                && result.rewardsBandOcr.normalizedText != winRtRaw)
                this.Log("[House Scan] Rewards band normalized: `"" result.rewardsBandOcr.normalizedText "`"")
            if result.rewardsBandOcr.HasOwnProp("ocrResult") && IsObject(result.rewardsBandOcr.ocrResult)
                && result.rewardsBandOcr.ocrResult.HasOwnProp("lines") && result.rewardsBandOcr.ocrResult.lines is Array {
                for idx, line in result.rewardsBandOcr.ocrResult.lines
                    this.Log("[House Scan] Rewards band OCR line " idx ": `"" line "`"")
            }
        }

        parsed := result.HasOwnProp("rewardsBandParsed") ? result.rewardsBandParsed : ""
        if IsObject(parsed) && parsed.HasOwnProp("ocrTexts") && parsed.ocrTexts is Array {
            for idx, name in parsed.ocrTexts
                this.Log("[House Scan] Rewards extracted name " idx ": `"" name "`"")
        }

        this.LogParsedHouseRewards(parsed)
    }

    LogParsedHouseRewards(parsed) {
        if !IsObject(parsed) || !parsed.found || !IsObject(parsed.tiers) {
            this.Log("[House Scan] House rewards: (could not parse tiers from OCR)")
            return
        }

        for _, tier in parsed.tiers {
            if tier.matched
                this.Log("[House Scan] Tier " tier.reward_tier ": " tier.item_name " (" tier.item_id ")")
            else if (Trim(tier.ocrText) != "")
                this.Log("[House Scan] Tier " tier.reward_tier ": (unmatched) " tier.ocrText)
            else
                this.Log("[House Scan] Tier " tier.reward_tier ": (missing)")
        }

        if (parsed.tiers.Length < 4)
            loop (4 - parsed.tiers.Length)
                this.Log("[House Scan] Tier " (parsed.tiers.Length + A_Index) ": (missing)")
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    ShowTooltipOverlays(areas) {
        this.Hide()

        this.Debug("[House Scan] Right search area ref ("
            areas.right.refX ", " areas.right.refY ", " areas.right.refW ", " areas.right.refH ").")
        this.Debug("[House Scan] Left search area ref ("
            areas.left.refX ", " areas.left.refY ", " areas.left.refW ", " areas.left.refH ").")

        rightOverlay := RectangleOverlay()
        rightOverlay.ShowAt(areas.right.refX, areas.right.refY, areas.right.refW, areas.right.refH)
        this.overlays.Push(rightOverlay)

        leftOverlay := RectangleOverlay()
        leftOverlay.ShowAt(areas.left.refX, areas.left.refY, areas.left.refW, areas.left.refH)
        this.overlays.Push(leftOverlay)
    }

    Hide() {
        for _, overlay in this.overlays {
            if IsObject(overlay)
                overlay.Close()
        }
        this.overlays := []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
