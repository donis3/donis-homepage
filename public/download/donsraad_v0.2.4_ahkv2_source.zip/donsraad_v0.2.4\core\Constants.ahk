#Requires AutoHotkey v2.0+

; Store some coordinates and offsets for common UI elements to avoid repeated image searches.
; All values are authored in 3440x1440 and converted via ResolutionManager for the game client.
; The 16:9 UI is 2560x1440; ultrawide 3440x1440 adds 440px padding on each side.
; 1080p is that 16:9 layout scaled by 0.75. Windowed mode uses the client, not the monitor.

GameConstants := Map(
    "GameUI", Map(
        "HouseGridSize", 5, ; Number of houses in the grid (5x5)
        "FirstGridPosition", { x: 1074, y: 333 }, ; First grid position (3440x1440)
        "GridSpacing", { x: 19, y: 19 }, ; Grid spacing (3440x1440)
        "GridCellSize", { x: 243, y: 138 }, ; Grid cell size (3440x1440)
        "HouseIconOffset", { x: 24, y: 22 }, ; House crest offset inside a grid cell (3440x1440)
        "HouseIconSize", { x: 72, y: 72 }, ; House crest search box (3440x1440)
        "MissionSelectorFirstPosition", { x: 1387, y: 624 }, ; 3-line mission text anchor (3440x1440)
        "MissionTextSize", { x: 200, y: 83 }, ; 3-line mission title selection box (3440x1440)
        "MissionSelectorSpacing", 23, ;(3440x1440)
        "GuildsTabButton", { x: 1756, y: 51, w: 108, h: 33 }, ; Guilds tab button anchor to search for button image (3440x1440)
        ; Active mission UI displays 3 boxes vertically, each with the mission name
        "ActiveMissionFirstPosition", { x: 1405, y: 461 }, ; 3-line active mission text anchor (3440x1440)
        "ActiveMissionTextSize", { x: 200, y: 82 }, ; 3-line active mission title selection box (3440x1440)
        "ActiveMissionSpacing", 250, ; Vertical Spacing between active mission slots (3440x1440)
        ; Check Active Mission Complete?
        "ActiveMissionFirstCompleteIcon", { x: 1486, y: 378, w: 41, h: 26 }, ; Active mission complete icon offset from active mission text position (3440x1440)
        "ActiveMissionCompleteIconSpacing", 250, ; Active mission complete icon vertical spacing (3440x1440)
        "ActiveMissionClaimClickCoords", { x: 2096, y: 1181 }, ; Claim reward button on mission detail (3440x1440)

        "ActiveMissionClaimConfirmImageSearchArea", { x: 1523, y: 1082, w: 293, h: 64 }, ; Search area for the claim confirmation image
        ; Buttons
        "LandsraadTabButton", { x: 1900, y: 43, w: 166, h: 50 }, ; Landsraad tab button anchor to search for button image (3440x1440)
        "LandsraadSubTabButton", { x: 770, y: 180 }, ; Landsraad sub-tab to go to active missions tab (3440x1440)
        "LandsraadSubGridTabButton", { x: 670, y: 200 }, ; Landsraad sub tab button click coords to go to house grid tab (3440x1440)
        ; Guild Disbanding (this removes all active missions)
        "GuildDisbandingButtonClickCoords", { x: 753, y: 1193 }, ; Guild disband button coords (3440x1440)
        "GuildDisbandingButton", { x: 610, y: 1165, w: 270, h: 59 }, ; Guild disband button coords (3440x1440)
        "CreateGuildButton", { x: 2083, y: 1096, w: 213, h: 53 }, ; Create guild button coords (3440x1440)
        "AlignGuildAtreidesButtonClickCoords", { x: 800, y: 1234 }, ; Align guild button click coords (3440x1440)
        "AlignGuildAtreidesButton", { x: 664, y: 1205, w: 292, h: 62 }, ; Align guild button coords (3440x1440)
        "AlignGuildHarkonnenButtonClickCoords", { x: 2611, y: 1234 }, ; Align guild button click coords (3440x1440)
        "AlignGuildHarkonnenButton", { x: 2483, y: 1205, w: 292, h: 62 }, ; Align guild button coords (3440x1440)
        ; Accept Mission Window
        "AcceptMissionAnchor", { x: 1945, y: 1039, w: 164, h: 51 }, ; Close/Esc button on the offer window (3440x1440)
        ; Mnemonic Devices
        ; Digits "11/35" measured at screen x=2583..2667, y=253..272 (3440x1440).
        ; OCR reads a box grown by 10px each side (Ocr.HudCaptureRect), so this box
        ; yields a capture of x=2566..2682, y=245..285: it contains the digits with
        ; ~16px margin and excludes the "<" chevron (ends 2564), the hourglass icon
        ; (starts 2684) and the badge's top/bottom border lines (243-244, 286-287).
        "MnemonicDeviceTextArea", { x: 2576, y: 255, w: 96, h: 20 },
        ; Travel Confirmation Window
        "TravelConfirmationTextArea", { x: 1546, y: 589, w: 116, h: 42 }, ; Travel confirmation text area that should read "Travel" and this window needs to be closed (3440x1440)
        "TravelConfirmationCancelButtonCoords", { x: 1828, y: 834 }, ; Travel confirmation cancel button coords to close the window(3440x1440)
        ; In-world "View mission report?" diamond ! icon (3440x1440).
        "MissionCompleteIndicator", { x: 1999, y: 997, w: 44, h: 44 },
        ; HOUSE GRID
        "HouseTooltipRightOffset", 315, ; If the tooltip is on the right, x value of the "House" text is this offset from the top left corner of the house cell.
        "HouseTooltipLeftOffset", 670, ; Left tooltip: panel left edge is this many px left of the cell top-left corner (3440x1440)
        "HouseTooltipWidth", 600, ; Width of the house-text image search area (3440x1440)
        "HouseTooltipHeight", 500, ; Height of the house-text image search area (3440x1440); expanded for upward-shifted bottom-row tooltips
        "HouseTooltipSearchYOffset", -300, ; House-text search starts 300px above cell top-left (3440x1440)
        "HouseNameSearchAreaRelativeToTooltip", { x: -10, y: -10, w: 350, h: 50 }, ; When we find the house text image, we use those coordinates and add these for OCR area to determine house name.
        "HousePersonalTextImgOffsetRelativeToTooltip", { x: 0, y: 100, w: 600, h: 600 }, ; When we find the house text image, we use those coordinates and add these to find the "Personal" image
        "HouseRewardsBandOcrInsetX", 120, ; Trim left edge of rewards-band OCR (3440x1440); shifts start x right and reduces width by same amount
        "HouseRewardsBandOcrMaxHeight", 280, ; Max OCR height above personal-text match — crops header/thresholds (3440x1440)
        ; Upscale factor for rewards-band OCR. The band is the largest region we OCR and its
        ; text is the largest (4 lines, ~40px glyphs), so 4x only multiplies the per-pixel
        ; threshold cost for no accuracy gain. Costs scale with the square: 4->2 is 4x fewer
        ; pixels. Raise back to 4 if reward tiers stop matching (check match= in [HouseBench]).
        "HouseRewardsBandOcrScale", 2,
        "PersonalContributionRowArea", { w: 590, h: 50, y: -10 }, ; Full row — x from house text match, y from personal image match.
        ; The row renders right-aligned as "Personal Contribution: <value>", so the digits sit
        ; at the row's RIGHT edge (x + 590). Keep origX + w == 590 so the right edge stays
        ; pinned there, and only narrow the width — a 210px box reached back into the word
        ; "Contribution" and OCR returned "I Contribution: O" for every zero-contribution
        ; house. 170px covers an 8-digit value with margin and leaves only the label tail.
        "PersonalContributionValueArea", { x: 420, y: -10, w: 170, h: 50 }, ; Right-aligned value — right edge pinned to the row's right edge.
        ; Contribution Reader (claim flow; OCR disabled for now)
        "ClaimMissionContributionIconSearchArea", { x: 1847, y: 359, w: 85, h: 683 }, ; Search area for the contribution icon image
        "ClaimMissionContributionTextArea", { w: 450, h: 40 }, ; OCR box for contribution value text
        "ClaimMissionContributionTextOffset", { x: 37, y: 0 }, ; Offset from contribution icon match to contribution value text start (3440x1440)
    ),
)