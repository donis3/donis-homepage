#Requires AutoHotkey v2.0+

/**
 * Log sink with two destinations:
 *
 *   1. An in-memory ring rendered into the Logs tab (maxLines, so a long run
 *      cannot grow the GUI control without bound).
 *   2. A file under debug_out\, appended to line by line.
 *
 * Every line reaches the file, including Debug(). A stuck run is only diagnosable
 * from the verbose trace, and the GUI ring exists purely to keep the Logs tab
 * readable - so Debug() lines are written to disk even when debug mode is off,
 * but mirrored to the GUI only when it is on.
 *
 * File appends are unbuffered (FileAppend per line) rather than an open handle:
 * a force-killed or hung process must still leave the last diagnostic on disk,
 * and this app's log volume is far too low for the extra syscall to matter.
 */
class Logger {
    logLines := []
    maxLines := 2000
    targetGui := ""
    targetControl := ""
    debugMode := false
    logFilePath := ""
    maxFileBytes := 4194304 ; 4 MB, then rotate to donsraad_debug.1.log

    __New(debugMode := false, logDir := "") {
        this.logLines := []
        this.debugMode := debugMode ? true : false
        if (logDir != "")
            this.OpenLogFile(logDir)
    }

    SetDebug(enabled) {
        wasEnabled := this.debugMode
        this.debugMode := enabled ? true : false
        if (this.debugMode != wasEnabled)
            this.AppendLine("---- debug mode " (this.debugMode ? "enabled" : "disabled") " ----")
    }

    BindGui(guiObj, controlObj) {
        this.targetGui := guiObj
        this.targetControl := controlObj
        this.Render()
    }

    Log(message) {
        this.Emit(message, true)
    }

    Debug(message) {
        this.Emit("(Debug) " message, this.debugMode)
    }

    Clear() {
        this.logLines := []
        this.Render()
    }

    Render() {
        if !IsObject(this.targetControl)
            return

        fullText := ""
        for _, line in this.logLines {
            fullText .= line . "`n"
        }

        this.targetControl.Value := RTrim(fullText, "`n")
    }

    GetLogFilePath() {
        return this.logFilePath
    }

    IsDebugEnabled() {
        return this.debugMode
    }

    /**
     * Opens (or creates) debug_out\donsraad_debug.log and appends a session
     * banner. The path is deliberately stable so the same file can always be
     * handed over after a failure, and one rotated backup is kept so repeated
     * runs cannot grow it without bound.
     */
    OpenLogFile(logDir) {
        try {
            DirCreate(logDir)
            path := logDir "\donsraad_debug.log"

            if (FileExist(path) && FileGetSize(path) > this.maxFileBytes) {
                backup := logDir "\donsraad_debug.1.log"
                try FileDelete(backup)
                FileMove(path, backup, true)
            }

            this.logFilePath := path
            this.AppendLine("")
            this.AppendLine("========== session start "
                FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " ==========")
        } catch {
            this.logFilePath := ""
        }
    }

    Emit(message, showInGui) {
        text := String(message)
        stamp := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
        line := stamp " | " text

        this.AppendLine(line)

        if (!showInGui)
            return

        this.logLines.Push(line)
        while (this.logLines.Length > this.maxLines)
            this.logLines.RemoveAt(1)

        this.Render()
    }

    /**
     * Never throws: logging must not be able to break a scenario mid-run. A
     * failed write (transient lock, full disk) drops the line and the next one
     * simply retries.
     */
    AppendLine(line) {
        if (this.logFilePath == "")
            return
        try {
            FileAppend(line "`n", this.logFilePath, "UTF-8")
        } catch as err {
            ; Intentionally swallowed - see comment above.
            return
        }
    }
}
