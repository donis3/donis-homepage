#Requires AutoHotkey v2.0+

/**
 * Accept Complete Missions Scenario
 * Runs while on Landsraad → Active Missions. Claims every completed active mission.
 *
 * 1. Confirm Landsraad tab; if missing, press L and click LandsraadSubTabButton, then check again.
 * 2. Scan slots bottom → top for active_mission_complete_icon.png (no OCR unless an icon matches).
 * 3. OCR only the completed slot for the mission name.
 * 4. Claim the lowest completed slot first (bottom → top). Claiming from the top shifts the
 *    stack upward and can pair a stale OCR name with the mission that moved into that slot.
 * 5. After each claim, wait for the stack to settle, then re-read until none are complete.
 * 6. When "Stop when mnemonic recollections run out" is on and the session's
 *    remaining recollections are depleted, stop the loop without claiming more
 *    (Master then goes idle and plays the finish cue).
 *
 * Callable via acceptCompleteMissionsScenarioInst.Execute().
 */
class AcceptCompleteMissionsScenario {
    stateManager := ""
    logger := ""
    anchorMatcher := ""
    profileManager := ""
    imageVariation := 30
    completeIconVariation := 60
    completeIconImage := "active_mission_complete_icon.png"
    completeIconTransColor := "Black"
    completeIconSearchPad := 28
    contributionIconImage := "landsraad_contribution_icon.png"
    contributionIconVariation := 50
    claimConfirmImage := "mission_claim_confirm.png"
    claimConfirmVariation := 45
    claimConfirmSearchTimeoutMs := 2000
    claimConfirmSearchPollMs := 40
    maxClaims := 3
    claimSettleTimeoutMs := 1200
    claimSettlePollMs := 50
    claimPanelOpenMs := 400
    claimConfirmOpenMs := 350
    lastClaimedCount := 0
    lastClaimedNames := []
    lastNoTargetedMissionsRemaining := false
    lastStoppedForMnemonicDepletion := false

    __New(stateManagerInst := "", loggerInst := "", anchorMatcherInst := "", profileManagerInst := "") {
        this.stateManager := stateManagerInst
        this.logger := loggerInst
        this.profileManager := profileManagerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
    }

    Execute() {
        StatusBar.PinBottomLeft()
        try {
            this.Debug("[AcceptCompleteMissions] Starting scenario...")
            this.EnsureGameActive()
            this.lastClaimedCount := 0
            this.lastClaimedNames := []
            this.lastNoTargetedMissionsRemaining := false
            this.lastStoppedForMnemonicDepletion := false

            global GameConstants
            if !IsObject(GameConstants) || !GameConstants.Has("GameUI") {
                return this.Fail("GameConstants GameUI is missing.")
            }
            if !GameConstants["GameUI"].Has("LandsraadTabButton") || !GameConstants["GameUI"].Has("LandsraadSubTabButton") {
                return this.Fail("Landsraad tab constants are missing.")
            }
            if !GameConstants["GameUI"].Has("ActiveMissionFirstCompleteIcon")
                || !GameConstants["GameUI"].Has("ActiveMissionCompleteIconSpacing") {
                return this.Fail("Active mission complete-icon constants are missing.")
            }
            if !GameConstants["GameUI"].Has("ActiveMissionClaimClickCoords")
                || !GameConstants["GameUI"].Has("ActiveMissionClaimConfirmImageSearchArea") {
                return this.Fail("Active mission claim coordinates are missing.")
            }
            if !GameConstants["GameUI"].Has("ClaimMissionContributionIconSearchArea") {
                return this.Fail("ClaimMissionContribution constants are missing.")
            }

            if !this.EnsureActiveMissionsMenu()
                return false

            if this.ShouldWaitForAllTargetedComplete() {
                this.Log("[AcceptCompleteMissions] Not all targeted missions are complete.")
                StatusBar.Notify("All targeted missions must be completed", "info")
                this.ReturnToGame()
                this.lastClaimedCount := 0
                return true
            }

            claimedCount := 0
            runSec := this.GetClaimRunSeconds()
            loop this.maxClaims {
                if this.ShouldStopForMnemonicDepletion() {
                    this.lastStoppedForMnemonicDepletion := true
                    this.Debug("[AcceptCompleteMissions] Mnemonic recollections are finished. Stopping claim loop after "
                        claimedCount " claim(s).")
                    break
                }

                completed := this.FindCompletedMission()
                if !IsObject(completed) {
                    if (claimedCount > 0)
                        this.Debug("[AcceptCompleteMissions] Claimed " claimedCount " completed mission(s). Stopping.")
                    else
                        this.Debug("[AcceptCompleteMissions] No completed missions found.")
                    this.lastClaimedCount := claimedCount
                    return true
                }

                if !this.ClaimCompletedMission(completed)
                    return false
                this.RecordClaimedMissionStats(completed.missionName, runSec)
                this.RememberClaimedName(completed.missionName)
                claimedCount += 1
                this.lastClaimedCount := claimedCount
                this.ConsumeMnemonicDevice()

                if (this.GetTargetedMissions().Length == 0) {
                    this.HandleNoTargetedMissionsRemaining()
                    this.lastNoTargetedMissionsRemaining := true
                    break
                }
            }

            this.lastClaimedCount := claimedCount
            this.Debug("[AcceptCompleteMissions] Claimed " claimedCount " completed mission(s). Stopping.")
            return true
        } finally {
            StatusBar.ClearBottomLeftPin()
        }
    }

    EnsureGameActive() {
        return GameWindow.Activate()
    }

    EnsureActiveMissionsMenu() {
        if this.IsLandsraadTabVisible() {
            this.Debug("[AcceptCompleteMissions] Landsraad tab confirmed. Opening active missions sub-tab...")
            this.OpenActiveMissionsTab()
            return true
        }

        this.Debug("[AcceptCompleteMissions] Landsraad tab not visible. Opening menu (L + sub-tab)...")
        this.OpenLandsraadAndActiveMissionsTab()

        if this.IsLandsraadTabVisible() {
            this.Debug("[AcceptCompleteMissions] Landsraad tab confirmed after recovery.")
            return true
        }

        return this.Fail("Could not open Landsraad active missions tab.")
    }

    IsLandsraadTabVisible() {
        searchArea := this.GetLandsraadTabSearchArea()
        if !IsObject(searchArea)
            return false

        foundX := 0, foundY := 0
        found := this.anchorMatcher.FindAnchor("landsraad_button.png", &foundX, &foundY, searchArea, this.imageVariation)
        if (found)
            this.Debug("[AcceptCompleteMissions] Landsraad button at (" foundX ", " foundY ").")
        return found
    }

    OpenLandsraadAndActiveMissionsTab() {
        InputHelper.SendGameKey("l", 60)
        startTime := A_TickCount
        while (A_TickCount - startTime < 1200) {
            if this.IsLandsraadTabVisible()
                break
            Sleep(40)
        }
        this.OpenActiveMissionsTab()
    }

    OpenActiveMissionsTab() {
        global GameConstants
        subTabConfig := GameConstants["GameUI"]["LandsraadSubTabButton"]
        subPos := ResolutionManager().coords(subTabConfig.x, subTabConfig.y)
        this.Debug("[AcceptCompleteMissions] Clicking LandsraadSubTabButton at (" subPos.x ", " subPos.y ")...")
        InputHelper.FastClick(subPos.x, subPos.y)
    }

    ReadActiveMissions() {
        boxes := this.GetActiveMissionBoxes()
        if (boxes.Length == 0) {
            this.Log("[AcceptCompleteMissions] Error: Unable to determine active mission box positions.")
            return []
        }

        candidates := this.GetCandidateMissions()
        ocrLang := this.GetOcrLanguage()
        activeMissions := []

        this.Debug("[AcceptCompleteMissions] Reading " boxes.Length " active mission slots...")

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                normalized := Ocr.NormalizeText(ocrResult.text)
                matched := Ocr.FindBestMatch(normalized, candidates)
                matchedName := (matched.confidence >= 0.4) ? matched.matchedName : ""

                if (matchedName != "") {
                    activeMissions.Push({
                        index: box.index,
                        missionName: matchedName
                    })
                    this.Debug("[AcceptCompleteMissions] Slot " box.index ": " matchedName)
                }
            } catch as err {
                this.Debug("[AcceptCompleteMissions] Error reading slot " box.index ": " err.Message)
            }
        }

        return activeMissions
    }

    ShouldWaitForAllTargetedComplete() {
        if !this.AllTargetedMissionsAreActive()
            return false
        if !this.HasAnyCompletedMission()
            return false
        return !this.AllTargetedActiveMissionsAreComplete()
    }

    AllTargetedMissionsAreActive() {
        if !IsObject(this.stateManager)
            return false
        targeted := this.stateManager.GetTargetedMissions()
        active := this.stateManager.GetActiveMissions()
        if (!(targeted is Array) || targeted.Length == 0)
            return false
        if (!(active is Array) || active.Length == 0)
            return false

        targetedNames := Map()
        targetedCount := 0
        for _, mission in targeted {
            if !(IsObject(mission))
                continue
            name := mission.HasOwnProp("missionName") ? Trim(mission.missionName) : ""
            if (name == "")
                continue
            targetedCount += 1
            targetedNames[StrLower(name)] := true
        }

        activeNames := Map()
        activeCount := 0
        for _, mission in active {
            if !(IsObject(mission))
                continue
            name := mission.HasOwnProp("missionName") ? Trim(mission.missionName) : ""
            if (name == "")
                continue
            activeCount += 1
            nameKey := StrLower(name)
            activeNames[nameKey] := true
            if !targetedNames.Has(nameKey)
                return false
        }

        if (targetedCount == 0 || activeCount == 0 || activeCount != targetedCount)
            return false

        for nameKey, _ in targetedNames {
            if !activeNames.Has(nameKey)
                return false
        }
        return true
    }

    HasAnyCompletedMission() {
        loop 3 {
            slotIndex := 4 - A_Index
            if this.HasCompleteIcon(slotIndex, false)
                return true
        }
        return false
    }

    AllTargetedActiveMissionsAreComplete() {
        targeted := this.GetTargetedMissions()
        if (targeted.Length == 0)
            return false

        targetedNames := Map()
        for _, mission in targeted {
            name := Trim(mission.missionName)
            if (name != "")
                targetedNames[StrLower(name)] := true
        }
        if (targetedNames.Count == 0)
            return false

        active := this.ReadActiveMissions()
        if (active.Length == 0)
            return false

        matched := 0
        for _, entry in active {
            nameKey := StrLower(Trim(entry.missionName))
            if (nameKey == "" || !targetedNames.Has(nameKey))
                return false
            if !this.HasCompleteIcon(entry.index, false)
                return false
            matched += 1
        }
        return matched == targetedNames.Count
    }

    GetTargetedMissions() {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("GetTargetedMissions")
            return []
        targeted := this.stateManager.GetTargetedMissions()
        return (targeted is Array) ? targeted : []
    }

    ReturnToGame() {
        this.Debug("[AcceptCompleteMissions] Returning to game (Esc).")
        InputHelper.SendGameKey("Esc")
    }

    HandleNoTargetedMissionsRemaining() {
        this.Log("[AcceptCompleteMissions] No targeted missions remaining.")
        StatusBar.Notify("No targeted missions", "info")
        StatusBar.SetStatus("No targeted missions")
        global mainGuiInst
        if IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus")
            mainGuiInst.SetStatus("No targeted missions")
        this.ReturnToGame()
    }

    /**
     * Image-search first (bottom → top). OCR only the slot that shows a complete icon.
     * Skips OCR entirely when no slot has a complete icon.
     */
    FindCompletedMission() {
        loop 3 {
            slotIndex := 4 - A_Index
            if !this.HasCompleteIcon(slotIndex, false)
                continue

            missionName := this.ReadMissionNameInSlot(slotIndex)
            if (missionName == "")
                missionName := "Unknown"
            this.Debug("[AcceptCompleteMissions] Complete icon for slot " slotIndex
                . ". Completed mission: " missionName)
            return {
                index: slotIndex,
                missionName: missionName
            }
        }
        return ""
    }

    ReadMissionNameInSlot(slotIndex) {
        boxes := this.GetActiveMissionBoxes()
        box := ""
        for _, entry in boxes {
            if (entry.index == slotIndex) {
                box := entry
                break
            }
        }
        if !IsObject(box)
            return ""

        try {
            ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, this.GetOcrLanguage())
            normalized := Ocr.NormalizeText(ocrResult.text)
            matched := Ocr.FindBestMatch(normalized, this.GetCandidateMissions())
            if (matched.confidence >= 0.4)
                return matched.matchedName
        } catch as err {
            this.Debug("[AcceptCompleteMissions] Error re-reading slot " slotIndex ": " err.Message)
        }
        return ""
    }

    ClaimCompletedMission(mission) {
        slotIndex := Integer(mission.index)
        missionName := Trim(IsObject(mission) && mission.HasOwnProp("missionName") ? mission.missionName : "")
        houseName := ""
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetActiveMissionHouse")
            houseName := Trim(this.stateManager.GetActiveMissionHouse(missionName))

        if !this.ClickActiveMissionSlot(slotIndex) {
            return this.Fail("Could not click completed mission slot " slotIndex ".")
        }

        Sleep(this.claimPanelOpenMs)

        contribParsed := false
        contribValue := 0
        if this.ShouldReadClaimContribution(missionName) {
            contribResult := this.ReadClaimContribution(mission)
            if IsObject(contribResult) && contribResult.found {
                contribParsed := true
                contribValue := contribResult.value
            }
        }

        if !this.ClickUiPoint("ActiveMissionClaimClickCoords", "claim reward", true)
            return false

        Sleep(this.claimConfirmOpenMs)

        if !this.ClickClaimConfirmButton()
            return false

        if !this.WaitForSlotClaimed(slotIndex)
            return this.Fail("Claim did not complete for slot " slotIndex " (`"" missionName "`").")

        if (contribParsed && houseName != "" && IsObject(this.profileManager)
            && this.profileManager.HasMethod("AddHouseContribution")) {
            result := this.profileManager.AddHouseContribution(houseName, contribValue)
            if IsObject(result) && result.Has("success") && result["success"] {
                this.Log("[AcceptCompleteMissions] Added " contribValue " contribution to " houseName ".")
                if result.Has("goalJustReached") && result["goalJustReached"] {
                    this.NotifyHouseGoalReached(houseName)
                    if (IsObject(this.stateManager)
                        && this.stateManager.HasMethod("RemoveTargetedMissionsForHouse"))
                        this.stateManager.RemoveTargetedMissionsForHouse(houseName, this.profileManager)
                } else {
                    this.NotifyHouseGoalProgress(houseName, contribValue, result)
                }
                if result.Has("swatchJustOwned") && result["swatchJustOwned"]
                    this.Log("[AcceptCompleteMissions] Swatch earned for " houseName ".")
                this.RefreshContributionUi()
            }
        }

        if (IsObject(this.stateManager) && this.stateManager.HasMethod("RemoveActiveMissionByName")
            && missionName != "" && StrLower(missionName) != "unknown") {
            this.stateManager.RemoveActiveMissionByName(missionName)
        }

        this.Debug("[AcceptCompleteMissions] Claimed `"" missionName "`" from slot " slotIndex ".")
        return true
    }

    /**
     * Poll until the complete icon clears after confirm. No fixed post-claim sleep.
     */
    WaitForSlotClaimed(slotIndex) {
        slotIndex := Integer(slotIndex)
        InputHelper.MoveCursorClearOfSearch()
        startTime := A_TickCount
        while (A_TickCount - startTime < this.claimSettleTimeoutMs) {
            if !this.HasCompleteIcon(slotIndex, false) {
                this.Debug("[AcceptCompleteMissions] Slot " slotIndex " complete icon cleared after claim.")
                return true
            }
            Sleep(this.claimSettlePollMs)
        }
        this.Debug("[AcceptCompleteMissions] Slot " slotIndex " still shows the complete icon after claim.")
        return false
    }

    ShouldReadClaimContribution(missionName := "") {
        missionName := Trim(missionName)
        if (missionName == "")
            return false
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("GetActiveMissionHouse")
            return false
        if (Trim(this.stateManager.GetActiveMissionHouse(missionName)) == "")
            return false
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("IsLandsraadScannedForCurrentWeek")
            return false
        return this.profileManager.IsLandsraadScannedForCurrentWeek()
    }

    ReadClaimContribution(mission) {
        slotIndex := IsObject(mission) ? Integer(mission.index) : 1
        missionName := Trim(IsObject(mission) && mission.HasOwnProp("missionName") ? mission.missionName : "")

        match := this.FindClaimContributionIcon()
        if !IsObject(match) {
            label := missionName != "" ? " (`"" missionName "`")" : ""
            this.Log("[AcceptCompleteMissions] failed to read cont" label ".")
            return { found: false, value: 0 }
        }

        box := this.BuildClaimContributionTextBox(match.x, match.y)
        if !IsObject(box) {
            this.Log("[AcceptCompleteMissions] failed to read cont.")
            return { found: false, value: 0 }
        }

        try {
            ocrResult := Ocr.FromHudRect(box.screenX, box.screenY, box.screenW, box.screenH, this.GetOcrLanguage())
            normalized := Ocr.NormalizeText(ocrResult.text)
            parsed := Ocr.ParseLandsraadContribution(normalized)
            if (parsed.found) {
                this.Log("[AcceptCompleteMissions] cont: " parsed.value)
                this.Debug("[AcceptCompleteMissions] Contribution OCR `"" normalized "`" for slot " slotIndex ".")
                return { found: true, value: parsed.value, rawText: normalized }
            }
            this.Log("[AcceptCompleteMissions] failed to read cont.")
            if (normalized != "")
                this.Debug("[AcceptCompleteMissions] Contribution OCR `"" normalized "`" (unparsed).")
        } catch as err {
            this.Log("[AcceptCompleteMissions] failed to read cont.")
            this.Debug("[AcceptCompleteMissions] Contribution OCR error: " err.Message)
        }
        return { found: false, value: 0 }
    }

    RefreshContributionUi() {
        global mainGuiInst
        if IsSet(mainGuiInst) && IsObject(mainGuiInst) {
            if mainGuiInst.HasMethod("RefreshMissionPickerTabs")
                mainGuiInst.RefreshMissionPickerTabs()
            if (mainGuiInst.activeTab == 2 && IsObject(mainGuiInst.landsraadTab)
                && mainGuiInst.landsraadTab.HasMethod("Refresh"))
                mainGuiInst.landsraadTab.Refresh()
            if mainGuiInst.HasMethod("RefreshRewardsTab")
                mainGuiInst.RefreshRewardsTab()
            if mainGuiInst.HasMethod("RefreshStatusProgress")
                mainGuiInst.RefreshStatusProgress()
        }
    }

    NotifyHouseGoalReached(houseName) {
        label := Trim(houseName)
        if (label == "")
            return
        msg := label " goal reached!"
        StatusBar.NotifyGoalReached(label)
        SfxPlayer.PlayGoalReach()
        this.Log("[AcceptCompleteMissions] " msg)
    }

    NotifyHouseGoalProgress(houseName, contribPerMission, result) {
        if !IsObject(this.profileManager) || !this.profileManager.HasMethod("GetHouseGoal")
            return
        try {
            contribPerMission := Integer(contribPerMission)
        } catch {
            return
        }
        if (contribPerMission <= 0)
            return

        goal := this.profileManager.GetHouseGoal(houseName)
        if (goal <= 0)
            return

        newCont := result.Has("newCont") ? Integer(result["newCont"]) : 0
        if (newCont >= goal)
            return

        remaining := goal - newCont
        missionsLeft := Ceil(remaining / contribPerMission)
        if (missionsLeft < 1)
            missionsLeft := 1

        StatusBar.NotifyGoalProgress(houseName, missionsLeft, newCont, goal)
        this.Log("[AcceptCompleteMissions] " houseName ": " missionsLeft " mission(s) left to goal.")
    }

    FindClaimContributionIcon() {
        searchArea := this.GetClaimContributionSearchArea()
        if !IsObject(searchArea)
            return ""

        foundX := 0, foundY := 0
        maskedPath := this.anchorMatcher.PrepareTanGlyphMask(this.contributionIconImage, "FFFFFF")
        if (maskedPath == "")
            return ""

        found := this.anchorMatcher.FindAnchor(
            maskedPath,
            &foundX,
            &foundY,
            searchArea,
            this.contributionIconVariation,
            "White",
            false
        )
        if !found
            return ""

        return { x: foundX, y: foundY }
    }

    GetClaimConfirmSearchArea() {
        global GameConstants
        area := GameConstants["GameUI"]["ActiveMissionClaimConfirmImageSearchArea"]
        return ResolutionManager().searchRect(area.x, area.y, area.w, area.h, 0)
    }

    ClickClaimConfirmButton() {
        searchArea := this.GetClaimConfirmSearchArea()
        if !IsObject(searchArea)
            return this.Fail("Claim confirm search area is missing.")

        this.Debug("[AcceptCompleteMissions] Searching " this.claimConfirmImage " in ["
            searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        foundX := 0, foundY := 0
        startTime := A_TickCount
        loop {
            if this.FindClaimConfirmButton(&foundX, &foundY) {
                clickPos := this.GetAnchorClickCenter(this.claimConfirmImage, foundX, foundY)
                this.Debug("[AcceptCompleteMissions] Clicking claim confirm at (" clickPos.x ", " clickPos.y ").")
                InputHelper.SendGameClick(clickPos.x, clickPos.y)
                return true
            }
            if (A_TickCount - startTime >= this.claimConfirmSearchTimeoutMs)
                return this.Fail("Claim confirm button not found in ["
                    searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "].")
            Sleep(this.claimConfirmSearchPollMs)
        }
    }

    FindClaimConfirmButton(&foundX, &foundY) {
        searchArea := this.GetClaimConfirmSearchArea()
        if !IsObject(searchArea)
            return false

        maskedPath := this.anchorMatcher.PrepareTanGlyphMask(this.claimConfirmImage, "FFFFFF")
        if (maskedPath != "")
            return this.anchorMatcher.FindAnchor(
                maskedPath, &foundX, &foundY, searchArea, this.claimConfirmVariation, "White", false)

        return this.anchorMatcher.FindAnchor(
            this.claimConfirmImage, &foundX, &foundY, searchArea, this.claimConfirmVariation, "Black", false)
    }

    GetAnchorClickCenter(imageName, foundX, foundY) {
        imagePath := this.anchorMatcher.ResolveImagePath(imageName)
        if !FileExist(imagePath)
            return { x: foundX, y: foundY }

        pBitmap := Gdip_BitmapFromFile(imagePath)
        if !pBitmap
            return { x: foundX, y: foundY }

        w := Gdip_GetImageWidth(pBitmap)
        h := Gdip_GetImageHeight(pBitmap)
        Gdip_DisposeImage(pBitmap)
        return { x: foundX + (w // 2), y: foundY + (h // 2) }
    }

    GetClaimContributionSearchArea() {
        global GameConstants
        area := GameConstants["GameUI"]["ClaimMissionContributionIconSearchArea"]
        return ResolutionManager().searchRect(area.x, area.y, area.w, area.h, 0)
    }

    BuildClaimContributionTextBox(iconScreenX, iconScreenY) {
        global GameConstants
        ui := GameConstants["GameUI"]
        if !ui.Has("ClaimMissionContributionTextOffset") || !ui.Has("ClaimMissionContributionTextArea")
            return ""

        offset := ui["ClaimMissionContributionTextOffset"]
        area := ui["ClaimMissionContributionTextArea"]
        offsetX := offset.HasOwnProp("x") ? offset.x : offset["x"]
        offsetY := offset.HasOwnProp("y") ? offset.y : offset["y"]
        areaW := area.HasOwnProp("w") ? area.w : area["w"]
        areaH := area.HasOwnProp("h") ? area.h : area["h"]

        rm := ResolutionManager()
        textStart := rm.add(iconScreenX, iconScreenY, offsetX, offsetY)
        size := rm.dimensions(areaW, areaH)
        screenX := textStart.x
        screenY := textStart.y
        screenW := Max(1, Round(size.w))
        screenH := Max(1, Round(size.h))
        rm.ClampCapture(&screenX, &screenY, &screenW, &screenH)

        return {
            screenX: screenX,
            screenY: screenY,
            screenW: screenW,
            screenH: screenH
        }
    }

    HasCompleteIcon(slotIndex, logSearch := true) {
        searchArea := this.GetCompleteIconSearchArea(slotIndex)
        if !IsObject(searchArea)
            return false

        foundX := 0, foundY := 0
        if logSearch
            this.Debug("[AcceptCompleteMissions] Searching slot " slotIndex " complete icon in ["
                searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        found := this.anchorMatcher.FindAnchor(
            this.completeIconImage,
            &foundX,
            &foundY,
            searchArea,
            this.completeIconVariation,
            this.completeIconTransColor
        )
        if (found && logSearch)
            this.Debug("[AcceptCompleteMissions] Complete icon for slot " slotIndex " at (" foundX ", " foundY ").")
        return found
    }

    GetClaimRunSeconds() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetCurrentRunElapsed")
            return this.stateManager.GetCurrentRunElapsed()
        return 0
    }

    RecordClaimedMissionStats(missionName, runSec) {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("RecordMissionCompletion")
            return
        this.stateManager.RecordMissionCompletion(missionName, runSec)
    }

    ConsumeMnemonicDevice() {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("ConsumeMnemonicDevice")
            return
        this.stateManager.ConsumeMnemonicDevice()
        this.Debug("[AcceptCompleteMissions] Mnemonic device remaining: " this.stateManager.GetMnemonicDeviceText())
        StatusBar.Refresh()
        RefreshDashboardFooter()
    }

    /**
     * True only when the "stop when mnemonic recollections run out" setting is on
     * and the session's remaining recollections are depleted. When off, claiming
     * continues regardless of the count.
     */
    ShouldStopForMnemonicDepletion() {
        global settingsManagerInst
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        return settingsManagerInst.ShouldStopAutomationForMnemonicDepletion(this.stateManager)
    }

    RememberClaimedName(missionName) {
        name := Trim(missionName)
        if (name == "" || StrLower(name) == "unknown")
            return
        if !(this.lastClaimedNames is Array)
            this.lastClaimedNames := []
        this.lastClaimedNames.Push(name)
    }

    ClickActiveMissionSlot(slotIndex) {
        boxes := this.GetActiveMissionBoxes()
        box := ""
        for _, entry in boxes {
            if (entry.index == slotIndex) {
                box := entry
                break
            }
        }
        if !IsObject(box)
            return false

        clickX := box.screenX + (box.screenW // 2)
        clickY := box.screenY + (box.screenH // 2)
        this.Debug("[AcceptCompleteMissions] Clicking slot " slotIndex " center at (" clickX ", " clickY ")...")
        InputHelper.SendGameClick(clickX, clickY)
        return true
    }

    ClickUiPoint(keyName, label, useGameClick := false) {
        global GameConstants
        if !GameConstants["GameUI"].Has(keyName)
            return this.Fail(keyName " is missing.")

        cfg := GameConstants["GameUI"][keyName]
        pos := ResolutionManager().coords(cfg.x, cfg.y)
        this.Debug("[AcceptCompleteMissions] Clicking " label " at (" pos.x ", " pos.y ")...")
        if useGameClick
            InputHelper.SendGameClick(pos.x, pos.y)
        else
            InputHelper.FastClick(pos.x, pos.y)
        return true
    }

    GetCompleteIconSlotOrigin(slotIndex) {
        global GameConstants
        firstIcon := GameConstants["GameUI"]["ActiveMissionFirstCompleteIcon"]
        spacing := GameConstants["GameUI"]["ActiveMissionCompleteIconSpacing"]
        iconW := firstIcon.HasOwnProp("w") ? firstIcon.w : 41
        iconH := firstIcon.HasOwnProp("h") ? firstIcon.h : 26
        ; 3440x1440: slot1 1486,378  slot2 1486,628  slot3 1486,878
        return {
            x: firstIcon.x,
            y: firstIcon.y + ((slotIndex - 1) * spacing),
            w: iconW,
            h: iconH
        }
    }

    GetCompleteIconSearchArea(slotIndex) {
        origin := this.GetCompleteIconSlotOrigin(slotIndex)
        return ResolutionManager().searchRect(origin.x, origin.y, origin.w, origin.h, this.completeIconSearchPad)
    }

    GetActiveMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("ActiveMissionFirstPosition") || !uiConfig.Has("ActiveMissionTextSize")
            return []

        firstPos := uiConfig["ActiveMissionFirstPosition"]
        textSize := uiConfig["ActiveMissionTextSize"]
        spacing := uiConfig.Has("ActiveMissionSpacing") ? uiConfig["ActiveMissionSpacing"] : 0
        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            pos := rm.coords(firstPos.x, firstPos.y + ((missionIndex - 1) * spacing))
            size := rm.dimensions(textSize.x, textSize.y)
            boxes.Push({
                index: missionIndex,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    GetLandsraadTabSearchArea() {
        global GameConstants
        if !GameConstants["GameUI"].Has("LandsraadTabButton")
            return ""

        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        return ResolutionManager().searchFromConfig(tabBtnConfig, 20)
    }

    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        return []
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    Fail(message) {
        this.Log("[AcceptCompleteMissions] Error: " message)
        StatusBar.SetStatus(message, "error")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus(message)
        return false
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
