#Requires AutoHotkey v2.0+

/**
 * In-memory session flags. Not written to player_state.json.
 * Resets when the script reloads.
 */
class UserState {
    initialized := false
    availableTargetedCount := 0
    sessionCompletedCount := 0
    runActive := false
    cancelRequested := false
    operationActive := false

    /**
     * True after Initialize has finished. While false, only targeted leftover
     * completions count toward SESSION (see StateManager.ShouldCountSessionCompletion).
     */
    IsInitialized() {
        return this.initialized
    }

    SetInitialized(value := true) {
        this.initialized := value ? true : false
    }

    SetAvailableTargetedCount(count) {
        n := Integer(count)
        this.availableTargetedCount := (n < 0) ? 0 : n
    }

    RecordSessionCompletion(count := 1) {
        n := Integer(count)
        if (n < 1)
            n := 1
        this.sessionCompletedCount += n
        return this.sessionCompletedCount
    }

    GetSessionCompletedCount() {
        return this.sessionCompletedCount
    }

    ResetSession() {
        this.initialized := false
        this.availableTargetedCount := 0
        this.runActive := false
        this.cancelRequested := false
        this.operationActive := false
        ; Session completes stay until the app reloads.
    }

    BeginRun() {
        this.ClearCancel()
        this.runActive := true
    }

    EndRun() {
        this.runActive := false
    }

    IsRunActive() {
        return this.runActive
    }

    /**
     * Marks a one-shot foreground scenario (e.g. the Landsraad grid scan) as running so
     * the Stop hotkey cancels it. Kept separate from BeginRun: it must NOT make
     * TravelAutoRun think the picker loop is active.
     */
    BeginOperation() {
        this.ClearCancel()
        this.operationActive := true
    }

    EndOperation() {
        this.operationActive := false
    }

    IsOperationActive() {
        return this.operationActive
    }

    /**
     * True while any cancellable scenario is running (picker loop or a one-shot action).
     * The Start/Stop hotkeys use this so they work for GUI-launched scenarios too.
     */
    IsBusy() {
        return this.runActive || this.operationActive
    }

    RequestCancel() {
        this.cancelRequested := true
    }

    ClearCancel() {
        this.cancelRequested := false
    }

    IsCancelRequested() {
        return this.cancelRequested
    }

    GetAvailableTargetedCount() {
        return this.availableTargetedCount
    }

    GetProgressText(totalCount := 0) {
        total := Integer(totalCount)
        if (total < 0)
            total := 0
        return this.availableTargetedCount "/" total
    }

    IsProgressComplete(totalCount := 0) {
        total := Integer(totalCount)
        if (total < 1)
            return false
        return this.availableTargetedCount >= total
    }

    GetReadyLabel() {
        return "Ready"
    }
}
