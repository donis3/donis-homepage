#Requires AutoHotkey v2.0+

class MissionPickerTab extends GuiPage {
    dragSourceSlot := 0
    dragHoverSlot := 0
    dragActive := false
    dragStartX := 0
    dragStartY := 0
    dragThreshold := 8
    gridDragInstalled := false
    gridCursors := ""
    gridCellBounds := []
    gridSlotByHwnd := ""
    controls := []

    __New(hostGui) {
        super.__New(hostGui, 1)
        this.gridCellBounds := []
        this.gridSlotByHwnd := Map()
    }

    AddCtl(ctl) {
        this.controls.Push(ctl)
        return this.PageAdd(this.pageId, ctl)
    }

    AddTabButton(x, y, w, h, label, callback, primary := false) {
        btn := this.AddTextButton(this.pageId, x, y, w, h, label, callback, primary)
        this.controls.Push(btn)
        return btn
    }

    AddTabSelect(selectCtrl) {
        this.controls.Push(selectCtrl.face)
        this.controls.Push(selectCtrl.caret)
        return this.PageAddSelect(this.pageId, selectCtrl)
    }

    SetVisible(show) {
        for ctl in this.controls {
            try ctl.Visible := show
        }
    }

    Build() {
        g := this.guiObj
        m := this.margin
        contentY := 124
        gapX := 8
        gapY := 8
        this.gridX := m
        this.gridW := this.contentW

        cellW := (this.gridW - 4 * gapX) // 5
        extraW := this.gridW - (cellW * 5 + gapX * 4)

        toolH := 32
        panelH := 150
        footerTop := this.winH - 36
        startY := contentY + toolH + 12
        panelY := footerTop - 12 - panelH
        gridH := panelY - startY - 12
        cellH := (gridH - 4 * gapY) // 5
        if (cellH < 56)
            cellH := 56

        initW := 196
        clearWToolbar := 118
        counterW := 52
        gapBtn := 10
        gapCounter := 20
        initX := this.gridX + this.gridW - initW
        clearXToolbar := initX - gapBtn - clearWToolbar
        counterX := clearXToolbar - gapCounter - counterW
        hintW := counterX - this.gridX - 12

        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.hintLabel := this.AddCtl(g.Add("Text",
            "x" this.gridX " y" contentY " w" hintW " h" toolH " +0x200 BackgroundTrans",
            "Pick up to 3 missions  ·  drag a filled cell to swap  ·  one spec per cell"))

        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.counterLabel := this.AddCtl(g.Add("Text",
            "x" counterX " y" contentY " w" counterW " h" toolH " Right +0x200 BackgroundTrans",
            "0 / 3"))

        this.AddTabButton(clearXToolbar, contentY, clearWToolbar, toolH,
            "Clear all", (*) => this.OnClearAllTargets())
        this.initActionBtn := this.AddTabButton(initX, contentY, initW, toolH,
            "▶   Start", (*) => this.OnInitActionClick(), true)
        this.RefreshInitButton()

        this.boxFrames := []
        this.boxButtons := []
        this.boxNums := []
        this.boxBodies := []
        this.boxInner := []
        this.gridCellBounds := []
        this.gridSlotByHwnd := Map()
        bodyH := 40
        loop 25 {
            idx := A_Index
            col := Mod(idx - 1, 5)
            row := (idx - 1) // 5
            x := this.gridX
            loop col
                x += cellW + ((A_Index <= extraW) ? 1 : 0) + gapX
            w := cellW + ((col + 1 <= extraW) ? 1 : 0)
            y := startY + row * (cellH + gapY)
            ix := x + 2
            iy := y + 2
            iw := w - 4
            ih := cellH - 4
            frame := this.AddCtl(g.Add("Text",
                "x" x " y" y " w" w " h" cellH " Background" this.mutedColor))
            btn := this.AddCtl(g.Add("Text",
                "x" ix " y" iy " w" iw " h" ih " Background" this.gridClickableBg))

            g.SetFont("s8 c52525B", "Segoe UI")
            num := this.AddCtl(g.Add("Text",
                "x" ix " y" iy " w" iw " h" ih " Center +0x200 BackgroundTrans", idx))

            g.SetFont("s10 bold cE4E4E7", "Segoe UI")
            body := this.AddCtl(g.Add("Text",
                "x" ix " y" (iy + (ih - bodyH) // 2) " w" iw " h" bodyH " Center BackgroundTrans", ""))

            this.gridCellBounds.Push({ x: x, y: y, w: w, h: cellH })
            this.gridSlotByHwnd[frame.Hwnd] := idx
            this.gridSlotByHwnd[btn.Hwnd] := idx
            this.gridSlotByHwnd[num.Hwnd] := idx
            this.gridSlotByHwnd[body.Hwnd] := idx

            this.boxFrames.Push(frame)
            this.boxButtons.Push(btn)
            this.boxNums.Push(num)
            this.boxBodies.Push(body)
            this.boxInner.Push({ x: ix, y: iy, w: iw, h: ih })
        }

        this.AddCtl(g.Add("Text",
            "x" this.gridX " y" panelY " w" this.gridW " h" panelH " Background" this.surfaceColor))

        g.SetFont("s9 bold cEAB308", "Segoe UI")
        this.panelLabel := this.AddCtl(g.Add("Text",
            "x" (this.gridX + 16) " y" (panelY + 10) " w" (this.gridW - 32) " h20 BackgroundTrans",
            "Select a house cell to assign missions"))

        this.mRow := []
        rowLabels := ["Mission 1", "Mission 2", "Mission 3"]
        labelW := 86
        clearW := 92
        rowPad := 16
        ddlX := this.gridX + rowPad + labelW + 8
        ddlW := this.gridW - (rowPad * 2) - labelW - 8 - clearW - 8
        clearX := this.gridX + this.gridW - rowPad - clearW
        rowH := 32
        rowGap := 6
        firstRowY := panelY + 36

        loop 3 {
            rowIdx := A_Index
            ry := firstRowY + (rowIdx - 1) * (rowH + rowGap)

            g.SetFont("s9 cA1A1AA", "Segoe UI")
            lbl := this.AddCtl(g.Add("Text",
                "x" (this.gridX + rowPad) " y" ry " w" labelW " h" rowH " +0x200 BackgroundTrans",
                rowLabels[rowIdx]))

            g.SetFont("s10 cE4E4E7", "Segoe UI")
            ddl := DarkSelect(g, ddlX, ry, ddlW, rowH, this)
            this.AddTabSelect(ddl)
            ddl.OnEvent("Change", this.MakeDdlHandler(rowIdx))
            ddl.Opt("+Disabled")

            clrBtn := this.AddTabButton(clearX, ry, clearW, rowH,
                "Clear", this.MakeClearHandler(rowIdx))
            this.SetTextButtonState(clrBtn, false)

            this.mRow.Push({ label: lbl, ddl: ddl, clearBtn: clrBtn, clearEnabled: false })
        }

        this.InstallGridDrag()
    }

    InstallGridDrag() {
        if (this.gridDragInstalled)
            return
        this.gridDragInstalled := true
        this._gridDragDown := this.GridDragDown.Bind(this)
        this._gridDragMove := this.GridDragMove.Bind(this)
        this._gridDragUp := this.GridDragUp.Bind(this)
        this._gridSetCursor := this.GridSetCursor.Bind(this)
        OnMessage(0x0201, this._gridDragDown)
        OnMessage(0x0202, this._gridDragUp)
        OnMessage(0x0200, this._gridDragMove)
        OnMessage(0x0020, this._gridSetCursor)
    }

    EnsureGridCursors() {
        if IsObject(this.gridCursors)
            return
        this.gridCursors := Map(
            "hand", DllCall("LoadCursor", "Ptr", 0, "Ptr", 32649, "Ptr"),
            "move", DllCall("LoadCursor", "Ptr", 0, "Ptr", 32646, "Ptr"),
            "no", DllCall("LoadCursor", "Ptr", 0, "Ptr", 32648, "Ptr")
        )
    }

    GetGridCursorKind(slotIdx) {
        if (this.dragActive)
            return "move"
        if (this.SlotMissionCount(slotIdx) > 0)
            return "move"
        if (this.TotalMissionCount() >= 3)
            return "no"
        return "hand"
    }

    ApplyGridCursor(kind) {
        this.EnsureGridCursors()
        cursor := this.gridCursors.Has(kind) ? this.gridCursors[kind] : this.gridCursors["hand"]
        DllCall("SetCursor", "Ptr", cursor)
    }

    GridSetCursor(wParam, lParam, msg, hwnd) {
        if !this.IsGridDragContext()
            return
        if (hwnd != this.guiObj.Hwnd && this.GetGridSlotFromHwnd(hwnd) == 0)
            return

        clientX := 0, clientY := 0
        if !this.GetGuiClientMousePos(&clientX, &clientY)
            return

        slotIdx := this.HitTestGridSlot(clientX, clientY)
        if (slotIdx == 0)
            return

        this.ApplyGridCursor(this.GetGridCursorKind(slotIdx))
        return 1
    }

    IsGridDragContext() {
        if (this.activeTab != 1 || !IsObject(this.guiObj))
            return false
        ; Scanned week uses MissionPickerGridTab — no drag on that view.
        if IsObject(this.profileManager) && this.profileManager.IsLandsraadScannedForCurrentWeek()
            return false
        return true
    }

    GetGridSlotFromHwnd(hwnd) {
        if IsObject(this.gridSlotByHwnd) && this.gridSlotByHwnd.Has(hwnd)
            return this.gridSlotByHwnd[hwnd]
        return 0
    }

    GetGuiClientMousePos(&clientX, &clientY) {
        MouseGetPos(&clientX, &clientY, &winUnder,, 2)
        return (winUnder == this.guiObj.Hwnd)
    }

    HitTestGridSlot(clientX, clientY) {
        if !(this.gridCellBounds is Array)
            return 0
        loop this.gridCellBounds.Length {
            bounds := this.gridCellBounds[A_Index]
            if (clientX >= bounds.x && clientX < (bounds.x + bounds.w)
                && clientY >= bounds.y && clientY < (bounds.y + bounds.h))
                return A_Index
        }
        return 0
    }

    SlotMissionCount(slotIdx) {
        cnt := 0
        if (this.slotMissions.Has(slotIdx)) {
            for _, label in this.slotMissions[slotIdx] {
                if (label != "")
                    cnt++
            }
        }
        return cnt
    }

    CloneSlotMissions(slotIdx) {
        cloned := []
        if (this.slotMissions.Has(slotIdx)) {
            for _, label in this.slotMissions[slotIdx] {
                if (label != "")
                    cloned.Push(label)
            }
        }
        return cloned
    }

    ClearDragState() {
        hadDrag := this.dragActive
        this.dragSourceSlot := 0
        this.dragHoverSlot := 0
        this.dragActive := false
        if (hadDrag)
            this.RefreshGrid()
    }

    GridDragDown(wParam, lParam, msg, hwnd) {
        if !this.IsGridDragContext()
            return

        slotIdx := this.GetGridSlotFromHwnd(hwnd)
        if (slotIdx == 0) {
            if !this.GetGuiClientMousePos(&clientX, &clientY)
                return
            slotIdx := this.HitTestGridSlot(clientX, clientY)
        }
        if (slotIdx == 0)
            return

        this.dragSourceSlot := slotIdx
        this.dragHoverSlot := slotIdx
        this.dragActive := false
        sx := 0, sy := 0
        MouseGetPos(&sx, &sy)
        this.dragStartX := sx
        this.dragStartY := sy
    }

    GridDragMove(wParam, lParam, msg, hwnd) {
        if (this.dragSourceSlot == 0 || !this.IsGridDragContext())
            return
        if !GetKeyState("LButton", "P") {
            this.ClearDragState()
            return
        }

        if !this.dragActive {
            MouseGetPos(&mx, &my)
            dx := mx - this.dragStartX
            dy := my - this.dragStartY
            if ((dx * dx + dy * dy) < (this.dragThreshold * this.dragThreshold))
                return
            if (this.SlotMissionCount(this.dragSourceSlot) == 0) {
                this.ClearDragState()
                return
            }
            DarkSelect.Dismiss()
            this.dragActive := true
        }

        if !this.GetGuiClientMousePos(&clientX, &clientY) {
            if (this.dragHoverSlot != 0) {
                this.dragHoverSlot := 0
                this.RefreshGrid()
            }
            return
        }

        hover := this.HitTestGridSlot(clientX, clientY)
        if (hover != this.dragHoverSlot) {
            this.dragHoverSlot := hover
            this.RefreshGrid()
        }
    }

    GridDragUp(wParam, lParam, msg, hwnd) {
        if (this.dragSourceSlot == 0 || !this.IsGridDragContext())
            return

        source := this.dragSourceSlot
        target := this.dragHoverSlot
        wasDrag := this.dragActive

        if (wasDrag && target > 0 && target != source && this.SlotMissionCount(source) > 0)
            this.SwapSlotMissions(source, target)
        else if (!wasDrag)
            this.OnBoxClick(source)

        this.dragSourceSlot := 0
        this.dragHoverSlot := 0
        this.dragActive := false
        if (wasDrag)
            this.RefreshGrid()
    }

    SwapSlotMissions(fromIdx, toIdx) {
        if (fromIdx == toIdx || fromIdx < 1 || toIdx < 1)
            return
        if (this.SlotMissionCount(fromIdx) == 0)
            return

        src := this.CloneSlotMissions(fromIdx)
        dst := this.CloneSlotMissions(toIdx)

        if (dst.Length == 0)
            this.slotMissions.Delete(fromIdx)
        else
            this.slotMissions[fromIdx] := dst
        this.slotMissions[toIdx] := src

        if (this.activeSlotIdx == fromIdx)
            this.activeSlotIdx := toIdx
        else if (this.activeSlotIdx == toIdx)
            this.activeSlotIdx := fromIdx

        this.PersistAndRefresh()
        if (this.activeSlotIdx > 0)
            this.PopulatePanel(this.activeSlotIdx)
    }

    MakeDdlHandler(rowIdx) {
        return (ctrl, *) => this.OnDdlChange(rowIdx)
    }
    MakeClearHandler(rowIdx) {
        return (ctrl, *) => this.OnClearRow(rowIdx)
    }

    OnBoxClick(slotIdx) {
        DarkSelect.Dismiss()
        total := this.TotalMissionCount()
        cnt := 0
        if (this.slotMissions.Has(slotIdx)) {
            for _, ml in this.slotMissions[slotIdx] {
                if (ml != "")
                    cnt++
            }
        }
        if (cnt == 0 && total >= 3)
            return

        this.activeSlotIdx := slotIdx
        this.RefreshGrid()
        this.PopulatePanel(slotIdx)
    }

    GetSlotSpecialization(slotIdx) {
        if (!this.slotMissions.Has(slotIdx))
            return ""
        for _, label in this.slotMissions[slotIdx] {
            if (label == "")
                continue
            parsed := this.stateManager.ParseMissionLabel(label)
            if (parsed.specialization != "")
                return parsed.specialization
        }
        return ""
    }

    PopulatePanel(slotIdx) {
        missions := this.slotMissions.Has(slotIdx) ? this.slotMissions[slotIdx] : []
        lockedSpec := this.GetSlotSpecialization(slotIdx)

        specNote := lockedSpec != "" ? "  ·  " lockedSpec : ""
        this.panelLabel.Text := "House cell " slotIdx specNote "  ·  up to 3 missions"

        totalUsed := this.TotalMissionCount()

        loop 3 {
            rowIdx := A_Index
            row := this.mRow[rowIdx]
            curLabel := missions.Length >= rowIdx ? missions[rowIdx] : ""
            takenNames := this.GetTargetedMissionNames(slotIdx, rowIdx)

            choices := []
            for _, m in this.stateManager.allMissionsList {
                mSpec := m.Has("specialization") ? m["specialization"] : ""
                mName := m.Has("name") ? m["name"] : ""
                if (lockedSpec != "" && mSpec != lockedSpec)
                    continue
                if (mName != "" && takenNames.Has(StrLower(mName)))
                    continue
                choices.Push(this.stateManager.FormatMissionLabel(mSpec, mName))
            }

            rowsFilled := 0
            loop rowIdx - 1 {
                rowsFilled += (missions.Length >= A_Index && missions[A_Index] != "") ? 1 : 0
            }
            prevFull := (rowIdx == 1) || (rowsFilled == rowIdx - 1)
            hasOwn := (curLabel != "")
            canEnable := prevFull && (totalUsed < 3 || hasOwn)

            row.ddl.Delete()
            for _, ch in choices
                row.ddl.Add([ch])

            if (canEnable) {
                row.ddl.Opt("-Disabled")
                row.clearEnabled := true
                this.SetTextButtonState(row.clearBtn, true)
            } else {
                row.ddl.Opt("+Disabled")
                row.clearEnabled := false
                this.SetTextButtonState(row.clearBtn, false)
            }

            if (curLabel != "") {
                found := false
                loop choices.Length {
                    if (choices[A_Index] == curLabel) {
                        row.ddl.Choose(A_Index)
                        found := true
                        break
                    }
                }
                if (!found)
                    row.ddl.Choose(0)
            } else {
                row.ddl.Choose(0)
            }
        }
    }

    OnDdlChange(rowIdx) {
        if (this.activeSlotIdx == 0)
            return

        chosen := this.mRow[rowIdx].ddl.Text
        if (chosen == "")
            return

        if (!this.slotMissions.Has(this.activeSlotIdx))
            this.slotMissions[this.activeSlotIdx] := []

        missions := this.slotMissions[this.activeSlotIdx]
        while (missions.Length < rowIdx)
            missions.Push("")
        missions[rowIdx] := chosen

        this.PersistAndRefresh()
        this.PopulatePanel(this.activeSlotIdx)
    }

    OnClearRow(rowIdx) {
        if (this.activeSlotIdx == 0)
            return
        if (!this.mRow[rowIdx].clearEnabled)
            return
        if (!this.slotMissions.Has(this.activeSlotIdx))
            return

        missions := this.slotMissions[this.activeSlotIdx]
        newMissions := []
        loop missions.Length {
            if (A_Index != rowIdx && missions[A_Index] != "")
                newMissions.Push(missions[A_Index])
        }

        if (newMissions.Length == 0)
            this.slotMissions.Delete(this.activeSlotIdx)
        else
            this.slotMissions[this.activeSlotIdx] := newMissions

        this.PersistAndRefresh()
        this.PopulatePanel(this.activeSlotIdx)
    }

    OnClearAllTargets() {
        DarkSelect.Dismiss()
        this.slotMissions := Map()
        this.activeSlotIdx := 0
        this.PersistAndRefresh()
        if IsObject(this.panelLabel)
            this.panelLabel.Text := "Select a house cell to assign missions"
        loop 3 {
            if (this.mRow.Length < A_Index)
                continue
            row := this.mRow[A_Index]
            row.ddl.Delete()
            row.ddl.Choose(0)
            row.ddl.Opt("+Disabled")
            row.clearEnabled := false
            this.SetTextButtonState(row.clearBtn, false)
        }
        this.ShowSessionHint()
    }

    TotalMissionCount() {
        total := 0
        for _, missions in this.slotMissions {
            for _, label in missions {
                if (label != "")
                    total++
            }
        }
        return total
    }

    GetTargetedMissionNames(exceptSlot := 0, exceptRow := 0) {
        taken := Map()
        for slotIdx, missions in this.slotMissions {
            for rowIdx, label in missions {
                if (label == "")
                    continue
                if (slotIdx == exceptSlot && rowIdx == exceptRow)
                    continue
                parsed := this.stateManager.ParseMissionLabel(label)
                if (parsed.missionName != "")
                    taken[StrLower(parsed.missionName)] := true
            }
        }
        return taken
    }

    RefreshGrid() {
        total := this.TotalMissionCount()
        this.counterLabel.Text := total . " / 3"

        loop 25 {
            idx := A_Index
            btn := this.boxButtons[idx]
            frame := this.boxFrames[idx]
            cnt := 0
            isActive := (idx == this.activeSlotIdx)
            spec := this.GetSlotSpecialization(idx)

            if (this.slotMissions.Has(idx)) {
                for _, ml in this.slotMissions[idx] {
                    if (ml != "")
                        cnt++
                }
            }

            isDisabled := (cnt == 0 && total >= 3)
            isDragSource := (this.dragActive && idx == this.dragSourceSlot)
            isDragHover := (this.dragActive && idx == this.dragHoverSlot && idx != this.dragSourceSlot)

            if (cnt > 0) {
                bg := this.gridTargetedBg
                fg := this.gridTargetedFg
                numFg := "5A8F6E"
            } else if (isDisabled) {
                bg := this.gridDisabledBg
                fg := this.gridDisabledFg
                numFg := "3F3F46"
            } else {
                bg := this.gridClickableBg
                fg := this.gridClickableFg
                numFg := "52525B"
            }

            if (isDragHover)
                frame.Opt("Background" this.gridActiveFrame)
            else if (isDragSource)
                frame.Opt("Background" this.mutedColor)
            else if (isActive)
                frame.Opt("Background" this.gridActiveFrame)
            else if (cnt > 0)
                frame.Opt("Background" this.gridTargetedBg)
            else if (isDisabled)
                frame.Opt("Background" this.gridDisabledBg)
            else
                frame.Opt("Background" this.mutedColor)
            frame.Redraw()

            btn.Opt("Background" bg)
            btn.Redraw()

            num := this.boxNums[idx]
            body := this.boxBodies[idx]
            inner := this.boxInner[idx]
            num.SetFont("s8 c" numFg, "Segoe UI")
            if (cnt == 0) {
                body.Text := ""
                num.Text := idx
                num.Move(inner.x, inner.y, inner.w, inner.h)
            } else {
                body.Text := (spec != "") ? (spec "`n" cnt "/3") : (cnt "/3")
                num.Text := idx
                num.Move(inner.x + 6, inner.y + 4, 26, 16)
            }
            body.SetFont("s10 bold c" fg, "Segoe UI")
            body.Redraw()
            num.Redraw()
        }
    }

    PersistAndRefresh() {
        this.RefreshGrid()
        this.SaveMissionSelections()
        this.RefreshStatusOverlay()
        this.RefreshStatusProgress()
    }

    SaveMissionSelections() {
        this.stateManager.SaveTargetedMissionsFromSlots(this.slotMissions)
    }

    RestoreMissionSelections() {
        this.slotMissions := this.stateManager.GetTargetedMissionsBySlot()
        this.RefreshGrid()
        this.RefreshStatusOverlay()
    }

    RefreshStatusOverlay() {
        StatusBar.Refresh()
    }
}
