#Requires AutoHotkey v2.0+

class StatsTab extends GuiPage {
    specs := ["Crafting", "Gathering", "Exploration", "Combat", "Sabotage"]
    specButtons := []
    activeSpec := "Crafting"
    summaryText := ""
    statsAbandons := ""
    statsAccepts := ""
    statsMnemonic := ""
    rowCards := []
    maxRows := 10
    pageIndex := 1
    pageLabel := ""
    prevPageBtn := ""
    nextPageBtn := ""

    __New(hostGui) {
        super.__New(hostGui, 2)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w" (cardW - 140) " h28 +0x200 BackgroundTrans", "Mission stats"))
        this.AddTextButton(2, m + cardW - 120, y, 120, 28, "Reset stats", (*) => this.OnResetStats())
        y += 32

        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w" cardW " h16 BackgroundTrans",
            "Completes, times, abandons, accepts, and mnemonic devices spent for this profile. Reset stats clears all of them."))
        y += 24

        totalsH := 56
        gap := 12
        thirdW := (cardW - gap * 2) // 3
        col2 := m + thirdW + gap
        col3 := col2 + thirdW + gap
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w" thirdW " h" totalsH " Background" this.surfaceColor))
        this.PageAdd(2, g.Add("Text", "x" col2 " y" y " w" thirdW " h" totalsH " Background" this.surfaceColor))
        this.PageAdd(2, g.Add("Text", "x" col3 " y" y " w" thirdW " h" totalsH " Background" this.surfaceColor))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(2, g.Add("Text",
            "x" (m + 16) " y" (y + 10) " w" (thirdW - 32) " h16 BackgroundTrans", "Total abandons"))
        this.PageAdd(2, g.Add("Text",
            "x" (col2 + 16) " y" (y + 10) " w" (thirdW - 32) " h16 BackgroundTrans", "Target missions accepted"))
        this.PageAdd(2, g.Add("Text",
            "x" (col3 + 16) " y" (y + 10) " w" (thirdW - 32) " h16 BackgroundTrans", "Mnemonic devices spent"))
        g.SetFont("s12 bold cEAB308", "Segoe UI")
        this.statsAbandons := this.PageAdd(2, g.Add("Text",
            "x" (m + 16) " y" (y + 28) " w" (thirdW - 32) " h22 BackgroundTrans", "0"))
        this.statsAccepts := this.PageAdd(2, g.Add("Text",
            "x" (col2 + 16) " y" (y + 28) " w" (thirdW - 32) " h22 BackgroundTrans", "0"))
        this.statsMnemonic := this.PageAdd(2, g.Add("Text",
            "x" (col3 + 16) " y" (y + 28) " w" (thirdW - 32) " h22 BackgroundTrans", "0"))
        y += totalsH + 12

        btnGap := 8
        btnW := (cardW - (this.specs.Length - 1) * btnGap) // this.specs.Length
        this.specButtons := []
        loop this.specs.Length {
            idx := A_Index
            spec := this.specs[idx]
            x := m + (idx - 1) * (btnW + btnGap)
            g.SetFont("s9 cA1A1AA", "Segoe UI")
            btn := this.PageAdd(2, g.Add("Text",
                "x" x " y" y " w" btnW " h30 Center +0x200 Background" this.surfaceColor, spec))
            btn.OnEvent("Click", this.MakeSpecHandler(spec))
            this.specButtons.Push({ spec: spec, btn: btn })
        }
        y += 42

        this.PageAdd(2, g.Add("Text", "x" m " y" y " w" cardW " h48 Background" this.surfaceColor))
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w4 h48 BackgroundEAB308"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.summaryText := this.PageAdd(2, g.Add("Text",
            "x" (m + 16) " y" (y + 14) " w" (cardW - 28) " h20 BackgroundTrans", ""))
        y += 60

        g.SetFont("s8 bold c52525B", "Segoe UI")
        nameW := cardW - 200
        this.PageAdd(2, g.Add("Text", "x" (m + 16) " y" y " w" nameW " h16 BackgroundTrans", "MISSION"))
        this.PageAdd(2, g.Add("Text", "x" (m + nameW + 16) " y" y " w80 h16 Right BackgroundTrans", "DONE"))
        this.PageAdd(2, g.Add("Text", "x" (m + cardW - 88) " y" y " w72 h16 Right BackgroundTrans", "BEST"))
        y += 22

        this.rowCards := []
        rowH := 40
        rowGap := 6
        loop this.maxRows {
            ry := y + (A_Index - 1) * (rowH + rowGap)
            bg := this.PageAdd(2, g.Add("Text",
                "x" m " y" ry " w" cardW " h" rowH " Background" this.surfaceColor))
            g.SetFont("s10 bold cE4E4E7", "Segoe UI")
            nameCtl := this.PageAdd(2, g.Add("Text",
                "x" (m + 16) " y" (ry + 10) " w" nameW " h20 BackgroundTrans", ""))
            g.SetFont("s10 bold cEAB308", "Segoe UI")
            doneCtl := this.PageAdd(2, g.Add("Text",
                "x" (m + nameW + 16) " y" (ry + 10) " w80 h20 Right BackgroundTrans", ""))
            g.SetFont("s10 bold cA1A1AA", "Segoe UI")
            bestCtl := this.PageAdd(2, g.Add("Text",
                "x" (m + cardW - 88) " y" (ry + 10) " w72 h20 Right BackgroundTrans", ""))
            this.rowCards.Push({ bg: bg, name: nameCtl, done: doneCtl, best: bestCtl })
        }

        pagerY := y + this.maxRows * (rowH + rowGap) - rowGap + 8
        pagerBtnW := 72
        this.prevPageBtn := this.AddTextButton(2, m + cardW - 232, pagerY, pagerBtnW, 26,
            "Prev", (*) => this.OnPrevPage())
        g.SetFont("s9 bold cA1A1AA", "Segoe UI")
        this.pageLabel := this.PageAdd(2, g.Add("Text",
            "x" (m + cardW - 152) " y" pagerY " w68 h26 Center +0x200 BackgroundTrans", "1 / 1"))
        this.nextPageBtn := this.AddTextButton(2, m + cardW - pagerBtnW, pagerY, pagerBtnW, 26,
            "Next", (*) => this.OnNextPage())

        this.PaintSpecButtons()
        this.Refresh()
    }

    MakeSpecHandler(spec) {
        return (*) => this.ShowSpec(spec)
    }

    OnResetStats() {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("ResetStats")
            return
        this.stateManager.ResetStats()
        this.Refresh()
        this.ShowSessionHint()
        this.SetStatus("Stats reset.")
    }

    ShowSpec(spec) {
        this.activeSpec := spec
        this.pageIndex := 1
        this.PaintSpecButtons()
        this.Refresh()
    }

    OnPrevPage() {
        if (this.pageIndex <= 1)
            return
        this.pageIndex -= 1
        this.Refresh()
    }

    OnNextPage() {
        if (this.pageIndex >= this.PageCount(this.CurrentRowCount()))
            return
        this.pageIndex += 1
        this.Refresh()
    }

    CurrentRowCount() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetMissionStatsForSpec")
            return this.stateManager.GetMissionStatsForSpec(this.activeSpec).Length
        return 0
    }

    PageCount(totalRows) {
        if (totalRows <= 0)
            return 1
        return (totalRows + this.maxRows - 1) // this.maxRows
    }

    PaintSpecButtons() {
        for _, entry in this.specButtons {
            btn := entry.btn
            if (entry.spec == this.activeSpec) {
                btn.Opt("BackgroundEAB308")
                btn.SetFont("s9 bold c18181B", "Segoe UI")
            } else {
                btn.Opt("Background" this.surfaceColor)
                btn.SetFont("s9 cA1A1AA", "Segoe UI")
            }
            btn.Redraw()
        }
    }

    Refresh() {
        rows := []
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetMissionStatsForSpec")
            rows := this.stateManager.GetMissionStatsForSpec(this.activeSpec)

        totalDone := 0
        withBest := 0
        for _, entry in rows {
            done := 0
            best := 0
            try done := Integer(entry.Has("completedCount") ? entry["completedCount"] : 0)
            try best := Integer(entry.Has("bestRunTime") ? entry["bestRunTime"] : 0)
            totalDone += done
            if (best > 0)
                withBest += 1
        }

        if IsObject(this.summaryText) {
            this.summaryText.Text := this.activeSpec "  ·  " rows.Length " missions  ·  "
                . totalDone " completes  ·  " withBest " with a best time"
            this.summaryText.SetFont("s9 bold cE4E4E7", "Segoe UI")
        }

        abandons := 0
        accepts := 0
        mnemonicSpent := 0
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetStat") {
            abandons := this.stateManager.GetStat("guildAbandons")
            accepts := this.stateManager.GetStat("targettedAccepts")
            mnemonicSpent := this.stateManager.GetStat("mnemonicDevicesSpent")
        }
        if IsObject(this.statsAbandons)
            this.statsAbandons.Text := abandons
        if IsObject(this.statsAccepts)
            this.statsAccepts.Text := accepts
        if IsObject(this.statsMnemonic)
            this.statsMnemonic.Text := mnemonicSpent

        pageCount := this.PageCount(rows.Length)
        if (this.pageIndex > pageCount)
            this.pageIndex := pageCount
        if (this.pageIndex < 1)
            this.pageIndex := 1
        start := (this.pageIndex - 1) * this.maxRows

        if IsObject(this.pageLabel)
            this.pageLabel.Text := this.pageIndex " / " pageCount
        this.SetTextButtonState(this.prevPageBtn, this.pageIndex > 1)
        this.SetTextButtonState(this.nextPageBtn, this.pageIndex < pageCount)

        loop this.maxRows {
            idx := A_Index
            card := this.rowCards[idx]
            srcIdx := start + idx
            if (srcIdx > rows.Length) {
                card.bg.Visible := false
                card.name.Visible := false
                card.done.Visible := false
                card.best.Visible := false
                continue
            }
            entry := rows[srcIdx]
            name := entry.Has("name") ? entry["name"] : ""
            done := 0
            best := 0
            try done := Integer(entry.Has("completedCount") ? entry["completedCount"] : 0)
            try best := Integer(entry.Has("bestRunTime") ? entry["bestRunTime"] : 0)
            card.name.Text := name
            card.done.Text := done
            card.best.Text := this.FormatBest(best)
            if (done > 0)
                card.done.SetFont("s10 bold cEAB308", "Segoe UI")
            else
                card.done.SetFont("s10 bold c52525B", "Segoe UI")
            if (best > 0)
                card.best.SetFont("s10 bold c4ADE80", "Segoe UI")
            else
                card.best.SetFont("s10 bold c52525B", "Segoe UI")
            show := (this.activeTab == 2)
            card.bg.Visible := show
            card.name.Visible := show
            card.done.Visible := show
            card.best.Visible := show
        }
    }

    FormatBest(totalSeconds) {
        sec := Integer(totalSeconds)
        if (sec <= 0)
            return "--:--"
        minutes := sec // 60
        seconds := Mod(sec, 60)
        minText := (minutes < 10) ? "0" minutes : minutes
        secText := (seconds < 10) ? "0" seconds : seconds
        return minText ":" secText
    }
}
