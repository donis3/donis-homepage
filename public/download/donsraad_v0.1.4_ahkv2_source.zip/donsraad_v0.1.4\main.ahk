#Requires AutoHotkey v2.0+
#SingleInstance Force
#MaxThreadsPerHotkey 2
Persistent(true)
SetWorkingDir(A_ScriptDir)

;@Ahk2Exe-SetName Donsraad
;@Ahk2Exe-SetDescription Easy Mission Picker for Dune: Awakening
;@Ahk2Exe-SetProductName Donsraad
;@Ahk2Exe-SetCompanyName Deniz Özkan
;@Ahk2Exe-SetCopyright Copyright 2026 Deniz Özkan
;@Ahk2Exe-SetOrigFilename Donsraad.exe
;@Ahk2Exe-SetLanguage 0x0409
;@Ahk2Exe-SetVersion 0.1.4

; Keep JSON and PNG on disk next to the script or exe. FileInstall only
; seeds missing files from a compiled build; existing files are never overwritten.
EnsureRuntimeFiles()

; ==============================================================================
; HIGH-SPEED GLOBAL INPUT INITIALIZATION
; ==============================================================================
SetControlDelay(-1)
SetMouseDelay(-1)
SetKeyDelay(-1, -1)
SendMode("Input")

; ==============================================================================
; GLOBAL INSTANCES & INITIALIZATION
; ==============================================================================
global resolutionManagerInst := ResolutionManager()
global gdipToken := Gdip_Startup()
global stateManagerInst := LandsraadStateManager(A_ScriptDir)
global settingsManagerInst := SettingsManager(A_ScriptDir)
global loggerInst := Logger(settingsManagerInst.Get("debugMode", false))
if IsObject(stateManagerInst) && (stateManagerInst.dbErrors is Array) {
    for _, dbMsg in stateManagerInst.dbErrors
        loggerInst.Log("[Database] " dbMsg)
    if !stateManagerInst.AreDatabasesReady()
        loggerInst.Log("[Database] Houses or missions database is not ready. Mission Picker will be empty until the JSON files are fixed.")
}
global anchorMatcherInst := AnchorMatcher(A_ScriptDir)

global profileManagerInst := ProfileManager(A_ScriptDir)
profileManagerInst.Initialize(stateManagerInst, settingsManagerInst)
global userStateInst := UserState()
global removeActiveMissionsScenarioInst := RemoveActiveMissionsScenario(settingsManagerInst, loggerInst, anchorMatcherInst, stateManagerInst)
global acceptMissionsScenarioInst := AcceptMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst)
global acceptTargettedMissionsScenarioInst := AcceptTargettedMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst)
global acceptCompleteMissionsScenarioInst := AcceptCompleteMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst)
global initializeScenarioInst := InitializeScenario(stateManagerInst, loggerInst, anchorMatcherInst, userStateInst, acceptCompleteMissionsScenarioInst, removeActiveMissionsScenarioInst)
global masterScenarioInst := MasterScenario(stateManagerInst, userStateInst, loggerInst, initializeScenarioInst, removeActiveMissionsScenarioInst, acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst, acceptCompleteMissionsScenarioInst, anchorMatcherInst)
global mainGuiInst := DonsraadGui(stateManagerInst, settingsManagerInst, loggerInst, initializeScenarioInst, userStateInst, profileManagerInst)
global statusOverlayInst := StatusOverlay(stateManagerInst, userStateInst, profileManagerInst, settingsManagerInst)
StatusBar.ApplyVisibility(settingsManagerInst.GetBool("showOverlay", true))
; global houseGridDebugInst := HouseGridDebug()
global missionHandlerDebugInst := MissionHandlerDebug(loggerInst, stateManagerInst)
global activeMissionDebugInst := ActiveMissionDebug(loggerInst, stateManagerInst)

; Register cleanup on script exit
OnExit(AppExitHandler)

; Show initial dashboard
global boundStartHotkey := ""
global boundExitHotkey := ""
global boundToggleHotkey := ""
global boundOverlayHotkey := ""
mainGuiInst.Show()
ApplyAppHotkeys()
TravelAutoRun.Sync()
if A_IsCompiled
    loggerInst.Debug("Standalone build. Data folder: " A_ScriptDir)
loggerInst.Log("Application ready. Donsraad dashboard loaded.")

; ==============================================================================
; HOTKEYS
; Bound at runtime from settings (defaults: Home = start, End = exit)
; ==============================================================================

ApplyAppHotkeys() {
    global settingsManagerInst, boundStartHotkey, boundExitHotkey, boundToggleHotkey, boundOverlayHotkey
    startKey := "Home"
    exitKey := "Pause"
    toggleKey := "Delete"
    overlayKey := "Insert"
    if IsObject(settingsManagerInst) {
        startKey := settingsManagerInst.Get("hotkeyStart", "Home")
        exitKey := settingsManagerInst.Get("hotkeyExit", "Pause")
        toggleKey := settingsManagerInst.Get("hotkeyToggleGui", "Delete")
        overlayKey := settingsManagerInst.Get("hotkeyToggleOverlay", "Insert")
    }
    if (Trim(startKey) == "")
        startKey := "Home"
    if (Trim(exitKey) == "")
        exitKey := "Pause"
    if (Trim(toggleKey) == "")
        toggleKey := "Delete"
    if (Trim(overlayKey) == "")
        overlayKey := "Insert"

    oldStart := boundStartHotkey
    oldExit := boundExitHotkey
    oldToggle := boundToggleHotkey
    oldOverlay := boundOverlayHotkey

    startOk := BindAppHotkey(startKey, OnStartHotkey)
    if !startOk {
        startKey := "Home"
        startOk := BindAppHotkey("Home", OnStartHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyStart", "Home")
    }

    exitOk := BindAppHotkey(exitKey, OnExitHotkey)
    if !exitOk {
        exitKey := "Pause"
        exitOk := BindAppHotkey("Pause", OnExitHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyExit", "Pause")
    }

    toggleOk := BindAppHotkey(toggleKey, OnToggleGuiHotkey)
    if !toggleOk {
        toggleKey := "Delete"
        toggleOk := BindAppHotkey("Delete", OnToggleGuiHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyToggleGui", "Delete")
    }

    overlayOk := BindAppHotkey(overlayKey, OnToggleOverlayHotkey)
    if !overlayOk {
        overlayKey := "Insert"
        overlayOk := BindAppHotkey("Insert", OnToggleOverlayHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyToggleOverlay", "Insert")
    }

    newKeys := Map()
    newKeys[StrLower(startKey)] := true
    newKeys[StrLower(exitKey)] := true
    newKeys[StrLower(toggleKey)] := true
    newKeys[StrLower(overlayKey)] := true

    if (oldStart != "" && !newKeys.Has(StrLower(oldStart))) {
        try Hotkey(oldStart, "Off")
    }
    if (oldExit != "" && !newKeys.Has(StrLower(oldExit))) {
        try Hotkey(oldExit, "Off")
    }
    if (oldToggle != "" && !newKeys.Has(StrLower(oldToggle))) {
        try Hotkey(oldToggle, "Off")
    }
    if (oldOverlay != "" && !newKeys.Has(StrLower(oldOverlay))) {
        try Hotkey(oldOverlay, "Off")
    }

    boundStartHotkey := startKey
    boundExitHotkey := exitKey
    boundToggleHotkey := toggleKey
    boundOverlayHotkey := overlayKey
    return startOk && exitOk && toggleOk && overlayOk
}

BindAppHotkey(key, callback) {
    try {
        Hotkey(key, callback)
        Hotkey(key, "On")
        return true
    } catch {
        return false
    }
}

OnStartHotkey(*) {
    StartPickerRun()
}

StartPickerRun(*) {
    global masterScenarioInst, userStateInst, loggerInst
    if (IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsRunActive()) {
        if userStateInst.IsFirstHome()
            return
        userStateInst.RequestCancel()
        if IsSet(loggerInst) && IsObject(loggerInst)
            loggerInst.Log("Cancelling...")
        StatusBar.SetStatus("Cancelling")
        return
    }

    if (IsSet(userStateInst) && IsObject(userStateInst))
        userStateInst.BeginRun()
    try {
        if (IsSet(masterScenarioInst) && IsObject(masterScenarioInst))
            masterScenarioInst.Execute()
    } finally {
        if (IsSet(userStateInst) && IsObject(userStateInst))
            userStateInst.EndRun()
        TravelAutoRun.Sync()
    }
}

OnToggleGuiHotkey(*) {
    global mainGuiInst
    if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("Toggle"))
        mainGuiInst.Toggle()
}

OnToggleOverlayHotkey(*) {
    StatusBar.Toggle()
}

OnExitHotkey(*) {
    ExitApp()
}

; ==============================================================================
; EXIT HANDLER
; ==============================================================================
AppExitHandler(exitReason, exitCode) {
    global gdipToken, stateManagerInst, profileManagerInst
    try {
        StatusBar.Close()
    }
    try {
        TravelAutoRun.Stop()
    }
    try {
        if IsSet(stateManagerInst) && IsObject(stateManagerInst)
            stateManagerInst.SavePlayerState()
    }
    try {
        if IsSet(profileManagerInst) && IsObject(profileManagerInst) && IsSet(stateManagerInst) && IsObject(stateManagerInst)
            profileManagerInst.SaveAll(stateManagerInst)
    }
    try {
        if (gdipToken)
            Gdip_Shutdown(gdipToken)
    }
    return 0
}

; ==============================================================================
; RUNTIME DATA (external JSON / PNG next to the exe)
; FileInstall source paths must be string literals for Ahk2Exe.
; Overwrite flag 0: never replace a file the user already has on disk.
; ==============================================================================
EnsureRuntimeFiles() {
    DirCreate(A_ScriptDir "\db")
    DirCreate(A_ScriptDir "\ui")
    DirCreate(A_ScriptDir "\ui_elements")

    dest := A_ScriptDir "\db\landsraad_houses.json"
    if !FileExist(dest)
        FileInstall "db\landsraad_houses.json", dest, 0
    dest := A_ScriptDir "\db\landsraad_missions.json"
    if !FileExist(dest)
        FileInstall "db\landsraad_missions.json", dest, 0
    dest := A_ScriptDir "\ui\donis.png"
    if !FileExist(dest)
        FileInstall "ui\donis.png", dest, 0
    dest := A_ScriptDir "\ui\donsraad_icon.png"
    if !FileExist(dest)
        FileInstall "ui\donsraad_icon.png", dest, 0
    dest := A_ScriptDir "\ui_elements\accept_mission_anchor.png"
    if !FileExist(dest)
        FileInstall "ui_elements\accept_mission_anchor.png", dest, 0
    dest := A_ScriptDir "\ui_elements\align_guild.png"
    if !FileExist(dest)
        FileInstall "ui_elements\align_guild.png", dest, 0
    dest := A_ScriptDir "\ui_elements\create_guild.png"
    if !FileExist(dest)
        FileInstall "ui_elements\create_guild.png", dest, 0
    dest := A_ScriptDir "\ui_elements\guild_disband.png"
    if !FileExist(dest)
        FileInstall "ui_elements\guild_disband.png", dest, 0
    dest := A_ScriptDir "\ui_elements\guilds_button.png"
    if !FileExist(dest)
        FileInstall "ui_elements\guilds_button.png", dest, 0
    dest := A_ScriptDir "\ui_elements\landsraad_button.png"
    if !FileExist(dest)
        FileInstall "ui_elements\landsraad_button.png", dest, 0
    dest := A_ScriptDir "\ui_elements\landsraad-corner.png"
    if !FileExist(dest)
        FileInstall "ui_elements\landsraad-corner.png", dest, 0
    dest := A_ScriptDir "\ui_elements\active_mission_complete_icon.png"
    if !FileExist(dest)
        FileInstall "ui_elements\active_mission_complete_icon.png", dest, 0
    dest := A_ScriptDir "\ui_elements\travel_confirmation_window.png"
    if !FileExist(dest)
        FileInstall "ui_elements\travel_confirmation_window.png", dest, 0
}

; ==============================================================================
; INCLUDES
; ==============================================================================
#Include lib\JSON.ahk
#Include lib\Gdip.ahk
#Include core\Version.ahk
#Include core\Constants.ahk
#Include core\Logger.ahk
#Include core\ResolutionManager.ahk
#Include core\OCR.ahk
#Include core\SettingsManager.ahk
#Include core\StateManager.ahk
#Include core\ProfileManager.ahk
#Include core\UserState.ahk
#Include core\AnchorMatcher.ahk
#Include core\InputHelper.ahk
#Include debug\RectangleOverlay.ahk
; #Include debug\HouseGridDebug.ahk
#Include debug\MissionHandlerDebug.ahk
#Include debug\ActiveMissionDebug.ahk
#Include debug\InitDebug.ahk
#Include ui\StatusOverlay.ahk
#Include scenarios\Initialize.ahk
#Include scenarios\RemoveActiveMissions.ahk
#Include scenarios\AcceptMissions.ahk
#Include scenarios\AcceptTargettedMissions.ahk
#Include scenarios\AcceptCompleteMissions.ahk
#Include scenarios\Master.ahk
#Include core\TravelAutoRun.ahk
#Include ui\GuiPage.ahk
#Include ui\DarkSelect.ahk
#Include ui\tabs\MissionPickerTab.ahk
#Include ui\tabs\StatsTab.ahk
#Include ui\tabs\SettingsTab.ahk
#Include ui\tabs\LogsTab.ahk
#Include ui\tabs\AboutTab.ahk
#Include ui\MainWindow.ahk