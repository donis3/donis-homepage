#Requires -Version 5.1
<#
.SYNOPSIS
  Compile Donsraad into a portable standalone folder.

.DESCRIPTION
  Produces dist\Donsraad-<version>\Donsraad.exe plus the JSON and PNG files the exe
  reads and writes at runtime. Source .ahk files are compiled into the exe;
  databases, settings, and UI images stay on disk next to it.
#>
[CmdletBinding()]
param(
    [switch]$SkipCompile
)

$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot

function Get-AppVersion {
    $versionFile = Join-Path $Root "core\Version.ahk"
    if (-not (Test-Path $versionFile)) {
        throw "Missing version file: core\Version.ahk"
    }
    $text = Get-Content -Path $versionFile -Raw
    if ($text -match 'static Version\s*:=\s*"([^"]+)"') {
        return $Matches[1]
    }
    throw "Could not read AppInfo.Version from core\Version.ahk"
}

$AppVersion = Get-AppVersion
$OutDir = Join-Path $Root "dist\Donsraad-$AppVersion"
$ToolsDir = Join-Path $Root "tools"
$Ahk64 = "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"

function Get-Ahk2Exe {
    $cached = Join-Path $ToolsDir "Ahk2Exe\Ahk2Exe.exe"
    if (Test-Path $cached) {
        return $cached
    }

    $known = @(
        "$env:ProgramFiles\AutoHotkey\Compiler\Ahk2Exe.exe",
        "${env:ProgramFiles(x86)}\AutoHotkey\Compiler\Ahk2Exe.exe"
    )
    foreach ($path in $known) {
        if (Test-Path $path) {
            return $path
        }
    }

    Write-Host "Downloading Ahk2Exe..."
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $release = Invoke-RestMethod -Uri "https://api.github.com/repos/AutoHotkey/Ahk2Exe/releases/latest"
    $asset = $release.assets | Where-Object { $_.name -like "*.zip" } | Select-Object -First 1
    if (-not $asset) {
        throw "Could not find an Ahk2Exe zip on GitHub."
    }

    $zipPath = Join-Path $ToolsDir "Ahk2Exe.zip"
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zipPath
    $extractDir = Join-Path $ToolsDir "Ahk2Exe"
    if (Test-Path $extractDir) {
        Remove-Item $extractDir -Recurse -Force
    }
    Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
    Remove-Item $zipPath -Force

    $found = Get-ChildItem -Path $extractDir -Filter Ahk2Exe.exe -Recurse | Select-Object -First 1
    if (-not $found) {
        throw "Ahk2Exe.exe was not in the downloaded zip."
    }
    return $found.FullName
}

function ConvertTo-Ico {
    param(
        [Parameter(Mandatory = $true)][string]$PngPath,
        [Parameter(Mandatory = $true)][string]$IcoPath
    )

    Add-Type -AssemblyName System.Drawing
    $src = [System.Drawing.Image]::FromFile((Resolve-Path $PngPath))
    try {
        $size = 256
        $bmp = New-Object System.Drawing.Bitmap $size, $size
        try {
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            try {
                $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $g.Clear([System.Drawing.Color]::Transparent)
                $g.DrawImage($src, 0, 0, $size, $size)
            } finally {
                $g.Dispose()
            }

            $ms = New-Object System.IO.MemoryStream
            try {
                $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
                $pngBytes = $ms.ToArray()
            } finally {
                $ms.Dispose()
            }
        } finally {
            $bmp.Dispose()
        }
    } finally {
        $src.Dispose()
    }

    $fs = [System.IO.File]::Create($IcoPath)
    $bw = New-Object System.IO.BinaryWriter $fs
    try {
        $bw.Write([uint16]0)
        $bw.Write([uint16]1)
        $bw.Write([uint16]1)
        $bw.Write([byte]0)
        $bw.Write([byte]0)
        $bw.Write([byte]0)
        $bw.Write([byte]0)
        $bw.Write([uint16]1)
        $bw.Write([uint16]32)
        $bw.Write([uint32]$pngBytes.Length)
        $bw.Write([uint32]22)
        $bw.Write($pngBytes)
    } finally {
        $bw.Dispose()
        $fs.Dispose()
    }
}

if (-not (Test-Path $Ahk64)) {
    throw "AutoHotkey v2 64-bit not found at $Ahk64"
}

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$exePath = Join-Path $OutDir "Donsraad.exe"

if (-not $SkipCompile) {
    $ahk2exe = Get-Ahk2Exe
    $icoPath = Join-Path $ToolsDir "donsraad.ico"
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
    ConvertTo-Ico -PngPath (Join-Path $Root "ui\donsraad_icon.png") -IcoPath $icoPath

    Write-Host "Compiling $exePath"
    $canCompile = $true
    if (Test-Path $exePath) {
        try {
            Remove-Item $exePath -Force -ErrorAction Stop
        } catch {
            Write-Warning "Donsraad.exe is in use. Data files will still be copied. Close the app and run build.ps1 again to refresh the exe."
            $canCompile = $false
        }
    }
    if ($canCompile) {
        $inPath = Join-Path $Root "main.ahk"
        $compileArgs = @(
            "/in", "`"$inPath`"",
            "/out", "`"$exePath`"",
            "/base", "`"$Ahk64`"",
            "/icon", "`"$icoPath`"",
            "/compress", "0"
        )
        $proc = Start-Process -FilePath $ahk2exe -WorkingDirectory $Root -ArgumentList $compileArgs -Wait -PassThru -NoNewWindow
        if (-not (Test-Path $exePath)) {
            throw "Ahk2Exe did not produce $exePath (exit $($proc.ExitCode))"
        }
        Write-Host "Compiled $exePath"
    }
}

function Copy-RuntimeFile {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath
    )
    $src = Join-Path $Root $RelativePath
    $dest = Join-Path $OutDir $RelativePath
    $destDir = Split-Path $dest -Parent
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null
    Copy-Item -Path $src -Destination $dest -Force
}

$runtimeFiles = @(
    "db\landsraad_houses.json",
    "db\landsraad_missions.json",
    "ui\donis.png",
    "ui\donsraad_icon.png"
)

foreach ($rel in $runtimeFiles) {
    $src = Join-Path $Root $rel
    if (Test-Path $src) {
        Copy-RuntimeFile $rel
    } else {
        Write-Warning "Missing runtime file: $rel"
    }
}

$userJson = @(
    "settings.json",
    "profiles.json",
    "player_state.json"
)
foreach ($name in $userJson) {
    $src = Join-Path $Root "defaults\$name"
    $dest = Join-Path $OutDir $name
    if (-not (Test-Path $src)) {
        throw "Missing default template: defaults\$name"
    }
    Copy-Item -Path $src -Destination $dest -Force
}

$uiElementsSrc = Join-Path $Root "ui_elements"
$uiElementsDest = Join-Path $OutDir "ui_elements"
New-Item -ItemType Directory -Force -Path $uiElementsDest | Out-Null
Get-ChildItem -Path $uiElementsSrc -File | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination (Join-Path $uiElementsDest $_.Name) -Force
}

$readme = @"
Donsraad v$AppVersion — portable build

Run Donsraad.exe. AutoHotkey does not need to be installed.

Keep this folder together. The exe reads and writes JSON next to itself:
  settings.json
  profiles.json
  player_state.json
  db\landsraad_houses.json
  db\landsraad_missions.json

PNG assets stay on disk and can be replaced without recompiling:
  ui\donis.png
  ui\donsraad_icon.png
  ui_elements\*.png

settings.json, profiles.json, and player_state.json in this folder are
clean defaults (not your local profiles). The app writes to them as you
use it. Existing files are never overwritten by a later extract.
"@
Set-Content -Path (Join-Path $OutDir "README.txt") -Value $readme -Encoding UTF8

Write-Host "Portable build ready: $OutDir (v$AppVersion)"
Get-ChildItem $OutDir -Recurse | Select-Object FullName, Length
