#Requires AutoHotkey v2.0+

/**
 * When AutoRun is enabled and a play timer is running, poll the Travel
 * confirmation window with ImageSearch. 1000ms is enough: the dialog stays
 * until dismissed, and a cropped ImageSearch is a few milliseconds.
 */
class TravelAutoRun {
    static intervalMs := 1000
    static boundTick := ""
    static busy := false

    static Start() {
        if (this.boundTick != "")
            return
        this.boundTick := ObjBindMethod(this, "Tick")
        SetTimer(this.boundTick, this.intervalMs)
    }

    static Stop() {
        if (this.boundTick != "") {
            try SetTimer(this.boundTick, 0)
        }
        this.boundTick := ""
    }

    static IsActive() {
        return this.busy || (this.boundTick != "")
    }

    static Sync() {
        if this.ShouldWatch()
            this.Start()
        else
            this.Stop()
        StatusBar.Refresh()
    }

    static ShouldWatch() {
        global settingsManagerInst, userStateInst, stateManagerInst
        if this.busy
            return false
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        if !settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false)
            return false
        if !IsSet(userStateInst) || !IsObject(userStateInst)
            return false
        if userStateInst.IsRunActive()
            return false
        if !userStateInst.IsInitialized() || userStateInst.IsFirstHome()
            return false
        if !IsSet(stateManagerInst) || !IsObject(stateManagerInst)
            return false
        if !stateManagerInst.HasMethod("HasActiveRunTimer")
            return false
        return stateManagerInst.HasActiveRunTimer()
    }

    static Tick() {
        if !this.ShouldWatch() {
            this.Stop()
            return
        }

        global masterScenarioInst, loggerInst
        if !IsSet(masterScenarioInst) || !IsObject(masterScenarioInst)
            return
        if !masterScenarioInst.HasMethod("IsTravelConfirmationVisible")
            return
        if !masterScenarioInst.IsTravelConfirmationVisible()
            return

        this.busy := true
        this.Stop()
        try {
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log("Travel confirmation detected. AutoRun starting the picker.")
            StatusBar.SetStatus("AutoRun", "working")
            StartPickerRun()
        } finally {
            this.busy := false
            this.Sync()
        }
    }
}
