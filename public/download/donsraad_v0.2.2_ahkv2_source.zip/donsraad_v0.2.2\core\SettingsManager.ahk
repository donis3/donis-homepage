#Requires AutoHotkey v2.0+

/**
 * Settings Manager class.
 * Handles loading, updating, and auto-saving user application settings in settings.json.
 */
class SettingsManager {
    settingsPath := ""
    defaultsPath := ""
    settings := Map()

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        this.settingsPath := rootDir . "\settings.json"
        this.defaultsPath := rootDir . "\defaults\settings.json"
        this.LoadSettings()
    }

    /**
     * Built-in fallback defaults when defaults/settings.json is missing a key.
     */
    GetBuiltinDefaultSettings() {
        return Map(
            "ocrLanguage", "en-US",
            "debugMode", false,
            "guildName", "wowza",
            "faction", "Atreides",
            "characterName", "player",
            "currentProfileId", "default",
            "hotkeyStart", "Home",
            "hotkeyStop", "End",
            "hotkeyToggleAutoRun", "Delete",
            "hotkeyExit", "Pause",
            "hotkeyToggleGui", "F8",
            "hotkeyToggleOverlay", "Insert",
            "hotkeyReload", "PgDn",
            "showOverlay", true,
            "overlayPosition", "topLeft",
            "overlayShowStatus", true,
            "overlayShowRun", true,
            "overlayShowCurrentRun", true,
            "overlayShowLastRun", true,
            "overlayShowTargets", true,
            "overlayShowSession", true,
            "overlayShowMnemonic", true,
            "overlayShowProfile", true,
            "overlayShowNotifications", true,
            "soundsEnabled", true,
            "actionDelay", 100,
            "autoRunOnTravelConfirmation", false,
            "stopWhenMnemonicRecollectionsEnd", false,
            "landsraadResetDay", "Tuesday",
            "landsraadResetHour", 7
        )
    }

    /**
     * Default settings: defaults/settings.json overrides built-in values.
     */
    GetDefaultSettings() {
        merged := Map()
        for key, val in this.GetBuiltinDefaultSettings()
            merged[key] := val
        for key, val in this.LoadDefaultsFile(this.defaultsPath)
            merged[key] := val
        return merged
    }

    LoadDefaultsFile(path) {
        out := Map()
        if !FileExist(path)
            return out
        try {
            rawJson := FileRead(path, "UTF-8")
            if (Trim(rawJson) == "")
                return out
            parsed := JSON.Parse(rawJson)
            if !(parsed is Map)
                return out
            for key, val in parsed
                out[key] := val
        } catch {
        }
        return out
    }

    /**
     * Loads settings from settings.json. Missing files get defaults from
     * defaults/settings.json (then built-in fallbacks). Existing files keep
     * their values; keys added in newer app versions are filled from defaults.
     */
    LoadSettings() {
        defaults := this.GetDefaultSettings()
        if this.TryLoadExisting(defaults)
            return
        this.settings := defaults
        this.SaveSettings()
    }

    TryLoadExisting(defaults) {
        if !FileExist(this.settingsPath)
            return false
        try {
            rawJson := FileRead(this.settingsPath, "UTF-8")
            if (Trim(rawJson) == "")
                return false
            parsed := JSON.Parse(rawJson)
            if !(parsed is Map)
                return false
            this.settings := parsed
            missingKey := false
            for key, val in defaults {
                if (!this.settings.Has(key)) {
                    this.settings[key] := val
                    missingKey := true
                }
            }
            this.ResolveHotkeyCollisions(&missingKey)
            if this.settings.Has("landsraadResetAt") {
                this.settings.Delete("landsraadResetAt")
                missingKey := true
            }
            if this.NormalizeStoredLandsraadReset(&missingKey)
                missingKey := true
            if (missingKey)
                this.SaveSettings()
            return true
        } catch {
            return false
        }
    }

    /**
     * Saves current settings to settings.json.
     */
    SaveSettings() {
        jsonString := JSON.Stringify(this.settings, 2)
        fileObj := FileOpen(this.settingsPath, "w", "UTF-8")
        fileObj.Write(jsonString)
        fileObj.Close()
    }

    /**
     * Gets a setting value by key, returning defaultVal if key is absent.
     */
    Get(key, defaultVal := "") {
        if (this.settings.Has(key))
            return this.settings[key]
        return defaultVal
    }

    GetBool(key, defaultVal := false) {
        raw := this.Get(key, defaultVal)
        return (raw == true || raw == 1 || raw == "1" || raw == "true")
    }

    GetInt(key, defaultVal := 0) {
        raw := this.Get(key, defaultVal)
        try {
            return Integer(raw)
        } catch {
            return Integer(defaultVal)
        }
    }

    GetDefaultLandsraadResetDay() {
        return "Tuesday"
    }

    GetDefaultLandsraadResetHour() {
        return 7
    }

    NormalizeLandsraadResetDay(dayVal) {
        day := Trim(dayVal)
        for _, name in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] {
            if (name == day)
                return name
        }
        return this.GetDefaultLandsraadResetDay()
    }

    NormalizeLandsraadResetHour(hourVal) {
        try {
            hour := Integer(hourVal)
        } catch {
            return this.GetDefaultLandsraadResetHour()
        }
        if (hour < 0 || hour > 23)
            return this.GetDefaultLandsraadResetHour()
        return hour
    }

    GetLandsraadResetDay() {
        return this.NormalizeLandsraadResetDay(this.Get("landsraadResetDay", this.GetDefaultLandsraadResetDay()))
    }

    GetLandsraadResetHour() {
        return this.NormalizeLandsraadResetHour(this.Get("landsraadResetHour", this.GetDefaultLandsraadResetHour()))
    }

    GetLandsraadResetWDay(dayName) {
        static wDays := Map("Sunday", 1, "Monday", 2, "Tuesday", 3, "Wednesday", 4, "Thursday", 5, "Friday", 6, "Saturday", 7)
        return wDays.Has(dayName) ? wDays[dayName] : wDays["Tuesday"]
    }

    GetCurrentLandsraadWeekStartStamp() {
        targetWDay := this.GetLandsraadResetWDay(this.GetLandsraadResetDay())
        resetHour := this.GetLandsraadResetHour()
        now := A_Now
        currentWDay := Integer(FormatTime(now, "WDay"))
        daysBack := (currentWDay >= targetWDay)
            ? (currentWDay - targetWDay)
            : (currentWDay - targetWDay + 7)
        resetYmd := FormatTime(DateAdd(FormatTime(now, "yyyyMMdd"), -daysBack, "Days"), "yyyyMMdd")
        resetStamp := resetYmd . Format("{:02d}0000", resetHour)
        if (now < resetStamp)
            resetStamp := FormatTime(DateAdd(resetStamp, -7, "Days"), "yyyyMMddHHmmss")
        return resetStamp
    }

    GetCurrentLandsraadWeekStartDate() {
        return FormatTime(this.GetCurrentLandsraadWeekStartStamp(), "yyyy-MM-dd")
    }

    GetNextLandsraadResetStamp() {
        return FormatTime(DateAdd(this.GetCurrentLandsraadWeekStartStamp(), 7, "Days"), "yyyyMMddHHmmss")
    }

    GetLandsraadWeekRemainingSeconds() {
        remainSec := DateDiff(this.GetNextLandsraadResetStamp(), A_Now, "Seconds")
        return (remainSec > 0) ? remainSec : 0
    }

    FormatLandsraadWeekRemaining(remainSec) {
        if (remainSec <= 0)
            return "resetting now"
        days := remainSec // 86400
        hours := Mod(remainSec, 86400) // 3600
        if (days > 0)
            return days "d " hours "h left"
        if (hours > 0)
            return hours "h left"
        mins := Mod(remainSec, 3600) // 60
        return mins "m left"
    }

    GetLandsraadWeekLabelText() {
        startStamp := this.GetCurrentLandsraadWeekStartStamp()
        endStamp := this.GetNextLandsraadResetStamp()
        startLabel := FormatTime(startStamp, "MMM d")
        endLabel := FormatTime(endStamp, "MMM d")
        remaining := this.FormatLandsraadWeekRemaining(this.GetLandsraadWeekRemainingSeconds())
        return startLabel " – " endLabel " · " remaining
    }

    NormalizeStoredLandsraadReset(&changed := false) {
        normDay := this.NormalizeLandsraadResetDay(this.settings.Has("landsraadResetDay") ? this.settings["landsraadResetDay"] : "")
        normHour := this.NormalizeLandsraadResetHour(this.settings.Has("landsraadResetHour") ? this.settings["landsraadResetHour"] : -1)
        if (this.settings.Has("landsraadResetDay") && this.settings["landsraadResetDay"] == normDay
            && this.settings.Has("landsraadResetHour") && this.settings["landsraadResetHour"] == normHour)
            return false
        this.settings["landsraadResetDay"] := normDay
        this.settings["landsraadResetHour"] := normHour
        changed := true
        return true
    }

    /**
     * Hotkeys and currentProfileId stay in settings.json only.
     */
    GetProfileSettingKeys() {
        return [
            "ocrLanguage",
            "debugMode",
            "guildName",
            "faction",
            "showOverlay",
            "overlayPosition",
            "overlayShowStatus",
            "overlayShowRun",
            "overlayShowCurrentRun",
            "overlayShowLastRun",
            "overlayShowTargets",
            "overlayShowSession",
            "overlayShowMnemonic",
            "overlayShowProfile",
            "overlayShowNotifications",
            "soundsEnabled",
            "actionDelay",
            "autoRunOnTravelConfirmation",
            "stopWhenMnemonicRecollectionsEnd",
            "landsraadResetDay",
            "landsraadResetHour"
        ]
    }

    IsProfileSettingKey(key) {
        for _, profileKey in this.GetProfileSettingKeys() {
            if (profileKey == key)
                return true
        }
        return false
    }

    GetDefaultProfileSettings() {
        defaults := this.GetDefaultSettings()
        out := Map()
        for _, key in this.GetProfileSettingKeys()
            out[key] := defaults.Has(key) ? defaults[key] : ""
        return out
    }

    /**
     * Default profile settings with a new random guild name (new/reset profile).
     */
    GetFreshProfileSettings() {
        out := this.GetDefaultProfileSettings()
        out["guildName"] := this.GenerateRandomGuildName()
        return out
    }

    GenerateRandomGuildName(length := 5) {
        letters := "abcdefghijklmnopqrstuvwxyz"
        out := ""
        loop length
            out .= SubStr(letters, Random(1, StrLen(letters)), 1)
        return out
    }

    MergeProfileSettings(profileSettings := "") {
        defaults := this.GetDefaultProfileSettings()
        merged := Map()
        for _, key in this.GetProfileSettingKeys() {
            val := defaults.Has(key) ? defaults[key] : ""
            if IsObject(profileSettings) && (profileSettings is Map) && profileSettings.Has(key)
                val := profileSettings[key]
            merged[key] := val
        }
        merged["landsraadResetDay"] := this.NormalizeLandsraadResetDay(merged["landsraadResetDay"])
        merged["landsraadResetHour"] := this.NormalizeLandsraadResetHour(merged["landsraadResetHour"])
        return merged
    }

    ExportProfileSettings() {
        return this.MergeProfileSettings(this.settings)
    }

    /**
     * Applies a profile's settings to the active settings mirror (settings.json).
     */
    ImportProfileSettings(profileSettings := "", save := true) {
        merged := this.MergeProfileSettings(profileSettings)
        for key, val in merged
            this.settings[key] := val
        if (save)
            this.SaveSettings()
        return merged
    }

    /**
     * Sets a setting value and immediately auto-saves to settings.json.
     */
    Set(key, value) {
        this.settings[key] := value
        this.SaveSettings()
        if this.IsProfileSettingKey(key) {
            global profileManagerInst
            if IsSet(profileManagerInst) && IsObject(profileManagerInst) && profileManagerInst.HasMethod("CaptureCurrentSettings")
                profileManagerInst.CaptureCurrentSettings(this)
        }
    }

    ApplySharedDefaults() {
        this.ResetBasicSettings()
    }

    /**
     * Restores guild, faction, overlay, delay, OCR, and debug to app defaults.
     * Leaves profile id, character name, hotkeys, and stats alone.
     */
    ResetBasicSettings() {
        this.ImportProfileSettings(Map())
    }

    ResetHotkeys() {
        this.Set("hotkeyStart", "Home")
        this.Set("hotkeyStop", "End")
        this.Set("hotkeyToggleAutoRun", "Delete")
        this.Set("hotkeyExit", "Pause")
        this.Set("hotkeyToggleGui", "F8")
        this.Set("hotkeyToggleOverlay", "Insert")
        this.Set("hotkeyReload", "PgDn")
    }

    GetHotkeyFallbacks() {
        return Map(
            "hotkeyStart", "Home",
            "hotkeyStop", "End",
            "hotkeyToggleAutoRun", "Delete",
            "hotkeyToggleGui", "F8",
            "hotkeyToggleOverlay", "Insert",
            "hotkeyReload", "PgDn",
            "hotkeyExit", "Pause"
        )
    }

    GetHotkeySettingKeys() {
        return ["hotkeyStart", "hotkeyStop", "hotkeyToggleAutoRun", "hotkeyToggleGui", "hotkeyToggleOverlay", "hotkeyReload", "hotkeyExit"]
    }

    /**
     * Older saves used Delete for the dashboard. AutoRun now defaults to Delete,
     * so move the dashboard bind if both would share that key.
     */
    ResolveHotkeyCollisions(&changed := false) {
        autoKey := Trim(this.Get("hotkeyToggleAutoRun", "Delete"))
        guiKey := Trim(this.Get("hotkeyToggleGui", "F8"))
        if (autoKey != "" && StrLower(autoKey) == StrLower(guiKey)) {
            this.settings["hotkeyToggleGui"] := "F8"
            changed := true
        }
    }
}
