#Requires AutoHotkey v2.0+

/**
 * Missions tab grid view — in-game-style 5×5 Landsraad house grid from weekly scan data.
 */
class MissionPickerGridTab extends GuiPage {
    controls := []
    gridCells := []
    activeRow := 0
    activeCol := 0
    gridSize := 5
    specIconSize := 22
    houseIconSize := 52
    nameBarH := 18
    progBarH := 4
    missionSlotW := 5
    missionSlotH := 10
    missionSlotGap := 3
    missionSlotActive := "EAB308"
    missionSlotEmpty := "27272F"
    trackBadgeSize := 10
    trackBadgePath := ""
    huntedRewardIconSize := 24
    huntedRewardIconMargin := 5
    huntedRewardIconPath := ""
    cellPad := 5
    cellGapX := 10
    cellGapY := 10
    cellBorderW := 2
    skinCache := Map()
    maxTargetMissions := 3
    specIcons := Map(
        "Crafting", "spec_crafting.png",
        "Exploration", "spec_exploration.png",
        "Gathering", "spec_gathering.png",
        "Combat", "spec_combat.png",
        "Sabotage", "spec_sabotage.png"
    )
    cellFrameColor := "3D3420"
    cellBgColor := "141418"
    cellTargetedBg := "14532D"
    cellUnrevealedBg := "0F0F12"
    cellUnrevealedBorder := "27272F"
    cellOverlayAlpha := "95"
    overlayCache := Map()
    trackBadgeColor := "4ADE80"
    trackedBarTrack := "27272F"
    trackedProgFill := "4ADE80"
    trackedDoneBar := "3B82F6"
    contributionMax := 14000
    cellSelectedFrame := "EAB308"
    initActionBtn := ""
    tabShown := false
    paintGen := 0
    toolbarCount := 0
    houseIconPathCache := Map()
    houseSpecCache := Map()
    cellWidths := []
    cellHeight := 0

    __New(hostGui) {
        super.__New(hostGui, 1)
    }

    AddCtl(ctl) {
        this.controls.Push(ctl)
        return this.PageAdd(this.pageId, ctl)
    }

    AddTabButton(x, y, w, h, label, callback, primary := false) {
        btn := this.AddTextButton(this.pageId, x, y, w, h, label, callback, primary)
        this.controls.Push(btn)
        return btn
    }

    IsDisplayActive() {
        return this.tabShown && IsObject(this.host) && this.host.activeTab == 1
    }

    SetVisible(show) {
        if !show {
            this.paintGen += 1
            this.tabShown := false
            this.HideAllGridControls()
            this.ClearAllCellVisualCaches()
            return
        }
        this.tabShown := true
        this.ShowToolbar(true)
    }

    ClearCellVisualCaches(cell) {
        for key in ["skinKey", "overlayKey", "specPicKey", "housePicKey", "trackBadgeKey",
            "huntedPicKey", "nameLabelText", "progFillW", "progFillColor"] {
            if cell.Has(key)
                cell.Delete(key)
        }
    }

    ClearAllCellVisualCaches() {
        for _, cell in this.gridCells
            this.ClearCellVisualCaches(cell)
    }

    InvalidateGuiClient() {
        if !IsObject(this.guiObj)
            return
        try DllCall("InvalidateRect", "ptr", this.guiObj.Hwnd, "ptr", 0, "int", 1)
    }

    ShowToolbar(show) {
        if (this.toolbarCount < 1)
            return
        loop this.toolbarCount {
            idx := A_Index
            if idx <= this.controls.Length {
                try this.controls[idx].Visible := show
            }
        }
    }

    HideAllGridControls() {
        for ctl in this.controls {
            try ctl.Visible := false
        }
        for _, cell in this.gridCells {
            this.HideGridCell(cell)
        }
    }

    HideGridCell(cell) {
        if IsObject(cell["cellSkin"])
            cell["cellSkin"].Visible := false
        if IsObject(cell["missionSlots"]) {
            for slotCtrl in cell["missionSlots"] {
                if IsObject(slotCtrl)
                    slotCtrl.Visible := false
            }
        }
        if IsObject(cell["specPic"])
            cell["specPic"].Visible := false
        if IsObject(cell["trackBadge"])
            cell["trackBadge"].Visible := false
        if IsObject(cell["huntedPic"])
            cell["huntedPic"].Visible := false
        if IsObject(cell["housePic"])
            cell["housePic"].Visible := false
        if IsObject(cell["nameLbl"]) {
            cell["nameLbl"].Text := ""
            cell["nameLbl"].Visible := false
        }
        if IsObject(cell["progBg"])
            cell["progBg"].Visible := false
        if IsObject(cell["progFill"])
            cell["progFill"].Visible := false
        if IsObject(cell["cellOverlay"])
            cell["cellOverlay"].Visible := false
    }

    RefreshStillValid(gen) {
        return this.IsDisplayActive() && this.paintGen == gen
    }

    LockGuiRedraw(lock) {
        ; WM_SETREDRAW caused partial client corruption after tab switches — invalidate only.
        if !lock
            this.InvalidateGuiClient()
    }

    EnsureHouseCaches() {
        if this.houseIconPathCache.Count > 0
            return
        for _, entry in this.GetHouseDbEntries() {
            if !(entry is Map) || !entry.Has("house")
                continue
            houseName := entry["house"]
            spec := entry.Has("specialization") ? entry["specialization"] : ""
            this.houseSpecCache[houseName] := spec
            slug := entry.Has("iconSlug") ? entry["iconSlug"] : ""
            iconPath := ""
            if (slug != "") {
                scaled := A_ScriptDir "\db\house_icons_scaled\1440p\" slug "_72x72.png"
                if FileExist(scaled)
                    iconPath := scaled
                else {
                    raw := A_ScriptDir "\db\house_icons\" slug ".png"
                    if FileExist(raw)
                        iconPath := raw
                }
            }
            this.houseIconPathCache[houseName] := iconPath
        }
    }

    PreWarmSkinCache() {
        if this.cellWidths.Length == 0
            return
        combos := [
            [this.cellUnrevealedBg, this.cellUnrevealedBorder],
            [this.cellBgColor, this.cellFrameColor],
            [this.cellTargetedBg, this.cellFrameColor],
            [this.cellBgColor, this.cellSelectedFrame],
            [this.cellTargetedBg, this.cellSelectedFrame],
        ]
        h := this.cellHeight
        if (h < 4)
            return
        for _, w in this.cellWidths {
            if (w < 4)
                continue
            for _, pair in combos {
                this.GetCachedCellSkin(w, h, pair[1], pair[2])
            }
            this.GetCachedCellOverlay(w, h)
        }
    }

    Build() {
        g := this.guiObj
        m := this.margin
        contentY := 124
        gapX := this.cellGapX
        gapY := this.cellGapY
        toolH := 28
        footerTop := this.winH - 36
        gridTop := contentY + toolH + 8
        gridBottom := footerTop - 10
        gridH := gridBottom - gridTop
        this.gridX := m
        this.gridW := this.contentW

        cellW := (this.gridW - 4 * gapX) // this.gridSize
        extraW := this.gridW - (cellW * this.gridSize + gapX * (this.gridSize - 1))
        cellH := (gridH - 4 * gapY) // this.gridSize
        if (cellH < 72)
            cellH := 72

        clearW := 118
        initW := 196
        gapBtn := 10
        helpW := 28
        initX := this.gridX + this.gridW - initW
        clearX := initX - gapBtn - clearW
        helpX := clearX - gapBtn - helpW
        counterW := helpX - this.gridX - 12

        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.targetCounterLabel := this.AddCtl(g.Add("Text",
            "x" this.gridX " y" contentY " w" counterW " h" toolH " +0x200 BackgroundTrans",
            "Selected missions 0 / 3"))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        clearBtn := this.AddCtl(g.Add("Text",
            "x" clearX " y" contentY " w" clearW " h" toolH " Center +0x200 Background" this.mutedColor,
            "Clear all"))
        clearBtn.OnEvent("Click", (*) => this.OnClearAllTargets())

        this.AddTabButton(helpX, contentY, helpW, toolH, "?",
            (*) => TabHelpDialog.Show(this.guiObj, "missions"))

        this.initActionBtn := this.AddTabButton(initX, contentY, initW, toolH,
            "▶   Start", (*) => this.OnInitActionClick(), true)
        this.RefreshInitButton()
        this.toolbarCount := this.controls.Length

        this.gridCells := []
        loop this.gridSize {
            row := A_Index
            loop this.gridSize {
                col := A_Index
                slot := (row - 1) * this.gridSize + col
                x := this.gridX
                loop col - 1
                    x += cellW + ((A_Index <= extraW) ? 1 : 0) + gapX
                w := cellW + ((col <= extraW) ? 1 : 0)
                y := gridTop + (row - 1) * (cellH + gapY)
                innerX := x + this.cellPad
                innerY := y + this.cellPad
                innerW := w - (this.cellPad * 2)
                innerH := cellH - (this.cellPad * 2)

                cellSkin := this.AddCtl(g.Add("Picture",
                    "x" x " y" y " w" w " h" cellH " BackgroundTrans", ""))

                slotX := innerX + 2
                missionSlots := []
                loop 3 {
                    slotCtrl := this.AddCtl(g.Add("Text",
                        "x" slotX " y0 w" this.missionSlotW " h" this.missionSlotH
                        " Background" this.missionSlotEmpty " Hidden"))
                    missionSlots.Push(slotCtrl)
                }

                specX := innerX + this.missionSlotW + 6
                specY := innerY + 4
                specPic := this.AddCtl(g.Add("Picture",
                    "x" specX " y" specY " w" this.specIconSize " h" this.specIconSize
                    " BackgroundTrans Hidden", ""))

                trackX := innerX + innerW - this.trackBadgeSize - 3
                trackY := innerY + 3
                trackBadge := this.AddCtl(g.Add("Picture",
                    "x" trackX " y" trackY " w" this.trackBadgeSize " h" this.trackBadgeSize
                    " BackgroundTrans Hidden", ""))

                huntedX := x + w - this.huntedRewardIconSize - this.huntedRewardIconMargin
                huntedY := y + this.huntedRewardIconMargin
                huntedPic := this.AddCtl(g.Add("Picture",
                    "x" huntedX " y" huntedY " w" this.huntedRewardIconSize " h" this.huntedRewardIconSize
                    " BackgroundTrans Hidden", ""))

                houseX := innerX + ((innerW - this.houseIconSize) // 2)
                houseY := innerY + this.specIconSize + 6
                housePic := this.AddCtl(g.Add("Picture",
                    "x" houseX " y" houseY " w" this.houseIconSize " h" this.houseIconSize
                    " BackgroundTrans Hidden", ""))

                nameY := innerY + innerH - this.nameBarH - this.progBarH - 4
                g.SetFont("s8 bold cEAB308", "Segoe UI")
                nameLbl := this.AddCtl(g.Add("Text",
                    "x" innerX " y" nameY " w" innerW " h" this.nameBarH
                    " Center +0x200 BackgroundTrans Hidden", ""))

                progY := innerY + innerH - this.progBarH - 2
                progBg := this.AddCtl(g.Add("Text",
                    "x" innerX " y" progY " w" innerW " h" this.progBarH
                    " Background" this.trackedBarTrack " Hidden"))
                progFill := this.AddCtl(g.Add("Text",
                    "x" innerX " y" progY " w0 h" this.progBarH
                    " Background" this.trackedProgFill " Hidden"))

                cellOverlay := this.AddCtl(g.Add("Picture",
                    "x" x " y" y " w" w " h" cellH " BackgroundTrans Hidden", ""))

                clickHandler := this.MakeCellClickHandler(row, col)
                this.BindCellClick(cellSkin, clickHandler)
                for _, slotCtrl in missionSlots
                    this.BindCellClick(slotCtrl, clickHandler)
                this.BindCellClick(specPic, clickHandler)
                this.BindCellClick(trackBadge, clickHandler)
                this.BindCellClick(huntedPic, clickHandler)
                this.BindCellClick(housePic, clickHandler)
                this.BindCellClick(nameLbl, clickHandler)
                this.BindCellClick(progBg, clickHandler)
                this.BindCellClick(progFill, clickHandler)
                this.BindCellClick(cellOverlay, clickHandler)

                this.gridCells.Push(Map(
                    "row", row,
                    "col", col,
                    "slot", slot,
                    "frameX", x,
                    "frameY", y,
                    "frameW", w,
                    "frameH", cellH,
                    "innerW", innerW,
                    "innerH", innerH,
                    "innerX", innerX,
                    "innerY", innerY,
                    "nameY", nameY,
                    "cellSkin", cellSkin,
                    "missionSlots", missionSlots,
                    "specPic", specPic,
                    "trackBadge", trackBadge,
                    "huntedPic", huntedPic,
                    "housePic", housePic,
                    "cellOverlay", cellOverlay,
                    "nameLbl", nameLbl,
                    "progBg", progBg,
                    "progFill", progFill,
                    "houseName", "",
                    "revealed", false,
                    "missionsRevealed", false,
                    "tracked", false,
                    "hasHuntedReward", false,
                    "hasMissions", false,
                    "missionCount", 0,
                    "cont", 0,
                    "goal", 0,
                    "goalReached", false
                ))
            }
        }

        widthSeen := Map()
        this.cellWidths := []
        this.cellHeight := 0
        for _, cell in this.gridCells {
            w := cell.Has("frameW") ? cell["frameW"] : 0
            h := cell.Has("frameH") ? cell["frameH"] : 0
            if (h > 0)
                this.cellHeight := h
            if (w > 0 && !widthSeen.Has(w)) {
                widthSeen[w] := true
                this.cellWidths.Push(w)
            }
        }
        this.EnsureHouseCaches()
        this.PreWarmSkinCache()

        ; Grid paints on first tab switch via RefreshMissionPickerTabs.
    }

    TotalMissionCount() {
        total := 0
        for _, missions in this.slotMissions {
            if !(missions is Array)
                continue
            for _, label in missions {
                if (label != "")
                    total++
            }
        }
        return total
    }

    UpdateTargetCounter() {
        if !IsObject(this.targetCounterLabel)
            return
        this.targetCounterLabel.Text := "Selected missions " this.TotalMissionCount() " / " this.maxTargetMissions
    }

    SlotMissionCount(slotIdx) {
        cnt := 0
        if this.slotMissions.Has(slotIdx) {
            for _, label in this.slotMissions[slotIdx] {
                if (label != "")
                    cnt++
            }
        }
        return cnt
    }

    OnClearAllTargets() {
        if IsObject(this.pickerTab)
            this.pickerTab.OnClearAllTargets()
        else {
            this.slotMissions := Map()
            this.SaveMissionSelections()
            this.RefreshStatusOverlay()
            this.RefreshStatusProgress()
        }
        if HouseMissionDialog.IsOpen()
            HouseMissionDialog.Populate()
        this.Refresh()
    }

    GetProgressWidth(contribution, barW, maxValue := "") {
        try {
            n := Integer(contribution)
        } catch {
            n := 0
        }
        if (n < 0)
            n := 0
        try {
            cap := (maxValue != "") ? Integer(maxValue) : this.contributionMax
        } catch {
            cap := this.contributionMax
        }
        if (cap < 1)
            cap := this.contributionMax
        if (n >= cap)
            return barW
        if (barW <= 0)
            return 0
        return Round(barW * n / cap)
    }

    MakeCellClickHandler(row, col) {
        return (*) => this.OnCellClick(row, col)
    }

    BindCellClick(ctrl, handler) {
        if IsObject(ctrl)
            ctrl.OnEvent("Click", handler)
    }

    OnCellClick(row, col) {
        cell := this.GetCell(row, col)
        if !IsObject(cell) || !cell["revealed"] || !cell["missionsRevealed"]
            return
        this.activeRow := row
        this.activeCol := col
        this.RefreshCellStyles()
        houseName := cell.Has("houseName") ? Trim(cell["houseName"]) : ""
        slotIdx := cell.Has("slot") ? cell["slot"] : ((row - 1) * this.gridSize + col)
        if (houseName != "")
            HouseMissionDialog.ShowOrUpdate(
                this.guiObj,
                this.HostRef(),
                slotIdx,
                houseName,
                row,
                col,
                this.GetHouseSpecialization(houseName),
                this.MakeMissionDialogHandler())
    }

    MakeMissionDialogHandler() {
        return (*) => this.OnMissionDialogChanged()
    }

    OnMissionDialogChanged() {
        this.UpdateTargetCounter()
        for _, cell in this.gridCells {
            if !cell["revealed"]
                continue
            slot := cell["slot"]
            cell["hasMissions"] := this.SlotMissionCount(slot) > 0
            cell["missionCount"] := this.SlotMissionCount(slot)
            houseName := Trim(cell["houseName"])
            if (houseName == "")
                continue
            cell["tracked"] := this.IsHouseTracked(houseName)
            if IsObject(this.profileManager) {
                cell["cont"] := this.profileManager.GetHouseContribution(houseName)
                cell["goal"] := this.profileManager.GetHouseGoal(houseName)
                goal := cell["goal"]
                cont := cell["cont"]
                cell["goalReached"] := goal > 0 && cont >= goal
            }
        }
        this.RefreshCellStyles()
    }

    GetCell(row, col) {
        for _, cell in this.gridCells {
            if (cell["row"] == row && cell["col"] == col)
                return cell
        }
        return ""
    }

    HexToArgb(hex, alpha := "FF") {
        hex := StrUpper(StrReplace(Trim(hex), "0X", ""))
        if (hex == "")
            return 0
        return Integer("0x" alpha hex)
    }

    GetTrackBadgePath() {
        if (this.trackBadgePath != "")
            return this.trackBadgePath

        size := this.trackBadgeSize
        pBitmap := Gdip_CreateBlankBitmap(size, size)
        if !pBitmap
            return ""

        g := Gdip_GraphicsFromImage(pBitmap)
        if !g {
            Gdip_DisposeImage(pBitmap)
            return ""
        }

        Gdip_SetSmoothingMode(g, 4)
        brush := Gdip_CreateSolidBrush(this.HexToArgb(this.trackBadgeColor))
        Gdip_FillEllipse(g, brush, 0, 0, size, size)
        Gdip_DeleteBrush(brush)
        Gdip_DeleteGraphics(g)

        path := A_Temp "\donsraad_track_badge.png"
        if (Gdip_SaveBitmapToFile(pBitmap, path) != 0) {
            Gdip_DisposeImage(pBitmap)
            return ""
        }
        Gdip_DisposeImage(pBitmap)
        this.trackBadgePath := path
        return path
    }

    GetHuntedRewardIconPath() {
        if (this.huntedRewardIconPath != "")
            return this.huntedRewardIconPath
        path := A_ScriptDir "\db\reward_icons\diamond.png"
        if FileExist(path) {
            this.huntedRewardIconPath := path
            return path
        }
        return ""
    }

    GetCachedCellSkin(w, h, fillHex, borderHex) {
        key := w "_" h "_" fillHex "_" borderHex
        if this.skinCache.Has(key)
            return this.skinCache[key]

        path := A_Temp "\donsraad_cell_" key ".png"
        if !this.RenderCellSkin(w, h, fillHex, borderHex, path)
            return ""

        this.skinCache[key] := path
        return path
    }

    RenderCellSkin(w, h, fillHex, borderHex, outPath) {
        if (w < 4 || h < 4)
            return false

        pBitmap := Gdip_CreateBlankBitmap(w, h)
        if !pBitmap
            return false

        g := Gdip_GraphicsFromImage(pBitmap)
        if !g {
            Gdip_DisposeImage(pBitmap)
            return false
        }

        pad := this.cellBorderW / 2.0

        fillBrush := Gdip_CreateSolidBrush(this.HexToArgb(fillHex))
        Gdip_FillRectangle(g, fillBrush, 0, 0, w, h)
        Gdip_DeleteBrush(fillBrush)

        borderPen := Gdip_CreatePen(this.HexToArgb(borderHex), this.cellBorderW)
        Gdip_DrawRectangle(g, borderPen, pad, pad, w - this.cellBorderW, h - this.cellBorderW)
        Gdip_DeletePen(borderPen)
        Gdip_DeleteGraphics(g)

        saved := (Gdip_SaveBitmapToFile(pBitmap, outPath) = 0)
        Gdip_DisposeImage(pBitmap)
        return saved
    }

    UpdateCellSkin(cell) {
        if !IsObject(cell["cellSkin"])
            return

        if !this.IsDisplayActive() {
            cell["cellSkin"].Visible := false
            return
        }

        w := cell.Has("frameW") ? cell["frameW"] : 0
        h := cell.Has("frameH") ? cell["frameH"] : 0
        if (w < 4 || h < 4)
            return

        revealed := cell["revealed"]
        missionsRevealed := cell.Has("missionsRevealed") && cell["missionsRevealed"]
        row := cell["row"]
        col := cell["col"]
        selected := revealed && missionsRevealed && (row == this.activeRow && col == this.activeCol)

        if !revealed {
            fillHex := this.cellUnrevealedBg
            borderHex := this.cellUnrevealedBorder
        } else if !missionsRevealed {
            fillHex := this.cellBgColor
            borderHex := this.cellFrameColor
        } else {
            hasMissions := cell.Has("hasMissions") && cell["hasMissions"]
            if hasMissions
                fillHex := this.cellTargetedBg
            else
                fillHex := this.cellBgColor
            borderHex := selected ? this.cellSelectedFrame : this.cellFrameColor
        }

        skinKey := w "_" h "_" fillHex "_" borderHex
        prevSkinKey := cell.Has("skinKey") ? cell["skinKey"] : ""
        wantVisible := this.IsDisplayActive()
        if (skinKey == prevSkinKey && IsObject(cell["cellSkin"])) {
            try {
                if (cell["cellSkin"].Visible != wantVisible)
                    cell["cellSkin"].Visible := wantVisible
            }
            return
        }
        cell["skinKey"] := skinKey

        skinPath := this.GetCachedCellSkin(w, h, fillHex, borderHex)
        if (skinPath != "" && wantVisible) {
            try cell["cellSkin"].Value := skinPath
            try cell["cellSkin"].Opt("+BackgroundTrans")
            cell["cellSkin"].Visible := true
        } else if IsObject(cell["cellSkin"]) {
            cell["cellSkin"].Visible := false
        }
    }

    EntryMissionsRevealed(entry) {
        if !(entry is Map)
            return false
        if entry.Has("missionsRevealed") {
            val := entry["missionsRevealed"]
            if (val = true)
                return true
            try {
                return (Integer(val) = 1)
            } catch {
                return false
            }
        }
        return true
    }

    GetScannedCellMap() {
        out := Map()
        if !IsObject(this.profileManager)
            return out
        contrib := this.profileManager.GetLandsraadContribution()
        houses := contrib.Has("houses") ? contrib["houses"] : []
        if !(houses is Array)
            return out
        for _, entry in houses {
            if !(entry is Map)
                continue
            try {
                row := Integer(entry.Has("row") ? entry["row"] : 0)
                col := Integer(entry.Has("col") ? entry["col"] : 0)
            } catch {
                continue
            }
            if (row < 1 || col < 1 || row > this.gridSize || col > this.gridSize)
                continue
            houseName := entry.Has("house") ? Trim(entry["house"]) : ""
            if (houseName == "")
                continue
            out[row "_" col] := entry
        }
        return out
    }

    IsHouseTracked(houseName) {
        if (houseName == "" || !IsObject(this.profileManager))
            return false
        try {
            return this.profileManager.GetHouseGoal(houseName) > 0
        } catch {
            return false
        }
    }

    GetSpecIconPath(spec) {
        if (spec == "" || !this.specIcons.Has(spec))
            return ""
        path := A_ScriptDir "\db\spec_icons\" this.specIcons[spec]
        if FileExist(path)
            return path
        return ""
    }

    GetHouseIconPath(houseName) {
        if (houseName == "")
            return ""
        this.EnsureHouseCaches()
        if this.houseIconPathCache.Has(houseName)
            return this.houseIconPathCache[houseName]
        return ""
    }

    GetHouseDbEntries() {
        if IsObject(this.stateManager) && (this.stateManager.allHousesList is Array)
            return this.stateManager.allHousesList
        dbPath := A_ScriptDir "\db\landsraad_houses.json"
        if FileExist(dbPath) {
            try {
                parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
                if (parsed is Array)
                    return parsed
            }
        }
        return []
    }

    GetHouseSpecialization(houseName) {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetHouseSpecialization")
            return this.stateManager.GetHouseSpecialization(houseName)
        this.EnsureHouseCaches()
        if this.houseSpecCache.Has(houseName)
            return this.houseSpecCache[houseName]
        return ""
    }

    FormatHouseLabel(houseName) {
        houseName := Trim(houseName)
        if (houseName == "")
            return ""
        parts := StrSplit(houseName, " ")
        if (parts.Length > 1)
            return StrUpper(parts[parts.Length])
        return StrUpper(houseName)
    }

    GetCachedCellOverlay(w, h, alphaHex := "") {
        if (alphaHex == "")
            alphaHex := this.cellOverlayAlpha
        key := "overlay_" w "_" h "_" alphaHex
        if this.overlayCache.Has(key)
            return this.overlayCache[key]

        path := A_Temp "\donsraad_cell_" key ".png"
        if !this.RenderCellOverlay(w, h, alphaHex, path)
            return ""

        this.overlayCache[key] := path
        return path
    }

    RenderCellOverlay(w, h, alphaHex, outPath) {
        if (w < 4 || h < 4)
            return false

        pBitmap := Gdip_CreateBlankBitmap(w, h)
        if !pBitmap
            return false

        g := Gdip_GraphicsFromImage(pBitmap)
        if !g {
            Gdip_DisposeImage(pBitmap)
            return false
        }

        fillBrush := Gdip_CreateSolidBrush(this.HexToArgb("000000", alphaHex))
        Gdip_FillRectangle(g, fillBrush, 0, 0, w, h)
        Gdip_DeleteBrush(fillBrush)
        Gdip_DeleteGraphics(g)

        saved := (Gdip_SaveBitmapToFile(pBitmap, outPath) = 0)
        Gdip_DisposeImage(pBitmap)
        return saved
    }

    UpdateCellOverlay(cell) {
        ctrl := cell.Has("cellOverlay") ? cell["cellOverlay"] : ""
        if !IsObject(ctrl)
            return

        if !this.IsDisplayActive() {
            ctrl.Visible := false
            return
        }

        revealed := cell["revealed"]
        missionsRevealed := cell.Has("missionsRevealed") && cell["missionsRevealed"]
        if !revealed || missionsRevealed {
            ctrl.Visible := false
            return
        }

        w := cell.Has("frameW") ? cell["frameW"] : 0
        h := cell.Has("frameH") ? cell["frameH"] : 0
        if (w < 4 || h < 4) {
            ctrl.Visible := false
            return
        }

        overlayKey := w "_" h "_" this.cellOverlayAlpha
        prevOverlayKey := cell.Has("overlayKey") ? cell["overlayKey"] : ""
        overlayPath := this.GetCachedCellOverlay(w, h)
        if (overlayPath == "") {
            ctrl.Visible := false
            return
        }
        if (overlayKey == prevOverlayKey && ctrl.Visible)
            return
        cell["overlayKey"] := overlayKey

        try ctrl.Value := overlayPath
        try ctrl.Opt("+BackgroundTrans")
        ctrl.Visible := true
    }

    SetPictureCached(cell, cacheField, ctrl, path, show := true, transBlack := false) {
        if !IsObject(ctrl)
            return
        wantVisible := path != "" && show && this.IsDisplayActive()
        display := ""
        if wantVisible
            display := transBlack ? ("*TransBlack " path) : path
        cached := cell.Has(cacheField) ? cell[cacheField] : ""
        ctrlVisible := false
        try ctrlVisible := ctrl.Visible
        if (cached == display && ctrlVisible == wantVisible)
            return
        cell[cacheField] := display
        if wantVisible {
            try ctrl.Value := display
            try ctrl.Opt("+BackgroundTrans")
            ctrl.Visible := true
        } else {
            try ctrl.Value := ""
            ctrl.Visible := false
        }
    }

    SetPicture(ctrl, path, show := true, transBlack := false) {
        if !IsObject(ctrl)
            return
        if (path != "" && show && this.IsDisplayActive()) {
            display := transBlack ? ("*TransBlack " path) : path
            try ctrl.Value := display
            try ctrl.Opt("+BackgroundTrans")
            ctrl.Visible := true
        } else {
            try ctrl.Value := ""
            ctrl.Visible := false
        }
    }

    UpdateMissionSlotIndicators(cell) {
        slots := cell.Has("missionSlots") ? cell["missionSlots"] : []
        if !(slots is Array) || slots.Length == 0
            return

        if !this.IsDisplayActive() {
            for slotCtrl in slots {
                if IsObject(slotCtrl)
                    slotCtrl.Visible := false
            }
            return
        }

        revealed := cell["revealed"]
        missionCount := cell.Has("missionCount") ? cell["missionCount"] : 0
        show := revealed && missionCount > 0
        nameY := cell.Has("nameY") ? cell["nameY"] : 0
        slotX := cell.Has("innerX") ? cell["innerX"] + 2 : 0

        loop slots.Length {
            idx := A_Index
            slotCtrl := slots[idx]
            if !IsObject(slotCtrl)
                continue
            if !show {
                slotCtrl.Visible := false
                continue
            }
            filled := missionCount >= idx
            color := filled ? this.missionSlotActive : this.missionSlotEmpty
            slotCtrl.Opt("Background" color)
            slotY := nameY - 4 - this.missionSlotH - (idx - 1) * (this.missionSlotH + this.missionSlotGap)
            slotCtrl.Move(slotX, slotY, this.missionSlotW, this.missionSlotH)
            slotCtrl.Visible := true
        }
    }

    RefreshCellStyles() {
        if !this.IsDisplayActive()
            return
        gen := this.paintGen
        for _, cell in this.gridCells {
            if !this.RefreshStillValid(gen)
                break
            row := cell["row"]
            col := cell["col"]
            revealed := cell["revealed"]
            missionsRevealed := cell.Has("missionsRevealed") && cell["missionsRevealed"]
            tracked := missionsRevealed && cell.Has("tracked") && cell["tracked"]
            cont := cell.Has("cont") ? cell["cont"] : 0
            goal := cell.Has("goal") ? cell["goal"] : 0
            goalReached := tracked && goal > 0 && cont >= goal
            houseName := cell.Has("houseName") ? Trim(cell["houseName"]) : ""

            specPath := ""
            if revealed
                specPath := this.GetSpecIconPath(this.GetHouseSpecialization(houseName))
            housePath := revealed ? this.GetHouseIconPath(houseName) : ""
            this.SetPictureCached(cell, "specPicKey", cell["specPic"], specPath, revealed, false)
            this.SetPictureCached(cell, "housePicKey", cell["housePic"], housePath, revealed, true)

            if IsObject(cell["nameLbl"]) {
                labelText := revealed ? this.FormatHouseLabel(houseName) : ""
                prevLabel := cell.Has("nameLabelText") ? cell["nameLabelText"] : ""
                if revealed && this.IsDisplayActive() {
                    if (labelText != prevLabel)
                        cell["nameLbl"].Text := labelText
                    cell["nameLbl"].Visible := true
                    cell["nameLabelText"] := labelText
                } else {
                    if (prevLabel != "")
                        cell["nameLbl"].Text := ""
                    cell["nameLbl"].Visible := false
                    cell["nameLabelText"] := ""
                }
            }

            this.UpdateCellSkin(cell)
            this.UpdateCellOverlay(cell)

            if IsObject(cell["trackBadge"]) {
                showBadge := tracked
                this.SetPictureCached(cell, "trackBadgeKey", cell["trackBadge"],
                    showBadge ? this.GetTrackBadgePath() : "", showBadge, false)
            }

            if IsObject(cell["huntedPic"]) {
                showHunted := revealed && missionsRevealed
                    && cell.Has("hasHuntedReward") && cell["hasHuntedReward"]
                this.SetPictureCached(cell, "huntedPicKey", cell["huntedPic"],
                    showHunted ? this.GetHuntedRewardIconPath() : "", showHunted, true)
            }

            barW := cell.Has("innerW") ? cell["innerW"] : 0
            showProg := missionsRevealed && cont > 0 && barW > 0
            if IsObject(cell["progBg"]) {
                cell["progBg"].Visible := showProg && this.IsDisplayActive()
                if showProg
                    cell["progBg"].Opt("Background" this.trackedBarTrack)
            }
            if IsObject(cell["progFill"]) {
                if showProg && this.IsDisplayActive() {
                    cap := goal > 0 ? goal : this.contributionMax
                    fillW := goalReached ? barW : this.GetProgressWidth(cont, barW, cap)
                    fillColor := goalReached ? this.trackedDoneBar : this.trackedProgFill
                    prevFillW := cell.Has("progFillW") ? cell["progFillW"] : -1
                    prevFillColor := cell.Has("progFillColor") ? cell["progFillColor"] : ""
                    if (fillW != prevFillW)
                        cell["progFill"].Move(, , fillW)
                    if (fillColor != prevFillColor)
                        cell["progFill"].Opt("Background" fillColor)
                    cell["progFillW"] := fillW
                    cell["progFillColor"] := fillColor
                    cell["progFill"].Visible := true
                } else {
                    cell["progFill"].Visible := false
                    cell["progFillW"] := 0
                    cell["progFillColor"] := ""
                }
            }

            this.UpdateMissionSlotIndicators(cell)
        }
    }

    Refresh() {
        if this.IsDisplayActive()
            this.RunRefresh()
    }

    RunRefresh() {
        if !this.IsDisplayActive()
            return
        gen := this.paintGen
        this.EnsureHouseCaches()
        this.LockGuiRedraw(true)
        try {
            this.ShowToolbar(true)

            scanned := Map()
            if IsObject(this.profileManager)
                scanned := this.GetScannedCellMap()

            activeStillValid := false
            for _, cell in this.gridCells {
                if !this.RefreshStillValid(gen)
                    break
                row := cell["row"]
                col := cell["col"]
                key := row "_" col
                entry := scanned.Has(key) ? scanned[key] : ""
                houseName := ""
                if (entry is Map && entry.Has("house"))
                    houseName := Trim(entry["house"])

                revealed := (houseName != "")
                missionsRevealed := revealed && this.EntryMissionsRevealed(entry)
                tracked := missionsRevealed && this.IsHouseTracked(houseName)
                slot := cell["slot"]
                missionCount := missionsRevealed ? this.SlotMissionCount(slot) : 0
                hasMissions := missionCount > 0
                cont := 0
                goal := 0
                if missionsRevealed && IsObject(this.profileManager) {
                    cont := this.profileManager.GetHouseContribution(houseName)
                    goal := this.profileManager.GetHouseGoal(houseName)
                }
                goalReached := tracked && goal > 0 && cont >= goal
                hasHuntedReward := false
                if missionsRevealed && IsObject(this.profileManager)
                    && this.profileManager.HasMethod("HouseHasHuntedReward")
                    hasHuntedReward := this.profileManager.HouseHasHuntedReward(entry)

                cell["revealed"] := revealed
                cell["missionsRevealed"] := missionsRevealed
                cell["houseName"] := houseName
                cell["tracked"] := tracked
                cell["hasHuntedReward"] := hasHuntedReward
                cell["hasMissions"] := hasMissions
                cell["missionCount"] := missionCount
                cell["cont"] := cont
                cell["goal"] := goal
                cell["goalReached"] := goalReached

                if missionsRevealed && row == this.activeRow && col == this.activeCol
                    activeStillValid := true
            }

            if this.IsDisplayActive() {
                this.RefreshCellStyles()
                this.UpdateTargetCounter()
            }

            if !this.RefreshStillValid(gen)
                return

            if !activeStillValid {
                this.activeRow := 0
                this.activeCol := 0
                if HouseMissionDialog.IsOpen()
                    HouseMissionDialog.Close()
            } else if HouseMissionDialog.IsOpen() {
                cell := this.GetCell(this.activeRow, this.activeCol)
                if IsObject(cell) && cell["revealed"] && cell["missionsRevealed"] {
                    houseName := Trim(cell["houseName"])
                    HouseMissionDialog.ShowOrUpdate(
                        this.guiObj,
                        this.HostRef(),
                        cell["slot"],
                        houseName,
                        this.activeRow,
                        this.activeCol,
                        this.GetHouseSpecialization(houseName),
                        this.MakeMissionDialogHandler())
                }
            }
        } finally {
            this.LockGuiRedraw(false)
        }
    }
}
