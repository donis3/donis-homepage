#Requires AutoHotkey v2.0+

/**
 * Master orchestration scenario.
 * Start (Home by default) runs this.
 *
 * If the session is not initialized yet, runs Initialize first, then:
 *   Claim any completed actives. If remaining actives are the full targetted set,
 *   stop (ready). If any other actives remain, disband for a clean slate, then
 *   loop AcceptMissions until missingTargettedMissionCount is 0 and run
 *   AcceptTargettedMissions once.
 *
 * Callable via masterScenarioInst.Execute().
 */
class MasterScenario {
    stateManager := ""
    userState := ""
    logger := ""
    initializeScenario := ""
    removeActiveMissionsScenario := ""
    acceptMissionsScenario := ""
    acceptTargettedMissionsScenario := ""
    acceptCompleteMissionsScenario := ""
    anchorMatcher := ""
    imageVariation := 30
    lastClaimedCount := 0
    huntAbandonStart := 0

    __New(stateManagerInst := "", userStateInst := "", loggerInst := "", initializeScenarioInst := "", removeActiveMissionsScenarioInst := "", acceptMissionsScenarioInst := "", acceptTargettedMissionsScenarioInst := "", acceptCompleteMissionsScenarioInst := "", anchorMatcherInst := "") {
        this.stateManager := stateManagerInst
        this.userState := userStateInst
        this.logger := loggerInst
        this.initializeScenario := initializeScenarioInst
        this.removeActiveMissionsScenario := removeActiveMissionsScenarioInst
        this.acceptMissionsScenario := acceptMissionsScenarioInst
        this.acceptTargettedMissionsScenario := acceptTargettedMissionsScenarioInst
        this.acceptCompleteMissionsScenario := acceptCompleteMissionsScenarioInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
    }

    Execute() {
        this.Debug("[Master] Starting orchestration...")
        GameWindow.Activate()
        this.SetOverlayState("Orchestrate")
        this.SetGuiStatus("Orchestrate")
        this.huntAbandonStart := this.GetGuildAbandonTotal()

        if !IsObject(this.stateManager) {
            this.StopWithError("State manager is unavailable.")
            return false
        }

        if !this.HasTargetedMissions() {
            this.Log("No targeted missions selected.")
            this.StopWithMessage("No targetted missions")
            return false
        }

        if !this.EnsureInitialized()
            return false
        return this.ExecuteMissionLoop()
    }

    /**
     * Claim completed actives, then either stop if the remaining set is exactly
     * the targetted missions, or disband leftovers and run the accept cycle.
     */
    ExecuteMissionLoop() {
        this.Debug("[Master] Running mission loop.")
        StatusBar.ShowCancelHint()

        if !this.HasTargetedMissions() {
            this.Log("No targeted missions selected.")
            this.StopWithMessage("No targetted missions")
            return false
        }

        this.DismissTravelConfirmationIfPresent()

        this.Log("Checking for completed missions...")
        if !this.RunClaimCompletedMissions()
            return false

        if this.ShouldStopForMnemonicDepletion()
            return this.StopForMnemonicDepletion()

        if !this.HasTargetedMissions() {
            this.Log("No targeted missions remaining.")
            this.CloseOpenMenu()
            if !(IsObject(this.acceptCompleteMissionsScenario)
                && this.acceptCompleteMissionsScenario.HasProp("lastNoTargetedMissionsRemaining")
                && this.acceptCompleteMissionsScenario.lastNoTargetedMissionsRemaining)
                StatusBar.Notify("No targeted missions", "info")
            this.StopWithMessage("No targeted missions")
            this.RestoreSessionState()
            return true
        }

        if IsObject(this.initializeScenario) && this.initializeScenario.HasMethod("ProcessActiveMissions")
            this.initializeScenario.ProcessActiveMissions()

        if this.AllTargetedMissionsAreActive() {
            this.Debug("[Master] Remaining actives match the targetted set.")
            if (this.lastClaimedCount == 0)
                this.Log("No completed missions. Your targets are still active.")
            this.CloseOpenMenu()
            return this.TargetAchieved()
        }

        if this.HasActiveMissions() {
            this.Log("Clearing leftover missions...")
            if !this.RunRemoveActiveMissions()
                return false
        } else {
            this.Debug("[Master] No leftover active missions. Opening house grid for accept sequence.")
            this.OpenHouseGridTab()
        }

        this.SetAvailableCount(0)
        this.DismissTravelConfirmationIfPresent()
        this.EnsureLandsraadTabVisible()
        if this.IsCancelled()
            return this.StopCancelled()
        return this.RunAcceptMissionsUntilAvailable()
    }

    RunClaimCompletedMissions() {
        this.lastClaimedCount := 0
        if !IsObject(this.acceptCompleteMissionsScenario) {
            this.Debug("[Master] AcceptCompleteMissions is unavailable. Skipping claim step.")
            return true
        }

        this.SetOverlayState("Claim completed")
        this.SetGuiStatus("Claim completed")
        this.Debug("[Master] Checking active missions for completed claims...")
        if !this.acceptCompleteMissionsScenario.Execute() {
            this.Log("Error: Could not claim completed missions.")
            this.StopWithError("Claim completed missions error")
            return false
        }
        claimedCount := 0
        if this.acceptCompleteMissionsScenario.HasProp("lastClaimedCount")
            claimedCount := Integer(this.acceptCompleteMissionsScenario.lastClaimedCount)
        this.lastClaimedCount := claimedCount
        claimedNames := []
        if (this.acceptCompleteMissionsScenario.HasProp("lastClaimedNames")
            && (this.acceptCompleteMissionsScenario.lastClaimedNames is Array))
            claimedNames := this.acceptCompleteMissionsScenario.lastClaimedNames
        if (claimedCount > 0 && this.stateManager.HasMethod("CompleteCurrentRun"))
            this.stateManager.CompleteCurrentRun(claimedNames)
        TravelAutoRun.Sync()
        return true
    }

    /**
     * Later runs only. ImageSearch on travel_confirmation_window.png is faster
     * and more stable than OCR for a fixed "Travel" title crop.
     */
    DismissTravelConfirmationIfPresent() {
        if !this.IsTravelConfirmationVisible()
            return false

        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            || !GameConstants["GameUI"].Has("TravelConfirmationCancelButtonCoords") {
            this.Debug("[Master] Travel confirmation is visible but cancel coords are missing.")
            return false
        }

        cfg := GameConstants["GameUI"]["TravelConfirmationCancelButtonCoords"]
        pos := ResolutionManager().coords(cfg.x, cfg.y)
        this.Debug("[Master] Travel confirmation detected. Clicking close at (" pos.x ", " pos.y ")...")
        InputHelper.FastClick(pos.x, pos.y)

        startTime := A_TickCount
        while (A_TickCount - startTime < 600) {
            if !this.IsTravelConfirmationVisible() {
                this.Debug("[Master] Travel confirmation closed.")
                return true
            }
            Sleep(40)
        }

        this.Debug("[Master] Travel confirmation still visible after close click.")
        return false
    }

    IsTravelConfirmationVisible() {
        if !IsObject(this.anchorMatcher)
            return false
        searchArea := this.GetTravelConfirmationSearchArea()
        if !IsObject(searchArea)
            return false
        foundX := 0, foundY := 0
        return this.anchorMatcher.FindAnchor("travel_confirmation_window.png", &foundX, &foundY, searchArea, this.imageVariation, "Black", false)
    }

    GetTravelConfirmationSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            || !GameConstants["GameUI"].Has("TravelConfirmationTextArea")
            return ""

        area := GameConstants["GameUI"]["TravelConfirmationTextArea"]
        return ResolutionManager().searchRect(area.x, area.y, area.w, area.h, 28)
    }

    /**
     * In-world "View mission report?" HUD. Masked ImageSearch only (OCR removed —
     * ImageSearch is enough and cheaper to poll). Leftover dismiss uses Esc via TravelAutoRun.
     */
    IsMissionCompleteIndicatorVisible() {
        if !IsObject(this.anchorMatcher)
            return false
        if !GameWindow.IsActive()
            return false

        searchArea := this.GetViewMissionReportSearchArea()
        if !IsObject(searchArea)
            return false

        attempts := [
            { image: "mission_complete_indicator.png", variation: 40 },
            { image: "mission_complete_indicator.png", variation: 60 },
            { image: "mission_complete_indicator.png", variation: 85 },
            { image: "view_mission_report_full.png", variation: 45 },
            { image: "view_mission_report.png", variation: 50 }
        ]

        for _, attempt in attempts {
            if this.TryMissionReportNeedle(attempt.image, searchArea, attempt.variation)
                return true
        }
        return false
    }

    TryMissionReportNeedle(imageName, searchArea, variation) {
        imagePath := this.anchorMatcher.ResolveImagePath(imageName)
        if !FileExist(imagePath)
            return false

        maskedPath := this.anchorMatcher.PrepareTanGlyphMask(imageName, "FFFFFF")
        if (maskedPath == "")
            return false
        foundX := 0, foundY := 0
        found := this.anchorMatcher.FindAnchor(maskedPath, &foundX, &foundY, searchArea, variation, "White", false)
        if (found)
            this.Debug("[Master] Mission-complete HUD matched '" imageName "' at (" foundX ", " foundY ") var=" variation ".")
        return found
    }

    GetViewMissionReportSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            || !GameConstants["GameUI"].Has("MissionCompleteIndicator")
            return ""
        area := GameConstants["GameUI"]["MissionCompleteIndicator"]
        return ResolutionManager().searchRect(area.x, area.y, area.w, area.h, 10)
    }

    OpenHouseGridTab() {
        global openLandsraadGridScenarioInst
        if IsSet(openLandsraadGridScenarioInst) && IsObject(openLandsraadGridScenarioInst)
            return openLandsraadGridScenarioInst.Execute()
        this.Log("[Master] Error: OpenLandsraadGrid scenario is unavailable.")
        return false
    }

    /**
     * Loop AcceptMissions until missingTargettedMissionCount is 0.
     * Global accept cap is 3; hitting it runs RemoveActiveMissions (max 50).
     * Loop counters reset each time this sequence starts.
     */
    RunAcceptMissionsUntilAvailable() {
        if !IsObject(this.acceptMissionsScenario) {
            this.StopWithError("Accept missions error")
            return false
        }

        maxRemoves := 50
        maxAcceptPasses := 100
        removeCount := 0
        acceptPass := 0
        totalCount := this.GetTargetedCount()
        missing := totalCount

        this.Log("Looking for your targeted missions...")
        this.Debug("[Master] Starting accept sequence. targetted=" totalCount ".")
        StatusBar.ShowCancelHint()
        if this.acceptMissionsScenario.HasMethod("BeginHunt")
            this.acceptMissionsScenario.BeginHunt()
        else if this.acceptMissionsScenario.HasMethod("ResetSession")
            this.acceptMissionsScenario.ResetSession()
        this.ShowAcceptProgress(missing, totalCount)

        if this.IsCancelled()
            return this.StopCancelled()

        if this.HasActiveMissions() && !this.AllTargetedMissionsAreActive() {
            this.Debug("[Master] Clearing leftover active missions before accept loop...")
            if !this.RunRemoveActiveMissions(false)
                return false
            removeCount++
            this.EnsureLandsraadTabVisible()
        }

        loop {
            if this.IsCancelled()
                return this.StopCancelled()
            if (missing == 0)
                break

            if (acceptPass >= maxAcceptPasses) {
                this.Log("Error: Gave up after too many pick attempts.")
                this.StopWithError("Accept missions loop exceeded 100")
                return false
            }

            acceptPass++
            this.DismissTravelConfirmationIfPresent()
            this.ShowAcceptProgress(missing, totalCount)
            this.Debug("[Master] Accept Missions pass " acceptPass
                " (removes " removeCount "/" maxRemoves ").")

            success := this.acceptMissionsScenario.Execute()
            if this.IsCancelled()
                return this.StopCancelled()
            status := this.acceptMissionsScenario.GetStatus()
            if (!success || (IsObject(status) && status.error != "")) {
                errText := (IsObject(status) && status.error != "") ? status.error : "Accept missions error"
                this.Log("Error: " errText)
                this.StopWithError(errText)
                return false
            }

            missing := IsObject(status) ? status.missingTargettedMissionCount : 0
            accepted := (IsObject(status) && status.HasOwnProp("acceptedCount")) ? status.acceptedCount : 0
            newAccepted := (IsObject(status) && status.HasOwnProp("newAcceptedCount")) ? status.newAcceptedCount : 0
            this.ShowAcceptProgress(missing, totalCount)
            this.Debug("[Master] Pass " acceptPass ": missing=" missing "/" totalCount
                " accepted=" accepted " newAccepted=" newAccepted ".")

            if (missing == 0)
                break

            shouldRemove := (accepted >= 3) || (newAccepted == 0 && accepted > 0)
            if (shouldRemove) {
                if (removeCount >= maxRemoves) {
                    this.Log("Error: Gave up after too many abandons.")
                    this.StopWithError("Remove missions loop exceeded 50")
                    return false
                }

                if (accepted >= 3)
                    this.Debug("[Master] Global accept cap (3) reached. Removing actives ("
                        (removeCount + 1) "/" maxRemoves ")...")
                else
                    this.Debug("[Master] No new unique missions left to accept. Removing actives ("
                        (removeCount + 1) "/" maxRemoves ")...")

                if !this.RunRemoveActiveMissions(false, accepted)
                    return false
                if this.IsCancelled()
                    return this.StopCancelled()
                if this.acceptMissionsScenario.HasMethod("ResetSession")
                    this.acceptMissionsScenario.ResetSession()
                removeCount++
                this.DismissTravelConfirmationIfPresent()
                this.EnsureLandsraadTabVisible()
            }
        }

        this.Debug("[Master] missingTargettedMissionCount=0. Running Accept Targetted Missions...")
        return this.RunAcceptTargettedMissions(totalCount, removeCount)
    }

    /**
     * One pass: accept the targetted offers on each targetted house.
     */
    RunAcceptTargettedMissions(totalCount, abandonPasses := 0) {
        if !IsObject(this.acceptTargettedMissionsScenario) {
            this.StopWithError("Accept targetted missions error")
            return false
        }

        this.SetAvailableCount(totalCount)
        this.DismissTravelConfirmationIfPresent()
        this.SetOverlayState("Accept targetted")
        this.SetGuiStatus("Accept targetted")

        if !this.acceptTargettedMissionsScenario.Execute() {
            this.Log("Error: Could not accept targeted missions.")
            this.StopWithError("Accept targetted missions error")
            return false
        }

        if IsObject(this.acceptMissionsScenario) && this.acceptMissionsScenario.HasMethod("ClearHuntDoneCells")
            this.acceptMissionsScenario.ClearHuntDoneCells()

        abandonPasses := Integer(abandonPasses)
        if (abandonPasses > 0) {
            word := (abandonPasses == 1) ? "abandon" : "abandons"
            this.Log("Missions accepted after " abandonPasses " " word ".")
        } else {
            this.Log("Targeted missions accepted.")
        }
        this.SetAvailableCount(totalCount)
        this.CloseOpenMenu()
        if this.StartPlayTimer() {
            this.Log("Timer started. You can play your missions now.")
            this.NotifyReadyToRun()
        }
        this.RestoreSessionState()
        return true
    }

    ShowAcceptProgress(missingCount, totalCount) {
        availableCount := totalCount - missingCount
        if (availableCount < 0)
            availableCount := 0
        this.SetAvailableCount(availableCount)
        this.SetOverlayState("Working, please wait")
        this.SetGuiStatus("Working, please wait")
    }

    SetAvailableCount(count) {
        if IsObject(this.userState)
            this.userState.SetAvailableTargetedCount(count)
        global mainGuiInst
        StatusBar.Refresh()
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatusProgress"))
            mainGuiInst.RefreshStatusProgress()
    }

    GetProgressText(totalCount := 0) {
        if (totalCount < 1)
            totalCount := this.GetTargetedCount()
        if IsObject(this.userState)
            return this.userState.GetProgressText(totalCount)
        return "0/3"
    }

    GetTargetedCount() {
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return 0
        return targeted.Length
    }

    EnsureInitialized() {
        if this.IsInitialized() {
            this.Debug("[Master] Session is ready.")
            return true
        }

        this.Debug("[Master] Session is waiting. Running Initialize...")
        this.SetOverlayState("Initialize")
        this.SetGuiStatus("Initialize")

        if !IsObject(this.initializeScenario) {
            this.StopWithError("Initialize error")
            return false
        }

        if !this.initializeScenario.Execute() {
            this.Log("Error: Setup failed.")
            this.StopWithError("Initialize error")
            return false
        }

        this.Debug("[Master] Initialize completed. Session is ready.")
        return true
    }

    RunRemoveActiveMissions(showStatus := true, abandonedCount := -1) {
        if !IsObject(this.removeActiveMissionsScenario) {
            this.StopWithError("Remove missions error")
            return false
        }

        if (showStatus) {
            this.SetOverlayState("Remove missions")
            this.SetGuiStatus("Remove missions")
        }
        if !this.removeActiveMissionsScenario.Execute(abandonedCount) {
            if this.IsCancelled()
                return this.StopCancelled()
            this.Log("Error: Could not clear leftover missions.")
            this.StopWithError("Remove missions error")
            return false
        }

        this.stateManager.SaveActiveMissions([])
        this.SetAvailableCount(0)
        this.Debug("[Master] Active missions cleared.")
        return true
    }

    /**
     * After first run the Landsraad menu is still open. Esc closes it.
     */
    CloseOpenMenu() {
        this.Debug("[Master] Sending Esc to close the open menu.")
        InputHelper.SendGameKey("Esc")
    }

    /**
     * Ready-state Home: landsraad_button.png must be in LandsraadTabButton.
     * If it is missing, press L and wait 500ms before Accept Missions.
     */
    EnsureLandsraadTabVisible() {
        searchArea := this.GetLandsraadTabSearchArea()
        foundX := 0, foundY := 0
        imageName := "landsraad_button.png"

        if IsObject(searchArea) && IsObject(this.anchorMatcher) {
            this.Debug("[Master] Checking LandsraadTabButton for " imageName "...")
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation) {
                this.Debug("[Master] Landsraad tab is visible at (" foundX ", " foundY ").")
                return
            }
        }

        this.Debug("[Master] Landsraad tab not visible. Sending L.")
        InputHelper.SendGameKey("l")
        startTime := A_TickCount
        while (A_TickCount - startTime < 800) {
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation)
                return
            Sleep(40)
        }
    }

    GetLandsraadTabSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("LandsraadTabButton")
            return ""

        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        return ResolutionManager().searchFromConfig(tabBtnConfig, 20)
    }

    ShouldStopForMnemonicDepletion() {
        global settingsManagerInst
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        if !settingsManagerInst.GetBool("stopWhenMnemonicRecollectionsEnd", false)
            return false
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("IsMnemonicRecollectionsDepleted")
            return false
        return this.stateManager.IsMnemonicRecollectionsDepleted()
    }

    StopForMnemonicDepletion() {
        this.Log("Mnemonic recollections ran out. Stopping automation.")
        StatusBar.Notify("Mnemonic recollections ran out", "info")
        TravelAutoRun.Suppress()
        this.CloseOpenMenu()
        if this.AllTargetedMissionsAreActive()
            return this.TargetAchieved()
        this.StopWithMessage("Mnemonic recollections ran out")
        this.RestoreSessionState()
        return true
    }

    TargetAchieved() {
        this.Debug("[Master] All targetted missions are already active. Target achieved.")
        this.SetAvailableCount(this.GetTargetedCount())
        if this.StartPlayTimer() {
            this.Log("Your targeted missions are ready. Timer started.")
            this.NotifyReadyToRun()
        }
        this.RestoreSessionState()
        return true
    }

    NotifyReadyToRun() {
        abandoned := this.GetCycleAbandonedCount()
        msg := "Ready to run missions!"
        if (abandoned > 0)
            msg := "Ready to run missions!  " abandoned " abandoned"
        StatusBar.Notify(msg, "ready")
        SfxPlayer.PlayRunStart()
    }

    GetCycleAbandonedCount() {
        total := this.GetGuildAbandonTotal()
        start := Integer(this.huntAbandonStart)
        n := total - start
        if (n < 0)
            n := 0
        return n
    }

    GetGuildAbandonTotal() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetStat")
            return Integer(this.stateManager.GetStat("guildAbandons"))
        return 0
    }

    StartPlayTimer() {
        started := false
        if IsObject(this.stateManager) && this.stateManager.HasMethod("StartRunTimerIfNeeded")
            started := this.stateManager.StartRunTimerIfNeeded()
        global statusOverlayInst
        if IsSet(statusOverlayInst) && IsObject(statusOverlayInst)
            statusOverlayInst.PaintRunTimes()
        TravelAutoRun.ArmLeftoverDismiss()
        TravelAutoRun.Sync()
        return started
    }

    IsInitialized() {
        return IsObject(this.userState) && this.userState.IsInitialized()
    }

    HasTargetedMissions() {
        targeted := this.stateManager.GetTargetedMissions()
        return (targeted is Array) && targeted.Length > 0
    }

    HasActiveMissions() {
        active := this.stateManager.GetActiveMissions()
        return (active is Array) && active.Length > 0
    }

    AllTargetedMissionsAreActive() {
        targeted := this.stateManager.GetTargetedMissions()
        active := this.stateManager.GetActiveMissions()
        if (!(targeted is Array) || targeted.Length == 0)
            return false
        if (!(active is Array) || active.Length == 0)
            return false

        targetedNames := Map()
        targetedCount := 0
        for _, mission in targeted {
            if (mission.missionName == "")
                continue
            targetedCount += 1
            targetedNames[StrLower(mission.missionName)] := true
        }

        activeNames := Map()
        activeCount := 0
        for _, mission in active {
            if (mission.missionName == "")
                continue
            activeCount += 1
            nameKey := StrLower(mission.missionName)
            activeNames[nameKey] := true
            if !targetedNames.Has(nameKey)
                return false
        }

        if (targetedCount == 0 || activeCount == 0 || activeCount != targetedCount)
            return false

        for nameKey, _ in targetedNames {
            if !activeNames.Has(nameKey)
                return false
        }
        return true
    }

    StopWithMessage(message) {
        this.SetGuiStatus(message)
        this.SetOverlayState(message)
    }

    StopWithError(message) {
        this.SetGuiStatus(message)
        this.SetOverlayState(message)
    }

    IsCancelled() {
        return IsObject(this.userState) && this.userState.IsCancelRequested()
    }

    StopCancelled() {
        this.Log("Cancelled.")
        StatusBar.SetHotkeyHint("")
        this.CloseOpenMenu()
        this.RestoreSessionState()
        return true
    }

    RestoreSessionState() {
        StatusBar.SetHotkeyHint("")
        StatusBar.RestoreIdle()
        this.SetGuiSessionStatus()
    }

    SetGuiSessionStatus() {
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("ShowSessionHint"))
            mainGuiInst.ShowSessionHint()
        else if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("GetStatusBarText"))
            this.SetGuiStatus(mainGuiInst.GetStatusBarText())
        else
            this.SetGuiStatus(IsObject(this.userState) ? this.userState.GetReadyLabel() : "Ready")
    }

    SetOverlayState(label) {
        StatusBar.SetStatus(label)
    }

    SetGuiStatus(message) {
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus(message)
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
