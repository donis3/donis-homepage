#Requires AutoHotkey v2.0+

class SettingsTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 5)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        pad := 14
        yTop := 124
        colGap := 12
        cardW := this.contentW
        colW := (cardW - colGap) // 2
        leftX := m
        rightX := m + colW + colGap
        halfW := (colW - colGap) // 2
        lCol1 := leftX
        lCol2 := leftX + halfW + colGap
        fieldH := 104
        ctrlW := 140

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" m " y" yTop " w" cardW " h24 BackgroundTrans", "Settings"))

        contentY := yTop + 32
        profileH := 76
        this.PageAdd(5, g.Add("Text", "x" m " y" contentY " w" cardW " h" profileH " Background" this.surfaceColor))
        this.PageAdd(5, g.Add("Text", "x" m " y" contentY " w4 h" profileH " BackgroundEAB308"))
        profileTextW := cardW - 426
        g.SetFont("s11 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad + 4) " y" (contentY + 14) " w" profileTextW " h20 BackgroundTrans",
            "Active profile"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad + 4) " y" (contentY + 36) " w" profileTextW " h36 +0x200 BackgroundTrans Wrap",
            "Each profile keeps its own missions, settings, and Landsraad tracking."))
        profileNames := IsObject(this.profileManager) ? this.profileManager.GetProfileNames() : ["Default"]
        if (profileNames.Length == 0)
            profileNames := ["Default"]
        profileCtrlY := contentY + 24
        profileBtnH := 28
        profileBtnGap := 8
        newBtnW := 60
        resetBtnW := 66
        deleteBtnW := 58
        profileSelectW := 200
        profileCtrlRight := m + cardW - pad
        newBtnX := profileCtrlRight - newBtnW
        resetBtnX := newBtnX - profileBtnGap - resetBtnW
        deleteBtnX := resetBtnX - profileBtnGap - deleteBtnW
        profileSelectX := deleteBtnX - profileBtnGap - profileSelectW
        this.setProfile := DarkSelect(g, profileSelectX, profileCtrlY, profileSelectW, profileBtnH, this, profileNames)
        this.PageAddSelect(5, this.setProfile)
        profileIdx := IsObject(this.profileManager) ? this.profileManager.GetCurrentIndex() : 1
        this.setProfile.Choose(profileIdx)
        this.setProfile.OnEvent("Change", (*) => this.OnProfileChange())
        this.AddTextButton(5, deleteBtnX, profileCtrlY, deleteBtnW, profileBtnH, "Delete", (*) => this.OnDeleteProfile())
        this.AddTextButton(5, resetBtnX, profileCtrlY, resetBtnW, profileBtnH, "Reset", (*) => this.OnResetProfile())
        this.AddTextButton(5, newBtnX, profileCtrlY, newBtnW, profileBtnH, "New", (*) => this.OnNewProfile())

        ly := contentY + profileH + 12
        ry := ly

        this.setCharacterName := this.AddSettingsTwinCard(g, 5, lCol1, ly, halfW, fieldH, "Character name",
            "Display name for this profile.", (*) => this.OnCharacterNameCommit(), true,
            IsObject(this.profileManager) ? this.profileManager.GetCurrentName() : this.settingsManager.Get("characterName", "Default"))

        this.setGuildName := this.AddSettingsTwinCard(g, 5, lCol2, ly, halfW, fieldH, "Guild name",
            "Used when creating a guild.", (*) => this.OnGuildNameCommit(), true,
            this.settingsManager.Get("guildName", "wowza"), 100)
        ly += fieldH + 10

        resetCardH := 116
        resetTextW := colW - (pad * 2)
        this.PageAdd(5, g.Add("Text", "x" leftX " y" ly " w" colW " h" resetCardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (leftX + pad) " y" (ly + 12) " w" resetTextW " h18 BackgroundTrans",
            "Weekly Landsraad reset"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (leftX + pad) " y" (ly + 30) " w" resetTextW " h32 +0x200 BackgroundTrans Wrap",
            "Local day and hour when Landsraad resets each week."))
        dayCtrlW := 148
        hourCtrlW := 108
        ctrlGap := 16
        dayX := leftX + pad
        hourX := dayX + dayCtrlW + ctrlGap
        labelY := ly + 68
        ctrlY := ly + 82
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" dayX " y" labelY " w" dayCtrlW " h14 BackgroundTrans", "Day"))
        this.PageAdd(5, g.Add("Text", "x" hourX " y" labelY " w" hourCtrlW " h14 BackgroundTrans", "Hour"))
        dayItems := this.GetLandsraadResetDayItems()
        hourItems := this.GetLandsraadResetHourItems()
        this.setLandsraadResetDay := DarkSelect(g, dayX, ctrlY, dayCtrlW, 28, this, dayItems)
        this.PageAddSelect(5, this.setLandsraadResetDay)
        this.setLandsraadResetDay.Choose(this.GetLandsraadResetDayIndex(this.settingsManager.GetLandsraadResetDay()))
        this.setLandsraadResetDay.OnEvent("Change", (*) => this.OnLandsraadResetDayChange())
        this.setLandsraadResetHour := DarkSelect(g, hourX, ctrlY, hourCtrlW, 28, this, hourItems)
        this.PageAddSelect(5, this.setLandsraadResetHour)
        this.setLandsraadResetHour.Choose(this.GetLandsraadResetHourIndex(this.settingsManager.GetLandsraadResetHour()))
        this.setLandsraadResetHour.OnEvent("Change", (*) => this.OnLandsraadResetHourChange())
        ly += resetCardH + 10

        this.setFaction := this.AddSettingsTwinSelect(g, 5, lCol1, ly, halfW, fieldH, "Faction",
            "Your Landsraad allegiance.", ["Atreides", "Harkonnen"],
            this.settingsManager.Get("faction", "Atreides"), (*) => this.OnFactionChange(), true)

        this.setOcrLang := this.AddSettingsTwinCard(g, 5, lCol2, ly, halfW, fieldH, "OCR language",
            "Windows OCR pack for mission names.", (*) => this.OnOcrLangChange(), false,
            this.settingsManager.Get("ocrLanguage", "en-US"))
        ly += fieldH + 10

        delayLabels := this.GetActionDelayLabels()
        this.setActionDelay := this.AddSettingsTwinSelect(g, 5, lCol1, ly, halfW, fieldH, "Action delay",
            "Wait after each click or key.", delayLabels, "",
            (*) => this.OnActionDelayChange(), true)
        if IsObject(this.setActionDelay)
            this.setActionDelay.Choose(this.GetActionDelayIndex())

        overlayVal := this.settingsManager.GetBool("showOverlay", true) ? 1 : 0
        this.setShowOverlay := this.AddSettingsToggleCard(g, 5, lCol2, ly, halfW, fieldH, "Status overlay",
            "Pins to the game window. Hides when unfocused.", overlayVal, (*) => this.OnShowOverlayChange())
        ly += fieldH + 10

        overlaySecH := 112
        this.PageAdd(5, g.Add("Text", "x" leftX " y" ly " w" colW " h" overlaySecH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (leftX + pad) " y" (ly + 10) " w200 h18 BackgroundTrans", "Overlay sections"))
        posLabels := this.GetOverlayPositionLabels()
        this.setOverlayPosition := DarkSelect(g, leftX + colW - pad - ctrlW, ly + 8, ctrlW, 28, this, posLabels)
        this.PageAddSelect(5, this.setOverlayPosition)
        this.setOverlayPosition.Choose(this.GetOverlayPositionIndex())
        this.setOverlayPosition.OnEvent("Change", (*) => this.OnOverlayPositionChange())
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (leftX + pad) " y" (ly + 30) " w" (colW - ctrlW - 36) " h16 BackgroundTrans",
            "HUD blocks and toast notifications."))
        this.overlaySectionChecks := Map()
        sectionRows := [
            [
                ["overlayShowStatus", "Status"],
                ["overlayShowRun", "Run"],
                ["overlayShowCurrentRun", "Current"],
                ["overlayShowLastRun", "Last"],
                ["overlayShowTargets", "Targets"]
            ],
            [
                ["overlayShowSession", "Session"],
                ["overlayShowMnemonic", "Mnemonic"],
                ["overlayShowProfile", "Profile"],
                ["overlayShowNotifications", "Notifications"]
            ]
        ]
        rowInnerW := colW - (pad * 2)
        g.SetFont("s9 cE4E4E7", "Segoe UI")
        loop sectionRows.Length {
            rowDefs := sectionRows[A_Index]
            rowY := ly + 52 + ((A_Index - 1) * 28)
            cols := rowDefs.Length
            colItemW := rowInnerW // cols
            boxX := leftX + pad
            for _, def in rowDefs {
                keyName := def[1]
                label := def[2]
                checked := this.settingsManager.GetBool(keyName, true) ? 1 : 0
                box := this.PageAdd(5, g.Add("Checkbox",
                    "x" boxX " y" rowY " w" colItemW " h22 Checked" checked, label))
                box.Value := checked
                box.OnEvent("Click", this.MakeOverlaySectionHandler(keyName))
                this.overlaySectionChecks[keyName] := box
                if (keyName == "overlayShowNotifications")
                    this.setShowNotifications := box
                boxX += colItemW
            }
        }

        ; --- Right column: automation, keybinds, database ---
        prefRowH := 44
        prefH := 14 + prefRowH * 4 + 10
        this.PageAdd(5, g.Add("Text", "x" rightX " y" ry " w" colW " h" prefH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (rightX + pad) " y" (ry + 10) " w" (colW - 28) " h18 BackgroundTrans", "Automation"))
        prefRows := [
            Map("title", "AutoRun", "hint", "Start loops from Travel or mission report.", "prop", "setAutoRunOnTravel",
                "setting", "autoRunOnTravelConfirmation", "handler", (*) => this.OnAutoRunOnTravelChange()),
            Map("title", "Stop when mnemonic recollections run out", "hint", "Stop automation when mnemonic recollections run out.", "prop", "setStopWhenMnemonicRecollectionsEnd",
                "setting", "stopWhenMnemonicRecollectionsEnd", "handler", (*) => this.OnStopWhenMnemonicRecollectionsEndChange()),
            Map("title", "Sound effects", "hint", "Cues when ready and goals reached.", "prop", "setSoundsEnabled",
                "setting", "soundsEnabled", "handler", (*) => this.OnSoundsEnabledChange()),
            Map("title", "Debug logging", "hint", "Verbose OCR and scenario logs.", "prop", "setDebugMode",
                "setting", "debugMode", "handler", (*) => this.OnDebugModeChange(), "debug", true)
        ]
        loop prefRows.Length {
            row := prefRows[A_Index]
            rowTop := ry + 30 + ((A_Index - 1) * prefRowH)
            this.AddSettingsPrefRow(g, 5, rightX, rowTop, colW, prefRowH, pad, row)
        }
        ry += prefH + 10

        dbH := 76
        keybindH := this.winH - ry - dbH - 10 - 52
        if (keybindH < 220)
            keybindH := 220

        this.PageAdd(5, g.Add("Text", "x" rightX " y" ry " w" colW " h" keybindH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (rightX + pad) " y" (ry + 8) " w160 h18 BackgroundTrans", "Keybinds"))
        this.AddTextButton(5, rightX + colW - pad - 56, ry + 6, 56, 22, "Reset", (*) => this.OnResetKeybinds())
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (rightX + pad) " y" (ry + 26) " w" (colW - 28) " h14 BackgroundTrans",
            "Click a bind, then press a key. Esc cancels."))

        bindDefs := [
            { setting: "hotkeyStart", label: "Start", fallback: "Home", prop: "setHotkeyStart" },
            { setting: "hotkeyStop", label: "Stop", fallback: "End", prop: "setHotkeyStop" },
            { setting: "hotkeyToggleAutoRun", label: "AutoRun", fallback: "Delete", prop: "setHotkeyAutoRun" },
            { setting: "hotkeyReload", label: "Reload", fallback: "PgDn", prop: "setHotkeyReload" },
            { setting: "hotkeyToggleGui", label: "Dashboard", fallback: "F8", prop: "setHotkeyToggle" },
            { setting: "hotkeyToggleOverlay", label: "Overlay", fallback: "Insert", prop: "setHotkeyOverlay" },
            { setting: "hotkeyExit", label: "Exit", fallback: "Pause", prop: "setHotkeyExit" }
        ]
        bindInnerGap := 10
        bindColW := (colW - (pad * 2) - bindInnerGap) // 2
        bindBtnW := 104
        bindLabelW := bindColW - bindBtnW - 6
        loop bindDefs.Length {
            def := bindDefs[A_Index]
            col := (A_Index <= 4) ? 0 : 1
            row := (A_Index <= 4) ? (A_Index - 1) : (A_Index - 5)
            colX := rightX + pad + col * (bindColW + bindInnerGap)
            rowY := ry + 46 + row * 26
            g.SetFont("s9 cA1A1AA", "Segoe UI")
            this.PageAdd(5, g.Add("Text", "x" colX " y" rowY " w" bindLabelW " h20 BackgroundTrans", def.label))
            keyName := this.settingsManager.Get(def.setting, def.fallback)
            btn := this.AddTextButton(5, colX + bindLabelW + 4, rowY, bindBtnW, 22,
                this.FormatHotkeyName(keyName), this.MakeHotkeyCaptureHandler(def.setting))
            this.%def.prop% := btn
        }
        ry += keybindH + 10

        this.PageAdd(5, g.Add("Text", "x" rightX " y" ry " w" colW " h" dbH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (rightX + pad) " y" (ry + 10) " w" (colW - 28) " h18 BackgroundTrans", "Database"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (rightX + pad) " y" (ry + 30) " w" (colW - 140) " h16 BackgroundTrans",
            "Loaded Landsraad houses and missions."))
        houseCount := IsObject(this.stateManager) ? this.stateManager.allHousesList.Length : 0
        missionCount := IsObject(this.stateManager) ? this.stateManager.allMissionsList.Length : 0
        g.SetFont("s11 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (rightX + colW - pad - 120) " y" (ry + 22) " w120 h36 Right BackgroundTrans",
            houseCount " houses`n" missionCount " missions"))
    }

    AddSettingsTwinCard(g, page, x, y, w, h, title, hint, onCommit, isEdit := true, value := "", limit := 0) {
        pad := 14
        textW := w - (pad * 2)
        ctrlH := 28
        titleY := y + 12
        hintY := y + 30
        ctrlY := y + h - pad - ctrlH
        hintH := ctrlY - hintY - 6
        this.PageAdd(page, g.Add("Text", "x" x " y" y " w" w " h" h " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" titleY " w" textW " h18 BackgroundTrans", title))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" hintY " w" textW " h" hintH " +0x200 BackgroundTrans Wrap", hint))
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        opts := "x" (x + pad) " y" ctrlY " w" textW " h" ctrlH " -Theme Background" this.inputBgColor
        if (limit > 0)
            opts .= " Limit" limit
        outCtrl := this.PageAdd(page, this.StyleEdit(g.Add("Edit", opts, value)))
        if isEdit
            outCtrl.OnEvent("LoseFocus", onCommit)
        else
            outCtrl.OnEvent("Change", onCommit)
        return outCtrl
    }

    AddSettingsTwinSelect(g, page, x, y, w, h, title, hint, items, currentVal, onChange, chooseByValue := false) {
        pad := 14
        textW := w - (pad * 2)
        ctrlH := 28
        titleY := y + 12
        hintY := y + 30
        ctrlY := y + h - pad - ctrlH
        hintH := ctrlY - hintY - 6
        this.PageAdd(page, g.Add("Text", "x" x " y" y " w" w " h" h " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" titleY " w" textW " h18 BackgroundTrans", title))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" hintY " w" textW " h" hintH " +0x200 BackgroundTrans Wrap", hint))
        outCtrl := DarkSelect(g, x + pad, ctrlY, textW, ctrlH, this, items)
        this.PageAddSelect(page, outCtrl)
        if chooseByValue {
            chosenIdx := 1
            loop items.Length {
                if (items[A_Index] == currentVal) {
                    chosenIdx := A_Index
                    break
                }
            }
            outCtrl.Choose(chosenIdx)
        }
        outCtrl.OnEvent("Change", onChange)
        return outCtrl
    }

    AddSettingsToggleCard(g, page, x, y, w, h, title, hint, checked, onClick) {
        pad := 14
        textW := w - (pad * 2) - 84
        titleY := y + 12
        hintY := y + 30
        this.PageAdd(page, g.Add("Text", "x" x " y" y " w" w " h" h " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" titleY " w" textW " h18 BackgroundTrans", title))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" hintY " w" textW " h40 +0x200 BackgroundTrans Wrap", hint))
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        box := this.PageAdd(page, g.Add("Checkbox",
            "x" (x + w - pad - 84) " y" (y + h - pad - 24) " w84 h22 Checked" checked, "Enabled"))
        box.Value := checked
        box.OnEvent("Click", onClick)
        return box
    }

    AddSettingsPrefRow(g, page, x, rowTop, w, rowH, pad, row) {
        textW := w - (pad * 2) - 84
        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" (rowTop + 4) " w" textW " h16 BackgroundTrans", row["title"]))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(page, g.Add("Text", "x" (x + pad) " y" (rowTop + 20) " w" textW " h20 +0x200 BackgroundTrans Wrap", row["hint"]))
        checked := 0
        if row.Has("debug")
            checked := this.settingsManager.GetBool(row["setting"], false) ? 1 : 0
        else
            checked := this.settingsManager.GetBool(row["setting"], row["setting"] == "soundsEnabled") ? 1 : 0
        g.SetFont("s9 cE4E4E7", "Segoe UI")
        box := this.PageAdd(page, g.Add("Checkbox",
            "x" (x + w - pad - 72) " y" (rowTop + 12) " w72 h22 Checked" checked, "On"))
        box.Value := checked
        box.OnEvent("Click", row["handler"])
        this.%row["prop"]% := box
    }

    GetLandsraadResetDayItems() {
        return ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    }

    GetLandsraadResetHourItems() {
        labels := []
        loop 24 {
            h := A_Index - 1
            if (h == 0)
                labels.Push("12 AM")
            else if (h < 12)
                labels.Push(h " AM")
            else if (h == 12)
                labels.Push("12 PM")
            else
                labels.Push((h - 12) " PM")
        }
        return labels
    }

    GetLandsraadResetDayIndex(dayName) {
        day := Trim(dayName)
        if (day == "")
            day := this.settingsManager.GetDefaultLandsraadResetDay()
        items := this.GetLandsraadResetDayItems()
        loop items.Length {
            if (items[A_Index] == day)
                return A_Index
        }
        loop items.Length {
            if (items[A_Index] == this.settingsManager.GetDefaultLandsraadResetDay())
                return A_Index
        }
        return 2
    }

    GetLandsraadResetHourIndex(hourVal) {
        hour := this.settingsManager.NormalizeLandsraadResetHour(hourVal)
        return hour + 1
    }

    LandsraadResetDayFromIndex(idx) {
        items := this.GetLandsraadResetDayItems()
        if (idx < 1 || idx > items.Length)
            return this.settingsManager.GetDefaultLandsraadResetDay()
        return items[idx]
    }

    LandsraadResetHourFromIndex(idx) {
        if (idx < 1 || idx > 24)
            return this.settingsManager.GetDefaultLandsraadResetHour()
        return idx - 1
    }

    RefreshLandsraadResetDropdowns() {
        if !IsObject(this.setLandsraadResetDay) || !IsObject(this.setLandsraadResetHour)
            return
        this.setLandsraadResetDay.Choose(this.GetLandsraadResetDayIndex(this.settingsManager.GetLandsraadResetDay()))
        this.setLandsraadResetHour.Choose(this.GetLandsraadResetHourIndex(this.settingsManager.GetLandsraadResetHour()))
    }

    SaveLandsraadResetFromDropdowns() {
        dayName := this.LandsraadResetDayFromIndex(this.setLandsraadResetDay.Value)
        hourVal := this.LandsraadResetHourFromIndex(this.setLandsraadResetHour.Value)
        dayName := this.settingsManager.NormalizeLandsraadResetDay(dayName)
        hourVal := this.settingsManager.NormalizeLandsraadResetHour(hourVal)
        savedDay := this.settingsManager.GetLandsraadResetDay()
        savedHour := this.settingsManager.GetLandsraadResetHour()
        if (dayName == savedDay && hourVal == savedHour)
            return false
        this.settingsManager.Set("landsraadResetDay", dayName)
        this.settingsManager.Set("landsraadResetHour", hourVal)
        return true
    }

    OnLandsraadResetDayChange() {
        if (this.isInitializing || !IsObject(this.setLandsraadResetDay) || !IsObject(this.setLandsraadResetHour))
            return
        if this.SaveLandsraadResetFromDropdowns()
            this.ShowSessionHint()
    }

    OnLandsraadResetHourChange() {
        if (this.isInitializing || !IsObject(this.setLandsraadResetDay) || !IsObject(this.setLandsraadResetHour))
            return
        if this.SaveLandsraadResetFromDropdowns()
            this.ShowSessionHint()
    }

    MakeHotkeyCaptureHandler(settingKey) {
        return (*) => this.CaptureHotkey(settingKey)
    }

    OnOcrLangChange() {
        if (this.isInitializing || !IsObject(this.setOcrLang))
            return

        curLang := Trim(this.setOcrLang.Value)
        if (curLang == "")
            curLang := "en-US"

        this.settingsManager.Set("ocrLanguage", curLang)
        this.ShowSessionHint()
    }

    OnCharacterNameCommit() {
        if (this.isInitializing || !IsObject(this.setCharacterName) || !IsObject(this.profileManager))
            return

        newName := Trim(this.setCharacterName.Value)
        currentName := this.profileManager.GetCurrentName()
        if (newName == "") {
            this.setCharacterName.Value := currentName
            return
        }
        if (StrLower(newName) == StrLower(currentName)) {
            this.setCharacterName.Value := currentName
            return
        }

        if !this.profileManager.RenameCurrent(newName, this.settingsManager) {
            this.setCharacterName.Value := currentName
            this.SetStatus("That character name is already used by another profile.")
            return
        }

        this.RefreshProfileDropdown(false)
        this.RefreshStatusOverlay()
        this.ShowSessionHint()
    }

    OnProfileChange() {
        if (this.isInitializing || !IsObject(this.setProfile) || !IsObject(this.profileManager))
            return

        chosenIdx := this.setProfile.Value
        if (chosenIdx == this.profileManager.GetCurrentIndex())
            return

        this.SaveMissionSelections()
        if !this.profileManager.SwitchToIndex(chosenIdx, this.stateManager, this.settingsManager) {
            this.RefreshProfileDropdown()
            this.SetStatus("Could not switch profile.")
            return
        }

        this.ApplyLoadedProfileToUi()
        this.SetStatus("Switched to " this.profileManager.GetCurrentName() ".")
    }

    OnNewProfile() {
        if (this.isInitializing || !IsObject(this.profileManager))
            return

        result := InputBox("Enter a character name for the new profile.", "New profile", "w360 h140", "")
        if (result.Result != "OK")
            return

        newName := Trim(result.Value)
        if (newName == "") {
            this.SetStatus("Character name cannot be empty.")
            return
        }

        this.SaveMissionSelections()
        if !this.profileManager.CreateProfile(newName, this.stateManager, this.settingsManager) {
            this.SetStatus("A profile with that name already exists.")
            return
        }

        this.ApplyLoadedProfileToUi()
        this.SetStatus("Created profile " this.profileManager.GetCurrentName() ".")
    }

    OnDeleteProfile() {
        if (this.isInitializing || !IsObject(this.profileManager))
            return

        profileName := this.profileManager.GetCurrentName()
        answer := MsgBox(
            "Delete profile " profileName "?`n`n"
            "This removes its missions, stats, Landsraad data, and settings. This cannot be undone.",
            "Delete profile",
            "YesNo Icon!")

        if (answer != "Yes")
            return

        this.SaveMissionSelections()
        createdDefault := this.profileManager.DeleteCurrentProfile(this.stateManager, this.settingsManager)
        if !createdDefault.success {
            this.SetStatus("Could not delete profile.")
            return
        }

        this.ApplyLoadedProfileToUi()
        if createdDefault.createdDefault {
            this.SetStatus("Deleted profile " profileName ". Created a new default profile.")
            this.Log("Deleted profile " profileName ". Created a new default profile.")
        } else {
            this.SetStatus("Deleted profile " profileName ".")
            this.Log("Deleted profile " profileName ".")
        }
    }

    OnResetProfile() {
        if (this.isInitializing || !IsObject(this.profileManager) || !IsObject(this.settingsManager))
            return
        this.profileManager.ResetCurrentProfileSettings(this.settingsManager)
        this.RefreshSettingsControls()
        this.ShowSessionHint()
        this.Log("Profile settings reset to defaults. Stats were left unchanged.")
        this.SetStatus("Settings reset.")
    }

    OnResetKeybinds() {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return
        this.settingsManager.ResetHotkeys()
        ApplyAppHotkeys()
        this.RefreshHotkeyDisplay()
        this.ShowSessionHint()
        this.Log("Keybinds reset to Home, End, Delete, F8, Insert, and Pause.")
    }

    RefreshSettingsControls() {
        wasInit := this.isInitializing
        this.isInitializing := true

        if IsObject(this.setCharacterName)
            this.setCharacterName.Value := IsObject(this.profileManager)
                ? this.profileManager.GetCurrentName()
                : this.settingsManager.Get("characterName", "player")
        if IsObject(this.setGuildName)
            this.setGuildName.Value := this.settingsManager.Get("guildName", "wowza")
        if IsObject(this.setFaction) {
            faction := this.settingsManager.Get("faction", "Atreides")
            if (faction = "Harkonnen")
                this.setFaction.Choose(2)
            else
                this.setFaction.Choose(1)
        }
        if IsObject(this.setDebugMode) {
            debugOn := this.settingsManager.GetBool("debugMode", false)
            this.setDebugMode.Value := debugOn ? 1 : 0
            if IsObject(this.logger)
                this.logger.SetDebug(debugOn)
        }
        if IsObject(this.setAutoRunOnTravel)
            this.setAutoRunOnTravel.Value := this.settingsManager.GetBool("autoRunOnTravelConfirmation", false) ? 1 : 0
        if IsObject(this.setStopWhenMnemonicRecollectionsEnd)
            this.setStopWhenMnemonicRecollectionsEnd.Value := this.settingsManager.GetBool("stopWhenMnemonicRecollectionsEnd", false) ? 1 : 0
        if IsObject(this.setSoundsEnabled)
            this.setSoundsEnabled.Value := this.settingsManager.GetBool("soundsEnabled", true) ? 1 : 0
        if IsObject(this.setShowOverlay) {
            showOverlay := this.settingsManager.GetBool("showOverlay", true)
            this.setShowOverlay.Value := showOverlay ? 1 : 0
            StatusBar.ApplyVisibility(showOverlay)
        }
        if IsObject(this.setShowNotifications)
            this.setShowNotifications.Value := this.settingsManager.GetBool("overlayShowNotifications", true) ? 1 : 0
        if IsObject(this.overlaySectionChecks) {
            for keyName, box in this.overlaySectionChecks {
                if IsObject(box)
                    box.Value := this.settingsManager.GetBool(keyName, true) ? 1 : 0
            }
            StatusBar.RebuildLayout()
        }
        if IsObject(this.setActionDelay)
            this.setActionDelay.Choose(this.GetActionDelayIndex())
        if IsObject(this.setOverlayPosition)
            this.setOverlayPosition.Choose(this.GetOverlayPositionIndex())
        this.RefreshLandsraadResetDropdowns()

        this.RefreshProfileDropdown()
        this.RefreshStatsDisplay()
        this.RefreshStatusOverlay()
        RefreshTrayAutoRunCheck()
        this.isInitializing := wasInit
    }

    RefreshStatsDisplay() {
        if IsObject(this.statsTab)
            this.statsTab.Refresh()
    }

    RefreshProfileDropdown(updateNameEdit := true) {
        if !IsObject(this.setProfile) || !IsObject(this.profileManager)
            return

        wasInit := this.isInitializing
        this.isInitializing := true
        names := this.profileManager.GetProfileNames()
        this.setProfile.Delete()
        if (names.Length > 0)
            this.setProfile.Add(names)
        this.setProfile.Choose(this.profileManager.GetCurrentIndex())
        if (updateNameEdit && IsObject(this.setCharacterName))
            this.setCharacterName.Value := this.profileManager.GetCurrentName()
        this.isInitializing := wasInit
    }

    ApplyLoadedProfileToUi() {
        if HouseMissionDialog.IsOpen()
            HouseMissionDialog.Close()
        this.activeSlotIdx := 0
        this.RestoreMissionSelections()
        if IsObject(this.panelLabel)
            this.panelLabel.Text := "Select a house cell to assign missions"
        loop 3 {
            if (this.mRow.Length < A_Index)
                continue
            row := this.mRow[A_Index]
            row.ddl.Delete()
            row.ddl.Choose(0)
            row.ddl.Opt("+Disabled")
            row.clearEnabled := false
            this.SetTextButtonState(row.clearBtn, false)
        }
        this.RefreshProfileDropdown()
        this.RefreshSettingsControls()
        this.RefreshStatsDisplay()
        if IsObject(this.pickerTab) || IsObject(this.pickerGridTab)
            this.RefreshMissionPickerTabs()
        if IsObject(this.landsraadTab)
            this.landsraadTab.Refresh()
        if this.HasMethod("RefreshRewardsTab")
            this.RefreshRewardsTab()
        if IsObject(this.userState)
            this.userState.ResetSession()
        TravelAutoRun.Sync()

        global acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst
        if IsSet(acceptMissionsScenarioInst) && IsObject(acceptMissionsScenarioInst) && acceptMissionsScenarioInst.HasMethod("ResetSession")
            acceptMissionsScenarioInst.ResetSession()
        if IsSet(acceptTargettedMissionsScenarioInst) && IsObject(acceptTargettedMissionsScenarioInst) && acceptTargettedMissionsScenarioInst.HasMethod("ResetSession")
            acceptTargettedMissionsScenarioInst.ResetSession()
        StatusBar.RestoreIdle()

        this.RefreshStatusOverlay()
        this.ShowSessionHint()
        this.SwitchTab(this.activeTab)
    }

    OnGuildNameCommit() {
        if (this.isInitializing || !IsObject(this.setGuildName))
            return

        savedGuild := Trim(this.settingsManager.Get("guildName", "wowza"))
        curGuild := Trim(this.setGuildName.Value)
        if (StrLen(curGuild) > 25)
            curGuild := SubStr(curGuild, 1, 25)

        if (StrLen(curGuild) < 3) {
            this.setGuildName.Value := savedGuild
            this.SetStatus("Guild name must be 3-25 characters.")
            return
        }

        this.setGuildName.Value := curGuild
        if (curGuild == savedGuild)
            return

        this.settingsManager.Set("guildName", curGuild)
        this.ShowSessionHint()
    }

    OnFactionChange() {
        if (this.isInitializing || !IsObject(this.setFaction))
            return

        chosen := this.setFaction.Text
        if (chosen != "Atreides" && chosen != "Harkonnen")
            chosen := "Atreides"

        this.settingsManager.Set("faction", chosen)
        this.ShowSessionHint()
    }

    OnDebugModeChange() {
        if (this.isInitializing || !IsObject(this.setDebugMode))
            return

        debugEnabled := (this.setDebugMode.Value == 1)
        this.settingsManager.Set("debugMode", debugEnabled)

        if (IsObject(this.logger))
            this.logger.SetDebug(debugEnabled)

        this.ShowSessionHint()
    }

    OnAutoRunOnTravelChange() {
        if (this.isInitializing || !IsObject(this.setAutoRunOnTravel))
            return
        ToggleAutoRunSetting(this.setAutoRunOnTravel.Value == 1)
        this.ShowSessionHint()
    }

    OnStopWhenMnemonicRecollectionsEndChange() {
        if (this.isInitializing || !IsObject(this.setStopWhenMnemonicRecollectionsEnd))
            return
        this.settingsManager.Set("stopWhenMnemonicRecollectionsEnd", this.setStopWhenMnemonicRecollectionsEnd.Value == 1)
        this.ShowSessionHint()
    }

    OnSoundsEnabledChange() {
        if (this.isInitializing || !IsObject(this.setSoundsEnabled))
            return
        this.settingsManager.Set("soundsEnabled", this.setSoundsEnabled.Value == 1)
        this.ShowSessionHint()
    }

    OnShowOverlayChange() {
        if (this.isInitializing || !IsObject(this.setShowOverlay))
            return

        showOverlay := (this.setShowOverlay.Value == 1)
        this.settingsManager.Set("showOverlay", showOverlay)

        StatusBar.ApplyVisibility(showOverlay)

        this.ShowSessionHint()
    }

    OnShowNotificationsChange() {
        if (this.isInitializing || !IsObject(this.setShowNotifications))
            return
        enabled := (this.setShowNotifications.Value == 1)
        this.settingsManager.Set("overlayShowNotifications", enabled)
        if !enabled {
            overlay := StatusBar.overlay
            if IsObject(overlay) && overlay.HasMethod("HideSplash")
                overlay.HideSplash()
        }
        this.ShowSessionHint()
    }

    SyncOverlayEnabledCheckbox() {
        if !IsObject(this.setShowOverlay) || !IsObject(this.settingsManager)
            return
        wasInit := this.isInitializing
        this.isInitializing := true
        this.setShowOverlay.Value := this.settingsManager.GetBool("showOverlay", true) ? 1 : 0
        this.isInitializing := wasInit
    }

    MakeOverlaySectionHandler(settingKey) {
        return (*) => this.OnOverlaySectionChange(settingKey)
    }

    OnOverlaySectionChange(settingKey) {
        if (this.isInitializing || !IsObject(this.overlaySectionChecks) || !this.overlaySectionChecks.Has(settingKey))
            return
        enabled := (this.overlaySectionChecks[settingKey].Value == 1)
        this.settingsManager.Set(settingKey, enabled)
        StatusBar.RebuildLayout()
        this.ShowSessionHint()
    }

    GetOverlayPositionKeys() {
        return ["topLeft", "topMiddle", "bottomLeft", "topRight", "bottomRight"]
    }

    GetOverlayPositionLabels() {
        return ["Top left", "Top middle", "Bottom left", "Top right", "Bottom right"]
    }

    GetOverlayPositionIndex() {
        current := "topLeft"
        if IsObject(this.settingsManager)
            current := this.settingsManager.Get("overlayPosition", "topLeft")
        keys := this.GetOverlayPositionKeys()
        loop keys.Length {
            if (keys[A_Index] == current)
                return A_Index
        }
        return 1
    }

    OnOverlayPositionChange() {
        if (this.isInitializing || !IsObject(this.setOverlayPosition))
            return
        keys := this.GetOverlayPositionKeys()
        idx := this.setOverlayPosition.Value
        posKey := "topLeft"
        if (idx >= 1 && idx <= keys.Length)
            posKey := keys[idx]
        this.settingsManager.Set("overlayPosition", posKey)
        StatusBar.RebuildLayout()
        this.ShowSessionHint()
    }

    GetActionDelayValues() {
        return [40, 50, 75, 100, 200, 300]
    }

    GetActionDelayLabels() {
        labels := []
        for _, ms in this.GetActionDelayValues()
            labels.Push(ms " ms")
        return labels
    }

    GetActionDelayIndex() {
        current := 100
        if IsObject(this.settingsManager)
            current := this.settingsManager.GetInt("actionDelay", 100)
        values := this.GetActionDelayValues()
        loop values.Length {
            if (values[A_Index] == current)
                return A_Index
        }
        return 4
    }

    OnActionDelayChange() {
        if (this.isInitializing || !IsObject(this.setActionDelay))
            return

        values := this.GetActionDelayValues()
        idx := this.setActionDelay.Value
        delayMs := 100
        if (idx >= 1 && idx <= values.Length)
            delayMs := values[idx]
        this.settingsManager.Set("actionDelay", delayMs)
        this.ShowSessionHint()
    }

    FormatHotkeyName(hotkey) {
        raw := Trim(hotkey)
        if (raw == "")
            return ""
        mods := ""
        key := raw
        loop {
            first := SubStr(key, 1, 1)
            if (first == "^") {
                mods .= "Ctrl+"
                key := SubStr(key, 2)
            } else if (first == "!") {
                mods .= "Alt+"
                key := SubStr(key, 2)
            } else if (first == "+") {
                mods .= "Shift+"
                key := SubStr(key, 2)
            } else if (first == "#") {
                mods .= "Win+"
                key := SubStr(key, 2)
            } else
                break
        }
        if (key == "")
            return Trim(raw)
        return mods . key
    }

    RefreshHotkeyDisplay() {
        fallbacks := this.settingsManager.GetHotkeyFallbacks()
        if IsObject(this.setHotkeyStart)
            this.setHotkeyStart.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyStart", fallbacks["hotkeyStart"]))
        if IsObject(this.setHotkeyStop)
            this.setHotkeyStop.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyStop", fallbacks["hotkeyStop"]))
        if IsObject(this.setHotkeyAutoRun)
            this.setHotkeyAutoRun.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyToggleAutoRun", fallbacks["hotkeyToggleAutoRun"]))
        if IsObject(this.setHotkeyToggle)
            this.setHotkeyToggle.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyToggleGui", fallbacks["hotkeyToggleGui"]))
        if IsObject(this.setHotkeyOverlay)
            this.setHotkeyOverlay.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyToggleOverlay", fallbacks["hotkeyToggleOverlay"]))
        if IsObject(this.setHotkeyReload)
            this.setHotkeyReload.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyReload", fallbacks["hotkeyReload"]))
        if IsObject(this.setHotkeyExit)
            this.setHotkeyExit.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyExit", fallbacks["hotkeyExit"]))
        this.RefreshHeaderHotkeys()
        StatusBar.Refresh()
    }

    GetHotkeyFallback(settingKey) {
        fallbacks := this.settingsManager.GetHotkeyFallbacks()
        if fallbacks.Has(settingKey)
            return fallbacks[settingKey]
        return "Pause"
    }

    GetHotkeyButton(settingKey) {
        if (settingKey == "hotkeyStart")
            return this.setHotkeyStart
        if (settingKey == "hotkeyStop")
            return this.setHotkeyStop
        if (settingKey == "hotkeyToggleAutoRun")
            return this.setHotkeyAutoRun
        if (settingKey == "hotkeyToggleGui")
            return this.setHotkeyToggle
        if (settingKey == "hotkeyToggleOverlay")
            return this.setHotkeyOverlay
        if (settingKey == "hotkeyReload")
            return this.setHotkeyReload
        return this.setHotkeyExit
    }

    GetOtherHotkeyValues(settingKey) {
        keys := []
        fallbacks := this.settingsManager.GetHotkeyFallbacks()
        for _, key in this.settingsManager.GetHotkeySettingKeys() {
            if (key == settingKey)
                continue
            keys.Push(this.settingsManager.Get(key, fallbacks[key]))
        }
        return keys
    }

    CaptureHotkey(settingKey) {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return

        otherKeys := this.GetOtherHotkeyValues(settingKey)
        targetBtn := this.GetHotkeyButton(settingKey)
        if IsObject(targetBtn)
            targetBtn.Text := "Press a key…"

        this.SetStatus("Press a key to rebind. Esc cancels.")

        SuspendAppHotkeys()

        ih := InputHook("T12")
        ih.KeyOpt("{All}", "E")
        ih.KeyOpt("{LControl}{RControl}{LAlt}{RAlt}{LShift}{RShift}{LWin}{RWin}", "-E")
        ih.Start()
        ih.Wait()

        newKey := ""
        if (ih.EndReason == "EndKey" && ih.EndKey != "" && ih.EndKey != "Escape")
            newKey := ih.EndMods . ih.EndKey

        if (newKey == "") {
            ApplyAppHotkeys()
            this.RefreshHotkeyDisplay()
            this.SetStatus("Keybind unchanged.")
            return
        }

        for _, otherKey in otherKeys {
            if (StrLower(newKey) == StrLower(otherKey)) {
                ApplyAppHotkeys()
                this.RefreshHotkeyDisplay()
                this.SetStatus("That key is already used by another action.")
                return
            }
        }

        this.settingsManager.Set(settingKey, newKey)
        if !ApplyAppHotkeys() {
            this.settingsManager.Set(settingKey, this.GetHotkeyFallback(settingKey))
            ApplyAppHotkeys()
            this.RefreshHotkeyDisplay()
            this.SetStatus("That key cannot be used. Reverted.")
            return
        }

        this.RefreshHotkeyDisplay()
        this.ShowSessionHint()
    }
}
