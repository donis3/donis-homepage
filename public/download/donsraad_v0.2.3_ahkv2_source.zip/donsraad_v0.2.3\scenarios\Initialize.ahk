#Requires AutoHotkey v2.0+

/**
 * Initialize Scenario
 * - Reads player state and saves it.
 *
 * Flow:
 * 1. Open Landsraad (landsraad_button.png / key L) and confirm the active missions sub-tab.
 * 2. Read mnemonic device, then read active mission slots.
 * 3. Claim any completed actives (AcceptCompleteMissions), then read remaining slots.
 * 4. Save remaining actives to player state with isTargetted flags.
 * 5. If remaining actives do not fully match the targetted set, disband/recreate guild
 *    (RemoveActiveMissions) to clear them.
 * 6. If all targetted missions are already active, stop.
 */
class InitializeScenario {
    stateManager := ""
    logger := ""
    anchorMatcher := ""
    userState := ""
    acceptCompleteMissionsScenario := ""
    removeActiveMissionsScenario := ""

    __New(stateManagerInst := "", loggerInst := "", anchorMatcherInst := "", userStateInst := "", acceptCompleteMissionsScenarioInst := "", removeActiveMissionsScenarioInst := "") {
        this.stateManager := stateManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.userState := userStateInst
        this.acceptCompleteMissionsScenario := acceptCompleteMissionsScenarioInst
        this.removeActiveMissionsScenario := removeActiveMissionsScenarioInst
    }

    /**
     * Ensures the game window is active if it is running, or waits briefly if requested.
     */
    EnsureGameActive() {
        return GameWindow.Activate()
    }

    /**
     * Executes the initialization scenario.
     * @param {Boolean} closeMenu - When true, send Esc after reading actives.
     * @returns {Boolean} - True if initialize completed (or all targeted missions are already active), false on error / no targets.
     */
    Execute(closeMenu := false) {
        StatusBar.PinBottomLeft()
        try {
            this.Debug("[Initialize] Starting initialization scenario...")

            if !this.HasTargetedMissions() {
                this.Log("No targeted missions selected.")
                return false
            }

            ; Ensure game window is focused if present
            this.EnsureGameActive()

            ; Step 1: Read and persist player state
            if IsObject(this.stateManager) {
                this.stateManager.LoadPlayerState()
                this.stateManager.SavePlayerState()
                this.Debug("[Initialize] Player state verified and saved.")
            }

            if !this.EnsureLandsraadTab()
                return false
            if !this.EnsureActiveMissionsSubTab()
                return false

            this.ReadAndSaveMnemonicDevice()

            if !this.ClaimCompletedActiveMissions()
                return false

            success := this.ProcessActiveMissions()
            if (success) {
                if !this.ClearLeftoverActivesIfNeeded()
                    return false
                this.MarkInitialized()
            }
            if (closeMenu)
                this.CloseOpenMenu()
            return success
        } finally {
            StatusBar.ClearBottomLeftPin()
        }
    }

    EnsureLandsraadTab() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("LandsraadTabButton") {
            this.Log("[Initialize] Error: LandsraadTabButton configuration missing in GameConstants.")
            return false
        }

        searchArea := this.GetLandsraadTabSearchArea()
        if !IsObject(searchArea) {
            this.Log("[Initialize] Error: Landsraad tab search area could not be calculated.")
            return false
        }

        imageName := "landsraad_button.png"
        variation := 30
        foundX := 0, foundY := 0

        this.Debug("[Initialize] Searching for " imageName " in region [" searchArea.x1 ", " searchArea.y1 ", " searchArea
            .x2 ", " searchArea.y2 "]...")

        found := this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, variation)
        if (!found) {
            this.Debug("[Initialize] Landsraad tab button not found. Sending key 'L' (game input)...")
            InputHelper.SendGameKey("l", 60)
            startTime := A_TickCount
            while (A_TickCount - startTime < 1500) {
                if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, variation) {
                    found := true
                    break
                }
                Sleep(40)
            }
        }

        if (!found) {
            this.Log("[Initialize] Error: Landsraad tab button could not be found. Mission menu could not be opened.")
            return false
        }

        this.Debug("[Initialize] Landsraad button detected at (" foundX ", " foundY "). Landsraad tab confirmed.")
        return true
    }

    EnsureActiveMissionsSubTab() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("LandsraadSubTabButton") {
            this.Log("[Initialize] Error: LandsraadSubTabButton configuration missing in GameConstants.")
            return false
        }

        loop 2 {
            this.ClickActiveMissionsSubTab()
            if this.WaitForActiveMissionsSubTab(1500) {
                this.Debug("[Initialize] Active missions sub-tab confirmed.")
                return true
            }
            this.Debug("[Initialize] Active missions sub-tab not confirmed yet. Retrying...")
        }

        this.Log("[Initialize] Error: Active missions sub-tab did not open.")
        return false
    }

    ClickActiveMissionsSubTab() {
        global GameConstants
        subTabConfig := GameConstants["GameUI"]["LandsraadSubTabButton"]
        subPos := ResolutionManager().coords(subTabConfig.x, subTabConfig.y)
        this.Debug("[Initialize] Clicking active missions sub-tab at (" subPos.x ", " subPos.y ")...")
        InputHelper.FastClick(subPos.x, subPos.y)
    }

    WaitForActiveMissionsSubTab(timeoutMs := 1500) {
        startTime := A_TickCount
        while (A_TickCount - startTime < timeoutMs) {
            if this.IsLandsraadTabVisible() && this.IsMnemonicHudVisible()
                return true
            Sleep(50)
        }
        return this.IsLandsraadTabVisible() && this.IsMnemonicHudVisible()
    }

    IsLandsraadTabVisible() {
        searchArea := this.GetLandsraadTabSearchArea()
        if !IsObject(searchArea)
            return false
        foundX := 0, foundY := 0
        return this.anchorMatcher.FindAnchor("landsraad_button.png", &foundX, &foundY, searchArea, 30)
    }

    GetLandsraadTabSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("LandsraadTabButton")
            return ""
        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        return ResolutionManager().searchFromConfig(tabBtnConfig, 20)
    }

    /**
     * The mnemonic badge only exists on Landsraad → Active Missions.
     * Gold HUD pixels in that box mean the sub-tab has actually opened.
     */
    IsMnemonicHudVisible() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("MnemonicDeviceTextArea")
            return false

        area := GameConstants["GameUI"]["MnemonicDeviceTextArea"]
        rect := ResolutionManager().rect(area.x, area.y, area.w, area.h)
        pBitmap := Gdip_BitmapFromScreen(rect.x, rect.y, Max(1, rect.w), Max(1, rect.h))
        if (!pBitmap)
            return false

        goldCount := 0
        bitmapData := ""
        w := Gdip_GetImageWidth(pBitmap)
        h := Gdip_GetImageHeight(pBitmap)
        if (w > 0 && h > 0 && !Gdip_LockBits(pBitmap, 0, 0, w, h, &bitmapData, 0x26200A, 1)) {
            stride := NumGet(bitmapData, 8, "int")
            scan0 := NumGet(bitmapData, 16, "ptr")
            loop h {
                row := scan0 + ((A_Index - 1) * stride)
                loop w {
                    px := row + ((A_Index - 1) * 4)
                    b := NumGet(px, 0, "uchar")
                    gVal := NumGet(px, 1, "uchar")
                    r := NumGet(px, 2, "uchar")
                    if (r >= 150 && gVal >= 110 && b <= 160 && r > b + 20)
                        goldCount += 1
                }
            }
            Gdip_UnlockBits(pBitmap, &bitmapData)
        }
        Gdip_DisposeImage(pBitmap)
        return goldCount >= 12
    }

    MarkInitialized() {
        if IsObject(this.userState)
            this.userState.SetInitialized(true)
    }

    ReadAndSaveMnemonicDevice() {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("SetMnemonicDevice") {
            this.Debug("[Initialize] State manager cannot store mnemonic device. Skipping read.")
            return false
        }

        parsed := this.ReadMnemonicDevice()
        if !IsObject(parsed) {
            this.Debug("[Initialize] Mnemonic device text was not read. Keeping saved value "
                this.stateManager.GetMnemonicDeviceText() ".")
            return false
        }

        this.stateManager.SetMnemonicDevice(parsed.current, parsed.max)
        this.Debug("[Initialize] Mnemonic device: " this.stateManager.GetMnemonicDeviceText())
        StatusBar.Refresh()
        RefreshDashboardFooter()
        return true
    }

    ReadMnemonicDevice() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("MnemonicDeviceTextArea") {
            this.Debug("[Initialize] MnemonicDeviceTextArea is missing from GameConstants.")
            return ""
        }

        area := GameConstants["GameUI"]["MnemonicDeviceTextArea"]
        rm := ResolutionManager()
        rect := rm.rect(area.x, area.y, area.w, area.h)
        ocrLang := this.GetOcrLanguage()

        this.Debug("[Initialize] Reading mnemonic device at [" rect.x ", " rect.y ", " rect.w ", " rect.h "]...")
        attempts := 8
        loop attempts {
            try {
                ocrResult := Ocr.FromHudRect(rect.x, rect.y, rect.w, rect.h, ocrLang)
                normalized := Ocr.NormalizeText(ocrResult.text)
                parsed := this.ParseMnemonicDeviceText(normalized)
                if IsObject(parsed) {
                    this.Debug("[Initialize] Mnemonic OCR `"" normalized "`" -> " parsed.current "/" parsed.max)
                    return parsed
                }
                this.Debug("[Initialize] Mnemonic OCR attempt " A_Index "/" attempts " did not match current/max: `"" normalized "`"")
            } catch as err {
                this.Debug("[Initialize] Mnemonic OCR attempt " A_Index "/" attempts " failed: " err.Message)
            }
            Sleep(150)
        }
        return ""
    }

    ParseMnemonicDeviceText(rawText) {
        norm := Trim(rawText)
        if (norm == "")
            return ""

        ; Twin 1s (11/35) often OCR as "1 1/35", "l1/35", or "I1/35".
        norm := StrReplace(norm, "I", "1")
        norm := StrReplace(norm, "l", "1")
        norm := StrReplace(norm, "|", "1")
        loop 3
            norm := RegExReplace(norm, "(\d)\s+(?=\d\s*[\/\\1])", "$1")

        current := ""
        maxVal := ""
        if RegExMatch(norm, "(\d{1,2})\s*[\/\\]\s*(\d{1,2})", &m) {
            current := m[1]
            maxVal := m[2]
        } else if RegExMatch(norm, "(\d+)\s+(\d+)", &m) {
            current := m[1]
            maxVal := m[2]
        } else if RegExMatch(norm, "^\d{3,4}$") && RegExMatch(norm, "(\d{1,2})(\d{2})$", &m) {
            current := m[1]
            maxVal := m[2]
        } else
            return ""

        cur := Integer(current)
        cap := Integer(maxVal)
        if (cur < 0)
            cur := 0
        if (cap < 1)
            return ""
        if (cur > cap)
            cur := cap
        return { current: cur, max: cap }
    }

    CloseOpenMenu() {
        this.Debug("[Initialize] Sending Esc to close the open menu.")
        InputHelper.SendGameKey("Esc")
    }

    /**
     * Steps 2-5: OCR the 3 active mission slots, persist them, then compare against targeted missions.
     */
    ProcessActiveMissions() {
        if !IsObject(this.stateManager) {
            this.Log("[Initialize] Error: State manager is unavailable; cannot process active missions.")
            return false
        }

        this.Debug("[Initialize] Reading active mission slots...")
        ocrResults := this.ReadActiveMissions()
        targetedMissions := this.stateManager.GetTargetedMissions()
        targetedNames := Map()
        for _, targeted in targetedMissions {
            if (targeted.missionName != "")
                targetedNames[StrLower(targeted.missionName)] := true
        }

        activeMissions := []
        for _, result in ocrResults {
            if (result.matchedName == "" || result.confidence < 0.4)
                continue

            isTargetted := targetedNames.Has(StrLower(result.matchedName))
            houseName := ""
            global profileManagerInst
            if IsSet(profileManagerInst) && IsObject(profileManagerInst)
                && profileManagerInst.HasMethod("ResolveHouseForActiveMission")
                houseName := profileManagerInst.ResolveHouseForActiveMission(result.matchedName, this.stateManager)
            activeMissions.Push({
                missionName: result.matchedName,
                specialization: result.specialization,
                isTargetted: isTargetted,
                house: houseName
            })
        }

        this.stateManager.SaveActiveMissions(activeMissions)

        if (activeMissions.Length == 0)
            this.Debug("[Initialize] No active missions detected in the 3 slots.")
        else {
            this.Debug("[Initialize] Saved " activeMissions.Length " active mission(s) to player state.")
            for _, mission in activeMissions {
                targetInfo := mission.isTargetted ? "targetted" : "not targetted"
                specInfo := mission.specialization != "" ? " [" mission.specialization "]" : ""
                houseInfo := mission.HasOwnProp("house") && mission.house != "" ? " @ " mission.house : ""
                this.Debug("[Initialize] Active: `"" mission.missionName "`"" specInfo houseInfo " (" targetInfo ")")
            }
        }

        if !this.HasTargetedMissions() {
            this.Log("No targeted missions selected.")
            this.SetAvailableTargetedCount(0)
            return false
        }

        missing := []
        for _, targeted in targetedMissions {
            foundActive := false
            for _, active in activeMissions {
                if (StrLower(active.missionName) == StrLower(targeted.missionName)) {
                    foundActive := true
                    break
                }
            }
            if (!foundActive)
                missing.Push(targeted.missionName)
        }

        if (missing.Length == 0 && this.AllTargetedMissionsAreActive()) {
            this.Debug("[Initialize] Remaining actives match the targetted set.")
            this.SetAvailableTargetedCount(targetedMissions.Length)
            return true
        }

        extraCount := activeMissions.Length - (targetedMissions.Length - missing.Length)
        if (extraCount < 0)
            extraCount := 0
        if (missing.Length > 0)
            this.Debug("[Initialize] " missing.Length " targetted mission(s) are not active: " this.JoinNames(missing) ".")
        if (extraCount > 0)
            this.Debug("[Initialize] " extraCount " leftover non-targetted active mission(s) remain.")
        this.SetAvailableTargetedCount(0)
        return true
    }

    ClaimCompletedActiveMissions() {
        if !IsObject(this.acceptCompleteMissionsScenario) {
            this.Debug("[Initialize] AcceptCompleteMissions is unavailable. Skipping claim step.")
            return true
        }

        this.Debug("[Initialize] Checking for completed active missions...")
        StatusBar.SetStatus("Claim completed", "working")
        if !this.acceptCompleteMissionsScenario.Execute() {
            this.Log("Error: Failed to claim completed missions.")
            return false
        }
        return true
    }

    ClearLeftoverActivesIfNeeded() {
        if !this.HasActiveMissions() {
            this.Debug("[Initialize] No leftover active missions to remove.")
            return true
        }
        if this.AllTargetedMissionsAreActive() {
            this.Debug("[Initialize] Remaining actives match the targetted set. Skipping disband.")
            return true
        }

        if !IsObject(this.removeActiveMissionsScenario) {
            this.Log("[Initialize] Error: RemoveActiveMissions is unavailable; leftover actives were not cleared.")
            return false
        }

        this.Debug("[Initialize] Active missions do not fully match the targetted set. Disbanding guild to clear them...")
        StatusBar.SetStatus("Remove missions", "working")
        if !this.removeActiveMissionsScenario.Execute() {
            this.Log("[Initialize] Error: RemoveActiveMissions failed.")
            return false
        }

        this.stateManager.SaveActiveMissions([])
        this.SetAvailableTargetedCount(0)
        this.Debug("[Initialize] Leftover active missions cleared.")
        return true
    }

    HasActiveMissions() {
        if !IsObject(this.stateManager)
            return false
        active := this.stateManager.GetActiveMissions()
        return (active is Array) && active.Length > 0
    }

    AllTargetedMissionsAreActive() {
        if !IsObject(this.stateManager)
            return false
        targeted := this.stateManager.GetTargetedMissions()
        active := this.stateManager.GetActiveMissions()
        if (!(targeted is Array) || targeted.Length == 0)
            return false
        if (!(active is Array) || active.Length == 0)
            return false

        targetedNames := Map()
        targetedCount := 0
        for _, mission in targeted {
            if (mission.missionName == "")
                continue
            targetedCount += 1
            targetedNames[StrLower(mission.missionName)] := true
        }

        activeNames := Map()
        activeCount := 0
        for _, mission in active {
            if (mission.missionName == "")
                continue
            activeCount += 1
            nameKey := StrLower(mission.missionName)
            activeNames[nameKey] := true
            if !targetedNames.Has(nameKey)
                return false
        }

        if (targetedCount == 0 || activeCount == 0 || activeCount != targetedCount)
            return false

        for nameKey, _ in targetedNames {
            if !activeNames.Has(nameKey)
                return false
        }
        return true
    }

    SetAvailableTargetedCount(count) {
        if IsObject(this.userState)
            this.userState.SetAvailableTargetedCount(count)
        StatusBar.Refresh()
    }

    /**
     * Calculates screen bounding boxes for the 3 vertical active mission slots.
     */
    GetActiveMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("ActiveMissionFirstPosition") || !uiConfig.Has("ActiveMissionTextSize")
            return []

        firstPos := uiConfig["ActiveMissionFirstPosition"]
        textSize := uiConfig["ActiveMissionTextSize"]
        spacing := uiConfig.Has("ActiveMissionSpacing") ? uiConfig["ActiveMissionSpacing"] : 0

        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            refX := firstPos.x
            refY := firstPos.y + ((missionIndex - 1) * spacing)
            refW := textSize.x
            refH := textSize.y

            pos := rm.coords(refX, refY)
            size := rm.dimensions(refW, refH)

            boxes.Push({
                index: missionIndex,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    /**
     * Reads text inside each active mission slot via WinRT OCR and matches against the mission DB.
     */
    ReadActiveMissions() {
        boxes := this.GetActiveMissionBoxes()
        if (boxes.Length == 0) {
            this.Log("[Initialize] Error: Unable to determine active mission box positions from GameConstants.")
            return []
        }

        candidates := this.GetCandidateMissions()
        ocrLang := this.GetOcrLanguage()
        results := []

        this.Debug("[Initialize] Scanning " boxes.Length " active mission slots...")

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                rawText := ocrResult.text
                normalized := Ocr.NormalizeText(rawText)
                matched := Ocr.FindBestMatch(normalized, candidates)

                matchedName := matched.matchedName
                specialization := ""
                matchedItem := matched.HasOwnProp("item") ? matched.item : ""
                if (IsObject(matchedItem) && matchedItem.HasOwnProp("specialization"))
                    specialization := matchedItem.specialization
                else if (IsObject(matchedItem) && matchedItem is Map && matchedItem.Has("specialization"))
                    specialization := matchedItem["specialization"]
                else if (IsObject(this.stateManager))
                    specialization := this.stateManager.GetMissionSpecialization(matchedName)

                results.Push({
                    index: box.index,
                    matchedName: (matched.confidence >= 0.4) ? matchedName : "",
                    specialization: specialization,
                    confidence: matched.confidence,
                    normalizedText: normalized
                })

                if (matchedName != "" && matched.confidence >= 0.4) {
                    specInfo := specialization != "" ? " [" specialization "]" : ""
                    this.Debug("[Initialize] Slot " box.index ": `"" matchedName "`"" specInfo " (Raw: `"" normalized "`")")
                } else if (normalized != "") {
                    this.Debug("[Initialize] Slot " box.index ": `"" normalized "`" (Unrecognized)")
                } else {
                    this.Debug("[Initialize] Slot " box.index ": (Empty / No text detected)")
                }
            } catch as err {
                this.Debug("[Initialize] Error reading Slot " box.index ": " err.Message)
                results.Push({
                    index: box.index,
                    matchedName: "",
                    specialization: "",
                    confidence: 0.0,
                    normalizedText: ""
                })
            }
        }

        return results
    }

    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        return []
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    HasTargetedMissions() {
        if !IsObject(this.stateManager)
            return false
        targeted := this.stateManager.GetTargetedMissions()
        return (targeted is Array) && targeted.Length > 0
    }

    JoinNames(names) {
        joined := ""
        for idx, name in names {
            if (idx > 1)
                joined .= ", "
            joined .= name
        }
        return joined
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
