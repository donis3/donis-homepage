#Requires AutoHotkey v2.0+

/**
 * Landsraad house grid tooltip scan — house name OCR and personal contribution.
 * Production scans use showDebugBoxes := false; HouseScanDebug enables overlays.
 */
class HouseGridScanner {
    logger := ""
    anchorMatcher := ""
    stateManager := ""
    houseTextImage := "landsraad_house_text.png"
    personalTextImage := "landsraad_personal_text.png"
    imageVariation := 30
    tooltipFadeWaitMs := 150
    ocrBoxFlashMs := 200
    rewardsBandOcrMaxRetries := 2
    rewardsBandOcrRetryMs := 100
    showDebugBoxes := false

    __New(loggerInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.stateManager := stateManagerInst
    }

    ScanAllCells(startRow := 1, endRow := 0) {
        gridSize := this.GetGridSize()
        if (endRow < 1 || endRow > gridSize)
            endRow := gridSize
        startRow := Max(1, Min(startRow, gridSize))
        results := []

        Loop (endRow - startRow + 1) {
            row := startRow + A_Index - 1
            Loop gridSize {
                col := A_Index
                if this.IsCancelled()
                    return results
                results.Push(this.ScanCell(row, col))
            }
        }
        return results
    }

    GetGridSize() {
        global GameConstants
        if IsObject(GameConstants) && GameConstants.Has("GameUI")
            && GameConstants["GameUI"].Has("HouseGridSize")
            return GameConstants["GameUI"]["HouseGridSize"]
        return 5
    }

    ScanCell(gridRow, gridCol) {
        empty := {
            row: gridRow,
            col: gridCol,
            slot: 0,
            houseName: "",
            contribution: 0,
            contributionParsed: false,
            found: false,
            notRevealed: false,
            missionsRevealed: false,
            rewards: Ocr.MakeEmptyHouseRewardEntries()
        }

        cell := this.GetGridCell(gridRow, gridCol)
        if !IsObject(cell)
            return empty

        empty.slot := cell.slot
        areas := this.GetTooltipSearchAreas(cell)
        if !IsObject(areas)
            return empty

        this.HoverCell(cell)

        result := this.TryReadCellTooltip(cell, areas)
        if IsObject(result)
            return result

        return empty
    }

    TryReadCellTooltip(cell, areas) {
        waitMs := this.tooltipFadeWaitMs

        result := this.SearchHouseText(cell, areas)
        if (IsObject(result) && result.found)
            return result

        this.Debug("[HouseGrid] Slot " cell.slot ": Tooltip not found, retrying after " waitMs "ms...")
        Sleep(waitMs)
        result := this.SearchHouseText(cell, areas)
        if (IsObject(result) && result.found)
            return result

        this.Debug("[HouseGrid] Slot " cell.slot " (row " cell.row ", col " cell.col
            "): House text not found after retry.")
        return {
            row: cell.row,
            col: cell.col,
            slot: cell.slot,
            houseName: "",
            contribution: 0,
            contributionParsed: false,
            found: false,
            notRevealed: true,
            missionsRevealed: false,
            rewards: Ocr.MakeEmptyHouseRewardEntries()
        }
    }

    GetGridCell(gridRow, gridCol) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("FirstGridPosition") || !uiConfig.Has("GridCellSize") || !uiConfig.Has("GridSpacing")
            return ""

        gridSize := uiConfig.Has("HouseGridSize") ? uiConfig["HouseGridSize"] : 5
        if (gridRow < 1 || gridCol < 1 || gridRow > gridSize || gridCol > gridSize)
            return ""

        firstPos := uiConfig["FirstGridPosition"]
        cellSize := uiConfig["GridCellSize"]
        spacing := uiConfig["GridSpacing"]
        col := gridCol - 1
        row := gridRow - 1
        rm := ResolutionManager()

        refX := firstPos.x + (col * (cellSize.x + spacing.x))
        refY := firstPos.y + (row * (cellSize.y + spacing.y))
        refW := cellSize.x
        refH := cellSize.y
        pos := rm.coords(refX, refY)
        size := rm.dimensions(refW, refH)
        center := rm.coords(refX + (refW / 2), refY + (refH / 2))

        return {
            row: gridRow,
            col: gridCol,
            slot: (row * gridSize) + col + 1,
            refX: refX,
            refY: refY,
            refW: refW,
            refH: refH,
            screenX: pos.x,
            screenY: pos.y,
            screenW: Max(1, Round(size.w)),
            screenH: Max(1, Round(size.h)),
            hoverX: center.x,
            hoverY: center.y
        }
    }

    GetTooltipSearchAreas(cell) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("HouseTooltipRightOffset") || !uiConfig.Has("HouseTooltipLeftOffset")
            || !uiConfig.Has("HouseTooltipWidth") || !uiConfig.Has("HouseTooltipHeight") {
            this.Debug("[HouseGrid] House tooltip constants missing in GameConstants.")
            return ""
        }

        tooltipW := uiConfig["HouseTooltipWidth"]
        tooltipH := uiConfig["HouseTooltipHeight"]
        searchYOffset := uiConfig.Has("HouseTooltipSearchYOffset") ? uiConfig["HouseTooltipSearchYOffset"] : 0
        rightOffset := uiConfig["HouseTooltipRightOffset"]
        leftOffset := uiConfig["HouseTooltipLeftOffset"]
        searchRefY := cell.refY + searchYOffset

        rightBox := this.BuildTooltipBox(cell.refX + rightOffset, searchRefY, tooltipW, tooltipH)
        leftBox := this.BuildTooltipBox(cell.refX - leftOffset, searchRefY, tooltipW, tooltipH)

        return { right: rightBox, left: leftBox }
    }

    BuildTooltipBox(refX, refY, refW, refH) {
        rm := ResolutionManager()
        pos := rm.coords(refX, refY)
        size := rm.dimensions(refW, refH)
        screenW := Max(1, Round(size.w))
        screenH := Max(1, Round(size.h))

        return {
            refX: refX,
            refY: refY,
            refW: refW,
            refH: refH,
            screenX: pos.x,
            screenY: pos.y,
            screenW: screenW,
            screenH: screenH,
            searchArea: {
                x1: pos.x,
                y1: pos.y,
                x2: pos.x + screenW,
                y2: pos.y + screenH
            }
        }
    }

    HoverCell(cell) {
        this.Debug("[HouseGrid] Hovering cell row " cell.row " col " cell.col
            " (slot " cell.slot ") at (" cell.hoverX ", " cell.hoverY ").")
        InputHelper.FastMove(cell.hoverX, cell.hoverY)
        if (this.tooltipFadeWaitMs > 0)
            Sleep(this.tooltipFadeWaitMs)
    }

    SearchHouseText(cell, areas) {
        if !IsObject(this.anchorMatcher) {
            this.Log("[HouseGrid] Error: AnchorMatcher is unavailable.")
            return ""
        }

        match := this.TryFindHouseText(cell, areas)
        if (match.found)
            return this.BuildCellScanResult(cell, match.foundX, match.foundY, match.side, match.area)

        return { houseName: "", contribution: 0, contributionParsed: false, found: false, notRevealed: false
            , missionsRevealed: false, rewards: Ocr.MakeEmptyHouseRewardEntries() }
    }

    TryFindHouseText(cell, areas) {
        foundX := 0, foundY := 0
        rightArea := areas.right.searchArea
        this.Debug("[HouseGrid] Searching right tooltip area ["
            rightArea.x1 ", " rightArea.y1 ", " rightArea.x2 ", " rightArea.y2 "]...")
        rightOverlay := this.ShowDebugBoxAtScreen(rightArea.x1, rightArea.y1
            , rightArea.x2 - rightArea.x1, rightArea.y2 - rightArea.y1)

        if this.FindHouseTextInArea(rightArea, &foundX, &foundY) {
            this.CloseDebugBox(rightOverlay)
            this.Debug("[HouseGrid] Slot " cell.slot " (row " cell.row ", col " cell.col
                "): House text found on right at (" foundX ", " foundY ").")
            return { found: true, side: "right", foundX: foundX, foundY: foundY, area: areas.right }
        }
        this.CloseDebugBox(rightOverlay)

        this.Debug("[HouseGrid] Right area: not found. Searching left tooltip area ["
            areas.left.searchArea.x1 ", " areas.left.searchArea.y1 ", "
            areas.left.searchArea.x2 ", " areas.left.searchArea.y2 "]...")
        leftOverlay := this.ShowDebugBoxAtScreen(areas.left.searchArea.x1, areas.left.searchArea.y1
            , areas.left.searchArea.x2 - areas.left.searchArea.x1
            , areas.left.searchArea.y2 - areas.left.searchArea.y1)

        foundX := 0, foundY := 0
        if this.FindHouseTextInArea(areas.left.searchArea, &foundX, &foundY) {
            this.CloseDebugBox(leftOverlay)
            this.Debug("[HouseGrid] Slot " cell.slot " (row " cell.row ", col " cell.col
                "): House text found on left at (" foundX ", " foundY ").")
            return { found: true, side: "left", foundX: foundX, foundY: foundY, area: areas.left }
        }
        this.CloseDebugBox(leftOverlay)

        return { found: false }
    }

    BuildCellScanResult(cell, anchorScreenX, anchorScreenY, side, area) {
        houseResult := this.ReadHouseName(cell, anchorScreenX, anchorScreenY)

        houseName := ""
        if IsObject(houseResult) {
            if (houseResult.matchedName != "" && houseResult.confidence >= 0.4)
                houseName := houseResult.matchedName
            else if (houseResult.normalizedText != "")
                houseName := houseResult.normalizedText
        }

        personalResult := this.SearchPersonalText(cell, anchorScreenX, anchorScreenY)
        missionsRevealed := IsObject(personalResult) && personalResult.found
        rewards := Ocr.MakeEmptyHouseRewardEntries()

        if !missionsRevealed {
            this.Debug("[HouseGrid] Slot " cell.slot " (row " cell.row ", col " cell.col
                "): Personal contribution text not found — missions not yet revealed.")
            return {
                row: cell.row,
                col: cell.col,
                slot: cell.slot,
                houseName: houseName,
                contribution: 0,
                contributionParsed: false,
                found: true,
                notRevealed: false,
                missionsRevealed: false,
                rewards: rewards,
                side: side,
                foundX: anchorScreenX,
                foundY: anchorScreenY,
                area: area,
                houseResult: houseResult,
                personalResult: personalResult
            }
        }

        rewardsData := this.ReadHouseRewardsData(anchorScreenX, anchorScreenY, personalResult.foundY)
        rewards := IsObject(rewardsData) ? rewardsData.entries : Ocr.MakeEmptyHouseRewardEntries()
        rewardsBandOcr := IsObject(rewardsData) ? rewardsData.ocr : ""
        rewardsBandParsed := IsObject(rewardsData) ? rewardsData.parsed : ""
        rewardsBandRawText := (IsObject(rewardsData) && IsObject(rewardsData.parsed)) ? rewardsData.parsed.rawText : ""
        rewardsBandBox := IsObject(rewardsData) ? rewardsData.box : ""

        contribution := 0
        contributionParsed := false
        if personalResult.contributionParsed {
            contribution := personalResult.contribution
            contributionParsed := true
        }

        return {
            row: cell.row,
            col: cell.col,
            slot: cell.slot,
            houseName: houseName,
            contribution: contribution,
            contributionParsed: contributionParsed,
            found: true,
            notRevealed: false,
            missionsRevealed: true,
            rewards: rewards,
            rewardsBandOcr: rewardsBandOcr,
            rewardsBandParsed: rewardsBandParsed,
            rewardsBandRawText: rewardsBandRawText,
            rewardsBandBox: rewardsBandBox,
            side: side,
            foundX: anchorScreenX,
            foundY: anchorScreenY,
            area: area,
            houseResult: houseResult,
            personalResult: personalResult
        }
    }

    FindHouseTextInArea(searchArea, &foundX, &foundY) {
        return this.FindImageInArea(this.houseTextImage, searchArea, &foundX, &foundY)
    }

    FindPersonalTextInArea(searchArea, &foundX, &foundY) {
        return this.FindImageInArea(this.personalTextImage, searchArea, &foundX, &foundY)
    }

    FindImageInArea(imageName, searchArea, &foundX, &foundY) {
        return this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY
            , searchArea, this.imageVariation, "", false)
    }

    BuildRelativeSearchBox(anchorScreenX, anchorScreenY, rel) {
        rm := ResolutionManager()
        origin := rm.add(anchorScreenX, anchorScreenY, rel.x, rel.y)
        size := rm.dimensions(rel.w, rel.h)
        screenW := Max(1, Round(size.w))
        screenH := Max(1, Round(size.h))

        return {
            screenX: origin.x,
            screenY: origin.y,
            screenW: screenW,
            screenH: screenH,
            searchArea: {
                x1: origin.x,
                y1: origin.y,
                x2: origin.x + screenW,
                y2: origin.y + screenH
            }
        }
    }

    SearchPersonalText(cell, anchorScreenX, anchorScreenY) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("HousePersonalTextImgOffsetRelativeToTooltip") {
            this.Log("[HouseGrid] Error: HousePersonalTextImgOffsetRelativeToTooltip missing in GameConstants.")
            return ""
        }

        rel := uiConfig["HousePersonalTextImgOffsetRelativeToTooltip"]
        box := this.BuildRelativeSearchBox(anchorScreenX, anchorScreenY, rel)

        this.Debug("[HouseGrid] Searching personal text in area ["
            box.searchArea.x1 ", " box.searchArea.y1 ", " box.searchArea.x2 ", " box.searchArea.y2
            "] (relative to house text at " anchorScreenX ", " anchorScreenY ").")
        personalOverlay := this.ShowDebugBoxAtScreen(box.screenX, box.screenY, box.screenW, box.screenH)

        foundX := 0, foundY := 0
        if this.FindPersonalTextInArea(box.searchArea, &foundX, &foundY) {
            this.Debug("[HouseGrid] Slot " cell.slot ": Personal text found at (" foundX ", " foundY ").")
            contribResult := this.ReadPersonalContribution(cell, anchorScreenX, foundX, foundY)
            this.CloseDebugBox(personalOverlay)
            if IsObject(contribResult) {
                return {
                    found: true,
                    foundX: foundX,
                    foundY: foundY,
                    box: box,
                    contribution: contribResult.contributionValue,
                    contributionParsed: contribResult.contributionParsed,
                    rawText: contribResult.rawText,
                    normalizedText: contribResult.normalizedText
                }
            }
            return { found: true, foundX: foundX, foundY: foundY, box: box
                , contribution: 0, contributionParsed: false }
        }

        this.CloseDebugBox(personalOverlay)
        this.Debug("[HouseGrid] Slot " cell.slot ": Personal text not found in search area.")
        return { found: false, box: box, contribution: 0, contributionParsed: false }
    }

    BuildPersonalContributionRowBox(houseTextScreenX, personalTextScreenY) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""
        if !GameConstants["GameUI"].Has("PersonalContributionRowArea")
            return ""

        area := GameConstants["GameUI"]["PersonalContributionRowArea"]
        rowW := area.HasOwnProp("w") ? area.w : area["w"]
        rowH := area.HasOwnProp("h") ? area.h : area["h"]
        rowY := area.HasOwnProp("y") ? area.y : 0

        rm := ResolutionManager()
        size := rm.dimensions(rowW, rowH)
        yOffset := rm.dimensions(0, rowY).h
        screenX := houseTextScreenX
        screenY := personalTextScreenY + yOffset
        screenW := Max(1, Round(size.w))
        screenH := Max(1, Round(size.h))

        rm.ClampCapture(&screenX, &screenY, &screenW, &screenH)

        return {
            screenX: screenX,
            screenY: screenY,
            screenW: screenW,
            screenH: screenH
        }
    }

    BuildPersonalContributionValueBox(houseTextScreenX, personalTextScreenY) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""
        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("PersonalContributionValueArea")
            return ""

        area := uiConfig["PersonalContributionValueArea"]
        rowX := area.HasOwnProp("x") ? area.x : 0
        rowW := area.HasOwnProp("w") ? area.w : area["w"]
        rowH := area.HasOwnProp("h") ? area.h : area["h"]
        rowY := area.HasOwnProp("y") ? area.y : 0

        rm := ResolutionManager()
        origin := rm.add(houseTextScreenX, personalTextScreenY, rowX, rowY)
        size := rm.dimensions(rowW, rowH)
        screenX := origin.x
        screenY := origin.y
        screenW := Max(1, Round(size.w))
        screenH := Max(1, Round(size.h))

        rm.ClampCapture(&screenX, &screenY, &screenW, &screenH)

        return {
            screenX: screenX,
            screenY: screenY,
            screenW: screenW,
            screenH: screenH
        }
    }

    ReadPersonalContributionOcrCandidates(houseTextScreenX, personalTextScreenY) {
        valueBox := this.BuildPersonalContributionValueBox(houseTextScreenX, personalTextScreenY)
        rowBox := this.BuildPersonalContributionRowBox(houseTextScreenX, personalTextScreenY)
        ocrLang := this.GetOcrLanguage()
        candidates := []

        if IsObject(valueBox) {
            candidates.Push(this.MakeContributionOcrCandidate(valueBox, "value", "rect", ocrLang))
            candidates.Push(this.MakeContributionOcrCandidate(valueBox, "value", "hud", ocrLang, 70))
            candidates.Push(this.MakeContributionOcrCandidate(valueBox, "value", "hud", ocrLang, 90))
        }
        if IsObject(rowBox)
            candidates.Push(this.MakeContributionOcrCandidate(rowBox, "row", "hud", ocrLang, 90))

        return {
            candidates: candidates,
            best: this.PickBestContributionCandidate(candidates),
            valueBox: valueBox,
            rowBox: rowBox
        }
    }

    MakeContributionOcrCandidate(box, region, mode, lang, lumaMin := 90) {
        try {
            ocrResult := (mode == "rect")
                ? Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, lang)
                : Ocr.FromHudRect(box.screenX, box.screenY, box.screenW, box.screenH, lang, 4, 10, lumaMin)
            normalized := Ocr.NormalizeText(ocrResult.text)
            parsed := this.ParsePersonalContributionNumber(normalized)
            return {
                region: region,
                mode: mode,
                lumaMin: lumaMin,
                box: box,
                rawText: ocrResult.text,
                normalizedText: normalized,
                parsed: parsed,
                ocrResult: ocrResult
            }
        } catch {
            return ""
        }
    }

    PickBestContributionCandidate(candidates) {
        best := ""
        bestValue := -1
        bestDigits := 0

        for _, candidate in candidates {
            if !IsObject(candidate) || !candidate.parsed.found
                continue
            if (candidate.parsed.value <= 0)
                continue
            digitLen := StrLen(StrReplace(candidate.parsed.number, ",", ""))
            if (candidate.parsed.value > bestValue
                || (candidate.parsed.value == bestValue && digitLen > bestDigits)) {
                best := candidate
                bestValue := candidate.parsed.value
                bestDigits := digitLen
            }
        }

        if !IsObject(best) {
            for _, candidate in candidates {
                if !IsObject(candidate) || !candidate.parsed.found
                    continue
                digitLen := StrLen(StrReplace(candidate.parsed.number, ",", ""))
                if (candidate.parsed.value > bestValue
                    || (candidate.parsed.value == bestValue && digitLen > bestDigits)) {
                    best := candidate
                    bestValue := candidate.parsed.value
                    bestDigits := digitLen
                }
            }
        }

        if !IsObject(best) {
            for _, candidate in candidates {
                if IsObject(candidate) && candidate.normalizedText != "" {
                    best := candidate
                    break
                }
            }
        }
        return best
    }

    ReadPersonalContribution(cell, houseTextScreenX, personalTextScreenX, personalTextScreenY) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        if !GameConstants["GameUI"].Has("PersonalContributionRowArea") {
            this.Log("[HouseGrid] Error: PersonalContributionRowArea missing in GameConstants.")
            return ""
        }

        ocrRun := this.ReadPersonalContributionOcrCandidates(houseTextScreenX, personalTextScreenY)
        best := ocrRun.best
        box := IsObject(best) ? best.box : ocrRun.rowBox
        if !IsObject(box)
            return ""

        if IsObject(best) {
            this.Debug("[HouseGrid] Personal contribution OCR [" best.region "/" best.mode
                (best.mode == "hud" ? " luma" best.lumaMin : "") "] at screen ["
                box.screenX ", " box.screenY ", " box.screenW ", " box.screenH "].")
        }

        contribOverlay := this.ShowDebugBoxAtScreen(box.screenX, box.screenY, box.screenW, box.screenH)

        if !IsObject(best) {
            this.CloseDebugBox(contribOverlay)
            this.Debug("[HouseGrid] Slot " cell.slot ": Personal contribution OCR returned no text.")
            return {
                rawText: "",
                normalizedText: "",
                contributionNumber: "",
                contributionValue: 0,
                contributionParsed: false,
                box: box,
                personalTextScreenX: personalTextScreenX,
                personalTextScreenY: personalTextScreenY
            }
        }

        rawText := best.rawText
        normalized := best.normalizedText
        parsed := best.parsed

        if (parsed.found) {
            this.Debug("[HouseGrid] Slot " cell.slot ": Personal contribution " parsed.value
                " (raw OCR `"" rawText "`").")
        } else if (normalized != "") {
            this.Debug("[HouseGrid] Slot " cell.slot ": Personal contribution raw OCR `"" rawText
                "`" (normalized `"" normalized "`"; could not parse contribution number).")
        } else {
            this.Debug("[HouseGrid] Slot " cell.slot ": Personal contribution OCR returned no text.")
        }

        this.CloseDebugBox(contribOverlay)
        return {
            rawText: rawText,
            normalizedText: normalized,
            contributionNumber: parsed.number,
            contributionValue: parsed.value,
            contributionParsed: parsed.found,
            box: box,
            personalTextScreenX: personalTextScreenX,
            personalTextScreenY: personalTextScreenY
        }
    }

    ParsePersonalContributionNumber(text) {
        norm := this.NormalizeContributionOcrText(text)
        if (norm == "")
            return { found: false, number: "", value: 0 }

        if RegExMatch(norm, "^\s*[O0o]\s*$")
            return { found: true, number: "0", value: 0, rawText: norm }

        best := this.ExtractLargestContributionNumber(norm)
        if (best.found)
            return best

        return { found: false, number: "", value: 0, rawText: norm }
    }

    NormalizeContributionOcrText(text) {
        s := Trim(text)
        if (s == "")
            return ""
        s := StrReplace(s, "`u{201A}", ",")
        s := StrReplace(s, "`u{FF0C}", ",")
        s := StrReplace(s, "`u{00A0}", " ")
        s := RegExReplace(s, "\s+", " ")
        return Trim(s)
    }

    ExtractLargestContributionNumber(text) {
        bestNumber := ""
        bestValue := -1
        pos := 1

        while RegExMatch(text, "([\dOolOl|]+(?:,\d{3})+)", &m, pos) {
            numberStr := this.NormalizeContributionNumberText(m[1])
            if (numberStr != "") {
                val := this.ParseContributionDigits(numberStr)
                if (val > bestValue) {
                    bestValue := val
                    bestNumber := numberStr
                }
            }
            pos := m.Pos(0) + m.Len(0)
        }

        pos := 1
        while RegExMatch(text, "([\dOolOl|]{2,})", &m, pos) {
            numberStr := this.NormalizeContributionNumberText(m[1])
            if (numberStr != "") {
                val := this.ParseContributionDigits(numberStr)
                if (val > bestValue) {
                    bestValue := val
                    bestNumber := numberStr
                }
            }
            pos := m.Pos(0) + m.Len(0)
        }

        if (bestNumber != "" && bestValue >= 0)
            return { found: true, number: bestNumber, value: bestValue, rawText: text }
        return { found: false, number: "", value: 0, rawText: text }
    }

    NormalizeContributionNumberText(text) {
        s := Trim(text)
        if (s == "")
            return ""

        s := StrReplace(s, "O", "0")
        s := StrReplace(s, "o", "0")
        s := StrReplace(s, "l", "1")
        s := StrReplace(s, "I", "1")
        s := StrReplace(s, "|", "1")
        s := RegExReplace(s, "[^\d,]", "")
        return s
    }

    ParseContributionDigits(numberStr) {
        cleaned := StrReplace(numberStr, ",", "")
        cleaned := StrReplace(cleaned, " ", "")
        if (cleaned == "")
            return 0
        return Integer(cleaned)
    }

    ReadHouseName(cell, anchorScreenX, anchorScreenY) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("HouseNameSearchAreaRelativeToTooltip") {
            this.Log("[HouseGrid] Error: HouseNameSearchAreaRelativeToTooltip missing in GameConstants.")
            return ""
        }

        rel := uiConfig["HouseNameSearchAreaRelativeToTooltip"]
        box := this.BuildRelativeSearchBox(anchorScreenX, anchorScreenY, rel)

        this.Debug("[HouseGrid] OCR house name area at screen ["
            box.screenX ", " box.screenY ", " box.screenW ", " box.screenH
            "] (relative to house text at " anchorScreenX ", " anchorScreenY ").")

        houseOverlay := this.ShowDebugBoxAtScreen(box.screenX, box.screenY, box.screenW, box.screenH)

        ocrLang := this.GetOcrLanguage()
        try {
            ocrResult := Ocr.FromHudRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
            rawText := ocrResult.text
            normalized := Ocr.NormalizeText(rawText)
            candidates := this.GetCandidateHouseNames()
            matched := Ocr.FindBestMatch(normalized, candidates)

            matchedName := matched.matchedName
            confidence := matched.confidence
            spec := ""
            if (matchedName != "" && IsObject(this.stateManager))
                spec := this.stateManager.GetHouseSpecialization(matchedName)

            if (matchedName != "" && confidence >= 0.4) {
                specInfo := spec != "" ? " [" spec "]" : ""
                this.Debug("[HouseGrid] Slot " cell.slot ": OCR `"" normalized "`" -> "
                    matchedName specInfo " (confidence " confidence ").")
            } else if (normalized != "") {
                this.Debug("[HouseGrid] Slot " cell.slot ": OCR `"" normalized "`" (unrecognized house).")
            } else {
                this.Debug("[HouseGrid] Slot " cell.slot ": OCR returned no text in house name area.")
            }

            this.CloseDebugBox(houseOverlay)
            return {
                rawText: rawText,
                normalizedText: normalized,
                matchedName: matchedName,
                specialization: spec,
                confidence: confidence
            }
        } catch as err {
            this.CloseDebugBox(houseOverlay)
            this.Log("[HouseGrid] Slot " cell.slot ": OCR error: " err.Message)
            return ""
        }
    }

    GetCandidateHouseNames() {
        houses := this.GetCandidateHouses()
        names := []
        for _, item in houses {
            if (item is Map && item.Has("house"))
                names.Push(item["house"])
            else if (IsObject(item) && item.HasOwnProp("house"))
                names.Push(item.house)
        }
        return names
    }

    GetCandidateHouses() {
        if (IsObject(this.stateManager) && this.stateManager.allHousesList.Length > 0)
            return this.stateManager.allHousesList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allHousesList.Length > 0)
            return stateManagerInst.allHousesList

        dbPath := A_ScriptDir "\db\landsraad_houses.json"
        if FileExist(dbPath) {
            try {
                parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
                if (parsed is Array)
                    return parsed
            }
        }

        return []
    }

    ReadHouseRewards(anchorScreenX, anchorScreenY, personalMatchY) {
        data := this.ReadHouseRewardsData(anchorScreenX, anchorScreenY, personalMatchY)
        return IsObject(data) ? data.entries : Ocr.MakeEmptyHouseRewardEntries()
    }

    ReadHouseRewardsData(anchorScreenX, anchorScreenY, personalMatchY) {
        personalBox := this.BuildPersonalTextSearchBox(anchorScreenX, anchorScreenY)
        if !IsObject(personalBox)
            return ""

        bandBox := this.BuildRewardsBandBox(personalBox, personalMatchY)
        if !IsObject(bandBox)
            return ""

        bandOverlay := this.ShowDebugBoxAtScreen(bandBox.screenX, bandBox.screenY, bandBox.screenW, bandBox.screenH)
        bandResult := this.ReadRewardsBandWithRetries(bandBox)
        this.CloseDebugBox(bandOverlay)
        return {
            entries: Ocr.FormatHouseRewardEntries(bandResult.parsed),
            ocr: bandResult.ocr,
            parsed: bandResult.parsed,
            box: bandBox
        }
    }

    BuildPersonalTextSearchBox(anchorScreenX, anchorScreenY) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""
        if !GameConstants["GameUI"].Has("HousePersonalTextImgOffsetRelativeToTooltip")
            return ""

        rel := GameConstants["GameUI"]["HousePersonalTextImgOffsetRelativeToTooltip"]
        return this.BuildRelativeSearchBox(anchorScreenX, anchorScreenY, rel)
    }

    BuildRewardsBandBox(personalSearchBox, personalMatchY) {
        screenX := personalSearchBox.screenX
        screenY := personalSearchBox.screenY
        screenW := personalSearchBox.screenW
        screenH := Integer(personalMatchY) - screenY
        if (screenH < 1)
            screenH := 1

        rm := ResolutionManager()
        insetRef := this.GetRewardsBandOcrInsetX()
        if (insetRef > 0) {
            insetW := Max(1, Round(rm.dimensions(insetRef, 0).w))
            screenX += insetW
            screenW -= insetW
        }
        if (screenW < 1)
            screenW := 1

        maxHRef := this.GetRewardsBandOcrMaxHeight()
        if (maxHRef > 0) {
            maxH := Max(1, Round(rm.dimensions(0, maxHRef).h))
            if (screenH > maxH) {
                screenY += screenH - maxH
                screenH := maxH
            }
        }

        rm.ClampCapture(&screenX, &screenY, &screenW, &screenH)

        return {
            screenX: screenX,
            screenY: screenY,
            screenW: screenW,
            screenH: screenH
        }
    }

    GetRewardsBandOcrInsetX() {
        return this.GetRewardsBandUiNumber("HouseRewardsBandOcrInsetX")
    }

    GetRewardsBandOcrMaxHeight() {
        return this.GetRewardsBandUiNumber("HouseRewardsBandOcrMaxHeight")
    }

    GetRewardsBandUiNumber(key) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return 0
        uiConfig := GameConstants["GameUI"]
        return uiConfig.Has(key) ? uiConfig[key] : 0
    }

    ReadRewardsBandWithRetries(box) {
        bestOcr := ""
        bestParsed := { found: false, tiers: [], ocrTexts: [], rawText: "" }
        bestMatched := 0
        bestNameCount := 0
        maxAttempts := this.rewardsBandOcrMaxRetries + 1

        loop maxAttempts {
            if (A_Index > 1) {
                this.Debug("[HouseGrid] Rewards band partial match, OCR retry "
                    (A_Index - 1) "/" this.rewardsBandOcrMaxRetries "...")
                if (this.rewardsBandOcrRetryMs > 0)
                    Sleep(this.rewardsBandOcrRetryMs)
            }

            for _, bandOcrResult in this.ReadRewardsBandOcrCandidates(box) {
                if !IsObject(bandOcrResult)
                    continue
                normalized := bandOcrResult.normalizedText
                parsed := Ocr.ParseHouseRewardTiers(normalized)
                matched := Ocr.CountMatchedHouseRewardTiers(parsed)
                nameCount := (IsObject(parsed) && parsed.HasOwnProp("ocrTexts") && parsed.ocrTexts is Array)
                    ? parsed.ocrTexts.Length : 0

                if (matched > bestMatched
                    || (matched == bestMatched && nameCount > bestNameCount)
                    || (matched == bestMatched && nameCount == bestNameCount && matched > 0
                        && IsObject(bandOcrResult) && bandOcrResult.normalizedText != "")) {
                    bestMatched := matched
                    bestNameCount := nameCount
                    bestOcr := bandOcrResult
                    bestParsed := parsed
                }

                if (matched >= 4)
                    break 2
            }

            if (bestMatched >= 4)
                break
            if !Ocr.HouseRewardParseNeedsRetry(bestParsed)
                break
        }

        return { ocr: bestOcr, parsed: bestParsed, matchedCount: bestMatched }
    }

    ReadRewardsBandOcrCandidates(box) {
        ocrLang := this.GetOcrLanguage()
        candidates := []
        try {
            ocrResult := Ocr.FromHudRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
        } catch as err {
            this.Log("[HouseGrid] OCR error: " err.Message)
            return candidates
        }

        this.PushRewardsBandOcrCandidate(candidates, ocrResult.text, "full", ocrResult)

        lineText := Ocr.JoinOcrLines(ocrResult.lines)
        if (lineText != "" && lineText != ocrResult.text)
            this.PushRewardsBandOcrCandidate(candidates, lineText, "lines", ocrResult)

        stripText := this.ReadRewardsBandStripText(box, ocrLang)
        if (stripText != "") {
            duplicate := false
            for _, candidate in candidates {
                if (candidate.rawText == stripText) {
                    duplicate := true
                    break
                }
            }
            if !duplicate
                this.PushRewardsBandOcrCandidate(candidates, stripText, "strips", ocrResult)
        }

        return candidates
    }

    ReadRewardsBandStripText(box, ocrLang) {
        stripCount := 6
        stripH := Max(1, Ceil(box.screenH / stripCount))
        parts := []

        loop stripCount {
            stripY := box.screenY + (A_Index - 1) * stripH
            stripHActual := Min(stripH, box.screenY + box.screenH - stripY)
            if (stripHActual < 1)
                break

            try {
                stripResult := Ocr.FromHudRect(box.screenX, stripY, box.screenW, stripHActual, ocrLang)
                t := Trim(stripResult.text)
                if (t != "")
                    parts.Push(t)
            } catch {
                continue
            }
        }

        return Ocr.JoinOcrLines(parts)
    }

    PushRewardsBandOcrCandidate(candidates, text, source, ocrResult) {
        if (Trim(text) == "")
            return
        candidates.Push({
            source: source,
            rawText: text,
            normalizedText: Ocr.NormalizeText(text),
            ocrResult: ocrResult
        })
    }

    ReadOcrFromBox(box) {
        ocrLang := this.GetOcrLanguage()
        try {
            ocrResult := Ocr.FromHudRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
            return {
                rawText: ocrResult.text,
                normalizedText: Ocr.NormalizeText(ocrResult.text)
            }
        } catch as err {
            this.Log("[HouseGrid] OCR error: " err.Message)
            return ""
        }
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    ShowDebugBoxAtScreen(screenX, screenY, screenW, screenH) {
        if !this.showDebugBoxes
            return ""
        overlay := RectangleOverlay()
        overlay.ShowAtScreen(screenX, screenY, screenW, screenH)
        return overlay
    }

    CloseDebugBox(overlay) {
        if IsObject(overlay) {
            if (this.ocrBoxFlashMs > 0)
                Sleep(this.ocrBoxFlashMs)
            overlay.Close()
        }
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
