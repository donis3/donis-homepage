﻿Donsraad â€” portable build

Run Donsraad.exe. AutoHotkey does not need to be installed.

Keep this folder together. The exe reads and writes JSON next to itself:
  settings.json
  profiles.json
  player_state.json
  db\landsraad_houses.json
  db\landsraad_missions.json

PNG assets stay on disk and can be replaced without recompiling:
  ui\donis.png
  ui_elements\*.png

settings.json, profiles.json, and player_state.json in this folder are
clean defaults (not your local profiles). The app writes to them as you
use it. Existing files are never overwritten by a later extract.
