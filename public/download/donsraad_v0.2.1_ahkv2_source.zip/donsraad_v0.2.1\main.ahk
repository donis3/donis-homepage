#Requires AutoHotkey v2.0+
#SingleInstance Force
#MaxThreadsPerHotkey 2
Persistent(true)
SetWorkingDir(A_ScriptDir)

;@Ahk2Exe-SetName Donsraad
;@Ahk2Exe-SetDescription Easy Mission Picker for Dune: Awakening
;@Ahk2Exe-SetProductName Donsraad
;@Ahk2Exe-SetCompanyName Deniz Özkan
;@Ahk2Exe-SetCopyright Copyright 2026 Deniz Özkan
;@Ahk2Exe-SetOrigFilename Donsraad.exe
;@Ahk2Exe-SetLanguage 0x0409
;@Ahk2Exe-SetVersion 0.2.1

; Keep JSON and PNG on disk next to the script or exe. FileInstall only
; seeds missing files from a compiled build; existing files are never overwritten.
#Include core\RuntimeFileInstall.ahk

EnsureRuntimeFiles() {
    DirCreate(A_ScriptDir "\db")
    DirCreate(A_ScriptDir "\ui")
    DirCreate(A_ScriptDir "\sfx")
    DirCreate(A_ScriptDir "\anchors\1080p")
    DirCreate(A_ScriptDir "\anchors\1440p")
    InstallBundledRuntimeFiles()
}

EnsureRuntimeFiles()

; ==============================================================================
; HIGH-SPEED GLOBAL INPUT INITIALIZATION
; ==============================================================================
SetControlDelay(-1)
SetMouseDelay(-1)
SetKeyDelay(-1, -1)
SendMode("Input")

; ==============================================================================
; GLOBAL INSTANCES & INITIALIZATION
; ==============================================================================
global resolutionManagerInst := ResolutionManager()
global gdipToken := Gdip_Startup()
global stateManagerInst := LandsraadStateManager(A_ScriptDir)
global settingsManagerInst := SettingsManager(A_ScriptDir)
global loggerInst := Logger(settingsManagerInst.Get("debugMode", false))
if IsObject(stateManagerInst) && (stateManagerInst.dbErrors is Array) {
    for _, dbMsg in stateManagerInst.dbErrors
        loggerInst.Log("[Database] " dbMsg)
    if !stateManagerInst.AreDatabasesReady()
        loggerInst.Log("[Database] Houses or missions database is not ready. Mission Picker will be empty until the JSON files are fixed.")
}
global anchorMatcherInst := AnchorMatcher(A_ScriptDir)

global profileManagerInst := ProfileManager(A_ScriptDir)
profileManagerInst.Initialize(stateManagerInst, settingsManagerInst)
global userStateInst := UserState()
global removeActiveMissionsScenarioInst := RemoveActiveMissionsScenario(settingsManagerInst, loggerInst, anchorMatcherInst, stateManagerInst)
global acceptMissionsScenarioInst := AcceptMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst, profileManagerInst)
global acceptTargettedMissionsScenarioInst := AcceptTargettedMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst, profileManagerInst)
global acceptCompleteMissionsScenarioInst := AcceptCompleteMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst, profileManagerInst)
global initializeScenarioInst := InitializeScenario(stateManagerInst, loggerInst, anchorMatcherInst, userStateInst, acceptCompleteMissionsScenarioInst, removeActiveMissionsScenarioInst)
global masterScenarioInst := MasterScenario(stateManagerInst, userStateInst, loggerInst, initializeScenarioInst, removeActiveMissionsScenarioInst, acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst, acceptCompleteMissionsScenarioInst, anchorMatcherInst)
global mainGuiInst := DonsraadGui(stateManagerInst, settingsManagerInst, loggerInst, initializeScenarioInst, userStateInst, profileManagerInst)
global statusOverlayInst := StatusOverlay(stateManagerInst, userStateInst, profileManagerInst, settingsManagerInst)
StatusBar.ApplyVisibility(settingsManagerInst.GetBool("showOverlay", true))
; global houseGridDebugInst := HouseGridDebug()
global openLandsraadGridScenarioInst := OpenLandsraadGridScenario(loggerInst, anchorMatcherInst)
global scanLandsraadGridScenarioInst := ScanLandsraadGridScenario(loggerInst, anchorMatcherInst, profileManagerInst, stateManagerInst)
global missionHandlerDebugInst := MissionHandlerDebug(loggerInst, stateManagerInst)
global activeMissionDebugInst := ActiveMissionDebug(loggerInst, stateManagerInst)
global houseScanDebugInst := HouseScanDebug(loggerInst, openLandsraadGridScenarioInst, anchorMatcherInst, stateManagerInst)

; Register cleanup on script exit
OnExit(AppExitHandler)

; Show initial dashboard
global boundStartHotkey := ""
global boundStopHotkey := ""
global boundAutoRunHotkey := ""
global boundExitHotkey := ""
global boundToggleHotkey := ""
global boundOverlayHotkey := ""
global boundReloadHotkey := ""
mainGuiInst.Show()
ApplyAppHotkeys()
ApplyTrayMenu()
TravelAutoRun.Sync()
if A_IsCompiled
    loggerInst.Debug("Standalone build. Data folder: " A_ScriptDir)
loggerInst.Log("Application ready. Donsraad dashboard loaded.")

; ==============================================================================
; HOTKEYS
; ==============================================================================

GetAppHotkeyBindSpecs() {
    return [
        { setting: "hotkeyStart", fallback: "Home", bound: "boundStartHotkey", callback: OnStartHotkey },
        { setting: "hotkeyStop", fallback: "End", bound: "boundStopHotkey", callback: OnStopHotkey },
        { setting: "hotkeyToggleAutoRun", fallback: "Delete", bound: "boundAutoRunHotkey", callback: OnToggleAutoRunHotkey },
        { setting: "hotkeyToggleGui", fallback: "F8", bound: "boundToggleHotkey", callback: OnToggleGuiHotkey },
        { setting: "hotkeyToggleOverlay", fallback: "Insert", bound: "boundOverlayHotkey", callback: OnToggleOverlayHotkey },
        { setting: "hotkeyReload", fallback: "PgDn", bound: "boundReloadHotkey", callback: OnReloadHotkey },
        { setting: "hotkeyExit", fallback: "Pause", bound: "boundExitHotkey", callback: OnExitHotkey }
    ]
}

SuspendAppHotkeys() {
    global boundStartHotkey, boundStopHotkey, boundAutoRunHotkey, boundExitHotkey, boundToggleHotkey, boundOverlayHotkey, boundReloadHotkey
    for _, spec in GetAppHotkeyBindSpecs() {
        oldKey := %spec.bound%
        if (oldKey != "") {
            try Hotkey(oldKey, "Off")
        }
    }
}

ApplyAppHotkeys() {
    global settingsManagerInst
    global boundStartHotkey, boundStopHotkey, boundAutoRunHotkey, boundExitHotkey, boundToggleHotkey, boundOverlayHotkey, boundReloadHotkey
    specs := GetAppHotkeyBindSpecs()
    oldKeys := Map()
    for _, spec in specs
        oldKeys[spec.bound] := %spec.bound%

    newKeys := Map()
    allOk := true
    for _, spec in specs {
        keyName := spec.fallback
        if IsObject(settingsManagerInst) {
            keyName := settingsManagerInst.Get(spec.setting, spec.fallback)
        }
        if (Trim(keyName) == "")
            keyName := spec.fallback

        ok := BindAppHotkey(keyName, spec.callback)
        if !ok {
            keyName := spec.fallback
            ok := BindAppHotkey(keyName, spec.callback)
            if IsObject(settingsManagerInst)
                settingsManagerInst.Set(spec.setting, spec.fallback)
        }
        if !ok
            allOk := false
        newKeys[StrLower(keyName)] := true
        %spec.bound% := keyName
    }

    for _, spec in specs {
        oldKey := oldKeys[spec.bound]
        if (oldKey != "" && !newKeys.Has(StrLower(oldKey))) {
            try Hotkey(oldKey, "Off")
        }
    }
    return allOk
}

BindAppHotkey(key, callback) {
    try {
        Hotkey(key, callback)
        Hotkey(key, "On")
        return true
    } catch {
        return false
    }
}

OnStartHotkey(*) {
    StartPickerRun()
}

OnStopHotkey(*) {
    StopPickerRun()
}

OnToggleAutoRunHotkey(*) {
    ToggleAutoRunSetting()
}

StartPickerRun(*) {
    global masterScenarioInst, userStateInst, loggerInst, stateManagerInst
    TravelAutoRun.ClearSuppress()
    if (IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsRunActive()) {
        userStateInst.RequestCancel()
        if IsSet(loggerInst) && IsObject(loggerInst)
            loggerInst.Log("Cancelling...")
        StatusBar.SetStatus("Cancelling")
        return
    }

    if (IsSet(userStateInst) && IsObject(userStateInst))
        userStateInst.BeginRun()
    if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.HasMethod("ResumeRunTimerIfPaused"))
        stateManagerInst.ResumeRunTimerIfPaused()
    StatusBar.PinForPickerLoop()
    try {
        if (IsSet(masterScenarioInst) && IsObject(masterScenarioInst))
            masterScenarioInst.Execute()
    } finally {
        if (IsSet(userStateInst) && IsObject(userStateInst))
            userStateInst.EndRun()
        StatusBar.ClearPickerPin()
        TravelAutoRun.Sync()
    }
}

StopPickerRun(*) {
    global userStateInst, loggerInst, stateManagerInst
    TravelAutoRun.Suppress()
    if (IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsRunActive()) {
        userStateInst.RequestCancel()
        if IsSet(loggerInst) && IsObject(loggerInst)
            loggerInst.Log("Stopping...")
        StatusBar.SetStatus("Stopping")
        return
    }
    if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.HasMethod("PauseCurrentRun"))
        stateManagerInst.PauseCurrentRun()
    if IsSet(loggerInst) && IsObject(loggerInst)
        loggerInst.Log("AutoRun paused. Press Start to resume.")
    StatusBar.SetStatus("Stopped")
    StatusBar.Refresh()
}

ToggleAutoRunSetting(enabled := unset) {
    global settingsManagerInst, mainGuiInst, loggerInst
    if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
        return
    if !IsSet(enabled)
        enabled := !settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false)
    settingsManagerInst.Set("autoRunOnTravelConfirmation", enabled)
    if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && IsObject(mainGuiInst.setAutoRunOnTravel))
        mainGuiInst.setAutoRunOnTravel.Value := enabled ? 1 : 0
    if enabled
        TravelAutoRun.ClearSuppress()
    else
        TravelAutoRun.Stop()
    TravelAutoRun.Sync()
    StatusBar.Refresh()
    RefreshTrayAutoRunCheck()
    if IsSet(loggerInst) && IsObject(loggerInst)
        loggerInst.Log(enabled ? "AutoRun enabled." : "AutoRun disabled.")
}

OnToggleGuiHotkey(*) {
    global mainGuiInst
    if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("Toggle"))
        mainGuiInst.Toggle()
}

OnToggleOverlayHotkey(*) {
    StatusBar.Toggle()
}

OnReloadHotkey(*) {
    global userStateInst, profileManagerInst, stateManagerInst, settingsManagerInst
    if (IsObject(profileManagerInst) && IsObject(stateManagerInst))
        profileManagerInst.SaveAll(stateManagerInst, settingsManagerInst)
    if IsObject(profileManagerInst)
        profileManagerInst.skipProfilesPersist := true
    if (IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsRunActive())
        userStateInst.RequestCancel()
    Reload()
}

OnExitHotkey(*) {
    ExitApp()
}

OnTrayShowDashboard(*) {
    global mainGuiInst
    if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("Show"))
        mainGuiInst.Show()
}

ApplyTrayMenu() {
    A_IconTip := "Donsraad"
    try A_TrayMenu.Delete()
    A_TrayMenu.Add("Show dashboard", OnTrayShowDashboard)
    A_TrayMenu.Add("Show / hide overlay", OnToggleOverlayHotkey)
    A_TrayMenu.Add("AutoRun", OnTrayToggleAutoRun)
    A_TrayMenu.Add()
    A_TrayMenu.Add("Start picker", OnStartHotkey)
    A_TrayMenu.Add("Stop", OnStopHotkey)
    A_TrayMenu.Add()
    A_TrayMenu.Add("Exit", OnExitHotkey)
    A_TrayMenu.Default := "Show dashboard"
    A_TrayMenu.ClickCount := 1
    RefreshTrayAutoRunCheck()
}

OnTrayToggleAutoRun(*) {
    ToggleAutoRunSetting()
}

RefreshTrayAutoRunCheck() {
    global settingsManagerInst
    enabled := (IsSet(settingsManagerInst) && IsObject(settingsManagerInst)
        && settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false))
    if enabled
        A_TrayMenu.Check("AutoRun")
    else
        A_TrayMenu.Uncheck("AutoRun")
}

; ==============================================================================
; EXIT HANDLER
; ==============================================================================
AppExitHandler(exitReason, exitCode) {
    global gdipToken, stateManagerInst, profileManagerInst, settingsManagerInst
    try {
        StatusBar.Close()
    }
    try {
        TravelAutoRun.Stop()
    }
    try {
        if IsSet(stateManagerInst) && IsObject(stateManagerInst)
            stateManagerInst.SavePlayerState()
    }
    try {
        if (exitReason != "Reload" && IsSet(profileManagerInst) && IsObject(profileManagerInst)
            && IsSet(stateManagerInst) && IsObject(stateManagerInst))
            profileManagerInst.SaveAll(stateManagerInst, settingsManagerInst)
    }
    try {
        if (gdipToken)
            Gdip_Shutdown(gdipToken)
    }
    return 0
}

; ==============================================================================
; INCLUDES
; ==============================================================================
#Include lib\JSON.ahk
#Include lib\Gdip.ahk
#Include core\Version.ahk
#Include core\Constants.ahk
#Include core\Logger.ahk
#Include core\GameWindow.ahk
#Include core\ResolutionManager.ahk
#Include core\OCR.ahk
#Include core\SettingsManager.ahk
#Include core\SfxPlayer.ahk
#Include core\StateManager.ahk
#Include core\ProfileManager.ahk
#Include core\HouseGridScanner.ahk
#Include core\UserState.ahk
#Include core\AnchorMatcher.ahk
#Include core\InputHelper.ahk
#Include debug\RectangleOverlay.ahk
; #Include debug\HouseGridDebug.ahk
#Include debug\MissionHandlerDebug.ahk
#Include debug\ActiveMissionDebug.ahk
#Include debug\HouseScanDebug.ahk
#Include debug\InitDebug.ahk
#Include ui\StatusOverlay.ahk
#Include scenarios\Initialize.ahk
#Include scenarios\RemoveActiveMissions.ahk
#Include scenarios\OpenLandsraadGrid.ahk
#Include scenarios\ScanLandsraadGrid.ahk
#Include scenarios\AcceptMissions.ahk
#Include scenarios\AcceptTargettedMissions.ahk
#Include scenarios\AcceptCompleteMissions.ahk
#Include scenarios\Master.ahk
#Include core\TravelAutoRun.ahk
#Include ui\GuiPage.ahk
#Include ui\DarkSelect.ahk
#Include ui\tabs\MissionPickerTab.ahk
#Include ui\tabs\MissionPickerGridTab.ahk
#Include ui\tabs\LandsraadTab.ahk
#Include ui\tabs\RewardsTab.ahk
#Include ui\tabs\StatsTab.ahk
#Include ui\tabs\SettingsTab.ahk
#Include ui\tabs\LogsTab.ahk
#Include ui\tabs\AboutTab.ahk
#Include ui\LegalDialog.ahk
#Include ui\UserGuideDialog.ahk
#Include ui\TabHelpDialog.ahk
#Include ui\HouseGoalDialog.ahk
#Include ui\RewardHunterWindow.ahk
#Include ui\HouseSwatchesWindow.ahk
#Include ui\HouseEarnedRewardsWindow.ahk
#Include ui\HouseMissionDialog.ahk
#Include ui\MainWindow.ahk