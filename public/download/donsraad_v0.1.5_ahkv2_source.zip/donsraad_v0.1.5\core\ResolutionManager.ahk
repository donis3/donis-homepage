#Requires AutoHotkey v2.0+

/**
 * Converts coordinates and sizes from the developer 3440x1440 (21:9) space
 * into the current display.
 *
 * Dune: Awakening keeps a fixed 16:9 game UI (2560x1440 at the reference height)
 * and centers it. 21:9 only adds empty side padding; 16:9 1440p is the same UI
 * with that padding removed. Other heights scale the UI uniformly, then center
 * it with pillarbox or letterbox as needed.
 *
 * All GameConstants values are authored in 3440x1440.
 *
 * Example:
 *   rm := ResolutionManager()
 *   pos := rm.coords(1074, 333)
 *   size := rm.dimensions(243, 138)
 */
class ResolutionManager {
    baseWidth := 3440
    baseHeight := 1440
    gameUiWidth := 2560
    gameUiHeight := 1440
    refPadX := 440
    refPadY := 0
    screenWidth := 0
    screenHeight := 0
    scale := 1.0
    scaleX := 1.0
    scaleY := 1.0
    leftPad := 0
    topPad := 0

    __New(baseWidth := 3440, baseHeight := 1440, gameUiWidth := 2560, gameUiHeight := 1440) {
        this.baseWidth := baseWidth
        this.baseHeight := baseHeight
        this.gameUiWidth := gameUiWidth
        this.gameUiHeight := gameUiHeight
        this.refPadX := Max(0, (this.baseWidth - this.gameUiWidth) // 2)
        this.refPadY := Max(0, (this.baseHeight - this.gameUiHeight) // 2)
        this.screenWidth := A_ScreenWidth
        this.screenHeight := A_ScreenHeight
        this.RecalcLayout()
    }

    RecalcLayout() {
        uiAspect := this.gameUiWidth / this.gameUiHeight
        screenAspect := this.screenWidth / this.screenHeight

        if (screenAspect >= uiAspect) {
            this.scale := this.screenHeight / this.gameUiHeight
            uiW := this.gameUiWidth * this.scale
            this.leftPad := Round((this.screenWidth - uiW) / 2)
            this.topPad := 0
        } else {
            this.scale := this.screenWidth / this.gameUiWidth
            uiH := this.gameUiHeight * this.scale
            this.leftPad := 0
            this.topPad := Round((this.screenHeight - uiH) / 2)
        }

        this.scaleX := this.scale
        this.scaleY := this.scale
    }

    /**
     * Point from 3440x1440 developer space into the current screen.
     */
    coords(x, y) {
        return {
            x: Round((x - this.refPadX) * this.scale + this.leftPad),
            y: Round((y - this.refPadY) * this.scale + this.topPad)
        }
    }

    coord(x, y) {
        return this.coords(x, y)
    }

    /**
     * Width/height from developer space. UI does not stretch independently on X vs Y.
     */
    dimensions(width, height) {
        return {
            w: Round(width * this.scale),
            h: Round(height * this.scale)
        }
    }

    /**
     * Adds a developer-space delta to a developer-space point, then converts.
     */
    addToCoords(x, y, deltaX, deltaY) {
        return this.coords(x + deltaX, y + deltaY)
    }

    /**
     * Adds a developer-space delta to a point that is already in screen space.
     */
    add(x, y, deltaX, deltaY) {
        return {
            x: Round(x + (deltaX * this.scale)),
            y: Round(y + (deltaY * this.scale))
        }
    }

    rect(x, y, width, height) {
        pos := this.coords(x, y)
        size := this.dimensions(width, height)
        return {
            x: pos.x,
            y: pos.y,
            w: size.w,
            h: size.h
        }
    }
}
