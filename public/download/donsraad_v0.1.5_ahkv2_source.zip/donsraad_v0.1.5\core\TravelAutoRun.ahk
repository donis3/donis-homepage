#Requires AutoHotkey v2.0+

/**
 * When AutoRun is enabled and a play timer is running, poll the Travel
 * confirmation window with ImageSearch. 1000ms is enough: the dialog stays
 * until dismissed, and a cropped ImageSearch is a few milliseconds.
 */
class TravelAutoRun {
    static intervalMs := 1000
    static boundTick := ""
    static busy := false
    static missionCompleteQuietUntil := 0
    static missionCompleteQuietMs := 32000

    static Start() {
        if (this.boundTick != "")
            return
        this.boundTick := ObjBindMethod(this, "Tick")
        SetTimer(this.boundTick, this.intervalMs)
    }

    static Stop() {
        if (this.boundTick != "") {
            try SetTimer(this.boundTick, 0)
        }
        this.boundTick := ""
    }

    static IsActive() {
        return this.busy || (this.boundTick != "")
    }

    static Sync() {
        if this.ShouldWatch()
            this.Start()
        else
            this.Stop()
        StatusBar.Refresh()
    }

    static ShouldWatch() {
        global settingsManagerInst, userStateInst, stateManagerInst
        if this.busy
            return false
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        if !settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false)
            return false
        if !IsSet(userStateInst) || !IsObject(userStateInst)
            return false
        if userStateInst.IsRunActive()
            return false
        if !userStateInst.IsInitialized() || userStateInst.IsFirstHome()
            return false
        if !IsSet(stateManagerInst) || !IsObject(stateManagerInst)
            return false
        if !stateManagerInst.HasMethod("HasActiveRunTimer")
            return false
        return stateManagerInst.HasActiveRunTimer()
    }

    static QuietMissionCompleteFor(ms := "") {
        if (ms == "")
            ms := this.missionCompleteQuietMs
        this.missionCompleteQuietUntil := A_TickCount + Integer(ms)
    }

    static IsMissionCompleteQuiet() {
        return (this.missionCompleteQuietUntil > 0 && A_TickCount < this.missionCompleteQuietUntil)
    }

    static Tick() {
        if !this.ShouldWatch() {
            this.Stop()
            return
        }

        global masterScenarioInst, loggerInst
        if !IsSet(masterScenarioInst) || !IsObject(masterScenarioInst)
            return
        travelVisible := (masterScenarioInst.HasMethod("IsTravelConfirmationVisible")
            && masterScenarioInst.IsTravelConfirmationVisible())
        missionDoneVisible := false
        if !this.IsMissionCompleteQuiet() {
            missionDoneVisible := (masterScenarioInst.HasMethod("IsMissionCompleteIndicatorVisible")
                && masterScenarioInst.IsMissionCompleteIndicatorVisible())
        }
        if !travelVisible && !missionDoneVisible
            return

        reason := travelVisible ? "Travel confirmation" : "Mission complete prompt"
        this.busy := true
        this.Stop()
        try {
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(reason " detected. AutoRun starting the picker.")
            StatusBar.SetStatus("AutoRun", "working")
            StartPickerRun()
        } finally {
            this.busy := false
            this.Sync()
        }
    }
}
