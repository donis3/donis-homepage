#Requires AutoHotkey v2.0+

/**
 * Standard Windows dialog for the disclaimer and terms of use.
 */
class LegalDialog {
    static dlg := ""

    static Show(ownerGui := "") {
        if IsObject(this.dlg) {
            try {
                this.dlg.Show()
                this.dlg.GetPos(&x, &y, &w, &h)
                if (w > 0)
                    return
            } catch {
                this.dlg := ""
            }
        }

        dlg := Gui("-MaximizeBox -MinimizeBox +AlwaysOnTop", "Donsraad — Disclaimer and Terms")
        if IsObject(ownerGui) {
            try dlg.Opt("+Owner" ownerGui.Hwnd)
        }
        dlg.MarginX := 12
        dlg.MarginY := 12
        dlg.SetFont("s9", "Segoe UI")
        dlg.Add("Text", "w560",
            "Read the disclaimer first, then the terms of use. Scroll to see the full text.")
        dlg.Add("Edit", "w560 h420 ReadOnly Wrap -WantReturn +VScroll", this.GetText())
        ok := dlg.Add("Button", "Default w88 h26", "OK")
        ok.OnEvent("Click", (*) => this.Close())
        dlg.OnEvent("Close", (*) => this.Close())
        dlg.OnEvent("Escape", (*) => this.Close())
        this.dlg := dlg
        dlg.Show("AutoSize Center")
    }

    static Close(*) {
        if IsObject(this.dlg) {
            try this.dlg.Destroy()
        }
        this.dlg := ""
    }

    static GetText() {
        disclaimer := this.ReadLegalFile("DISCLAIMER.txt")
        terms := this.ReadLegalFile("TERMS.txt")
        if (disclaimer != "" && terms != "")
            return disclaimer "`n`n" terms
        if (disclaimer != "")
            return disclaimer
        if (terms != "")
            return terms
        return "DISCLAIMER.txt and TERMS.txt were not found next to Donsraad."
    }

    static ReadLegalFile(fileName) {
        path := A_ScriptDir "\" fileName
        if !FileExist(path)
            return ""
        try {
            text := FileRead(path, "UTF-8")
            text := RegExReplace(text, "^\x{FEFF}", "")
            return Trim(text, " `t`r`n")
        } catch {
            return ""
        }
    }
}
