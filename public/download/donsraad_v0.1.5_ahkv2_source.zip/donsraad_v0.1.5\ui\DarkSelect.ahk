#Requires AutoHotkey v2.0+

/**
 * Dark themed dropdown. Native ComboBox/DropDownList stay white under Windows theming.
 */
class DarkSelect {
    static openInst := ""
    static popupGui := ""
    static popupList := ""

    face := ""
    ownerGui := ""
    host := ""
    items := []
    selectedIndex := 0
    enabled := true
    changeCallback := ""
    ignoreListChange := false
    caret := ""
    totalW := 0
    caretW := 24
    placeholder := "Select…"

    __New(guiObj, x, y, w, h, host, items := "") {
        this.ownerGui := guiObj
        this.host := host
        this.totalW := w
        this.items := []
        if (items is Array) {
            for _, item in items
                this.items.Push(item)
        }
        labelW := Max(40, w - this.caretW)
        guiObj.SetFont("s10 cFAFAFA", "Segoe UI")
        this.face := guiObj.Add("Text",
            "x" x " y" y " w" labelW " h" h " +0x200 Background" host.inputBgColor,
            this.FormatFaceText())
        this.face.OnEvent("Click", (*) => this.ToggleList())
        this.caret := guiObj.Add("Text",
            "x" (x + labelW) " y" y " w" this.caretW " h" h " Center +0x200 Background" host.inputBgColor,
            "▾")
        this.caret.OnEvent("Click", (*) => this.ToggleList())
        this.RefreshFace()
    }

    Text {
        get {
            if (this.selectedIndex < 1 || this.selectedIndex > this.items.Length)
                return ""
            return this.items[this.selectedIndex]
        }
    }

    Value {
        get => this.selectedIndex
    }

    OnEvent(eventName, callback) {
        if (eventName = "Change")
            this.changeCallback := callback
    }

    Delete() {
        this.items := []
        this.selectedIndex := 0
        this.RefreshFace()
    }

    Add(items) {
        if (items is Array) {
            for _, item in items
                this.items.Push(item)
        } else if (items != "")
            this.items.Push(items)
        this.RefreshFace()
    }

    Choose(index) {
        idx := Integer(index)
        if (idx < 0)
            idx := 0
        if (idx > this.items.Length)
            idx := 0
        this.selectedIndex := idx
        this.RefreshFace()
    }

    Opt(option) {
        if InStr(option, "-Disabled")
            this.enabled := true
        else if InStr(option, "Disabled")
            this.enabled := false
        this.RefreshFace()
    }

    FormatFaceText() {
        label := this.Text
        if (label == "")
            label := this.placeholder
        return "  " label
    }

    RefreshFace() {
        if !IsObject(this.face)
            return
        this.face.Text := this.FormatFaceText()
        if this.enabled {
            bg := this.host.inputBgColor
            fg := "FAFAFA"
        } else {
            bg := this.host.mutedColor
            fg := "71717A"
        }
        this.face.Opt("Background" bg)
        this.face.SetFont("s10 c" fg, "Segoe UI")
        this.face.Redraw()
        if IsObject(this.caret) {
            this.caret.Opt("Background" bg)
            this.caret.SetFont("s10 c" fg, "Segoe UI")
            this.caret.Redraw()
        }
    }

    ToggleList() {
        if !this.enabled
            return
        if (DarkSelect.openInst = this) {
            this.CloseList()
            return
        }
        this.OpenList()
    }

    OpenList() {
        if (this.items.Length == 0)
            return
        DarkSelect.Dismiss()
        DarkSelect.EnsurePopup()
        this.ignoreListChange := true
        DarkSelect.popupList.Delete()
        DarkSelect.popupList.Add(this.items)
        if (this.selectedIndex > 0)
            DarkSelect.popupList.Choose(this.selectedIndex)
        this.ignoreListChange := false

        this.face.GetPos(&fx, &fy, &fw, &fh)
        WinGetClientPos(&wx, &wy, , , this.ownerGui.Hwnd)
        rowH := 22
        listH := Min(this.items.Length, 12) * rowH + 6
        popupW := this.totalW > 0 ? this.totalW : fw
        DarkSelect.popupList.Move(0, 0, popupW, listH)
        DarkSelect.popupGui.Show("x" (wx + fx) " y" (wy + fy + fh) " w" popupW " h" listH)
        DarkSelect.openInst := this
    }

    CloseList() {
        if IsObject(DarkSelect.popupGui)
            DarkSelect.popupGui.Hide()
        if (DarkSelect.openInst = this)
            DarkSelect.openInst := ""
    }

    static Dismiss() {
        if IsObject(DarkSelect.openInst)
            DarkSelect.openInst.CloseList()
    }

    static EnsurePopup() {
        if IsObject(DarkSelect.popupGui)
            return
        pop := Gui("-Caption +ToolWindow +AlwaysOnTop")
        pop.BackColor := "3F3F46"
        pop.MarginX := 0
        pop.MarginY := 0
        pop.SetFont("s10 cFAFAFA", "Segoe UI")
        lb := pop.Add("ListBox", "x0 y0 w400 h220 -Theme Background3F3F46")
        try DllCall("uxtheme\SetWindowTheme", "ptr", lb.Hwnd, "wstr", "", "wstr", "")
        lb.OnEvent("Change", (*) => DarkSelect.OnPopupChange())
        DarkSelect.popupGui := pop
        DarkSelect.popupList := lb
    }

    static OnPopupChange() {
        inst := DarkSelect.openInst
        if !IsObject(inst) || inst.ignoreListChange
            return
        idx := DarkSelect.popupList.Value
        if (idx < 1)
            return
        inst.Choose(idx)
        inst.CloseList()
        if IsObject(inst.changeCallback)
            inst.changeCallback.Call(inst)
    }
}
