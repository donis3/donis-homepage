#Requires AutoHotkey v2.0+

class HouseGridDebug {
    overlay := ""
    overlays := []
    visible := false

    __New() {
        this.overlay := RectangleOverlay()
        this.overlays := []
    }

    Toggle() {
        if this.visible {
            this.Hide()
        } else {
            this.ShowAll()
        }
    }

    Show() {
        global GameConstants

        if !IsObject(GameConstants)
            return

        if !GameConstants.Has("GameUI")
            return

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("FirstGridPosition") || !uiConfig.Has("GridCellSize")
            return

        firstPos := uiConfig["FirstGridPosition"]
        cellSize := uiConfig["GridCellSize"]

        this.overlay.ShowAt(firstPos.x, firstPos.y, cellSize.x, cellSize.y)
        this.visible := true
    }

    ShowAll() {
        global GameConstants

        if !IsObject(GameConstants)
            return

        if !GameConstants.Has("GameUI")
            return

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("FirstGridPosition") || !uiConfig.Has("GridCellSize") || !uiConfig.Has("GridSpacing")
            return

        firstPos := uiConfig["FirstGridPosition"]
        cellSize := uiConfig["GridCellSize"]
        spacing := uiConfig["GridSpacing"]
        gridSize := uiConfig.Has("HouseGridSize") ? uiConfig["HouseGridSize"] : 5

        this.Hide()
        this.overlays := []

        loop gridSize {
            row := A_Index - 1
            loop gridSize {
                col := A_Index - 1
                cellX := firstPos.x + (col * (cellSize.x + spacing.x))
                cellY := firstPos.y + (row * (cellSize.y + spacing.y))

                overlay := RectangleOverlay()
                overlay.ShowAt(cellX, cellY, cellSize.x, cellSize.y)
                this.overlays.Push(overlay)
            }
        }

        this.visible := true
    }

    Hide() {
        if IsObject(this.overlay)
            this.overlay.Close()

        for _, overlay in this.overlays {
            if IsObject(overlay)
                overlay.Close()
        }

        this.overlays := []
        this.visible := false
    }
}
