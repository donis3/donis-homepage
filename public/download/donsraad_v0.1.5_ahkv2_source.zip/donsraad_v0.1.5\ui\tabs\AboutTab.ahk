#Requires AutoHotkey v2.0+

class AboutTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 5)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        pad := 20
        innerW := cardW - pad * 2

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h24 BackgroundTrans", "About"))
        y += 32

        brandH := 90
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h" brandH " Background" this.surfaceColor))
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w4 h" brandH " BackgroundEAB308"))
        g.SetFont("s16 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 8) " w" innerW " h24 BackgroundTrans",
            "DONSRAAD"))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 32) " w" innerW " h16 BackgroundTrans",
            "Easy Mission Picker"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 50) " w" innerW " h16 BackgroundTrans",
            "Version " this.GetAppVersion()))
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        projectLink := this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 68) " w" innerW " h16 BackgroundTrans",
            "donis.dev/projects/donsraad"))
        projectLink.OnEvent("Click", (*) => this.OpenProjectSite())
        y += brandH + 10

        helpH := 430
        colGap := 28
        colW := (innerW - colGap) // 2
        leftX := m + pad
        rightX := leftX + colW + colGap
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h" helpH " Background" this.surfaceColor))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" leftX " y" (y + 10) " w" innerW " h18 BackgroundTrans",
            "Help"))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" leftX " y" (y + 32) " w" colW " h16 BackgroundTrans",
            "How it works"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" leftX " y" (y + 52) " w" colW " h" (helpH - 64) " BackgroundTrans Wrap",
            "Landsraad missions are repeatable, but each specialization only shows a random handful of offers. "
            "Pick up to three missions you want to repeat — ideally in the same area — and Donsraad rolls the board until those three are in your active slots.`n`n"
            "Refresh uses guild disband. Filler offers fill your three slots, then disbanding clears them and rolls new offers. Repeat until your targets appear, then accept them."))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" rightX " y" (y + 32) " w" colW " h16 BackgroundTrans",
            "How to use"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" rightX " y" (y + 52) " w" colW " h" (helpH - 64) " BackgroundTrans Wrap",
            "1.  Settings — Character, guild name, and faction. Enable AutoRun if you want the next loop to start from Travel or the mission-report prompt.`n"
            "2.  Missions — Click a house cell and assign up to 3 targets. One specialization per cell.`n"
            "3.  First setup — Focus Dune: Awakening, then Initialize or press Start once.`n"
            "4.  Run — Press Start (Home) until your targets are active. If AutoRun is off, press Start again after you finish them.`n"
            "5.  AutoRun — Play, then leave Travel confirmation open at the ornithopter, or finish in the world so View mission report? appears. Either starts the next picker loop. After ready, mission-report detection waits 30 seconds. Overlay AUTO is green when AutoRun is on.`n"
            "6.  Stats — Completes, best times, and Availability. Availability is only recorded when you target exactly one mission from a specialization. It is 1 / (average abandons until it showed + 1) over the last 30 cycles.`n"
            "7.  Overlay — Status, run, mnemonic, and profile. Pick a screen corner in Settings (not top middle). Count turns green when targets are ready.`n"
            "8.  Dashboard — Window X hides the UI. Tray icon or Delete shows it. Pause exits. Rebind in Settings."))
        y += helpH + 10

        devH := this.winH - y - 52
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h" devH " Background" this.surfaceColor))
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w4 h" devH " BackgroundEAB308"))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 14) " w" innerW " h20 BackgroundTrans",
            "Developer"))

        picSize := 64
        picX := m + pad
        picY := y + 40
        photoPath := A_ScriptDir "\ui\donis.png"
        textX := picX
        nameW := innerW
        if FileExist(photoPath) {
            this.PageAdd(5, g.Add("Text",
                "x" (picX - 2) " y" (picY - 2) " w" (picSize + 4) " h" (picSize + 4) " BackgroundEAB308"))
            this.PageAdd(5, g.Add("Picture",
                "x" picX " y" picY " w" picSize " h" picSize, photoPath))
            textX := picX + picSize + 16
            nameW := innerW - picSize - 16
        }

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 40) " w" nameW " h22 BackgroundTrans",
            "Deniz Özkan"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 62) " w" nameW " h16 BackgroundTrans",
            "Dune: Awakening Landsraad companion"))
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        siteLink := this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 80) " w" nameW " h16 BackgroundTrans",
            "donis.dev"))
        siteLink.OnEvent("Click", (*) => this.OpenDeveloperSite())
        projectSiteLink := this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 98) " w" nameW " h16 BackgroundTrans",
            "donis.dev/projects/donsraad"))
        projectSiteLink.OnEvent("Click", (*) => this.OpenProjectSite())

        purposeY := y + 128
        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" purposeY " w" innerW " h16 BackgroundTrans",
            "Why this exists"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text",
            "x" (m + pad) " y" (purposeY + 18) " w" innerW " h48 BackgroundTrans Wrap",
            "Random Landsraad missions scatter you across the map. Donsraad keeps you on jobs in the same area so you can actually play — fewer loading screens, less travel."))

        g.SetFont("s8 c52525B", "Segoe UI")
        this.PageAdd(5, g.Add("Text",
            "x" (m + pad) " y" (y + devH - 28) " w" innerW " h16 BackgroundTrans",
            "© 2026 Deniz Özkan. All rights reserved.  ·  v" this.GetAppVersion()))
    }
}
