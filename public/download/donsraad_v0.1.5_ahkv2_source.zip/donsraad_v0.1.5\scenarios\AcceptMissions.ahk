#Requires AutoHotkey v2.0+

/**
 * Accept Missions Scenario
 * On each house the player has targetted, accept offered missions that are NOT
 * in the targetted list (Space). Targetted offers are left untouched.
 * Stops after 3 accepts (game active-mission cap). If every targetted mission
 * for a house is already in that house's offers, skip the house (Esc).
 *
 * After Execute(), GetStatus() reports the last run:
 *   error — empty when the loop finished without a hard stop
 *   missingTargettedMissionCount — targetted missions not seen in that house's offers
 * If missingTargettedMissionCount is 0 and error is empty, every targetted
 * mission was available to pick up.
 *
 * Callable via acceptMissionsScenarioInst.Execute().
 *
 * Assumes the Landsraad house grid tab is already open.
 */
class AcceptMissionsScenario {
    stateManager := ""
    logger := ""
    anchorMatcher := ""
    lastStatus := ""
    sessionAcceptedNames := ""
    sessionAcceptedCount := 0
    houseOpenWaitMs := 100
    minReadConfidence := 0.4
    imageVariation := 30
    soloTargetBySpec := ""
    recordedSoloSpecs := ""
    huntAbandonStart := 0

    __New(stateManagerInst := "", loggerInst := "", anchorMatcherInst := "") {
        this.stateManager := stateManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.ResetSession()
    }

    /**
     * Clears the sequence-level accepted-mission list. Call when a new
     * accept sequence starts and after RemoveActiveMissions.
     */
    ResetSession() {
        this.sessionAcceptedNames := Map()
        this.sessionAcceptedCount := 0
    }

    /**
     * Start of a full pick sequence (before leftover disbands).
     * Solo-spec targets record abandonsUntilReveal when they appear.
     */
    BeginHunt() {
        this.ResetSession()
        this.recordedSoloSpecs := Map()
        this.huntAbandonStart := this.GetGuildAbandonTotal()
        this.RefreshSoloSpecTargets()
    }

    GetGuildAbandonTotal() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetStat")
            return Integer(this.stateManager.GetStat("guildAbandons"))
        return 0
    }

    RefreshSoloSpecTargets() {
        this.soloTargetBySpec := Map()
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("GetTargetedMissions")
            return
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return

        bySpec := Map()
        for _, mission in targeted {
            if !IsObject(mission)
                continue
            name := mission.HasOwnProp("missionName") ? Trim(mission.missionName) : ""
            spec := mission.HasOwnProp("specialization") ? Trim(mission.specialization) : ""
            if (spec == "" && name != "" && this.stateManager.HasMethod("GetMissionSpecialization"))
                spec := this.stateManager.GetMissionSpecialization(name)
            if (name == "" || spec == "")
                continue
            specKey := StrLower(spec)
            if !bySpec.Has(specKey)
                bySpec[specKey] := []
            bySpec[specKey].Push(name)
        }

        for specKey, names in bySpec {
            if (names.Length == 1)
                this.soloTargetBySpec[specKey] := names[1]
        }
    }

    IsAlreadyAccepted(missionName) {
        if (missionName == "" || !IsObject(this.sessionAcceptedNames))
            return false
        return this.sessionAcceptedNames.Has(StrLower(missionName))
    }

    MarkAccepted(missionName) {
        if (missionName == "")
            return
        if !IsObject(this.sessionAcceptedNames)
            this.sessionAcceptedNames := Map()
        key := StrLower(missionName)
        if this.sessionAcceptedNames.Has(key)
            return
        this.sessionAcceptedNames[key] := true
        this.sessionAcceptedCount++
    }

    EnsureGameActive() {
        gameWindows := ["ahk_exe Dune-Win64-Shipping.exe", "ahk_exe Dune.exe", "Dune: Awakening", "Dune"]
        for _, winTitle in gameWindows {
            if WinExist(winTitle) {
                try {
                    WinActivate(winTitle)
                    WinWaitActive(winTitle, , 2)
                    Sleep(100)
                    return true
                }
            }
        }
        return false
    }

    /**
     * Last-run result for orchestration.
     * error is empty when the loop finished without a hard stop.
     * missingTargettedMissionCount is 0 when every targetted mission was seen
     * in that house's offers (and can be picked up).
     */
    GetStatus() {
        if IsObject(this.lastStatus)
            return this.lastStatus
        return this.MakeStatus()
    }

    /**
     * @returns {Boolean} - True when the house loop finishes, false on a hard stop.
     */
    Execute() {
        this.lastStatus := this.MakeStatus()
        this.Debug("[AcceptMissions] Starting scenario...")
        this.EnsureGameActive()

        if !IsObject(this.stateManager) {
            this.SetStatus(0, "State manager is unavailable.")
            this.Log("[AcceptMissions] Error: State manager is unavailable.")
            return false
        }

        targeted := this.stateManager.GetTargetedMissions()
        if (targeted.Length == 0) {
            this.SetStatus(0, "No targetted missions were found.")
            this.Log("[AcceptMissions] No targeted missions selected.")
            return false
        }

        targetedNames := this.BuildTargetedNameMap(targeted)
        this.RefreshSoloSpecTargets()
        houses := this.GetTargetedHouses(targeted)
        acceptedCount := this.sessionAcceptedCount
        newAccepted := 0
        maxActive := 3
        missingCount := 0
        visitedSlots := Map()
        this.Debug("[AcceptMissions] Looping " houses.Length " targetted house(s). Session accepted="
            acceptedCount "/" maxActive ".")

        for houseIdx, house in houses {
            if this.IsCancelled() {
                this.Debug("[AcceptMissions] Cancelled.")
                this.SetStatus(missingCount, "", acceptedCount, newAccepted)
                return false
            }
            if (acceptedCount >= maxActive) {
                this.Debug("[AcceptMissions] Reached " maxActive " accepted missions (global cap). Stopping.")
                break
            }

            this.Debug("[AcceptMissions] House cell " house.gridLocation
                " (row " house.gridRow ", col " house.gridCol ").")

            if !this.OpenHouse(house) {
                this.FailOfferWindow(house)
                remaining := this.CountTargetsFromHouseIndex(houses, houseIdx)
                this.SetStatus(missingCount + remaining,
                    "Offer window did not open at grid " house.gridLocation ".", acceptedCount, newAccepted)
                return false
            }

            offered := this.ReadOfferedMissions()
            recognized := this.GetRecognizedMissions(offered)
            this.LogOfferedMissions(offered)

            if (recognized.Length != 3) {
                this.FailMissionRead(house)
                remaining := this.CountTargetsFromHouseIndex(houses, houseIdx)
                this.SetStatus(missingCount + remaining,
                    "Failed to read offered missions at grid " house.gridLocation ".", acceptedCount, newAccepted)
                return false
            }

            if !this.HouseSpecializationMatches(house, recognized) {
                remaining := this.CountTargetsFromHouseIndex(houses, houseIdx)
                this.SetStatus(missingCount + remaining, "Wrong specialization", acceptedCount, newAccepted)
                return false
            }

            missingHere := this.CountMissingTargetsForHouse(house, recognized)
            missingCount += missingHere
            visitedSlots[house.gridLocation] := true

            if this.HouseTargetsAreOffered(house, recognized) {
                this.Debug("[AcceptMissions] All targetted missions for house " house.gridLocation
                    " are in the offers. Skipping.")
                this.RecordSoloSpecHuntIfReady(house)
                this.CloseOfferWindowIfOpen()
                continue
            }

            nonTargeted := this.GetNonTargetedOffers(recognized, targetedNames)
            if (nonTargeted.Length == 0) {
                this.Debug("[AcceptMissions] No non-targetted offers on house " house.gridLocation ".")
                this.CloseOfferWindowIfOpen()
                continue
            }

            this.Debug("[AcceptMissions] " nonTargeted.Length " non-targetted offer(s) on house "
                house.gridLocation ".")

            stopHouses := false
            for offerIdx, offer in nonTargeted {
                if (acceptedCount >= maxActive) {
                    stopHouses := true
                    break
                }

                if (offerIdx > 1) {
                    this.Debug("[AcceptMissions] Re-opening house " house.gridLocation
                        " for the next non-targetted mission.")
                    if !this.OpenHouse(house) {
                        this.FailOfferWindow(house)
                        remaining := this.CountTargetsFromHouseIndex(houses, houseIdx + 1)
                        this.SetStatus(missingCount + remaining,
                            "Offer window did not open at grid " house.gridLocation ".", acceptedCount, newAccepted)
                        return false
                    }
                }

                this.Debug("[AcceptMissions] Accepting non-targetted " offer.matchedName
                    " on house " house.gridLocation " slot " offer.index ".")
                this.ClickMissionOffer(offer)
                InputHelper.SendGameKey("Space")
                this.MarkAccepted(offer.matchedName)
                newAccepted++
                acceptedCount := this.sessionAcceptedCount
                this.Debug("[AcceptMissions] Accepted count: " acceptedCount "/" maxActive " (global).")
                InputHelper.FastMove(0, 0)
                userDelay(this.houseOpenWaitMs)

                if (acceptedCount >= maxActive) {
                    this.Debug("[AcceptMissions] Reached " maxActive " accepted missions (global cap). Stopping.")
                    stopHouses := true
                    break
                }
            }

            this.Debug("[AcceptMissions] Finished non-targetted accepts for house "
                house.gridLocation ".")
            this.CloseOfferWindowIfOpen()
            if (stopHouses)
                break
        }

        for _, house in houses {
            if !visitedSlots.Has(house.gridLocation)
                missingCount += this.CountHouseTargets(house)
        }

        this.SetStatus(missingCount, "", acceptedCount, newAccepted)
        this.Debug("[AcceptMissions] Finished. accepted=" acceptedCount
            " newAccepted=" newAccepted " missingTargettedMissionCount=" missingCount ".")
        return true
    }

    OpenHouse(house) {
        clickPos := this.GetHouseClickPos(house.gridLocation)
        if (!IsObject(clickPos)) {
            this.Log("[AcceptMissions] Error: House grid coordinates missing in GameConstants.")
            return false
        }

        this.Debug("[AcceptMissions] Clicking house cell " house.gridLocation
            " at (" clickPos.x ", " clickPos.y ")...")
        InputHelper.SendGameClick(clickPos.x, clickPos.y)
        InputHelper.FastMove(0, 0)

        if !this.WaitForOfferWindow() {
            this.Log("[AcceptMissions] Error: Offer window did not open at grid "
                house.gridLocation " (row " house.gridRow ", col " house.gridCol ").")
            return false
        }

        return true
    }

    /**
     * If the offer window is still open, close it with Esc before the next house.
     */
    CloseOfferWindowIfOpen() {
        if !this.IsOfferWindowOpen()
            return

        this.Debug("[AcceptMissions] Offer window still open. Sending Esc.")
        InputHelper.SendGameKey("Esc")
        InputHelper.FastMove(0, 0)
    }

    IsOfferWindowOpen() {
        searchArea := this.GetOfferWindowSearchArea()
        if (!IsObject(searchArea))
            return false

        foundX := 0, foundY := 0
        return this.anchorMatcher.FindAnchor("accept_mission_anchor.png", &foundX, &foundY, searchArea, this.imageVariation)
    }

    GetOfferWindowSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("AcceptMissionAnchor")
            return ""

        btn := GameConstants["GameUI"]["AcceptMissionAnchor"]
        rm := ResolutionManager()
        pos := rm.coords(btn.x, btn.y)
        size := rm.dimensions(btn.w, btn.h)
        padding := 20
        return {
            x1: Max(0, pos.x - padding),
            y1: Max(0, pos.y - padding),
            x2: Min(A_ScreenWidth, pos.x + size.w + padding),
            y2: Min(A_ScreenHeight, pos.y + size.h + padding)
        }
    }

    /**
     * Confirms the accept-mission window via accept_mission_anchor.png in AcceptMissionAnchor.
     */
    WaitForOfferWindow(timeoutMs := 3000) {
        searchArea := this.GetOfferWindowSearchArea()
        if (!IsObject(searchArea)) {
            this.Log("[AcceptMissions] Error: AcceptMissionAnchor missing in GameConstants.")
            return false
        }

        imageName := "accept_mission_anchor.png"
        foundX := 0, foundY := 0
        this.Debug("[AcceptMissions] Waiting up to " timeoutMs "ms for " imageName
            " in [" searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        startTime := A_TickCount
        while (A_TickCount - startTime < timeoutMs) {
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation) {
                this.Debug("[AcceptMissions] Offer window confirmed at (" foundX ", " foundY ").")
                return true
            }
            Sleep(100)
            if this.IsCancelled()
                return false
        }
        return false
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    ClickMissionOffer(offer) {
        box := offer.box
        clickX := box.screenX + (box.screenW // 2)
        clickY := box.screenY + (box.screenH // 2)
        this.Debug("[AcceptMissions] Clicking offer slot " offer.index
            " at (" clickX ", " clickY ")...")
        InputHelper.SendGameClick(clickX, clickY)
    }

    FailOfferWindow(house) {
        posInfo := "grid " house.gridLocation " (row " house.gridRow ", col " house.gridCol ")"
        this.SetOverlayState("mission window error")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("mission window error")
    }

    FailMissionRead(house) {
        posInfo := "grid " house.gridLocation " (row " house.gridRow ", col " house.gridCol ")"
        this.Log("[AcceptMissions] Error: Failed to read offered missions at " posInfo ".")
        this.SetOverlayState("mission read error")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("mission read error")
    }

    HouseSpecializationMatches(house, recognized) {
        targetSpec := this.GetHouseTargetSpecialization(house)
        offeredSpec := this.GetOfferedSpecialization(recognized)
        if (targetSpec == "" || offeredSpec == "")
            return true
        if (StrLower(targetSpec) == StrLower(offeredSpec))
            return true

        this.FailSpecializationMismatch(house, targetSpec, offeredSpec)
        return false
    }

    GetHouseTargetSpecialization(house) {
        if !IsObject(house.missions)
            return ""
        for _, mission in house.missions {
            spec := ""
            if IsObject(mission) && mission.HasOwnProp("specialization")
                spec := mission.specialization
            if (spec == "" && IsObject(mission) && mission.HasOwnProp("missionName") && mission.missionName != "" && IsObject(this.stateManager))
                spec := this.stateManager.GetMissionSpecialization(mission.missionName)
            if (spec != "")
                return spec
        }
        return ""
    }

    GetOfferedSpecialization(recognized) {
        counts := Map()
        for _, entry in recognized {
            spec := ""
            if IsObject(entry) && entry.HasOwnProp("specialization")
                spec := entry.specialization
            if (spec == "" && IsObject(entry) && entry.HasOwnProp("matchedName") && entry.matchedName != "" && IsObject(this.stateManager))
                spec := this.stateManager.GetMissionSpecialization(entry.matchedName)
            if (spec == "")
                continue
            key := StrLower(spec)
            if !counts.Has(key)
                counts[key] := { name: spec, n: 0 }
            item := counts[key]
            item.n++
            counts[key] := item
        }

        bestName := ""
        bestN := 0
        for _, item in counts {
            if (item.n > bestN) {
                bestN := item.n
                bestName := item.name
            }
        }
        return bestName
    }

    RecordSoloSpecHuntIfReady(house) {
        specKey := StrLower(this.GetHouseTargetSpecialization(house))
        if (specKey == "" || !IsObject(this.soloTargetBySpec) || !this.soloTargetBySpec.Has(specKey))
            return
        if IsObject(this.recordedSoloSpecs) && this.recordedSoloSpecs.Has(specKey)
            return

        missionName := this.soloTargetBySpec[specKey]
        count := this.GetGuildAbandonTotal() - Integer(this.huntAbandonStart)
        if (count < 0)
            count := 0
        if !IsObject(this.recordedSoloSpecs)
            this.recordedSoloSpecs := Map()
        this.recordedSoloSpecs[specKey] := true

        if IsObject(this.stateManager) && this.stateManager.HasMethod("RecordAbandonsUntilReveal")
            this.stateManager.RecordAbandonsUntilReveal(missionName, count)
        this.Debug("[AcceptMissions] Solo " specKey " hunt: " count
            " abandon(s) until `"" missionName "`" showed.")
    }

    FailSpecializationMismatch(house, targetSpec, offeredSpec) {
        this.CloseOfferWindowIfOpen()
        this.Log("[AcceptMissions] Error: House cell " house.gridLocation
            " offers " offeredSpec ", but the targetted mission is " targetSpec ". Stopping.")
        this.SetOverlayState("Wrong specialization")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("Wrong specialization")
    }

    SetOverlayState(label) {
        StatusBar.SetStatus(label)
    }

    BuildTargetedNameMap(targeted) {
        names := Map()
        for _, mission in targeted {
            if (mission.missionName != "")
                names[StrLower(mission.missionName)] := true
        }
        return names
    }

    GetTargetedHouses(targeted) {
        bySlot := Map()
        for _, mission in targeted {
            slotIdx := mission.gridLocation
            if (slotIdx < 1)
                continue
            if (!bySlot.Has(slotIdx)) {
                bySlot[slotIdx] := {
                    gridLocation: slotIdx,
                    gridRow: mission.gridRow,
                    gridCol: mission.gridCol,
                    missions: []
                }
            }
            bySlot[slotIdx].missions.Push(mission)
        }

        houses := []
        loop 25 {
            if bySlot.Has(A_Index)
                houses.Push(bySlot[A_Index])
        }
        return houses
    }

    GetRecognizedMissions(offered) {
        recognized := []
        for _, entry in offered {
            if (entry.matchedName != "" && entry.confidence >= this.minReadConfidence)
                recognized.Push(entry)
        }
        return recognized
    }

    GetNonTargetedOffers(recognized, targetedNames) {
        nonTargeted := []
        for _, entry in recognized {
            if targetedNames.Has(StrLower(entry.matchedName))
                continue
            if this.IsAlreadyAccepted(entry.matchedName) {
                this.Debug("[AcceptMissions] Skipping already-accepted " entry.matchedName
                    " (slot " entry.index ").")
                continue
            }
            nonTargeted.Push(entry)
        }
        return nonTargeted
    }

    /**
     * Last-run status object. Property names are unquoted per project rules.
     */
    MakeStatus(missingTargettedMissionCount := 0, error := "", acceptedCount := 0, newAcceptedCount := 0) {
        return {
            error: error,
            missingTargettedMissionCount: missingTargettedMissionCount,
            acceptedCount: acceptedCount,
            newAcceptedCount: newAcceptedCount
        }
    }

    SetStatus(missingTargettedMissionCount := 0, error := "", acceptedCount := 0, newAcceptedCount := 0) {
        this.lastStatus := this.MakeStatus(missingTargettedMissionCount, error, acceptedCount, newAcceptedCount)
        if (error != "")
            this.Debug("[AcceptMissions] Status error: " error
                " missingTargettedMissionCount=" missingTargettedMissionCount
                " acceptedCount=" acceptedCount)
        else
            this.Debug("[AcceptMissions] Status: missingTargettedMissionCount="
                missingTargettedMissionCount " acceptedCount=" acceptedCount
                " newAcceptedCount=" newAcceptedCount)
    }

    CountHouseTargets(house) {
        count := 0
        if !IsObject(house.missions)
            return 0
        for _, mission in house.missions {
            if (mission.missionName != "")
                count++
        }
        return count
    }

    CountTargetsFromHouseIndex(houses, startIdx) {
        total := 0
        for idx, house in houses {
            if (idx >= startIdx)
                total += this.CountHouseTargets(house)
        }
        return total
    }

    CountMissingTargetsForHouse(house, recognized) {
        if (!IsObject(house.missions) || house.missions.Length == 0)
            return 0

        offeredNames := Map()
        for _, entry in recognized {
            if (entry.matchedName != "")
                offeredNames[StrLower(entry.matchedName)] := true
        }

        missing := 0
        for _, mission in house.missions {
            if (mission.missionName == "")
                continue
            if !offeredNames.Has(StrLower(mission.missionName))
                missing++
        }
        return missing
    }

    /**
     * True when every targetted mission for this house appears in the offered list.
     */
    HouseTargetsAreOffered(house, recognized) {
        if (!IsObject(house.missions) || house.missions.Length == 0)
            return false

        offeredNames := Map()
        for _, entry in recognized {
            if (entry.matchedName != "")
                offeredNames[StrLower(entry.matchedName)] := true
        }

        for _, mission in house.missions {
            if (mission.missionName == "")
                continue
            if !offeredNames.Has(StrLower(mission.missionName))
                return false
        }
        return true
    }

    LogOfferedMissions(offered) {
        this.Debug("[AcceptMissions] Offered missions:")
        for _, entry in offered {
            if (entry.matchedName != "" && entry.confidence >= this.minReadConfidence) {
                specInfo := entry.specialization != "" ? " [" entry.specialization "]" : ""
                this.Debug("[AcceptMissions]   Slot " entry.index ": " entry.matchedName specInfo)
            } else if (entry.normalizedText != "") {
                this.Debug("[AcceptMissions]   Slot " entry.index ": " entry.normalizedText " (unrecognized)")
            } else {
                this.Debug("[AcceptMissions]   Slot " entry.index ": (empty)")
            }
        }
    }

    GetHouseClickPos(slotIdx) {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return ""

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("FirstGridPosition") || !uiConfig.Has("GridCellSize") || !uiConfig.Has("GridSpacing")
            return ""

        gridSize := uiConfig.Has("HouseGridSize") ? uiConfig["HouseGridSize"] : 5
        firstPos := uiConfig["FirstGridPosition"]
        cellSize := uiConfig["GridCellSize"]
        spacing := uiConfig["GridSpacing"]

        col := Mod(slotIdx - 1, gridSize)
        row := (slotIdx - 1) // gridSize
        cellX := firstPos.x + (col * (cellSize.x + spacing.x))
        cellY := firstPos.y + (row * (cellSize.y + spacing.y))
        centerX := cellX + (cellSize.x / 2)
        centerY := cellY + (cellSize.y / 2)

        return ResolutionManager().coords(centerX, centerY)
    }

    ReadOfferedMissions() {
        reader := MissionHandlerDebug(this.logger, this.stateManager)
        return reader.ReadMissions()
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
