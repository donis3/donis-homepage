#Requires AutoHotkey v2.0+

/**
 * Landsraad State Manager class.
 * Handles database lookups and player state persistence (player_state.json).
 */
class LandsraadStateManager {
    workspaceRoot := ""
    dbHousesPath := ""
    dbMissionsPath := ""
    playerStatePath := ""

    housesMap := Map()           ; "House Alexin" -> "Crafting"
    missionsBySpec := Map()      ; "Crafting" -> ["Convergence", ...]
    missionSpecMap := Map()      ; "Convergence" -> "Crafting"
    allHousesList := []          ; [{house: "House Alexin", specialization: "Crafting"}]
    allMissionsList := []        ; [{specialization: "Crafting", name: "Convergence"}]
    dbErrors := []
    housesReady := false
    missionsReady := false

    currentPlayerState := Map()  ; Runtime state loaded from player_state.json
    mnemonicDeviceKnown := false

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        
        this.workspaceRoot := rootDir
        this.dbHousesPath := rootDir . "\db\landsraad_houses.json"
        this.dbMissionsPath := rootDir . "\db\landsraad_missions.json"
        this.playerStatePath := rootDir . "\player_state.json"

        this.LoadDatabases()
        this.LoadPlayerState()
    }

    /**
     * Loads landsraad_houses.json and landsraad_missions.json into memory.
     * Each file must exist, parse as JSON, and be a non-empty array.
     */
    LoadDatabases() {
        this.dbErrors := []
        this.housesReady := false
        this.missionsReady := false
        this.housesMap := Map()
        this.missionSpecMap := Map()
        this.allHousesList := []
        this.allMissionsList := []
        this.missionsBySpec := Map()
        this.missionsBySpec["Crafting"] := []
        this.missionsBySpec["Gathering"] := []
        this.missionsBySpec["Exploration"] := []
        this.missionsBySpec["Combat"] := []
        this.missionsBySpec["Sabotage"] := []

        parsedHouses := this.LoadJsonArray(this.dbHousesPath, "houses")
        if (parsedHouses is Array) {
            this.allHousesList := parsedHouses
            this.housesReady := true
            for _, item in parsedHouses {
                if !(item is Map)
                    continue
                hName := item.Has("house") ? item["house"] : ""
                hSpec := item.Has("specialization") ? item["specialization"] : ""
                if (hName != "") {
                    this.housesMap[StrLower(hName)] := hSpec
                    this.housesMap[hName] := hSpec
                }
            }
        }

        parsedMissions := this.LoadJsonArray(this.dbMissionsPath, "missions")
        if (parsedMissions is Array) {
            this.allMissionsList := parsedMissions
            this.missionsReady := true
            for _, item in parsedMissions {
                if !(item is Map)
                    continue
                mName := item.Has("name") ? item["name"] : ""
                mSpec := item.Has("specialization") ? item["specialization"] : ""
                if (mName != "") {
                    this.missionSpecMap[StrLower(mName)] := mSpec
                    this.missionSpecMap[mName] := mSpec
                    if (!this.missionsBySpec.Has(mSpec))
                        this.missionsBySpec[mSpec] := []
                    this.missionsBySpec[mSpec].Push(mName)
                }
            }
        }
    }

    LoadJsonArray(path, label) {
        if !FileExist(path) {
            this.dbErrors.Push("Missing " label " database: " path)
            return ""
        }
        try {
            rawJson := FileRead(path, "UTF-8")
            parsed := JSON.Parse(rawJson)
            if !(parsed is Array) {
                this.dbErrors.Push(label " database is not a JSON array: " path)
                return ""
            }
            if (parsed.Length < 1) {
                this.dbErrors.Push(label " database is empty: " path)
                return ""
            }
            return parsed
        } catch as err {
            this.dbErrors.Push("Failed to parse " label " database: " err.Message)
            return ""
        }
    }

    AreDatabasesReady() {
        return this.housesReady && this.missionsReady
    }

    /**
     * Loads player_state.json or writes a default file if it is missing.
     * Existing files are migrated in place (legacy keys dropped, new stat
     * fields filled) so an older profile keeps completes, targets, and times.
     */
    LoadPlayerState() {
        if FileExist(this.playerStatePath) {
            try {
                rawJson := FileRead(this.playerStatePath, "UTF-8")
                this.currentPlayerState := JSON.Parse(rawJson)
                if (this.currentPlayerState is Map) {
                    this.MigrateMissionSelections()
                    this.NormalizePlayerState()
                    this.ClearSessionMnemonicDevice()
                    this.ClearCurrentRunStart()
                    return
                }
            } catch {
                ; If corrupt or error, recreate default
            }
        }

        this.currentPlayerState := this.GetDefaultPlayerState()
        this.SavePlayerState()
    }

    GetDefaultPlayerState() {
        return Map(
            "version", "1.0",
            "lastUpdated", FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss"),
            "activeMissions", [],
            "targettedMissions", [],
            "guildAbandons", 0,
            "targettedAccepts", 0,
            "mnemonicDevicesSpent", 0,
            "successfulRunDurations", [],
            "currentRunStartAt", "",
            "lastRunDuration", "",
            "missionStats", [],
            "mnemonicDevice", 0,
            "mnemonicDeviceMax", 0
        )
    }

    ApplyPlayerState(stateMap) {
        if !(stateMap is Map) || stateMap.Count == 0
            this.currentPlayerState := this.GetDefaultPlayerState()
        else
            this.currentPlayerState := stateMap
        this.MigrateMissionSelections()
        this.NormalizePlayerState()
        this.ClearSessionMnemonicDevice()
        this.ClearCurrentRunStart()
        this.SavePlayerState()
    }

    ClonePlayerState() {
        try {
            return JSON.Parse(JSON.Stringify(this.currentPlayerState))
        } catch {
            return this.GetDefaultPlayerState()
        }
    }

    /**
     * Persists runtime state to player_state.json with UTF-8 encoding.
     */
    SavePlayerState() {
        this.currentPlayerState["lastUpdated"] := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
        liveCurrent := this.currentPlayerState.Has("mnemonicDevice") ? this.currentPlayerState["mnemonicDevice"] : 0
        liveMax := this.currentPlayerState.Has("mnemonicDeviceMax") ? this.currentPlayerState["mnemonicDeviceMax"] : 0
        known := this.mnemonicDeviceKnown
        this.currentPlayerState["mnemonicDevice"] := 0
        this.currentPlayerState["mnemonicDeviceMax"] := 0
        jsonString := JSON.Stringify(this.currentPlayerState, 2)
        
        fileObj := FileOpen(this.playerStatePath, "w", "UTF-8")
        fileObj.Write(jsonString)
        fileObj.Close()

        global profileManagerInst
        if IsSet(profileManagerInst) && IsObject(profileManagerInst) {
            profileManagerInst.CaptureCurrentState(this)
            profileManagerInst.SaveProfilesFile()
        }

        this.currentPlayerState["mnemonicDevice"] := liveCurrent
        this.currentPlayerState["mnemonicDeviceMax"] := liveMax
        this.mnemonicDeviceKnown := known
    }

    /**
     * Looks up specialization for a house name.
     */
    GetHouseSpecialization(houseName) {
        if (this.housesMap.Has(houseName))
            return this.housesMap[houseName]
        if (this.housesMap.Has(StrLower(houseName)))
            return this.housesMap[StrLower(houseName)]
        return ""
    }

    /**
     * Looks up specialization for a mission name.
     */
    GetMissionSpecialization(missionName) {
        if (this.missionSpecMap.Has(missionName))
            return this.missionSpecMap[missionName]
        if (this.missionSpecMap.Has(StrLower(missionName)))
            return this.missionSpecMap[StrLower(missionName)]
        return ""
    }

    /**
     * Converts a 1-based 5x5 slot index into row/col (1-based, left-to-right, top-to-bottom).
     */
    SlotToGrid(slotIdx) {
        if (slotIdx < 1)
            return { row: 0, col: 0 }
        return {
            row: ((slotIdx - 1) // 5) + 1,
            col: Mod(slotIdx - 1, 5) + 1
        }
    }

    FormatMissionLabel(specialization, missionName) {
        if (specialization != "")
            return specialization . " — " . missionName
        return missionName
    }

    ParseMissionLabel(label) {
        spec := ""
        name := Trim(label)
        parts := StrSplit(label, " — ", , 2)
        if (parts.Length >= 2) {
            spec := Trim(parts[1])
            name := Trim(parts[2])
        }
        if (spec == "" && name != "")
            spec := this.GetMissionSpecialization(name)
        return {
            missionName: name,
            specialization: spec
        }
    }

    /**
     * Reads one persisted targetted-mission record (Map or object) into a typed object.
     */
    ParseTargetedEntry(entry, fallbackSlot := 0) {
        gridLocation := fallbackSlot
        missionName := ""
        specialization := ""

        if (entry is Map) {
            if (entry.Has("gridLocation"))
                gridLocation := entry["gridLocation"]
            else if (entry.Has("slot"))
                gridLocation := entry["slot"]
            if (entry.Has("missionName"))
                missionName := entry["missionName"]
            if (entry.Has("specialization"))
                specialization := entry["specialization"]
        } else if (IsObject(entry)) {
            if (entry.HasOwnProp("gridLocation"))
                gridLocation := entry.gridLocation
            else if (entry.HasOwnProp("slot"))
                gridLocation := entry.slot
            if (entry.HasOwnProp("missionName"))
                missionName := entry.missionName
            if (entry.HasOwnProp("specialization"))
                specialization := entry.specialization
        } else if (entry is String) {
            parsed := this.ParseMissionLabel(entry)
            missionName := parsed.missionName
            specialization := parsed.specialization
        }

        if (specialization == "" && missionName != "")
            specialization := this.GetMissionSpecialization(missionName)

        grid := this.SlotToGrid(gridLocation)
        return {
            gridLocation: gridLocation,
            gridRow: grid.row,
            gridCol: grid.col,
            missionName: missionName,
            specialization: specialization
        }
    }

    BuildTargetedRecord(gridLocation, missionName, specialization) {
        grid := this.SlotToGrid(gridLocation)
        return Map(
            "gridLocation", gridLocation,
            "gridRow", grid.row,
            "gridCol", grid.col,
            "missionName", missionName,
            "specialization", specialization
        )
    }

    /**
     * Migrates legacy missionSelections labels into targettedMissions, then drops the old key.
     */
    MigrateMissionSelections() {
        hasLegacy := this.currentPlayerState.Has("missionSelections")
        hasNew := this.currentPlayerState.Has("targettedMissions")
            && this.currentPlayerState["targettedMissions"] is Array
            && this.currentPlayerState["targettedMissions"].Length > 0

        if (hasLegacy && !hasNew) {
            converted := []
            saved := this.currentPlayerState["missionSelections"]
            if (saved is Array) {
                for _, entry in saved {
                    if (!(entry is Map))
                        continue
                    slotIdx := entry.Has("slot") ? entry["slot"] : 0
                    if (!entry.Has("missions") || !(entry["missions"] is Array))
                        continue
                    for _, label in entry["missions"] {
                        if (label == "")
                            continue
                        parsed := this.ParseMissionLabel(label)
                        converted.Push(this.BuildTargetedRecord(slotIdx, parsed.missionName, parsed.specialization))
                    }
                }
            }
            this.currentPlayerState["targettedMissions"] := converted
        }

        if (hasLegacy)
            this.currentPlayerState.Delete("missionSelections")

        if (!this.currentPlayerState.Has("targettedMissions"))
            this.currentPlayerState["targettedMissions"] := []

        if (hasLegacy)
            this.SavePlayerState()
    }

    /**
     * Drops unused legacy fields and ensures profile stats exist.
     */
    NormalizePlayerState() {
        if !(this.currentPlayerState is Map)
            this.currentPlayerState := this.GetDefaultPlayerState()

        dirty := false
        for _, key in ["dailyStats", "completedMissions", "activeHouses"] {
            if this.currentPlayerState.Has(key) {
                this.currentPlayerState.Delete(key)
                dirty := true
            }
        }
        if this.EnsureStatKey("guildAbandons")
            dirty := true
        if this.EnsureStatKey("targettedAccepts")
            dirty := true
        if this.EnsureStatKey("mnemonicDevicesSpent")
            dirty := true
        if this.EnsureRunDurationFields()
            dirty := true
        if this.EnsureMissionStats()
            dirty := true
        if this.EnsureMnemonicDeviceFields()
            dirty := true
        if (this.currentPlayerState["mnemonicDevice"] != 0 || this.currentPlayerState["mnemonicDeviceMax"] != 0)
            dirty := true
        this.ClearSessionMnemonicDevice()
        if (!this.currentPlayerState.Has("activeMissions") || !(this.currentPlayerState["activeMissions"] is Array)) {
            this.currentPlayerState["activeMissions"] := []
            dirty := true
        }
        if (!this.currentPlayerState.Has("targettedMissions") || !(this.currentPlayerState["targettedMissions"] is Array)) {
            this.currentPlayerState["targettedMissions"] := []
            dirty := true
        }
        if (dirty)
            this.SavePlayerState()
    }

    EnsureStatKey(key) {
        if this.currentPlayerState.Has(key) {
            try {
                n := Integer(this.currentPlayerState[key])
            } catch {
                n := 0
            }
            if (n < 0)
                n := 0
            if (this.currentPlayerState[key] != n) {
                this.currentPlayerState[key] := n
                return true
            }
            return false
        }
        this.currentPlayerState[key] := 0
        return true
    }

    maxStoredRunDurations := 50
    maxStoredAbandonsUntilReveal := 30

    EnsureRunDurationFields() {
        dirty := false
        if (!this.currentPlayerState.Has("successfulRunDurations") || !(this.currentPlayerState["successfulRunDurations"] is Array)) {
            this.currentPlayerState["successfulRunDurations"] := []
            dirty := true
        }
        if !this.currentPlayerState.Has("currentRunStartAt") {
            this.currentPlayerState["currentRunStartAt"] := ""
            dirty := true
        }
        durations := this.currentPlayerState["successfulRunDurations"]
        while (durations.Length > this.maxStoredRunDurations)
            durations.RemoveAt(1)
        if !this.currentPlayerState.Has("lastRunDuration") {
            this.currentPlayerState["lastRunDuration"] := ""
            dirty := true
        } else if (this.currentPlayerState["lastRunDuration"] == 0) {
            this.currentPlayerState["lastRunDuration"] := ""
            dirty := true
        }
        return dirty
    }

    /**
     * Drops a persisted in-progress run clock. Script load / profile apply
     * should not resume CURRENT from a previous session.
     */
    ClearCurrentRunStart() {
        this.EnsureRunDurationFields()
        startAt := this.currentPlayerState["currentRunStartAt"]
        if (startAt == "")
            return false
        this.currentPlayerState["currentRunStartAt"] := ""
        this.SavePlayerState()
        return true
    }

    HasLastRunDuration() {
        this.EnsureRunDurationFields()
        v := this.currentPlayerState["lastRunDuration"]
        if (v == "")
            return false
        try {
            Integer(v)
            return true
        }
        return false
    }

    EnsureMissionStats() {
        existingByName := Map()
        if (this.currentPlayerState.Has("missionStats") && this.currentPlayerState["missionStats"] is Array) {
            for _, entry in this.currentPlayerState["missionStats"] {
                if !(entry is Map)
                    continue
                name := entry.Has("name") ? Trim(entry["name"]) : ""
                if (name == "")
                    continue
                existingByName[StrLower(name)] := entry
            }
        }

        merged := []
        dirty := false
        for _, mission in this.allMissionsList {
            if !(mission is Map)
                continue
            name := mission.Has("name") ? Trim(mission["name"]) : ""
            spec := mission.Has("specialization") ? Trim(mission["specialization"]) : ""
            if (name == "")
                continue
            key := StrLower(name)
            if existingByName.Has(key) {
                entry := existingByName[key]
                completed := 0
                bestTime := 0
                try completed := Integer(entry.Has("completedCount") ? entry["completedCount"] : 0)
                try bestTime := Integer(entry.Has("bestRunTime") ? entry["bestRunTime"] : 0)
                huntHistory := this.NormalizeAbandonsUntilReveal(entry.Has("abandonsUntilReveal")
                    ? entry["abandonsUntilReveal"] : [])
                if (completed < 0)
                    completed := 0
                if (bestTime < 0)
                    bestTime := 0
                if (!entry.Has("specialization") || entry["specialization"] != spec
                    || !entry.Has("completedCount") || entry["completedCount"] != completed
                    || !entry.Has("bestRunTime") || entry["bestRunTime"] != bestTime
                    || !entry.Has("abandonsUntilReveal")) {
                    dirty := true
                }
                merged.Push(Map(
                    "name", name,
                    "specialization", spec,
                    "completedCount", completed,
                    "bestRunTime", bestTime,
                    "abandonsUntilReveal", huntHistory
                ))
                existingByName.Delete(key)
            } else {
                dirty := true
                merged.Push(Map(
                    "name", name,
                    "specialization", spec,
                    "completedCount", 0,
                    "bestRunTime", 0,
                    "abandonsUntilReveal", []
                ))
            }
        }

        if (merged.Length != (this.currentPlayerState.Has("missionStats") && this.currentPlayerState["missionStats"] is Array
            ? this.currentPlayerState["missionStats"].Length : -1))
            dirty := true

        this.currentPlayerState["missionStats"] := merged
        return dirty
    }

    StartRunTimerIfNeeded() {
        this.EnsureRunDurationFields()
        startAt := this.currentPlayerState["currentRunStartAt"]
        if (startAt != "")
            return false
        this.currentPlayerState["currentRunStartAt"] := A_Now
        this.SavePlayerState()
        this.DebugStat("[State] Run timer started.")
        return true
    }

    /**
     * Closes the current timed run when completed missions were claimed.
     * Stores duration in seconds (last 50) and clears the start stamp.
     */
    CompleteCurrentRun(missionNames := unset) {
        this.EnsureRunDurationFields()
        startAt := Trim(this.currentPlayerState["currentRunStartAt"])
        if (startAt == "") {
            this.DebugStat("[State] Completed missions claimed with no run start time; duration skipped.")
            return 0
        }

        durationSec := 0
        try durationSec := Integer(DateDiff(A_Now, startAt, "Seconds"))
        if (durationSec < 0)
            durationSec := 0

        durations := this.currentPlayerState["successfulRunDurations"]
        durations.Push(durationSec)
        while (durations.Length > this.maxStoredRunDurations)
            durations.RemoveAt(1)

        this.currentPlayerState["lastRunDuration"] := durationSec
        this.currentPlayerState["currentRunStartAt"] := ""
        this.SavePlayerState()
        this.LogStat("Run successful: " durationSec " seconds" this.FormatCompletedNames(missionNames) ".")
        global statusOverlayInst
        if IsSet(statusOverlayInst) && IsObject(statusOverlayInst)
            statusOverlayInst.PaintRunTimes()
        return durationSec
    }

    FormatCompletedNames(missionNames) {
        if !IsSet(missionNames) || !(missionNames is Array) || (missionNames.Length == 0)
            return ""
        joined := ""
        for idx, name in missionNames {
            label := Trim(name)
            if (label == "")
                continue
            if (joined != "")
                joined .= ", "
            joined .= label
        }
        if (joined == "")
            return ""
        return " — " joined
    }

    GetLastRunDuration() {
        this.EnsureRunDurationFields()
        if !this.HasLastRunDuration()
            return ""
        try return Integer(this.currentPlayerState["lastRunDuration"])
        return ""
    }

    GetCurrentRunElapsed() {
        this.EnsureRunDurationFields()
        startAt := Trim(this.currentPlayerState["currentRunStartAt"])
        if (startAt == "")
            return 0
        elapsed := 0
        try elapsed := Integer(DateDiff(A_Now, startAt, "Seconds"))
        if (elapsed < 0)
            elapsed := 0
        return elapsed
    }

    HasActiveRunTimer() {
        this.EnsureRunDurationFields()
        return Trim(this.currentPlayerState["currentRunStartAt"]) != ""
    }

    DebugStat(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug(message)
    }

    GetStat(key) {
        this.EnsureStatKey(key)
        return Integer(this.currentPlayerState[key])
    }

    IncrementStat(key, amount := 1) {
        add := Integer(amount)
        if (add < 1)
            return this.GetStat(key)
        n := this.GetStat(key) + add
        this.currentPlayerState[key] := n
        this.SavePlayerState()
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatsDisplay"))
            mainGuiInst.RefreshStatsDisplay()
        return n
    }

    EnsureMnemonicDeviceFields() {
        dirty := false
        if this.EnsureStatKey("mnemonicDevice")
            dirty := true
        if this.EnsureStatKey("mnemonicDeviceMax")
            dirty := true
        return dirty
    }

    ClearSessionMnemonicDevice() {
        this.mnemonicDeviceKnown := false
        this.EnsureMnemonicDeviceFields()
        this.currentPlayerState["mnemonicDevice"] := 0
        this.currentPlayerState["mnemonicDeviceMax"] := 0
    }

    GetMnemonicDeviceCurrent() {
        this.EnsureMnemonicDeviceFields()
        return Integer(this.currentPlayerState["mnemonicDevice"])
    }

    GetMnemonicDeviceMax() {
        this.EnsureMnemonicDeviceFields()
        return Integer(this.currentPlayerState["mnemonicDeviceMax"])
    }

    HasMnemonicDeviceReading() {
        return this.mnemonicDeviceKnown
    }

    GetMnemonicDeviceText() {
        if !this.HasMnemonicDeviceReading()
            return "—"
        return this.GetMnemonicDeviceCurrent() "/" this.GetMnemonicDeviceMax()
    }

    SetMnemonicDevice(current, maxVal := "") {
        this.EnsureMnemonicDeviceFields()
        cur := 0
        try cur := Integer(current)
        if (cur < 0)
            cur := 0

        cap := 0
        if (maxVal != "") {
            try cap := Integer(maxVal)
            if (cap < 0)
                cap := 0
        }
        if (cap > 0 && cur > cap)
            cur := cap

        this.currentPlayerState["mnemonicDevice"] := cur
        this.currentPlayerState["mnemonicDeviceMax"] := cap
        this.mnemonicDeviceKnown := (cap > 0)
        return cur
    }

    ConsumeMnemonicDevice() {
        this.EnsureMnemonicDeviceFields()
        if !this.HasMnemonicDeviceReading() {
            this.DebugStat("[State] Claimed a mission before mnemonic OCR; remaining left unread.")
            return 0
        }

        current := this.GetMnemonicDeviceCurrent()
        if (current < 1)
            return 0
        this.currentPlayerState["mnemonicDevice"] := current - 1
        spent := this.GetStat("mnemonicDevicesSpent") + 1
        this.currentPlayerState["mnemonicDevicesSpent"] := spent
        this.SavePlayerState()
        this.DebugStat("[State] Mnemonic device: " this.GetMnemonicDeviceText() " (spent " spent ")")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatsDisplay"))
            mainGuiInst.RefreshStatsDisplay()
        return this.GetMnemonicDeviceCurrent()
    }

    IncrementGuildAbandons(amount := 1) {
        n := this.IncrementStat("guildAbandons", amount)
        this.DebugStat("[State] Total abandons: " n " (+" Integer(amount) ")")
        return n
    }

    IncrementTargettedAccepts(amount := 1) {
        n := this.IncrementStat("targettedAccepts", amount)
        this.DebugStat("[State] Successfully accepted target missions: " n " (+" Integer(amount) ")")
        return n
    }

    /**
     * Records a claimed completion. completedCount always +1.
     * bestRunTime updates when durationSec > 0 and is lower than the stored best
     * (0 means no best yet).
     */
    RecordMissionCompletion(missionName, durationSec := 0) {
        name := Trim(missionName)
        if (name == "" || StrLower(name) == "unknown") {
            this.DebugStat("[State] Skipped mission stats; claimed name was empty.")
            return false
        }

        this.EnsureMissionStats()
        duration := 0
        try duration := Integer(durationSec)
        if (duration < 0)
            duration := 0

        spec := ""
        if this.missionSpecMap.Has(name)
            spec := this.missionSpecMap[name]
        else if this.missionSpecMap.Has(StrLower(name))
            spec := this.missionSpecMap[StrLower(name)]

        stats := this.currentPlayerState["missionStats"]
        key := StrLower(name)
        entry := ""
        for _, row in stats {
            if !(row is Map)
                continue
            rowName := row.Has("name") ? Trim(row["name"]) : ""
            if (StrLower(rowName) == key) {
                entry := row
                break
            }
        }

        if !IsObject(entry) {
            entry := Map(
                "name", name,
                "specialization", spec,
                "completedCount", 0,
                "bestRunTime", 0,
                "abandonsUntilReveal", []
            )
            stats.Push(entry)
        }

        completed := 0
        try completed := Integer(entry.Has("completedCount") ? entry["completedCount"] : 0)
        if (completed < 0)
            completed := 0
        completed += 1
        entry["completedCount"] := completed
        if (spec != "")
            entry["specialization"] := spec

        bestUpdated := false
        if (duration > 0) {
            best := 0
            try best := Integer(entry.Has("bestRunTime") ? entry["bestRunTime"] : 0)
            if (best <= 0 || duration < best) {
                entry["bestRunTime"] := duration
                bestUpdated := true
            }
        }

        this.SavePlayerState()
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatsDisplay"))
            mainGuiInst.RefreshStatsDisplay()

        timesLabel := (completed == 1) ? "1 time" : completed " times"
        if bestUpdated {
            this.LogStat("Completed " name " (" timesLabel "). New best: " duration " seconds.")
            StatusBar.Notify("New best: " name, "best")
        } else {
            this.LogStat("Completed " name " (" timesLabel ").")
        }
        return true
    }

    NormalizeAbandonsUntilReveal(raw) {
        history := []
        if (raw is Array) {
            for _, value in raw {
                n := 0
                try n := Integer(value)
                if (n < 0)
                    n := 0
                history.Push(n)
                if (history.Length >= this.maxStoredAbandonsUntilReveal)
                    break
            }
        }
        return history
    }

    /**
     * Prepends this cycle's abandon count for a solo-spec target.
     * Newest first. Keeps the last 30 cycles.
     */
    RecordAbandonsUntilReveal(missionName, abandonCount) {
        name := Trim(missionName)
        if (name == "" || StrLower(name) == "unknown")
            return false

        count := 0
        try count := Integer(abandonCount)
        if (count < 0)
            count := 0

        this.EnsureMissionStats()
        spec := ""
        if this.missionSpecMap.Has(name)
            spec := this.missionSpecMap[name]
        else if this.missionSpecMap.Has(StrLower(name))
            spec := this.missionSpecMap[StrLower(name)]

        stats := this.currentPlayerState["missionStats"]
        key := StrLower(name)
        entry := ""
        for _, row in stats {
            if !(row is Map)
                continue
            rowName := row.Has("name") ? Trim(row["name"]) : ""
            if (StrLower(rowName) == key) {
                entry := row
                break
            }
        }

        if !IsObject(entry) {
            entry := Map(
                "name", name,
                "specialization", spec,
                "completedCount", 0,
                "bestRunTime", 0,
                "abandonsUntilReveal", []
            )
            stats.Push(entry)
        }

        if (spec != "")
            entry["specialization"] := spec
        history := this.NormalizeAbandonsUntilReveal(entry.Has("abandonsUntilReveal")
            ? entry["abandonsUntilReveal"] : [])
        history.InsertAt(1, count)
        while (history.Length > this.maxStoredAbandonsUntilReveal)
            history.RemoveAt(history.Length)
        entry["abandonsUntilReveal"] := history

        this.SavePlayerState()
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatsDisplay"))
            mainGuiInst.RefreshStatsDisplay()

        this.LogStat(name ": " count " abandon(s) until reveal. Availability "
            this.FormatAvailabilityPercent(history) ".")
        return true
    }

    GetAbandonsUntilRevealAverage(history) {
        if !(history is Array) || (history.Length == 0)
            return ""
        sum := 0
        for _, n in history
            sum += Integer(n)
        return sum / history.Length
    }

    GetMissionAvailabilityText(entry) {
        if !(entry is Map) || !entry.Has("abandonsUntilReveal")
            return ""
        return this.FormatAvailabilityPercent(entry["abandonsUntilReveal"])
    }

    /**
     * 1 / (average abandons until reveal + 1). Ten abandons → 1 in 11 → ~9%.
     */
    FormatAvailabilityPercent(history) {
        avg := this.GetAbandonsUntilRevealAverage(history)
        if (avg == "")
            return ""
        pct := 100 / (avg + 1)
        rounded := Round(pct, 1)
        if (rounded == Integer(rounded))
            return Integer(rounded) "%"
        return rounded "%"
    }

    GetMissionStatsForSpec(specName) {
        this.EnsureMissionStats()
        rows := []
        needle := StrLower(Trim(specName))
        stats := this.currentPlayerState["missionStats"]
        if !(stats is Array)
            return rows
        for _, entry in stats {
            if !(entry is Map)
                continue
            spec := entry.Has("specialization") ? Trim(entry["specialization"]) : ""
            if (StrLower(spec) != needle)
                continue
            rows.Push(entry)
        }
        return rows
    }

    /**
     * Clears run and mission statistics for the active profile.
     * Targeted missions and settings are left as they are.
     */
    ResetStats() {
        this.EnsureRunDurationFields()
        this.EnsureMissionStats()
        this.currentPlayerState["guildAbandons"] := 0
        this.currentPlayerState["targettedAccepts"] := 0
        this.currentPlayerState["mnemonicDevicesSpent"] := 0
        this.currentPlayerState["successfulRunDurations"] := []
        this.currentPlayerState["currentRunStartAt"] := ""
        this.currentPlayerState["lastRunDuration"] := ""
        stats := this.currentPlayerState["missionStats"]
        if (stats is Array) {
            for _, entry in stats {
                if !(entry is Map)
                    continue
                entry["completedCount"] := 0
                entry["bestRunTime"] := 0
                entry["abandonsUntilReveal"] := []
            }
        }
        this.SavePlayerState()
        this.LogStat("Stats reset for this profile.")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatsDisplay"))
            mainGuiInst.RefreshStatsDisplay()
        global statusOverlayInst
        if IsSet(statusOverlayInst) && IsObject(statusOverlayInst)
            statusOverlayInst.PaintRunTimes()
        return true
    }

    LogStat(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Log")
            loggerInst.Log(message)
    }

    /**
     * Returns missions the player selected in the Mission Picker.
     * Each entry is {gridLocation, gridRow, gridCol, missionName, specialization}.
     */
    GetTargetedMissions() {
        targeted := []
        if (!this.currentPlayerState.Has("targettedMissions") || !(this.currentPlayerState["targettedMissions"] is Array))
            return targeted

        for _, entry in this.currentPlayerState["targettedMissions"] {
            parsed := this.ParseTargetedEntry(entry)
            if (parsed.missionName == "")
                continue
            targeted.Push(parsed)
        }

        return targeted
    }

    /**
     * Groups targetted missions by grid slot as dropdown labels for the Mission Picker UI.
     * @returns {Map} slotIdx -> Array of "Specialization — Mission Name"
     */
    GetTargetedMissionsBySlot() {
        bySlot := Map()
        for _, mission in this.GetTargetedMissions() {
            slotIdx := mission.gridLocation
            if (slotIdx < 1 || slotIdx > 25)
                continue
            if (!bySlot.Has(slotIdx))
                bySlot[slotIdx] := []
            bySlot[slotIdx].Push(this.FormatMissionLabel(mission.specialization, mission.missionName))
        }
        return bySlot
    }

    /**
     * Persists Mission Picker assignments as structured targettedMissions.
     * @param {Map} slotMissions - slotIdx -> Array of "Specialization — Mission Name" labels
     */
    SaveTargetedMissionsFromSlots(slotMissions) {
        records := []
        if (IsObject(slotMissions)) {
            for slotIdx, missions in slotMissions {
                if (!IsObject(missions))
                    continue
                for _, label in missions {
                    if (label == "")
                        continue
                    parsed := this.ParseMissionLabel(label)
                    if (parsed.missionName == "")
                        continue
                    records.Push(this.BuildTargetedRecord(slotIdx, parsed.missionName, parsed.specialization))
                }
            }
        }

        oldSig := this.TargetedMissionsSignature()
        this.currentPlayerState["targettedMissions"] := records
        if (this.currentPlayerState.Has("missionSelections"))
            this.currentPlayerState.Delete("missionSelections")
        if (this.TargetedMissionsSignature(records) != oldSig) {
            this.currentPlayerState["lastRunDuration"] := ""
            this.currentPlayerState["currentRunStartAt"] := ""
        }
        this.SavePlayerState()
    }

    TargetedMissionsSignature(records := unset) {
        list := IsSet(records) ? records : (this.currentPlayerState.Has("targettedMissions")
            ? this.currentPlayerState["targettedMissions"] : [])
        if !(list is Array)
            return ""
        text := ""
        for _, rec in list {
            if !(rec is Map)
                continue
            loc := rec.Has("gridLocation") ? rec["gridLocation"] : 0
            name := rec.Has("missionName") ? rec["missionName"] : ""
            spec := rec.Has("specialization") ? rec["specialization"] : ""
            text .= loc "|" StrLower(Trim(name)) "|" StrLower(Trim(spec)) "`n"
        }
        return Sort(text, "C")
    }

    /**
     * Replaces the active-missions list in player state and persists it.
     * @param {Array} activeMissions - Array of {missionName, specialization, isTargetted}
     */
    SaveActiveMissions(activeMissions) {
        records := []
        if (IsObject(activeMissions)) {
            for _, mission in activeMissions {
                if (!IsObject(mission))
                    continue

                mName := ""
                mSpec := ""
                mTargetted := false

                if (mission.HasOwnProp("missionName"))
                    mName := mission.missionName
                else if (mission is Map && mission.Has("missionName"))
                    mName := mission["missionName"]

                if (mission.HasOwnProp("specialization"))
                    mSpec := mission.specialization
                else if (mission is Map && mission.Has("specialization"))
                    mSpec := mission["specialization"]

                if (mission.HasOwnProp("isTargetted"))
                    mTargetted := mission.isTargetted
                else if (mission is Map && mission.Has("isTargetted"))
                    mTargetted := mission["isTargetted"]

                if (mName == "")
                    continue

                records.Push(Map(
                    "missionName", mName,
                    "specialization", mSpec,
                    "isTargetted", mTargetted ? true : false
                ))
            }
        }

        this.currentPlayerState["activeMissions"] := records
        this.SavePlayerState()
    }

    /**
     * Returns the 3 active mission slots last saved to player state.
     * Each entry is {missionName, specialization, isTargetted}.
     */
    GetActiveMissions() {
        active := []
        if (!this.currentPlayerState.Has("activeMissions") || !(this.currentPlayerState["activeMissions"] is Array))
            return active

        for _, entry in this.currentPlayerState["activeMissions"] {
            mName := ""
            mSpec := ""
            mTargetted := false

            if (entry is Map) {
                if entry.Has("missionName")
                    mName := entry["missionName"]
                if entry.Has("specialization")
                    mSpec := entry["specialization"]
                if entry.Has("isTargetted")
                    mTargetted := entry["isTargetted"]
            } else if IsObject(entry) {
                if entry.HasOwnProp("missionName")
                    mName := entry.missionName
                if entry.HasOwnProp("specialization")
                    mSpec := entry.specialization
                if entry.HasOwnProp("isTargetted")
                    mTargetted := entry.isTargetted
            }

            if (mName == "")
                continue

            active.Push({
                missionName: mName,
                specialization: mSpec,
                isTargetted: mTargetted ? true : false
            })
        }

        return active
    }
}
