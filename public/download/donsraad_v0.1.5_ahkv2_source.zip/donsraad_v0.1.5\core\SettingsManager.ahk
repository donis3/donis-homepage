#Requires AutoHotkey v2.0+

/**
 * Settings Manager class.
 * Handles loading, updating, and auto-saving user application settings in settings.json.
 */
class SettingsManager {
    settingsPath := ""
    settings := Map()

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        this.settingsPath := rootDir . "\settings.json"
        this.LoadSettings()
    }

    /**
     * Default settings dictionary.
     */
    GetDefaultSettings() {
        return Map(
            "ocrLanguage", "en-US",
            "debugMode", false,
            "guildName", "wowza",
            "faction", "Atreides",
            "characterName", "player",
            "currentProfileId", "default",
            "hotkeyStart", "Home",
            "hotkeyExit", "Pause",
            "hotkeyToggleGui", "Delete",
            "hotkeyToggleOverlay", "Insert",
            "showOverlay", true,
            "overlayPosition", "topLeft",
            "overlayShowStatus", true,
            "overlayShowRun", true,
            "overlayShowCurrentRun", true,
            "overlayShowLastRun", true,
            "overlayShowTargets", true,
            "overlayShowMnemonic", true,
            "overlayShowProfile", true,
            "overlayShowNotifications", true,
            "actionDelay", 100,
            "autoRunOnTravelConfirmation", false
        )
    }

    /**
     * Loads settings from settings.json. Missing files get a full default write.
     * Existing files keep their values; keys added in newer app versions are
     * filled from defaults and saved. Unreadable files are replaced.
     */
    LoadSettings() {
        defaults := this.GetDefaultSettings()
        if this.TryLoadExisting(defaults)
            return
        this.settings := defaults
        this.SaveSettings()
    }

    TryLoadExisting(defaults) {
        if !FileExist(this.settingsPath)
            return false
        try {
            rawJson := FileRead(this.settingsPath, "UTF-8")
            if (Trim(rawJson) == "")
                return false
            parsed := JSON.Parse(rawJson)
            if !(parsed is Map)
                return false
            this.settings := parsed
            missingKey := false
            for key, val in defaults {
                if (!this.settings.Has(key)) {
                    this.settings[key] := val
                    missingKey := true
                }
            }
            if (missingKey)
                this.SaveSettings()
            return true
        } catch {
            return false
        }
    }

    /**
     * Saves current settings to settings.json.
     */
    SaveSettings() {
        jsonString := JSON.Stringify(this.settings, 2)
        fileObj := FileOpen(this.settingsPath, "w", "UTF-8")
        fileObj.Write(jsonString)
        fileObj.Close()
    }

    /**
     * Gets a setting value by key, returning defaultVal if key is absent.
     */
    Get(key, defaultVal := "") {
        if (this.settings.Has(key))
            return this.settings[key]
        return defaultVal
    }

    GetBool(key, defaultVal := false) {
        raw := this.Get(key, defaultVal)
        return (raw == true || raw == 1 || raw == "1" || raw == "true")
    }

    GetInt(key, defaultVal := 0) {
        raw := this.Get(key, defaultVal)
        try {
            return Integer(raw)
        } catch {
            return Integer(defaultVal)
        }
    }

    /**
     * Sets a setting value and immediately auto-saves to settings.json.
     */
    Set(key, value) {
        this.settings[key] := value
        this.SaveSettings()
    }

    ApplySharedDefaults() {
        this.ResetBasicSettings()
    }

    /**
     * Restores guild, faction, overlay, delay, OCR, and debug.
     * Leaves profile, character name, hotkeys, and stats alone.
     */
    ResetBasicSettings() {
        this.Set("debugMode", false)
        this.Set("guildName", "wowza")
        this.Set("faction", "Atreides")
        this.Set("ocrLanguage", "en-US")
        this.Set("actionDelay", 100)
        this.Set("showOverlay", true)
        this.Set("overlayPosition", "topLeft")
        this.Set("overlayShowStatus", true)
        this.Set("overlayShowRun", true)
        this.Set("overlayShowCurrentRun", true)
        this.Set("overlayShowLastRun", true)
        this.Set("overlayShowTargets", true)
        this.Set("overlayShowMnemonic", true)
        this.Set("overlayShowProfile", true)
        this.Set("overlayShowNotifications", true)
        this.Set("autoRunOnTravelConfirmation", false)
    }

    ResetHotkeys() {
        this.Set("hotkeyStart", "Home")
        this.Set("hotkeyExit", "Pause")
        this.Set("hotkeyToggleGui", "Delete")
        this.Set("hotkeyToggleOverlay", "Insert")
    }
}
