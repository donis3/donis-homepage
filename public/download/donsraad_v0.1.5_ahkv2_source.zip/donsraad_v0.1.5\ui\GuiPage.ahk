#Requires AutoHotkey v2.0+

/**
 * Base page hosted by DonsraadGui.
 * Unknown properties and methods forward to the container after host is attached.
 * Field initializers run before __New, so __Set must not touch host until it exists.
 */
class GuiPage {
    __New(hostGui, pageId) {
        this.DefineProp("host", {Value: hostGui})
        this.DefineProp("pageId", {Value: Integer(pageId)})
    }

    HasHost() {
        return this.HasOwnProp("host")
    }

    HostRef() {
        if !this.HasOwnProp("host")
            return ""
        return this.GetOwnPropDesc("host").Value
    }

    __Get(name, params) {
        if this.HasOwnProp(name) {
            desc := this.GetOwnPropDesc(name)
            if desc.HasProp("Value")
                return desc.Value
            if desc.HasProp("Get")
                return desc.Get()
        }
        h := this.HostRef()
        if !IsObject(h)
            throw UnsetError("GuiPage host is not ready for property " name)
        if (params.Length)
            return h.%name%[params*]
        return h.%name%
    }

    __Set(name, params, value) {
        if (name = "host" || name = "pageId" || !this.HasHost() || this.HasOwnProp(name)) {
            if (params.Length && this.HasOwnProp(name)) {
                cur := this.GetOwnPropDesc(name).Value
                cur[params*] := value
                return value
            }
            this.DefineProp(name, {Value: value})
            return value
        }
        h := this.HostRef()
        if (params.Length) {
            h.%name%[params*] := value
            return value
        }
        h.%name% := value
        return value
    }

    __Call(name, params) {
        h := this.HostRef()
        if !IsObject(h)
            throw UnsetError("GuiPage host is not ready for method " name)
        return h.%name%(params*)
    }
}
