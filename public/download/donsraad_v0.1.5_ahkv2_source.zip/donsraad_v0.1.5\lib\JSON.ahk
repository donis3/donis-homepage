#Requires AutoHotkey v2.0+

/**
 * High-performance, robust JSON parser and serializer for AutoHotkey v2.
 */
class JSON {
    /**
     * Parses a JSON string into AHK v2 types (Map, Array, String, Number, etc.).
     * @param {String} jsonString - The JSON string to parse.
     * @returns {Any} - Parsed AHK v2 object/array/value.
     */
    static Parse(jsonString) {
        if (jsonString == "")
            return ""
        
        ctx := { pos: 1, str: jsonString, len: StrLen(jsonString) }
        this.SkipWhitespace(ctx)
        result := this.ParseValue(ctx)
        this.SkipWhitespace(ctx)
        
        if (ctx.pos <= ctx.len)
            throw Error("Unexpected trailing character at position " . ctx.pos . ": '" . SubStr(ctx.str, ctx.pos, 1) . "'")
        
        return result
    }

    static SkipWhitespace(ctx) {
        while (ctx.pos <= ctx.len) {
            ch := SubStr(ctx.str, ctx.pos, 1)
            if (ch == " " || ch == "`t" || ch == "`n" || ch == "`r")
                ctx.pos++
            else
                break
        }
    }

    static ParseValue(ctx) {
        this.SkipWhitespace(ctx)
        if (ctx.pos > ctx.len)
            throw Error("Unexpected end of JSON input at position " . ctx.pos)

        ch := SubStr(ctx.str, ctx.pos, 1)
        if (ch == "{")
            return this.ParseObject(ctx)
        else if (ch == "[")
            return this.ParseArray(ctx)
        else if (ch == '"')
            return this.ParseString(ctx)
        else if (ch == "t" || ch == "f")
            return this.ParseBoolean(ctx)
        else if (ch == "n")
            return this.ParseNull(ctx)
        else if (ch == "-" || (ch >= "0" && ch <= "9"))
            return this.ParseNumber(ctx)
        else
            throw Error("Unexpected token at position " . ctx.pos . ": '" . ch . "'")
    }

    static ParseObject(ctx) {
        objMap := Map()
        ctx.pos++ ; Skip '{'
        this.SkipWhitespace(ctx)

        if (ctx.pos <= ctx.len && SubStr(ctx.str, ctx.pos, 1) == "}") {
            ctx.pos++
            return objMap
        }

        loop {
            this.SkipWhitespace(ctx)
            if (ctx.pos > ctx.len || SubStr(ctx.str, ctx.pos, 1) != '"')
                throw Error("Expected string key in object at position " . ctx.pos)
            
            keyStr := this.ParseString(ctx)
            this.SkipWhitespace(ctx)

            if (ctx.pos > ctx.len || SubStr(ctx.str, ctx.pos, 1) != ":")
                throw Error("Expected ':' after key at position " . ctx.pos)
            ctx.pos++ ; Skip ':'

            val := this.ParseValue(ctx)
            objMap[keyStr] := val

            this.SkipWhitespace(ctx)
            if (ctx.pos > ctx.len)
                throw Error("Unterminated object at position " . ctx.pos)

            nextCh := SubStr(ctx.str, ctx.pos, 1)
            if (nextCh == ",") {
                ctx.pos++
            } else if (nextCh == "}") {
                ctx.pos++
                break
            } else {
                throw Error("Expected ',' or '}' in object at position " . ctx.pos)
            }
        }

        return objMap
    }

    static ParseArray(ctx) {
        arrList := []
        ctx.pos++ ; Skip '['
        this.SkipWhitespace(ctx)

        if (ctx.pos <= ctx.len && SubStr(ctx.str, ctx.pos, 1) == "]") {
            ctx.pos++
            return arrList
        }

        loop {
            val := this.ParseValue(ctx)
            arrList.Push(val)

            this.SkipWhitespace(ctx)
            if (ctx.pos > ctx.len)
                throw Error("Unterminated array at position " . ctx.pos)

            nextCh := SubStr(ctx.str, ctx.pos, 1)
            if (nextCh == ",") {
                ctx.pos++
            } else if (nextCh == "]") {
                ctx.pos++
                break
            } else {
                throw Error("Expected ',' or ']' in array at position " . ctx.pos)
            }
        }

        return arrList
    }

    static ParseString(ctx) {
        ctx.pos++ ; Skip opening '"'
        strResult := ""
        startPos := ctx.pos

        while (ctx.pos <= ctx.len) {
            ch := SubStr(ctx.str, ctx.pos, 1)
            if (ch == '"') {
                strResult .= SubStr(ctx.str, startPos, ctx.pos - startPos)
                ctx.pos++ ; Skip closing '"'
                return strResult
            } else if (ch == "\") {
                strResult .= SubStr(ctx.str, startPos, ctx.pos - startPos)
                ctx.pos++
                if (ctx.pos > ctx.len)
                    throw Error("Unterminated escape sequence at position " . ctx.pos)
                
                escCh := SubStr(ctx.str, ctx.pos, 1)
                if (escCh == '"')
                    strResult .= '"'
                else if (escCh == "\")
                    strResult .= "\"
                else if (escCh == "/")
                    strResult .= "/"
                else if (escCh == "b")
                    strResult .= "`b"
                else if (escCh == "f")
                    strResult .= "`f"
                else if (escCh == "n")
                    strResult .= "`n"
                else if (escCh == "r")
                    strResult .= "`r"
                else if (escCh == "t")
                    strResult .= "`t"
                else if (escCh == "u") {
                    if (ctx.pos + 4 > ctx.len)
                        throw Error("Incomplete unicode escape at position " . ctx.pos)
                    hexCode := SubStr(ctx.str, ctx.pos + 1, 4)
                    ctx.pos += 4
                    strResult .= Chr("0x" . hexCode)
                } else {
                    strResult .= escCh
                }
                ctx.pos++
                startPos := ctx.pos
            } else {
                ctx.pos++
            }
        }

        throw Error("Unterminated string literal at position " . startPos)
    }

    static ParseNumber(ctx) {
        startPos := ctx.pos
        if (SubStr(ctx.str, ctx.pos, 1) == "-")
            ctx.pos++
        
        while (ctx.pos <= ctx.len) {
            code := Ord(SubStr(ctx.str, ctx.pos, 1))
            if (code >= 48 && code <= 57) ; '0'..'9'
                ctx.pos++
            else
                break
        }

        isFloat := false
        if (ctx.pos <= ctx.len && SubStr(ctx.str, ctx.pos, 1) == ".") {
            isFloat := true
            ctx.pos++
            while (ctx.pos <= ctx.len) {
                code := Ord(SubStr(ctx.str, ctx.pos, 1))
                if (code >= 48 && code <= 57) ; '0'..'9'
                    ctx.pos++
                else
                    break
            }
        }

        if (ctx.pos <= ctx.len) {
            ch := SubStr(ctx.str, ctx.pos, 1)
            if (ch == "e" || ch == "E") {
                isFloat := true
                ctx.pos++
                if (ctx.pos <= ctx.len && (SubStr(ctx.str, ctx.pos, 1) == "+" || SubStr(ctx.str, ctx.pos, 1) == "-"))
                    ctx.pos++
                while (ctx.pos <= ctx.len) {
                    code := Ord(SubStr(ctx.str, ctx.pos, 1))
                    if (code >= 48 && code <= 57) ; '0'..'9'
                        ctx.pos++
                    else
                        break
                }
            }
        }

        numStr := SubStr(ctx.str, startPos, ctx.pos - startPos)
        return isFloat ? Float(numStr) : Integer(numStr)
    }

    static ParseBoolean(ctx) {
        if (SubStr(ctx.str, ctx.pos, 4) == "true") {
            ctx.pos += 4
            return true
        } else if (SubStr(ctx.str, ctx.pos, 5) == "false") {
            ctx.pos += 5
            return false
        }
        throw Error("Invalid boolean literal at position " . ctx.pos)
    }

    static ParseNull(ctx) {
        if (SubStr(ctx.str, ctx.pos, 4) == "null") {
            ctx.pos += 4
            return ""
        }
        throw Error("Invalid null literal at position " . ctx.pos)
    }

    /**
     * Serializes an AHK v2 value or object into a JSON formatted string.
     * @param {Any} val - The value to stringify.
     * @param {String|Integer} indent - Optional indentation (spaces or number of spaces).
     * @returns {String} - JSON string.
     */
    static Stringify(val, indent := "") {
        indentStr := ""
        if (IsInteger(indent) && indent > 0) {
            loop indent
                indentStr .= " "
        } else if (Type(indent) == "String") {
            indentStr := indent
        }

        return this.StringifyValue(val, "", indentStr)
    }

    static StringifyValue(v, currentIndent, stepIndent) {
        if (v == "")
            return "null"
        
        if (IsObject(v)) {
            if (v is Array) {
                if (v.Length == 0)
                    return "[]"
                
                nextIndent := stepIndent != "" ? currentIndent . stepIndent : ""
                newline := stepIndent != "" ? "`n" : ""
                
                res := "[" . newline
                for idx, item in v {
                    if (idx > 1)
                        res .= "," . newline
                    res .= nextIndent . this.StringifyValue(item, nextIndent, stepIndent)
                }
                res .= newline . currentIndent . "]"
                return res
            } else if (v is Map) {
                if (v.Count == 0)
                    return "{}"
                
                nextIndent := stepIndent != "" ? currentIndent . stepIndent : ""
                newline := stepIndent != "" ? "`n" : ""
                colonSpace := stepIndent != "" ? ": " : ":"
                
                res := "{" . newline
                first := true
                for key, item in v {
                    if (!first)
                        res .= "," . newline
                    first := false
                    res .= nextIndent . this.EscapeString(String(key)) . colonSpace . this.StringifyValue(item, nextIndent, stepIndent)
                }
                res .= newline . currentIndent . "}"
                return res
            } else {
                props := []
                for propName in v.OwnProps()
                    props.Push(propName)
                
                if (props.Length == 0)
                    return "{}"
                
                nextIndent := stepIndent != "" ? currentIndent . stepIndent : ""
                newline := stepIndent != "" ? "`n" : ""
                colonSpace := stepIndent != "" ? ": " : ":"
                
                res := "{" . newline
                for idx, propName in props {
                    if (idx > 1)
                        res .= "," . newline
                    res .= nextIndent . this.EscapeString(propName) . colonSpace . this.StringifyValue(v.%propName%, nextIndent, stepIndent)
                }
                res .= newline . currentIndent . "}"
                return res
            }
        } else if (IsInteger(v) || IsFloat(v)) {
            return String(v)
        } else {
            return this.EscapeString(String(v))
        }
    }

    static EscapeString(str) {
        str := StrReplace(str, "\", "\\")
        str := StrReplace(str, '"', '\"')
        str := StrReplace(str, "`b", "\b")
        str := StrReplace(str, "`f", "\f")
        str := StrReplace(str, "`n", "\n")
        str := StrReplace(str, "`r", "\r")
        str := StrReplace(str, "`t", "\t")
        return '"' . str . '"'
    }
}
