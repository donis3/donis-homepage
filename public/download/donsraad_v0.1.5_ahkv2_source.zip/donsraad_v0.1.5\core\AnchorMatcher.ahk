#Requires AutoHotkey v2.0+

/**
 * Anchor point and image matching helper for AutoHotkey v2.
 * Uses ImageSearch with variation tolerance and computes relative UI offsets.
 */
class AnchorMatcher {
    uiElementsDir := ""
    defaultVariation := 25

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        this.uiElementsDir := rootDir . "\ui_elements"
    }

    /**
     * Searches the screen for an anchor image.
     * @param {String} imageName - File name or path relative to ui_elements/
     * @param {VarRef} foundX - Output variable for matched X coordinate
     * @param {VarRef} foundY - Output variable for matched Y coordinate
     * @param {Object} searchArea - Optional bounding box {x1: 0, y1: 0, x2: 1920, y2: 1080}
     * @param {Integer} variation - Color variation tolerance (default 25)
     * @param {String} transColor - Optional ImageSearch Trans color (e.g. "Black") so PNG alpha/black is ignored
     * @returns {Boolean} - True if found, false otherwise.
     */
    FindAnchor(imageName, &foundX, &foundY, searchArea := "", variation := 25, transColor := "") {
        imagePath := this.ResolveImagePath(imageName)
        if !FileExist(imagePath) {
            this.Debug("Image file not found: " imagePath)
            return false
        }

        if (variation <= 0)
            variation := this.defaultVariation

        x1 := 0, y1 := 0, x2 := A_ScreenWidth, y2 := A_ScreenHeight
        if (IsObject(searchArea)) {
            x1 := searchArea.HasOwnProp("x1") ? searchArea.x1 : 0
            y1 := searchArea.HasOwnProp("y1") ? searchArea.y1 : 0
            x2 := searchArea.HasOwnProp("x2") ? searchArea.x2 : A_ScreenWidth
            y2 := searchArea.HasOwnProp("y2") ? searchArea.y2 : A_ScreenHeight
        }

        searchOption := "*" . variation
        if (transColor != "")
            searchOption .= " *Trans" transColor
        searchOption .= " " . imagePath

        prevCoordMode := A_CoordModePixel
        CoordMode("Pixel", "Screen")
        
        found := false
        outX := 0, outY := 0
        try {
            if ImageSearch(&outX, &outY, x1, y1, x2, y2, searchOption) {
                foundX := outX
                foundY := outY
                found := true
            }
        } catch as err {
            this.Debug("ImageSearch failed for " imagePath ": " err.Message)
            found := false
        }

        CoordMode("Pixel", prevCoordMode)
        return found
    }

    /**
     * Builds a sibling *_masked.png: keep tan HUD glyphs and their gold border,
     * paint everything else magenta for ImageSearch *TransFF00FF.
     */
    PrepareTanGlyphMask(imageName, transHex := "FF00FF") {
        sourcePath := this.ResolveImagePath(imageName)
        if !FileExist(sourcePath)
            return ""

        SplitPath(sourcePath, , &dir, &ext, &nameNoExt)
        maskedPath := dir "\" nameNoExt "_masked." ext
        if this.IsMaskedImageFresh(sourcePath, maskedPath)
            return maskedPath

        pBitmap := Gdip_BitmapFromFile(sourcePath)
        if !pBitmap {
            this.Debug("Could not load image for masking: " sourcePath)
            return ""
        }

        ok := this.PaintNonGlyphPixelsTrans(pBitmap, transHex)
        if (ok)
            ok := (Gdip_SaveBitmapToFile(pBitmap, maskedPath) = 0)
        Gdip_DisposeImage(pBitmap)

        if !ok {
            this.Debug("Could not write masked image: " maskedPath)
            return ""
        }
        return maskedPath
    }

    IsMaskedImageFresh(sourcePath, maskedPath) {
        if !FileExist(maskedPath)
            return false
        srcTime := FileGetTime(sourcePath, "M")
        maskTime := FileGetTime(maskedPath, "M")
        return (maskTime != "" && srcTime != "" && maskTime >= srcTime)
    }

    PaintNonGlyphPixelsTrans(pBitmap, transHex) {
        w := Gdip_GetImageWidth(pBitmap)
        h := Gdip_GetImageHeight(pBitmap)
        if (w < 4 || h < 4)
            return false

        transR := Integer("0x" SubStr(transHex, 1, 2))
        transG := Integer("0x" SubStr(transHex, 3, 2))
        transB := Integer("0x" SubStr(transHex, 5, 2))

        bitmapData := ""
        if Gdip_LockBits(pBitmap, 0, 0, w, h, &bitmapData, 0x26200A, 3)
            return false

        stride := NumGet(bitmapData, 8, "int")
        scan0 := NumGet(bitmapData, 16, "ptr")

        loop h {
            row := scan0 + ((A_Index - 1) * stride)
            loop w {
                px := row + ((A_Index - 1) * 4)
                b := NumGet(px, 0, "uchar")
                gVal := NumGet(px, 1, "uchar")
                r := NumGet(px, 2, "uchar")
                if this.IsHudGlyphPixel(r, gVal, b)
                    continue
                NumPut("uchar", transB, px, 0)
                NumPut("uchar", transG, px, 1)
                NumPut("uchar", transR, px, 2)
                NumPut("uchar", 255, px, 3)
            }
        }

        Gdip_UnlockBits(pBitmap, &bitmapData)
        return true
    }

    IsHudGlyphPixel(r, gVal, b) {
        return (r >= 150 && gVal >= 110 && b <= 145 && r > b + 30 && gVal > b + 12 && r >= gVal - 6)
    }

    /**
     * Finds an anchor image and calculates an interactable point offset from it.
     * @param {String} imageName - Anchor image file
     * @param {Integer} offsetX - Pixel offset X from anchor top-left
     * @param {Integer} offsetY - Pixel offset Y from anchor top-left
     * @param {VarRef} targetX - Output calculated X coordinate
     * @param {VarRef} targetY - Output calculated Y coordinate
     * @param {Object} searchArea - Optional search bounding box
     * @param {Integer} variation - Color variation tolerance
     * @returns {Boolean} - True if anchor found and offset calculated
     */
    FindAnchorOffset(imageName, offsetX, offsetY, &targetX, &targetY, searchArea := "", variation := 25) {
        anchorX := 0, anchorY := 0
        if this.FindAnchor(imageName, &anchorX, &anchorY, searchArea, variation) {
            targetX := anchorX + offsetX
            targetY := anchorY + offsetY
            return true
        }
        targetX := 0
        targetY := 0
        return false
    }

    /**
     * Finds an anchor image and returns a relative bounding rectangle for scanning/cropping.
     */
    FindRelativeRegion(imageName, relX, relY, relW, relH, searchArea := "", variation := 25) {
        anchorX := 0, anchorY := 0
        if this.FindAnchor(imageName, &anchorX, &anchorY, searchArea, variation) {
            return {
                x: anchorX + relX,
                y: anchorY + relY,
                w: relW,
                h: relH
            }
        }
        return ""
    }

    /**
     * Waits for an anchor to appear on screen within a timeout.
     */
    WaitForAnchor(imageName, &foundX, &foundY, timeoutMs := 3000, variation := 25) {
        startTime := A_TickCount
        while (A_TickCount - startTime < timeoutMs) {
            if this.FindAnchor(imageName, &foundX, &foundY, "", variation)
                return true
            Sleep(50)
        }
        return false
    }

    ResolveImagePath(imageName) {
        if FileExist(imageName)
            return imageName
        
        candidate := this.uiElementsDir . "\" . imageName
        if FileExist(candidate)
            return candidate
        
        return imageName
    }

    Debug(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[AnchorMatcher] " message)
    }
}
