#Requires AutoHotkey v2.0+

/**
 * Character profiles. Each profile has its own targeted missions / player state.
 * Stored in profiles.json; the active profile is also written to player_state.json.
 */
class ProfileManager {
    workspaceRoot := ""
    profilesPath := ""
    currentId := "default"
    profiles := []

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        this.workspaceRoot := rootDir
        this.profilesPath := rootDir . "\profiles.json"
        this.profiles := []
        this.currentId := "default"
    }

    /**
     * Loads profiles.json, or creates a default profile from existing player state.
     */
    Initialize(stateManagerInst, settingsManagerInst) {
        if !this.LoadProfilesFile() {
            charName := "player"
            if IsObject(settingsManagerInst) {
                charName := settingsManagerInst.Get("characterName", "player")
            }
            if (Trim(charName) == "")
                charName := "player"
            this.profiles := []
            this.profiles.Push(this.MakeProfile("default", charName, stateManagerInst.ClonePlayerState()))
            this.currentId := "default"
            this.SaveProfilesFile()
        }

        savedId := ""
        if IsObject(settingsManagerInst)
            savedId := settingsManagerInst.Get("currentProfileId", this.currentId)
        if (savedId != "" && this.FindIndexById(savedId) > 0)
            this.currentId := savedId
        else
            this.currentId := this.profiles[1]["id"]

        this.ApplyCurrentToState(stateManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveAll(stateManagerInst)
    }

    LoadProfilesFile() {
        this.profiles := []
        if !FileExist(this.profilesPath)
            return false
        try {
            parsed := JSON.Parse(FileRead(this.profilesPath, "UTF-8"))
            if !this.IsValidProfilesPayload(parsed)
                return false
            if parsed.Has("currentId") && parsed["currentId"] != ""
                this.currentId := parsed["currentId"]
            for _, entry in parsed["profiles"] {
                if !(entry is Map)
                    continue
                id := entry.Has("id") ? entry["id"] : ""
                name := entry.Has("characterName") ? entry["characterName"] : "player"
                state := entry.Has("state") && (entry["state"] is Map)
                    ? entry["state"]
                    : Map()
                if (id == "" || Trim(name) == "")
                    continue
                this.profiles.Push(this.MakeProfile(id, name, state))
            }
            if (this.profiles.Length < 1)
                return false
            return true
        } catch {
            this.profiles := []
            return false
        }
    }

    IsValidProfilesPayload(parsed) {
        if !(parsed is Map)
            return false
        if !parsed.Has("profiles") || !(parsed["profiles"] is Array)
            return false
        if (parsed["profiles"].Length < 1)
            return false
        return true
    }

    SaveProfilesFile() {
        payload := Map(
            "currentId", this.currentId,
            "profiles", this.profiles
        )
        jsonString := JSON.Stringify(payload, 2)
        fileObj := FileOpen(this.profilesPath, "w", "UTF-8")
        fileObj.Write(jsonString)
        fileObj.Close()
    }

    MakeProfile(id, characterName, stateMap) {
        return Map(
            "id", id,
            "characterName", characterName,
            "state", (stateMap is Map) ? stateMap : Map()
        )
    }

    GetCurrent() {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1 && this.profiles.Length > 0)
            return this.profiles[1]
        if (idx < 1)
            return ""
        return this.profiles[idx]
    }

    GetCurrentName() {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return "Default"
        name := profile["characterName"]
        return (name != "") ? name : "Default"
    }

    GetProfileNames() {
        names := []
        for _, profile in this.profiles
            names.Push(profile["characterName"])
        return names
    }

    GetCurrentIndex() {
        idx := this.FindIndexById(this.currentId)
        return (idx > 0) ? idx : 1
    }

    FindIndexById(id) {
        for idx, profile in this.profiles {
            if (profile["id"] == id)
                return idx
        }
        return 0
    }

    FindIndexByName(characterName) {
        needle := StrLower(Trim(characterName))
        for idx, profile in this.profiles {
            if (StrLower(profile["characterName"]) == needle)
                return idx
        }
        return 0
    }

    CaptureCurrentState(stateManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return
        this.profiles[idx]["state"] := stateManagerInst.ClonePlayerState()
    }

    ApplyCurrentToState(stateManagerInst) {
        profile := this.GetCurrent()
        if !IsObject(profile)
            return
        state := profile.Has("state") ? profile["state"] : Map()
        stateManagerInst.ApplyPlayerState((state is Map) ? JSON.Parse(JSON.Stringify(state)) : Map())
    }

    SyncSettings(settingsManagerInst) {
        if !IsObject(settingsManagerInst)
            return
        settingsManagerInst.Set("currentProfileId", this.currentId)
        settingsManagerInst.Set("characterName", this.GetCurrentName())
    }

    SaveAll(stateManagerInst) {
        this.CaptureCurrentState(stateManagerInst)
        this.SaveProfilesFile()
        stateManagerInst.SavePlayerState()
    }

    SwitchToIndex(index, stateManagerInst, settingsManagerInst) {
        if (index < 1 || index > this.profiles.Length)
            return false
        this.CaptureCurrentState(stateManagerInst)
        this.currentId := this.profiles[index]["id"]
        this.ApplyCurrentToState(stateManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveProfilesFile()
        return true
    }

    RenameCurrent(newName, settingsManagerInst) {
        name := Trim(newName)
        if (name == "")
            return false
        other := this.FindIndexByName(name)
        currentIdx := this.FindIndexById(this.currentId)
        if (other > 0 && other != currentIdx)
            return false
        if (currentIdx < 1)
            return false
        this.profiles[currentIdx]["characterName"] := name
        this.SyncSettings(settingsManagerInst)
        this.SaveProfilesFile()
        return true
    }

    CreateProfile(characterName, stateManagerInst, settingsManagerInst) {
        name := Trim(characterName)
        if (name == "")
            return false
        if (this.FindIndexByName(name) > 0)
            return false

        this.CaptureCurrentState(stateManagerInst)
        newId := "p" FormatTime(A_Now, "yyyyMMddHHmmss") A_TickCount
        emptyState := stateManagerInst.GetDefaultPlayerState()
        this.profiles.Push(this.MakeProfile(newId, name, emptyState))
        this.currentId := newId
        this.ApplyCurrentToState(stateManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveAll(stateManagerInst)
        return true
    }

    ResetCurrent(stateManagerInst, settingsManagerInst) {
        idx := this.FindIndexById(this.currentId)
        if (idx < 1)
            return false

        name := "player"
        n := 2
        while (this.FindIndexByName(name) > 0 && this.FindIndexByName(name) != idx) {
            name := "player " n
            n++
        }
        this.profiles[idx]["characterName"] := name
        this.profiles[idx]["state"] := stateManagerInst.GetDefaultPlayerState()
        this.ApplyCurrentToState(stateManagerInst)
        this.SyncSettings(settingsManagerInst)
        this.SaveAll(stateManagerInst)
        return true
    }
}
