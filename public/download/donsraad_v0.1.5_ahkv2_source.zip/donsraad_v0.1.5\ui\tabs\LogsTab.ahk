#Requires AutoHotkey v2.0+

class LogsTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 4)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" (this.contentW - 140) " h28 +0x200 BackgroundTrans", "Logs"))

        this.AddTextButton(4, m + this.contentW - 120, y, 120, 28, "Clear", (*) => this.ClearLogs())

        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" m " y" (y + 28) " w" this.contentW " h16 BackgroundTrans",
            "Scenario and OCR output while the app is running."))

        logBox := this.PageAdd(4, this.StyleEdit(g.Add("Edit",
            "x" m " y" (y + 50) " w" this.contentW " h" (this.winH - y - 50 - 52)
            " +ReadOnly +HScroll -Wrap -Theme Background" this.inputBgColor, ""),
            "Consolas", 9))
        logBox.Opt("-Tabstop")
        if (IsObject(this.logger))
            this.logger.BindGui(this.guiObj, logBox)
    }
}
