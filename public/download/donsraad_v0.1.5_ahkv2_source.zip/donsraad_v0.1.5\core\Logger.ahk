#Requires AutoHotkey v2.0+

class Logger {
    logLines := []
    maxLines := 250
    targetGui := ""
    targetControl := ""
    debugMode := false

    __New(debugMode := false) {
        this.logLines := []
        this.debugMode := debugMode
    }

    SetDebug(enabled) {
        this.debugMode := enabled ? true : false
    }

    BindGui(guiObj, controlObj) {
        this.targetGui := guiObj
        this.targetControl := controlObj
        this.Render()
    }

    Log(message) {
        text := String(message)
        stamp := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
        this.logLines.Push(stamp " | " text)

        while (this.logLines.Length > this.maxLines)
            this.logLines.RemoveAt(1)

        this.Render()
    }

    Debug(message) {
        if (!this.debugMode)
            return
        this.Log("(Debug) " message)
    }

    Clear() {
        this.logLines := []
        this.Render()
    }

    Render() {
        if !IsObject(this.targetControl)
            return

        fullText := ""
        for _, line in this.logLines {
            fullText .= line . "`n"
        }

        this.targetControl.Value := RTrim(fullText, "`n")
    }
}
