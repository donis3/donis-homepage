#Requires AutoHotkey v2.0+

/**
 * Accept Complete Missions Scenario
 * Runs while on Landsraad → Active Missions. Claims every completed active mission.
 *
 * 1. Confirm Landsraad tab; if missing, press L and click LandsraadSubTabButton, then check again.
 * 2. Read the 3 active mission slots. Stop if none are occupied.
 * 3. For occupied slots, search active_mission_complete_icon.png.
 * 4. On a completed slot: click the slot center, then Claim and Confirm (client-side, short waits).
 * 5. Re-read slots after each claim (layout shifts) until none are complete.
 *
 * Callable via acceptCompleteMissionsScenarioInst.Execute().
 */
class AcceptCompleteMissionsScenario {
    stateManager := ""
    logger := ""
    anchorMatcher := ""
    imageVariation := 30
    completeIconVariation := 60
    completeIconImage := "active_mission_complete_icon.png"
    completeIconTransColor := "Black"
    completeIconSearchPad := 28
    maxClaims := 3
    lastClaimedCount := 0
    lastClaimedNames := []

    __New(stateManagerInst := "", loggerInst := "", anchorMatcherInst := "") {
        this.stateManager := stateManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
    }

    Execute() {
        this.Debug("[AcceptCompleteMissions] Starting scenario...")
        this.EnsureGameActive()

        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") {
            return this.Fail("GameConstants GameUI is missing.")
        }
        if !GameConstants["GameUI"].Has("LandsraadTabButton") || !GameConstants["GameUI"].Has("LandsraadSubTabButton") {
            return this.Fail("Landsraad tab constants are missing.")
        }
        if !GameConstants["GameUI"].Has("ActiveMissionFirstCompleteIcon")
            || !GameConstants["GameUI"].Has("ActiveMissionCompleteIconSpacing") {
            return this.Fail("Active mission complete-icon constants are missing.")
        }
        if !GameConstants["GameUI"].Has("ActiveMissionClaimClickCoords")
            || !GameConstants["GameUI"].Has("ActiveMissionClaimConfirmCoords") {
            return this.Fail("Active mission claim coordinates are missing.")
        }

        if !this.EnsureActiveMissionsMenu()
            return false

        claimedCount := 0
        this.lastClaimedCount := 0
        this.lastClaimedNames := []
        runSec := this.GetClaimRunSeconds()
        loop this.maxClaims {
            activeMissions := this.ReadActiveMissions()
            completed := this.FindCompletedMission(activeMissions)
            if !IsObject(completed) {
                if (claimedCount > 0)
                    this.Debug("[AcceptCompleteMissions] Claimed " claimedCount " completed mission(s). Stopping.")
                else if (activeMissions.Length == 0)
                    this.Debug("[AcceptCompleteMissions] No active missions. Stopping.")
                else
                    this.Debug("[AcceptCompleteMissions] No completed missions found.")
                this.lastClaimedCount := claimedCount
                return true
            }

            if !this.ClaimCompletedMission(completed)
                return false
            this.RecordClaimedMissionStats(completed.missionName, runSec)
            this.RememberClaimedName(completed.missionName)
            claimedCount += 1
            this.lastClaimedCount := claimedCount
            this.ConsumeMnemonicDevice()
        }

        this.lastClaimedCount := claimedCount
        this.Debug("[AcceptCompleteMissions] Claimed " claimedCount " completed mission(s). Stopping.")
        return true
    }

    EnsureGameActive() {
        gameWindows := ["ahk_exe Dune-Win64-Shipping.exe", "ahk_exe Dune.exe", "Dune: Awakening", "Dune"]
        for _, winTitle in gameWindows {
            if WinExist(winTitle) {
                try {
                    WinActivate(winTitle)
                    WinWaitActive(winTitle, , 2)
                    Sleep(100)
                    return true
                }
            }
        }
        return false
    }

    EnsureActiveMissionsMenu() {
        if this.IsLandsraadTabVisible() {
            this.Debug("[AcceptCompleteMissions] Landsraad tab confirmed. Opening active missions sub-tab...")
            this.OpenActiveMissionsTab()
            return true
        }

        this.Debug("[AcceptCompleteMissions] Landsraad tab not visible. Opening menu (L + sub-tab)...")
        this.OpenLandsraadAndActiveMissionsTab()

        if this.IsLandsraadTabVisible() {
            this.Debug("[AcceptCompleteMissions] Landsraad tab confirmed after recovery.")
            return true
        }

        return this.Fail("Could not open Landsraad active missions tab.")
    }

    IsLandsraadTabVisible() {
        searchArea := this.GetLandsraadTabSearchArea()
        if !IsObject(searchArea)
            return false

        foundX := 0, foundY := 0
        found := this.anchorMatcher.FindAnchor("landsraad_button.png", &foundX, &foundY, searchArea, this.imageVariation)
        if (found)
            this.Debug("[AcceptCompleteMissions] Landsraad button at (" foundX ", " foundY ").")
        return found
    }

    OpenLandsraadAndActiveMissionsTab() {
        InputHelper.SendGameKey("l", 60)
        startTime := A_TickCount
        while (A_TickCount - startTime < 1200) {
            if this.IsLandsraadTabVisible()
                break
            Sleep(40)
        }
        this.OpenActiveMissionsTab()
    }

    OpenActiveMissionsTab() {
        global GameConstants
        subTabConfig := GameConstants["GameUI"]["LandsraadSubTabButton"]
        subPos := ResolutionManager().coords(subTabConfig.x, subTabConfig.y)
        this.Debug("[AcceptCompleteMissions] Clicking LandsraadSubTabButton at (" subPos.x ", " subPos.y ")...")
        InputHelper.FastClick(subPos.x, subPos.y)
    }

    ReadActiveMissions() {
        boxes := this.GetActiveMissionBoxes()
        if (boxes.Length == 0) {
            this.Log("[AcceptCompleteMissions] Error: Unable to determine active mission box positions.")
            return []
        }

        candidates := this.GetCandidateMissions()
        ocrLang := this.GetOcrLanguage()
        activeMissions := []

        this.Debug("[AcceptCompleteMissions] Reading " boxes.Length " active mission slots...")

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                normalized := Ocr.NormalizeText(ocrResult.text)
                matched := Ocr.FindBestMatch(normalized, candidates)
                matchedName := (matched.confidence >= 0.4) ? matched.matchedName : ""

                if (matchedName != "") {
                    activeMissions.Push({
                        index: box.index,
                        missionName: matchedName
                    })
                    this.Debug("[AcceptCompleteMissions] Slot " box.index ": " matchedName)
                }
            } catch as err {
                this.Debug("[AcceptCompleteMissions] Error reading slot " box.index ": " err.Message)
            }
        }

        return activeMissions
    }

    FindCompletedMission(activeMissions) {
        namesBySlot := Map()
        if (activeMissions is Array) {
            for _, mission in activeMissions {
                if IsObject(mission)
                    namesBySlot[mission.index] := mission.missionName
            }
        }

        loop 3 {
            slotIndex := A_Index
            if !this.HasCompleteIcon(slotIndex) {
                name := namesBySlot.Has(slotIndex) ? namesBySlot[slotIndex] : ""
                if (name != "")
                    this.Debug("[AcceptCompleteMissions] Slot " slotIndex " (`"" name "`") is not complete.")
                else
                    this.Debug("[AcceptCompleteMissions] Slot " slotIndex " is not complete.")
                continue
            }

            missionName := namesBySlot.Has(slotIndex) ? namesBySlot[slotIndex] : "Unknown"
            this.Debug("[AcceptCompleteMissions] Completed mission in slot " slotIndex ": " missionName)
            return {
                index: slotIndex,
                missionName: missionName
            }
        }
        return ""
    }

    ClaimCompletedMission(mission) {
        if !this.ClickActiveMissionSlot(mission.index) {
            return this.Fail("Could not click completed mission slot " mission.index ".")
        }

        if !this.ClickUiPoint("ActiveMissionClaimClickCoords", "claim reward")
            return false

        if !this.ClickUiPoint("ActiveMissionClaimConfirmCoords", "claim confirm")
            return false

        this.Debug("[AcceptCompleteMissions] Claimed `"" mission.missionName "`" from slot " mission.index ".")
        return true
    }

    GetClaimRunSeconds() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("GetCurrentRunElapsed")
            return this.stateManager.GetCurrentRunElapsed()
        return 0
    }

    RecordClaimedMissionStats(missionName, runSec) {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("RecordMissionCompletion")
            return
        this.stateManager.RecordMissionCompletion(missionName, runSec)
    }

    ConsumeMnemonicDevice() {
        if !IsObject(this.stateManager) || !this.stateManager.HasMethod("ConsumeMnemonicDevice")
            return
        this.stateManager.ConsumeMnemonicDevice()
        this.Debug("[AcceptCompleteMissions] Mnemonic device remaining: " this.stateManager.GetMnemonicDeviceText())
        StatusBar.Refresh()
    }

    RememberClaimedName(missionName) {
        name := Trim(missionName)
        if (name == "" || StrLower(name) == "unknown")
            return
        if !(this.lastClaimedNames is Array)
            this.lastClaimedNames := []
        this.lastClaimedNames.Push(name)
    }

    ClickActiveMissionSlot(slotIndex) {
        boxes := this.GetActiveMissionBoxes()
        box := ""
        for _, entry in boxes {
            if (entry.index == slotIndex) {
                box := entry
                break
            }
        }
        if !IsObject(box)
            return false

        clickX := box.screenX + (box.screenW // 2)
        clickY := box.screenY + (box.screenH // 2)
        this.Debug("[AcceptCompleteMissions] Clicking slot " slotIndex " center at (" clickX ", " clickY ")...")
        InputHelper.SendGameClick(clickX, clickY)
        return true
    }

    ClickUiPoint(keyName, label) {
        global GameConstants
        if !GameConstants["GameUI"].Has(keyName)
            return this.Fail(keyName " is missing.")

        cfg := GameConstants["GameUI"][keyName]
        pos := ResolutionManager().coords(cfg.x, cfg.y)
        this.Debug("[AcceptCompleteMissions] Clicking " label " at (" pos.x ", " pos.y ")...")
        InputHelper.FastClick(pos.x, pos.y)
        return true
    }

    HasCompleteIcon(slotIndex) {
        searchArea := this.GetCompleteIconSearchArea(slotIndex)
        if !IsObject(searchArea)
            return false

        foundX := 0, foundY := 0
        this.Debug("[AcceptCompleteMissions] Searching slot " slotIndex " complete icon in ["
            searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        found := this.anchorMatcher.FindAnchor(
            this.completeIconImage,
            &foundX,
            &foundY,
            searchArea,
            this.completeIconVariation,
            this.completeIconTransColor
        )
        if (found)
            this.Debug("[AcceptCompleteMissions] Complete icon for slot " slotIndex " at (" foundX ", " foundY ").")
        return found
    }

    GetCompleteIconSlotOrigin(slotIndex) {
        global GameConstants
        firstIcon := GameConstants["GameUI"]["ActiveMissionFirstCompleteIcon"]
        spacing := GameConstants["GameUI"]["ActiveMissionCompleteIconSpacing"]
        iconW := firstIcon.HasOwnProp("w") ? firstIcon.w : 41
        iconH := firstIcon.HasOwnProp("h") ? firstIcon.h : 26
        ; 3440x1440: slot1 1486,378  slot2 1486,628  slot3 1486,878
        return {
            x: firstIcon.x,
            y: firstIcon.y + ((slotIndex - 1) * spacing),
            w: iconW,
            h: iconH
        }
    }

    GetCompleteIconSearchArea(slotIndex) {
        origin := this.GetCompleteIconSlotOrigin(slotIndex)
        rect := ResolutionManager().rect(origin.x, origin.y, origin.w, origin.h)
        pad := this.completeIconSearchPad
        return {
            x1: Max(0, rect.x - pad),
            y1: Max(0, rect.y - pad),
            x2: Min(A_ScreenWidth, rect.x + Max(1, rect.w) + pad),
            y2: Min(A_ScreenHeight, rect.y + Max(1, rect.h) + pad)
        }
    }

    GetActiveMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("ActiveMissionFirstPosition") || !uiConfig.Has("ActiveMissionTextSize")
            return []

        firstPos := uiConfig["ActiveMissionFirstPosition"]
        textSize := uiConfig["ActiveMissionTextSize"]
        spacing := uiConfig.Has("ActiveMissionSpacing") ? uiConfig["ActiveMissionSpacing"] : 0
        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            pos := rm.coords(firstPos.x, firstPos.y + ((missionIndex - 1) * spacing))
            size := rm.dimensions(textSize.x, textSize.y)
            boxes.Push({
                index: missionIndex,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    GetLandsraadTabSearchArea() {
        global GameConstants
        if !GameConstants["GameUI"].Has("LandsraadTabButton")
            return ""

        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        rm := ResolutionManager()
        pos := rm.coords(tabBtnConfig.x, tabBtnConfig.y)
        size := rm.dimensions(tabBtnConfig.w, tabBtnConfig.h)
        searchPadding := 20
        return {
            x1: Max(0, pos.x - searchPadding),
            y1: Max(0, pos.y - searchPadding),
            x2: Min(A_ScreenWidth, pos.x + size.w + searchPadding),
            y2: Min(A_ScreenHeight, pos.y + size.h + searchPadding)
        }
    }

    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        return []
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    Fail(message) {
        this.Log("[AcceptCompleteMissions] Error: " message)
        StatusBar.SetStatus(message, "error")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus(message)
        return false
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
