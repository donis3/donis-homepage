#Requires AutoHotkey v2.0+

class AboutTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 5)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        pad := 20
        innerW := cardW - pad * 2

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h24 BackgroundTrans", "About"))
        y += 32

        brandH := 90
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h" brandH " Background" this.surfaceColor))
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w4 h" brandH " BackgroundEAB308"))
        g.SetFont("s16 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 8) " w" innerW " h24 BackgroundTrans",
            "DONSRAAD"))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 32) " w" innerW " h16 BackgroundTrans",
            "Easy Mission Picker"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 50) " w" innerW " h16 BackgroundTrans",
            "Version " this.GetAppVersion()))
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        projectLink := this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 68) " w" innerW " h16 BackgroundTrans",
            "donis.dev/projects/donsraad"))
        projectLink.OnEvent("Click", (*) => this.OpenProjectSite())
        y += brandH + 10

        helpH := 430
        colGap := 28
        colW := (innerW - colGap) // 2
        leftX := m + pad
        rightX := leftX + colW + colGap
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h" helpH " Background" this.surfaceColor))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" leftX " y" (y + 10) " w" innerW " h18 BackgroundTrans",
            "Help"))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" leftX " y" (y + 32) " w" colW " h16 BackgroundTrans",
            "Missions grid"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" leftX " y" (y + 52) " w" colW " h" (helpH - 64) " BackgroundTrans Wrap",
            "The Missions tab is the same 5×5 Landsraad house board you see in game.`n`n"
            "Want a mission from a house? Click that same cell here and pick the mission. Green cells are your targets.`n`n"
            "You can pick up to 3 missions total. One specialization per cell — it must match what that house offers.`n`n"
            "Landsraad only shows a few random offers per specialization. Donsraad fills leftover slots, disbands your guild to refresh the board, and repeats until your targets appear, then accepts them."))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" rightX " y" (y + 32) " w" colW " h16 BackgroundTrans",
            "How to use"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" rightX " y" (y + 52) " w" colW " h" (helpH - 64) " BackgroundTrans Wrap",
            "1.  Settings — Character, guild name, and faction. Guild name is required to refresh the board. Turn on AutoRun if you want loops to start themselves.`n`n"
            "2.  Missions — Match the in-game house cell, then choose your targets.`n`n"
            "3.  First setup — Focus Dune: Awakening, then Initialize or press Start once.`n`n"
            "4.  Run — Start (Home) runs the picker. End stops it and pauses AutoRun. Delete toggles AutoRun.`n`n"
            "5.  Play — Run your missions. With AutoRun on, leave Travel confirmation open at the ornithopter, or finish so View mission report? shows — either starts the next loop.`n`n"
            "6.  Stats — Completes, best times, and Availability (only when you target one mission from a specialization).`n`n"
            "7.  Overlay — Pins to the game window and hides when you alt-tab. During picker loops it sits bottom left. SESSION counts completes this run.`n`n"
            "8.  Dashboard — Window X hides it. Tray icon or the dashboard key shows it again. Pause exits. Rebind keys in Settings."))
        y += helpH + 10

        devH := this.winH - y - 52
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w" cardW " h" devH " Background" this.surfaceColor))
        this.PageAdd(5, g.Add("Text", "x" m " y" y " w4 h" devH " BackgroundEAB308"))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" (y + 14) " w" innerW " h20 BackgroundTrans",
            "Developer"))

        picSize := 64
        picX := m + pad
        picY := y + 40
        photoPath := A_ScriptDir "\ui\donis.png"
        textX := picX
        nameW := innerW
        if FileExist(photoPath) {
            this.PageAdd(5, g.Add("Text",
                "x" (picX - 2) " y" (picY - 2) " w" (picSize + 4) " h" (picSize + 4) " BackgroundEAB308"))
            this.PageAdd(5, g.Add("Picture",
                "x" picX " y" picY " w" picSize " h" picSize, photoPath))
            textX := picX + picSize + 16
            nameW := innerW - picSize - 16
        }

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 40) " w" nameW " h22 BackgroundTrans",
            "Deniz Özkan"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 62) " w" nameW " h16 BackgroundTrans",
            "Dune: Awakening Landsraad companion"))
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        siteLink := this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 80) " w" nameW " h16 BackgroundTrans",
            "donis.dev"))
        siteLink.OnEvent("Click", (*) => this.OpenDeveloperSite())
        projectSiteLink := this.PageAdd(5, g.Add("Text", "x" textX " y" (y + 98) " w" nameW " h16 BackgroundTrans",
            "donis.dev/projects/donsraad"))
        projectSiteLink.OnEvent("Click", (*) => this.OpenProjectSite())

        purposeY := y + 128
        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(5, g.Add("Text", "x" (m + pad) " y" purposeY " w" innerW " h16 BackgroundTrans",
            "Why this exists"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(5, g.Add("Text",
            "x" (m + pad) " y" (purposeY + 18) " w" innerW " h48 BackgroundTrans Wrap",
            "Random Landsraad missions scatter you across the map. Donsraad keeps you on jobs in the same area so you can actually play — fewer loading screens, less travel."))

        g.SetFont("s8 c52525B", "Segoe UI")
        this.PageAdd(5, g.Add("Text",
            "x" (m + pad) " y" (y + devH - 28) " w" innerW " h16 BackgroundTrans",
            "© 2026 Deniz Özkan. All rights reserved.  ·  v" this.GetAppVersion()))
    }
}
