#Requires AutoHotkey v2.0+

/**
 * Converts coordinates and sizes from the developer 3440x1440 (21:9) space
 * into the current game client (screen pixels).
 *
 * Dune: Awakening keeps a fixed 16:9 game UI. At 1440p that UI is 2560x1440.
 * Ultrawide 3440x1440 only adds 440px of empty padding on each side — the UI
 * is not stretched. Standard 2560x1440 is the same UI with that padding gone:
 *   x1440 = x3440 - 440
 *   y1440 = y3440
 *
 * 1080p is that 16:9 1440p layout scaled by 1080/1440 = 0.75:
 *   x1080 = (x3440 - 440) * 0.75
 *   y1080 = y3440 * 0.75
 *
 * Windowed mode uses the game client size and origin, not the monitor.
 * coords() / rect() return screen-space points (client origin + converted).
 *
 * All GameConstants values are authored in 3440x1440.
 *
 * Example:
 *   rm := ResolutionManager()
 *   pos := rm.coords(1074, 333)
 *   size := rm.dimensions(243, 138)
 */
class ResolutionManager {
    baseWidth := 3440
    baseHeight := 1440
    gameUiWidth := 2560
    gameUiHeight := 1440
    refPadX := 440
    refPadY := 0
    screenWidth := 0
    screenHeight := 0
    originX := 0
    originY := 0
    scale := 1.0
    scaleX := 1.0
    scaleY := 1.0
    leftPad := 0
    topPad := 0
    hwnd := 0
    lastLayoutKey := ""
    static sharedLastLayoutKey := ""

    __New(baseWidth := 3440, baseHeight := 1440, gameUiWidth := 2560, gameUiHeight := 1440) {
        this.baseWidth := baseWidth
        this.baseHeight := baseHeight
        this.gameUiWidth := gameUiWidth
        this.gameUiHeight := gameUiHeight
        this.refPadX := Max(0, (this.baseWidth - this.gameUiWidth) // 2)
        this.refPadY := Max(0, (this.baseHeight - this.gameUiHeight) // 2)
        this.Refresh()
    }

    /**
     * Re-read the game client (or fall back to the monitor if the game is closed).
     */
    Refresh() {
        client := GameWindow.GetClient()
        if IsObject(client) {
            this.hwnd := client.hwnd
            this.originX := client.x
            this.originY := client.y
            this.screenWidth := client.w
            this.screenHeight := client.h
        } else {
            this.hwnd := 0
            this.originX := 0
            this.originY := 0
            this.screenWidth := A_ScreenWidth
            this.screenHeight := A_ScreenHeight
        }
        this.RecalcLayout()
        this.LogLayoutIfChanged()
    }

    RecalcLayout() {
        uiAspect := this.gameUiWidth / this.gameUiHeight
        screenAspect := this.screenWidth / this.screenHeight

        if (screenAspect >= uiAspect) {
            this.scale := this.screenHeight / this.gameUiHeight
            uiW := this.gameUiWidth * this.scale
            this.leftPad := Round((this.screenWidth - uiW) / 2)
            this.topPad := 0
        } else {
            this.scale := this.screenWidth / this.gameUiWidth
            uiH := this.gameUiHeight * this.scale
            this.leftPad := 0
            this.topPad := Round((this.screenHeight - uiH) / 2)
        }

        this.scaleX := this.scale
        this.scaleY := this.scale
    }

    LogLayoutIfChanged() {
        key := this.originX "," this.originY "," this.screenWidth "x" this.screenHeight "," this.scale
        if (key == ResolutionManager.sharedLastLayoutKey)
            return
        ResolutionManager.sharedLastLayoutKey := key
        this.lastLayoutKey := key
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[Resolution] Client " this.screenWidth "x" this.screenHeight
                " at (" this.originX ", " this.originY ") scale=" this.scale
                " leftPad=" this.leftPad " anchors=" this.AnchorFolderAt())
    }

    coordsAt(x, y) {
        return {
            x: Round((x - this.refPadX) * this.scale + this.leftPad + this.originX),
            y: Round((y - this.refPadY) * this.scale + this.topPad + this.originY)
        }
    }

    dimensionsAt(width, height) {
        return {
            w: Round(width * this.scale),
            h: Round(height * this.scale)
        }
    }

    /**
     * Point from 3440x1440 developer space into the current game client (screen pixels).
     */
    coords(x, y) {
        this.Refresh()
        return this.coordsAt(x, y)
    }

    coord(x, y) {
        return this.coords(x, y)
    }

    /**
     * Width/height from developer space. UI does not stretch independently on X vs Y.
     */
    dimensions(width, height) {
        this.Refresh()
        return this.dimensionsAt(width, height)
    }

    /**
     * Adds a developer-space delta to a developer-space point, then converts.
     */
    addToCoords(x, y, deltaX, deltaY) {
        return this.coords(x + deltaX, y + deltaY)
    }

    /**
     * Adds a developer-space delta to a point that is already in screen space.
     */
    add(x, y, deltaX, deltaY) {
        this.Refresh()
        return {
            x: Round(x + (deltaX * this.scale)),
            y: Round(y + (deltaY * this.scale))
        }
    }

    rect(x, y, width, height) {
        this.Refresh()
        pos := this.coordsAt(x, y)
        size := this.dimensionsAt(width, height)
        return {
            x: pos.x,
            y: pos.y,
            w: size.w,
            h: size.h
        }
    }

    /**
     * ImageSearch box from a 3440x1440 region, padded and clamped to the game client.
     */
    searchRect(x, y, width, height, padding := 20) {
        r := this.rect(x, y, width, height)
        return this.inflateSearch(r.x, r.y, r.w, r.h, padding)
    }

    searchFromConfig(cfg, padding := 20) {
        w := (IsObject(cfg) && cfg.HasOwnProp("w")) ? cfg.w : 1
        h := (IsObject(cfg) && cfg.HasOwnProp("h")) ? cfg.h : 1
        return this.searchRect(cfg.x, cfg.y, w, h, padding)
    }

    inflateSearch(x, y, w, h, padding := 0) {
        this.Refresh()
        left := this.originX
        top := this.originY
        right := this.originX + this.screenWidth
        bottom := this.originY + this.screenHeight
        x1 := Max(left, Integer(x) - padding)
        y1 := Max(top, Integer(y) - padding)
        x2 := Min(right, Integer(x) + Max(1, Integer(w)) + padding)
        y2 := Min(bottom, Integer(y) + Max(1, Integer(h)) + padding)
        if (x2 <= x1)
            x2 := Min(right, x1 + 1)
        if (y2 <= y1)
            y2 := Min(bottom, y1 + 1)
        return {
            x1: x1,
            y1: y1,
            x2: x2,
            y2: y2
        }
    }

    clientSearchArea() {
        this.Refresh()
        return {
            x1: this.originX,
            y1: this.originY,
            x2: this.originX + this.screenWidth,
            y2: this.originY + this.screenHeight
        }
    }

    /**
     * Bottom-right band where the in-world mission-report prompt appears
     * (above the hotbar). More reliable than a fixed 3440 crop.
     */
    bottomRightClientSearchArea(widthFraction := 0.50, heightFraction := 0.28) {
        this.Refresh()
        inset := Max(8, Round(16 * this.scale))
        w := Max(1, Round(this.screenWidth * widthFraction))
        h := Max(1, Round(this.screenHeight * heightFraction))
        return {
            x1: this.originX + this.screenWidth - w - inset,
            y1: this.originY + this.screenHeight - h - inset,
            x2: this.originX + this.screenWidth - inset,
            y2: this.originY + this.screenHeight - inset
        }
    }

    ClampCapture(&x, &y, &w, &h) {
        this.Refresh()
        left := this.originX
        top := this.originY
        right := this.originX + this.screenWidth
        bottom := this.originY + this.screenHeight
        x := Max(left, Integer(x))
        y := Max(top, Integer(y))
        w := Max(1, Integer(w))
        h := Max(1, Integer(h))
        if (x + w > right)
            w := Max(1, right - x)
        if (y + h > bottom)
            h := Max(1, bottom - y)
    }

    /**
     * 1080p UI is 0.75 of 1440p. Midpoint 0.875 picks the matching ImageSearch pack.
     */
    AnchorFolder() {
        this.Refresh()
        return this.AnchorFolderAt()
    }

    AnchorFolderAt() {
        if (this.scale < 0.875)
            return "1080p"
        return "1440p"
    }
}
