#Requires AutoHotkey v2.0+

/**
 * Donsraad GUI container. Tab pages live in ui\tabs.
 * 1 Missions  2 Stats  3 Settings  4 Logs  5 About
 */
class DonsraadGui {
    guiObj := ""
    stateManager := ""
    settingsManager := ""
    logger := ""

    winW := 900
    winH := 980
    margin := 36
    contentW := 828
    gridX := 80
    gridW := 740
    bgColor := "0F0F12"
    surfaceColor := "18181F"
    mutedColor := "27272F"
    inputBgColor := "3F3F46"
    inputFgColor := "FAFAFA"
    gridClickableBg := "27272F"
    gridTargetedBg := "166534"
    gridDisabledBg := "3F3F46"
    gridClickableFg := "E4E4E7"
    gridTargetedFg := "ECFDF5"
    gridDisabledFg := "A1A1AA"
    gridActiveFrame := "EAB308"
    editBgBrush := 0
    ctlColorHandler := ""
    listColorHandler := ""
    styledEdits := []

    slotMissions := Map()
    boxFrames := []
    boxButtons := []
    activeSlotIdx := 0
    panelLabel := ""
    mRow := []
    counterLabel := ""
    hintLabel := ""
    initActionBtn := ""

    tabButtons := []
    pageControls := Map()
    activeTab := 1

    pickerTab := ""
    statsTab := ""
    settingsTab := ""
    logsTab := ""
    aboutTab := ""

    setOcrLang := ""
    setGuildName := ""
    setFaction := ""
    setDebugMode := ""
    setAutoRunOnTravel := ""
    setShowOverlay := ""
    setOverlayPosition := ""
    setShowNotifications := ""
    setActionDelay := ""
    setCharacterName := ""
    setProfile := ""
    setHotkeyStart := ""
    setHotkeyStop := ""
    setHotkeyAutoRun := ""
    setHotkeyExit := ""
    setHotkeyToggle := ""
    setHotkeyOverlay := ""
    overlaySectionChecks := ""
    headerHotkeyItems := []
    statusBar := ""
    statusProgress := ""
    initScenario := ""
    userState := ""
    profileManager := ""
    isInitializing := true

    __New(stateManagerInst, settingsManagerInst := "", loggerInst := "", initScenarioInst := "", userStateInst := "", profileManagerInst := "") {
        this.isInitializing := true
        this.stateManager := stateManagerInst
        this.settingsManager := settingsManagerInst ? settingsManagerInst : SettingsManager(A_ScriptDir)
        this.logger := loggerInst
        this.initScenario := initScenarioInst
        this.userState := userStateInst
        this.profileManager := profileManagerInst

        if (IsObject(this.logger) && IsObject(this.settingsManager))
            this.logger.SetDebug(this.settingsManager.Get("debugMode", false))

        loop 5
            this.pageControls[A_Index] := []

        this.BuildGui()
        this.isInitializing := false
    }

    PageAdd(page, ctl) {
        if !this.pageControls.Has(page)
            this.pageControls[page] := []
        this.pageControls[page].Push(ctl)
        return ctl
    }

    PageAddSelect(page, selectCtrl) {
        this.PageAdd(page, selectCtrl.face)
        this.PageAdd(page, selectCtrl.caret)
        return selectCtrl
    }

    BuildGui() {
        this.guiObj := Gui("+Resize +MinSize820x940", "Donsraad — Easy Mission Picker")
        this.ApplyAppIcon()
        g := this.guiObj
        g.BackColor := this.bgColor
        g.MarginX := 0
        g.MarginY := 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")

        this.contentW := this.winW - (this.margin * 2)

        this.BuildHeader()
        this.BuildTabBar()
        this.pickerTab := MissionPickerTab(this)
        this.statsTab := StatsTab(this)
        this.settingsTab := SettingsTab(this)
        this.logsTab := LogsTab(this)
        this.aboutTab := AboutTab(this)
        this.pickerTab.Build()
        this.statsTab.Build()
        this.settingsTab.Build()
        this.logsTab.Build()
        this.aboutTab.Build()
        this.BuildFooter()

        this.RestoreMissionSelections()
        this.SwitchTab(1)
        this.InitEditColors()
        try {
            useDark := Buffer(4, 0)
            NumPut("Int", 1, useDark)
            DllCall("dwmapi\DwmSetWindowAttribute", "ptr", g.Hwnd, "uint", 20, "ptr", useDark, "uint", 4)
        }
        g.OnEvent("Close", (*) => this.guiObj.Minimize())
    }

    AddTextButton(page, x, y, w, h, label, callback, primary := false) {
        g := this.guiObj
        bg := primary ? "EAB308" : this.mutedColor
        fg := primary ? "18181B" : "E4E4E7"
        g.SetFont("s9 bold c" fg, "Segoe UI")
        btn := this.PageAdd(page, g.Add("Text",
            "x" x " y" y " w" w " h" h " Center +0x200 Background" bg, label))
        btn.OnEvent("Click", callback)
        return btn
    }

    SetTextButtonState(ctrl, enabled, primary := false) {
        if !IsObject(ctrl)
            return
        if (primary) {
            ctrl.Opt("BackgroundEAB308")
            ctrl.SetFont("s9 bold c18181B", "Segoe UI")
        } else if (enabled) {
            ctrl.Opt("Background" this.mutedColor)
            ctrl.SetFont("s9 bold cE4E4E7", "Segoe UI")
        } else {
            ctrl.Opt("Background" this.inputBgColor)
            ctrl.SetFont("s9 bold c71717A", "Segoe UI")
        }
        ctrl.Redraw()
    }

    StyleEdit(ctrl, fontName := "Segoe UI", fontSize := 10) {
        try DllCall("uxtheme\SetWindowTheme", "ptr", ctrl.Hwnd, "wstr", "", "wstr", "")
        ctrl.Opt("-Theme Background" this.inputBgColor)
        ctrl.SetFont("s" fontSize " c" this.inputFgColor, fontName)
        this.styledEdits.Push(ctrl)
        return ctrl
    }

    InitEditColors() {
        if (!this.editBgBrush)
            this.editBgBrush := DllCall("gdi32\CreateSolidBrush", "uint", 0x463F3F, "ptr")
        this.ctlColorHandler := ObjBindMethod(this, "OnCtlColorEdit")
        OnMessage(0x0133, this.ctlColorHandler)
        OnMessage(0x0138, this.ctlColorHandler)
        this.listColorHandler := ObjBindMethod(this, "OnCtlColorListBox")
        OnMessage(0x0134, this.listColorHandler)
    }

    OnCtlColorListBox(wParam, lParam, msg, hwnd) {
        DllCall("gdi32\SetTextColor", "ptr", wParam, "uint", 0xFAFAFA)
        DllCall("gdi32\SetBkColor", "ptr", wParam, "uint", 0x463F3F)
        DllCall("gdi32\SetBkMode", "ptr", wParam, "int", 2)
        return this.editBgBrush
    }

    OnCtlColorEdit(wParam, lParam, msg, hwnd) {
        isOurs := false
        for _, ctl in this.styledEdits {
            if (IsObject(ctl) && lParam == ctl.Hwnd) {
                isOurs := true
                break
            }
        }
        if (!isOurs)
            return
        DllCall("gdi32\SetTextColor", "ptr", wParam, "uint", 0xFAFAFA)
        DllCall("gdi32\SetBkColor", "ptr", wParam, "uint", 0x463F3F)
        DllCall("gdi32\SetBkMode", "ptr", wParam, "int", 2)
        return this.editBgBrush
    }

    BuildHeader() {
        g := this.guiObj
        m := this.margin
        g.SetFont("s16 bold cEAB308", "Segoe UI")
        g.Add("Text", "x" m " y14 w280 h26 BackgroundTrans", "DONSRAAD")
        g.SetFont("s9 c71717A", "Segoe UI")
        g.Add("Text", "x" m " y40 w360 h16 BackgroundTrans", "Easy Mission Picker for Dune: Awakening")
        this.BuildHeaderHotkeys()
        g.Add("Text", "x0 y62 w" this.winW " h2 BackgroundEAB308")
    }

    BuildTabBar() {
        g := this.guiObj
        labels := ["Missions", "Stats", "Settings", "Logs", "About"]
        tabH := 34
        tabY := 76
        tabX := this.margin
        gap := 8
        count := labels.Length
        tabW := (this.contentW - (count - 1) * gap) // count
        extra := this.contentW - (tabW * count + gap * (count - 1))
        this.tabButtons := []
        x := tabX
        loop count {
            idx := A_Index
            w := tabW + ((idx <= extra) ? 1 : 0)
            g.SetFont("s10 cA1A1AA", "Segoe UI")
            btn := g.Add("Text", "x" x " y" tabY " w" w " h" tabH " Center +0x200 Background" this.surfaceColor,
                labels[idx])
            btn.OnEvent("Click", this.MakeTabHandler(idx))
            this.tabButtons.Push(btn)
            x += w + gap
        }
    }

    MakeTabHandler(idx) {
        return (ctrl, *) => this.SwitchTab(idx)
    }

    SwitchTab(page) {
        DarkSelect.Dismiss()
        this.activeTab := page
        loop this.tabButtons.Length {
            idx := A_Index
            isOn := (idx == page)
            if this.pageControls.Has(idx) {
                for _, ctl in this.pageControls[idx] {
                    try ctl.Visible := isOn
                }
            }
            tabBtn := this.tabButtons[idx]
            if (isOn) {
                tabBtn.Opt("BackgroundEAB308")
                tabBtn.SetFont("s10 bold c18181B", "Segoe UI")
            } else {
                tabBtn.Opt("Background" this.surfaceColor)
                tabBtn.SetFont("s10 cA1A1AA", "Segoe UI")
            }
            tabBtn.Redraw()
        }
        if (page == 2 && IsObject(this.statsTab))
            this.statsTab.Refresh()
    }

    BuildFooter() {
        g := this.guiObj
        g.Add("Text", "x0 y" (this.winH - 36) " w" this.winW " h36 Background" this.surfaceColor)
        legalW := 108
        legalH := 26
        progW := 64
        gap := 10
        reserved := legalW + gap + progW
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        this.statusBar := g.Add("Text",
            "x" this.margin " y" (this.winH - 28) " w" (this.contentW - reserved - gap) " h20 +0x200 cEAB308 Background" this.surfaceColor,
            this.GetStatusBarText())
        g.SetFont("s9 bold c18181B", "Segoe UI")
        legal := g.Add("Text",
            "x" (this.margin + this.contentW - reserved) " y" (this.winH - 31) " w" legalW " h" legalH " Center +0x200 BackgroundEAB308",
            "Disclaimer")
        legal.OnEvent("Click", (*) => LegalDialog.Show(this.guiObj))
        g.SetFont("s9 bold cA1A1AA", "Segoe UI")
        this.statusProgress := g.Add("Text",
            "x" (this.margin + this.contentW - progW) " y" (this.winH - 28) " w" progW " h20 Right BackgroundTrans",
            this.GetProgressText())
        this.RefreshStatusProgress()
    }

    RestoreMissionSelections() {
        if IsObject(this.pickerTab)
            this.pickerTab.RestoreMissionSelections()
    }

    SaveMissionSelections() {
        if IsObject(this.pickerTab)
            this.pickerTab.SaveMissionSelections()
    }

    RefreshStatsDisplay() {
        if IsObject(this.settingsTab)
            this.settingsTab.RefreshStatsDisplay()
        if IsObject(this.statsTab)
            this.statsTab.Refresh()
    }

    SyncOverlayEnabledCheckbox() {
        if IsObject(this.settingsTab)
            this.settingsTab.SyncOverlayEnabledCheckbox()
    }

    RefreshSettingsControls() {
        if IsObject(this.settingsTab)
            this.settingsTab.RefreshSettingsControls()
    }

    GetHotkeyHeaderPairs() {
        fallbacks := Map(
            "hotkeyStart", "Home",
            "hotkeyStop", "End",
            "hotkeyToggleAutoRun", "Delete",
            "hotkeyToggleGui", "F8",
            "hotkeyToggleOverlay", "Insert",
            "hotkeyExit", "Pause"
        )
        if IsObject(this.settingsManager)
            fallbacks := this.settingsManager.GetHotkeyFallbacks()
        startKey := fallbacks["hotkeyStart"]
        stopKey := fallbacks["hotkeyStop"]
        autoKey := fallbacks["hotkeyToggleAutoRun"]
        toggleKey := fallbacks["hotkeyToggleGui"]
        overlayKey := fallbacks["hotkeyToggleOverlay"]
        exitKey := fallbacks["hotkeyExit"]
        if IsObject(this.settingsManager) {
            startKey := this.settingsManager.Get("hotkeyStart", startKey)
            stopKey := this.settingsManager.Get("hotkeyStop", stopKey)
            autoKey := this.settingsManager.Get("hotkeyToggleAutoRun", autoKey)
            toggleKey := this.settingsManager.Get("hotkeyToggleGui", toggleKey)
            overlayKey := this.settingsManager.Get("hotkeyToggleOverlay", overlayKey)
            exitKey := this.settingsManager.Get("hotkeyExit", exitKey)
        }
        return [
            { key: this.FormatHotkeyName(startKey), action: "start" },
            { key: this.FormatHotkeyName(stopKey), action: "stop" },
            { key: this.FormatHotkeyName(autoKey), action: "autorun" },
            { key: this.FormatHotkeyName(toggleKey), action: "dashboard" },
            { key: this.FormatHotkeyName(overlayKey), action: "overlay" },
            { key: this.FormatHotkeyName(exitKey), action: "exit" }
        ]
    }

    BuildHeaderHotkeys() {
        g := this.guiObj
        pairs := this.GetHotkeyHeaderPairs()
        colW := 78
        keyW := 70
        gap := 6
        totalW := pairs.Length * colW + (pairs.Length - 1) * gap
        x := this.winW - this.margin - totalW
        this.headerHotkeyItems := []
        loop pairs.Length {
            p := pairs[A_Index]
            keyX := x + ((colW - keyW) // 2)
            keyCtl := g.Add("Text",
                "x" keyX " y14 w" keyW " h22 Center +0x200 Background" this.mutedColor, p.key)
            keyCtl.SetFont("s8 bold cEAB308", "Segoe UI")
            actionCtl := g.Add("Text",
                "x" x " y40 w" colW " h16 Center BackgroundTrans", p.action)
            actionCtl.SetFont("s8 c71717A", "Segoe UI")
            this.headerHotkeyItems.Push({ keyCtl: keyCtl, actionCtl: actionCtl })
            x += colW + gap
        }
    }

    RefreshHeaderHotkeys() {
        pairs := this.GetHotkeyHeaderPairs()
        loop this.headerHotkeyItems.Length {
            if (A_Index > pairs.Length)
                break
            item := this.headerHotkeyItems[A_Index]
            p := pairs[A_Index]
            item.keyCtl.Text := p.key
            item.actionCtl.Text := p.action
            item.keyCtl.Redraw()
        }
    }

    FormatHotkeyName(hotkey) {
        raw := Trim(hotkey)
        if (raw == "")
            return ""
        mods := ""
        key := raw
        loop {
            first := SubStr(key, 1, 1)
            if (first == "^") {
                mods .= "Ctrl+"
                key := SubStr(key, 2)
            } else if (first == "!") {
                mods .= "Alt+"
                key := SubStr(key, 2)
            } else if (first == "+") {
                mods .= "Shift+"
                key := SubStr(key, 2)
            } else if (first == "#") {
                mods .= "Win+"
                key := SubStr(key, 2)
            } else
                break
        }
        if (key == "")
            return Trim(raw)
        return mods . key
    }

    ApplyAppIcon() {
        iconPath := A_ScriptDir "\ui\donsraad_icon.png"
        if !FileExist(iconPath)
            return
        try TraySetIcon(iconPath)
        try {
            hIcon := LoadPicture(iconPath, "GDI+ w256 h256", &imgType)
            if (hIcon) {
                SendMessage(0x80, 1, hIcon, this.guiObj)
                SendMessage(0x80, 0, hIcon, this.guiObj)
            }
        }
    }

    GetAppVersion() {
        try {
            return AppInfo.Version
        } catch {
            return "0.0.0"
        }
    }

    OpenDeveloperSite() {
        Run("https://donis.dev")
    }

    OpenProjectSite() {
        Run("https://donis.dev/projects/donsraad")
    }

    ClearLogs() {
        if (IsObject(this.logger))
            this.logger.Clear()
    }

    Log(message) {
        if (IsObject(this.logger))
            this.logger.Log(message)
    }

    RunInitializeScenario() {
        if this.GetTargetedCount() < 1 {
            this.Log("No targeted missions selected.")
            this.SetStatus("No targetted missions")
            StatusBar.SetStatus("No targetted missions", "error")
            return
        }

        this.SetStatus("Running Initialize…")
        StatusBar.SetStatus("Initialize", "working")
        StatusBar.PinForPickerLoop()
        success := false

        try {
            if IsObject(this.initScenario) {
                success := this.initScenario.Execute(true)
            } else {
                global initializeScenarioInst
                if IsSet(initializeScenarioInst) && IsObject(initializeScenarioInst) {
                    success := initializeScenarioInst.Execute(true)
                } else {
                    initInst := InitializeScenario(this.stateManager, this.logger, "", this.userState)
                    success := initInst.Execute(true)
                }
            }
        } finally {
            StatusBar.ClearPickerPin()
        }

        this.ShowSessionHint()
    }

    GetReadyLabel() {
        if IsObject(this.userState)
            return this.userState.GetReadyLabel()
        return "Awaiting initialization"
    }

    GetStatusBarText() {
        keyName := this.GetStartHotkeyName()
        if this.IsSessionReady()
            return "Press " keyName " to run mission picker"
        return "Press " keyName " to run first setup"
    }

    GetStartHotkeyName() {
        startKey := "Home"
        if IsObject(this.settingsManager)
            startKey := this.settingsManager.Get("hotkeyStart", "Home")
        name := this.FormatHotkeyName(startKey)
        return (name != "") ? name : "Home"
    }

    IsSessionReady() {
        return IsObject(this.userState) && this.userState.IsInitialized()
    }

    OnInitActionClick() {
        if this.IsSessionReady()
            this.ResetSessionState()
        else
            this.RunInitializeScenario()
    }

    ResetSessionState() {
        if IsObject(this.userState)
            this.userState.ResetSession()

        global acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst
        if IsSet(acceptMissionsScenarioInst) && IsObject(acceptMissionsScenarioInst) && acceptMissionsScenarioInst.HasMethod("ResetSession")
            acceptMissionsScenarioInst.ResetSession()
        if IsSet(acceptTargettedMissionsScenarioInst) && IsObject(acceptTargettedMissionsScenarioInst) && acceptTargettedMissionsScenarioInst.HasMethod("ResetSession")
            acceptTargettedMissionsScenarioInst.ResetSession()
        StatusBar.RestoreIdle()

        this.ShowSessionHint()
        this.Log("Session reset. Run Initialize to start again.")
    }

    RefreshInitButton() {
        if !IsObject(this.initActionBtn)
            return
        if this.IsSessionReady() {
            this.initActionBtn.Text := "■   Ready"
            this.initActionBtn.Opt("Background991B1B")
            this.initActionBtn.SetFont("s9 bold cFEE2E2", "Segoe UI")
        } else {
            this.initActionBtn.Text := "▶   Initialize"
            this.initActionBtn.Opt("BackgroundEAB308")
            this.initActionBtn.SetFont("s9 bold c18181B", "Segoe UI")
        }
        this.initActionBtn.Redraw()
    }

    GetProgressText() {
        total := this.GetTargetedCount()
        if IsObject(this.userState)
            return this.userState.GetProgressText(total)
        return "0/0"
    }

    GetTargetedCount() {
        if !IsObject(this.stateManager)
            return 0
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return 0
        return targeted.Length
    }

    IsProgressComplete() {
        if IsObject(this.userState)
            return this.userState.IsProgressComplete(this.GetTargetedCount())
        return false
    }

    RefreshStatusOverlay() {
        StatusBar.Refresh()
    }

    RefreshStatusProgress() {
        if !IsObject(this.statusProgress)
            return
        this.statusProgress.Text := this.GetProgressText()
        if this.IsProgressComplete()
            this.statusProgress.SetFont("s9 bold c4ADE80", "Segoe UI")
        else
            this.statusProgress.SetFont("s9 bold cA1A1AA", "Segoe UI")
    }

    ReloadState() {
        this.stateManager.LoadDatabases()
        this.stateManager.LoadPlayerState()
        this.SetStatus("Databases and state reloaded.")
    }

    SetStatus(msg) {
        if !IsObject(this.statusBar)
            return
        this.statusBar.Text := msg
        this.statusBar.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.RefreshStatusProgress()
        this.RefreshInitButton()
    }

    ShowSessionHint() {
        if !IsObject(this.statusBar)
            return
        this.statusBar.Text := this.GetStatusBarText()
        this.statusBar.SetFont("s9 bold cEAB308", "Segoe UI")
        this.statusBar.Redraw()
        this.RefreshStatusProgress()
        this.RefreshInitButton()
        StatusBar.RestoreIdle()
    }

    Show() {
        try WinRestore("ahk_id " this.guiObj.Hwnd)
        this.guiObj.Show("w" this.winW " h" this.winH)
        this.ShowSessionHint()
    }

    Hide() {
        DarkSelect.Dismiss()
        this.guiObj.Minimize()
    }

    Toggle() {
        hwnd := this.guiObj.Hwnd
        if DllCall("IsIconic", "ptr", hwnd) || !DllCall("IsWindowVisible", "ptr", hwnd)
            this.Show()
        else
            this.Hide()
    }
}
