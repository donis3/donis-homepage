#Requires AutoHotkey v2.0+

/**
 * Temporary rewrite of Initialize. Kept for reference; not bound to a hotkey.
 * Current slice: open Landsraad, switch to active missions, OCR slot names.
 */
class InitDebug {
    logger := ""
    anchorMatcher := ""
    stateManager := ""

    __New(loggerInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.stateManager := stateManagerInst
    }

    Execute(*) {
        this.Log("[InitDebug] Starting debug initialize...")
        this.EnsureGameActive()

        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("LandsraadTabButton") {
            this.Log("[InitDebug] Error: LandsraadTabButton configuration missing in GameConstants.")
            return false
        }

        if !this.EnsureLandsraadTab() {
            this.Log("[InitDebug] Error: Landsraad tab button could not be found. Mission menu could not be opened.")
            return false
        }

        if !GameConstants["GameUI"].Has("LandsraadSubTabButton") {
            this.Log("[InitDebug] Error: LandsraadSubTabButton configuration missing in GameConstants.")
            return false
        }

        if !this.OpenActiveMissionsTab() {
            this.Log("[InitDebug] Error: Active missions tab could not be opened.")
            return false
        }

        names := this.ReadActiveMissionNames()
        if (names.Length == 0) {
            this.Log("[InitDebug] Finished reading active missions. Stopping.")
            return true
        }

        this.Log("[InitDebug] Active missions detected. Running AcceptCompleteMissions...")
        global acceptCompleteMissionsScenarioInst
        if (IsSet(acceptCompleteMissionsScenarioInst) && IsObject(acceptCompleteMissionsScenarioInst))
            acceptCompleteMissionsScenarioInst.Execute()
        else
            this.Log("[InitDebug] Error: AcceptCompleteMissions scenario is unavailable.")
        return true
    }

    EnsureGameActive() {
        return GameWindow.Activate()
    }

    EnsureLandsraadTab() {
        searchArea := this.GetLandsraadTabSearchArea()
        if !IsObject(searchArea)
            return false

        imageName := "landsraad_button.png"
        variation := 30
        foundX := 0, foundY := 0

        this.Debug("[InitDebug] Searching for " imageName " in region ["
            searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        found := this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, variation)
        if (!found) {
            this.Debug("[InitDebug] Landsraad tab button not found. Sending key 'L'...")
            InputHelper.SendGameKey("l", 60)

            startTime := A_TickCount
            while (A_TickCount - startTime < 1200) {
                Sleep(150)
                if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, variation) {
                    found := true
                    break
                }
            }
        }

        if (!found)
            return false

        this.Debug("[InitDebug] Landsraad button detected at (" foundX ", " foundY ").")
        return true
    }

    OpenActiveMissionsTab() {
        global GameConstants
        subTabConfig := GameConstants["GameUI"]["LandsraadSubTabButton"]
        rm := ResolutionManager()
        subPos := rm.coords(subTabConfig.x, subTabConfig.y)
        this.Log("[InitDebug] Clicking LandsraadSubTabButton at (" subPos.x ", " subPos.y ")...")
        InputHelper.SendGameClick(subPos.x, subPos.y)
        userDelay(100)
        return true
    }

    ReadActiveMissionNames() {
        boxes := this.GetActiveMissionBoxes()
        if (boxes.Length == 0) {
            this.Log("[InitDebug] Error: Unable to determine active mission box positions from GameConstants.")
            return []
        }

        candidates := this.GetCandidateMissions()
        ocrLang := this.GetOcrLanguage()
        names := []

        this.Log("[InitDebug] Reading " boxes.Length " active mission slots...")

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                normalized := Ocr.NormalizeText(ocrResult.text)
                matched := Ocr.FindBestMatch(normalized, candidates)
                matchedName := (matched.confidence >= 0.4) ? matched.matchedName : ""

                if (matchedName != "") {
                    names.Push(matchedName)
                    this.Log("[InitDebug] Slot " box.index ": " matchedName)
                } else if (normalized != "") {
                    this.Log("[InitDebug] Slot " box.index ": unrecognized (`"" normalized "`")")
                } else {
                    this.Debug("[InitDebug] Slot " box.index ": empty")
                }
            } catch as err {
                this.Log("[InitDebug] Error reading slot " box.index ": " err.Message)
            }
        }

        if (names.Length == 0)
            this.Log("[InitDebug] No active missions.")
        else
            this.Log("[InitDebug] Active missions (" names.Length "): " this.JoinNames(names))

        return names
    }

    GetActiveMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("ActiveMissionFirstPosition") || !uiConfig.Has("ActiveMissionTextSize")
            return []

        firstPos := uiConfig["ActiveMissionFirstPosition"]
        textSize := uiConfig["ActiveMissionTextSize"]
        spacing := uiConfig.Has("ActiveMissionSpacing") ? uiConfig["ActiveMissionSpacing"] : 0
        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            pos := rm.coords(firstPos.x, firstPos.y + ((missionIndex - 1) * spacing))
            size := rm.dimensions(textSize.x, textSize.y)
            boxes.Push({
                index: missionIndex,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        return []
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    JoinNames(names) {
        joined := ""
        for idx, name in names {
            if (idx > 1)
                joined .= ", "
            joined .= name
        }
        return joined
    }

    GetLandsraadTabSearchArea() {
        global GameConstants
        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        return ResolutionManager().searchFromConfig(tabBtnConfig, 20)
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
