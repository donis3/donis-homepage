#Requires AutoHotkey v2.0+

/**
 * High-speed input helper for AutoHotkey v2.
 * Delivers immediate, high-throughput inputs without artificial jitter or movement delays.
 */
class InputHelper {
    /**
     * Instantly clicks at the specified screen coordinates.
     */
    static FastClick(x, y, button := "Left", count := 1) {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        Click(x . " " . y . " " . button . " " . count)
        CoordMode("Mouse", prevMode)
        userDelay()
    }

    /**
     * Moves to a point, waits for hover, then holds a click so Unreal UI registers it.
     */
    static SendGameClick(x, y, holdMs := 60, hoverMs := 80) {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseMove(x, y, 0)
        Sleep(hoverMs)
        Click("Left Down")
        Sleep(holdMs)
        Click("Left Up")
        CoordMode("Mouse", prevMode)
        userDelay()
    }

    /**
     * Instantly moves cursor to screen coordinates.
     */
    static FastMove(x, y) {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseMove(x, y, 0)
        CoordMode("Mouse", prevMode)
    }

    /**
     * Moves the cursor off a search/hover region but keeps it inside the game client.
     * Leaving the window leaves Unreal buttons stuck in hover and breaks ImageSearch.
     * @param {Object} searchArea - Optional {x1, y1, x2, y2}; only moves when the cursor overlaps it.
     */
    static MoveCursorClearOfSearch(searchArea := "") {
        if IsObject(searchArea) && !this.CursorOverlapsArea(searchArea)
            return

        safe := this.GetSafeCursorPoint(searchArea)
        if IsObject(safe)
            this.FastMove(safe.x, safe.y)
    }

    static CursorOverlapsArea(area) {
        if !IsObject(area)
            return false
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseGetPos(&mx, &my)
        CoordMode("Mouse", prevMode)
        return this.PointInRect(mx, my, area)
    }

    static PointInRect(x, y, rect) {
        if !IsObject(rect)
            return false
        x1 := rect.HasOwnProp("x1") ? rect.x1 : 0
        y1 := rect.HasOwnProp("y1") ? rect.y1 : 0
        x2 := rect.HasOwnProp("x2") ? rect.x2 : 0
        y2 := rect.HasOwnProp("y2") ? rect.y2 : 0
        return (x >= x1 && x <= x2 && y >= y1 && y <= y2)
    }

    /**
     * Picks an in-client point outside searchArea. Prefers ultrawide side padding (no UI).
     */
    static GetSafeCursorPoint(searchArea := "") {
        rm := ResolutionManager()
        rm.Refresh()

        inset := 16
        left := rm.originX
        top := rm.originY
        right := rm.originX + rm.screenWidth
        bottom := rm.originY + rm.screenHeight
        midY := top + (rm.screenHeight // 2)

        candidates := []

        if (rm.leftPad >= 24) {
            candidates.Push({ x: left + (rm.leftPad // 2), y: midY })
            candidates.Push({ x: right - (rm.leftPad // 2), y: midY })
        }

        candidates.Push({ x: left + inset, y: bottom - inset })
        candidates.Push({ x: right - inset, y: bottom - inset })
        candidates.Push({ x: left + inset, y: top + inset })
        candidates.Push({ x: right - inset, y: top + inset })

        for _, pt in candidates {
            if !this.PointInRect(pt.x, pt.y, searchArea)
                return pt
        }

        return { x: left + (rm.screenWidth // 2), y: bottom - inset }
    }

    /**
     * Finds an anchor image and instantly clicks at a relative offset.
     * @param {Object} anchorMatcherInst - Instance of AnchorMatcher
     * @param {String} imageName - Anchor image name
     * @param {Integer} offsetX - Relative X offset
     * @param {Integer} offsetY - Relative Y offset
     * @param {Integer} variation - Color variation tolerance
     * @returns {Boolean} - True if anchor found and clicked
     */
    static ClickAnchorOffset(anchorMatcherInst, imageName, offsetX := 0, offsetY := 0, variation := 25) {
        targetX := 0, targetY := 0
        if anchorMatcherInst.FindAnchorOffset(imageName, offsetX, offsetY, &targetX, &targetY, "", variation) {
            this.FastClick(targetX, targetY)
            return true
        }
        return false
    }

    /**
     * Instantly drags from (x1, y1) to (x2, y2).
     */
    static FastDrag(x1, y1, x2, y2, button := "Left") {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseClickDrag(button, x1, y1, x2, y2, 0)
        CoordMode("Mouse", prevMode)
    }

    /**
     * Sends raw keystrokes at maximum speed.
     */
    static SendInstant(keys) {
        SendInput(keys)
    }

    /**
     * Sends a key press with an explicit hold duration so Unreal Engine / game tick loops register it.
     * Uses SendEvent with down/up and a discrete sleep.
     * @param {String} key - Key name (e.g. "l", "Esc", "Tab")
     * @param {Integer} holdMs - Duration to hold the key down in ms (default 60ms)
     */
    static SendGameKey(key, holdMs := 60) {
        SendEvent("{" key " down}")
        Sleep(holdMs)
        SendEvent("{" key " up}")
        userDelay()
    }

    /**
     * Sends a modifier+key combination with an explicit hold so the game registers it.
     */
    static SendGameModifierKey(modKey, key, holdMs := 40) {
        SendEvent("{" modKey " down}")
        Sleep(20)
        SendEvent("{" key " down}")
        Sleep(holdMs)
        SendEvent("{" key " up}")
        SendEvent("{" modKey " up}")
        userDelay()
    }

    /**
     * Types text into an already-focused field as fast as the game will accept.
     */
    static SendGameText(text) {
        SendEvent("{Text}" text)
        userDelay()
    }

    /**
     * Pause after a client-side UI action.
     * Waits the user's Action Delay, plus optionalDelay extra ms when a step needs more time.
     */
    static WaitClient(optionalDelay := 0) {
        userDelay(optionalDelay)
    }

    static GetActionDelay() {
        ms := 100
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            ms := settingsManagerInst.GetInt("actionDelay", 100)
        allowed := [40, 50, 75, 100, 200, 300]
        for _, allowedMs in allowed {
            if (ms == allowedMs)
                return ms
        }
        return 100
    }

    static UserDelay(optionalDelay := 0) {
        extra := 0
        try {
            extra := Integer(optionalDelay)
        } catch {
            extra := 0
        }
        if (extra < 0)
            extra := 0
        Sleep(InputHelper.GetActionDelay() + extra)
    }
}

/**
 * Client-side wait: Action Delay setting + optional extra ms.
 */
userDelay(optionalDelay := 0) {
    InputHelper.UserDelay(optionalDelay)
}
