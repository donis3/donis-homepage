#Requires AutoHotkey v2.0+

class SettingsTab extends GuiPage {
    __New(hostGui) {
        super.__New(hostGui, 3)
    }

    Build() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        cardH := 68
        colGap := 12
        halfW := (cardW - colGap) // 2
        col1 := m
        col2 := m + halfW + colGap
        ctrlW := 160
        hintW := halfW - 36 - ctrlW - 12

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" m " y" y " w" cardW " h24 BackgroundTrans", "Settings"))
        y += 32

        ; Character | Guild
        this.PageAdd(3, g.Add("Text", "x" col1 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Character Name"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Easily identify your current profile with a name."))
        curChar := IsObject(this.profileManager) ? this.profileManager.GetCurrentName() : this.settingsManager.Get("characterName", "Default")
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setCharacterName := this.PageAdd(3, this.StyleEdit(g.Add("Edit",
            "x" (col1 + halfW - 16 - ctrlW) " y" (y + 20) " w" ctrlW " h28 -Theme Background" this.inputBgColor,
            curChar)))
        this.setCharacterName.OnEvent("LoseFocus", (*) => this.OnCharacterNameCommit())

        this.PageAdd(3, g.Add("Text", "x" col2 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Guild name"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Used when creating a guild. 3–100 characters."))
        curGuild := this.settingsManager.Get("guildName", "wowza")
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setGuildName := this.PageAdd(3, this.StyleEdit(g.Add("Edit",
            "x" (col2 + halfW - 16 - ctrlW) " y" (y + 20) " w" ctrlW " h28 Limit100 -Theme Background" this.inputBgColor,
            curGuild)))
        this.setGuildName.OnEvent("LoseFocus", (*) => this.OnGuildNameCommit())
        y += cardH + 12

        ; Profile switcher — full width
        profileCardH := 68
        this.PageAdd(3, g.Add("Text", "x" m " y" y " w" cardW " h" profileCardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (m + 18) " y" (y + 10) " w" (cardW - 360) " h18 BackgroundTrans", "Active profile"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (m + 18) " y" (y + 32) " w" (cardW - 360) " h28 BackgroundTrans Wrap",
            "Switch character, reset settings, or create a new profile."))
        profileNames := IsObject(this.profileManager) ? this.profileManager.GetProfileNames() : ["Default"]
        if (profileNames.Length == 0)
            profileNames := ["Default"]
        this.setProfile := DarkSelect(g, m + cardW - 336, y + 20, 180, 28, this, profileNames)
        this.PageAddSelect(3, this.setProfile)
        profileIdx := IsObject(this.profileManager) ? this.profileManager.GetCurrentIndex() : 1
        this.setProfile.Choose(profileIdx)
        this.setProfile.OnEvent("Change", (*) => this.OnProfileChange())
        this.AddTextButton(3, m + cardW - 148, y + 20, 62, 28, "Reset", (*) => this.OnResetProfile())
        this.AddTextButton(3, m + cardW - 78, y + 20, 60, 28, "New", (*) => this.OnNewProfile())
        y += profileCardH + 12

        ; Faction | OCR
        this.PageAdd(3, g.Add("Text", "x" col1 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Faction"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Your Landsraad allegiance."))
        factions := ["Atreides", "Harkonnen"]
        curFaction := this.settingsManager.Get("faction", "Atreides")
        this.setFaction := DarkSelect(g, col1 + halfW - 16 - ctrlW, y + 20, ctrlW, 28, this, factions)
        this.PageAddSelect(3, this.setFaction)
        chosenIdx := 1
        loop factions.Length {
            if (factions[A_Index] == curFaction) {
                chosenIdx := A_Index
                break
            }
        }
        this.setFaction.Choose(chosenIdx)
        this.setFaction.OnEvent("Change", (*) => this.OnFactionChange())

        this.PageAdd(3, g.Add("Text", "x" col2 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "OCR language"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Windows OCR pack used to read mission names."))
        curLang := this.settingsManager.Get("ocrLanguage", "en-US")
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setOcrLang := this.PageAdd(3, this.StyleEdit(g.Add("Edit",
            "x" (col2 + halfW - 16 - ctrlW) " y" (y + 20) " w" ctrlW " h28 -Theme Background" this.inputBgColor,
            curLang)))
        this.setOcrLang.OnEvent("Change", (*) => this.OnOcrLangChange())
        y += cardH + 12

        ; Action delay | Overlay
        this.PageAdd(3, g.Add("Text", "x" col1 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Action delay"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Wait after each click or key. Raise this if the game misses inputs."))
        delayLabels := this.GetActionDelayLabels()
        this.setActionDelay := DarkSelect(g, col1 + halfW - 16 - ctrlW, y + 20, ctrlW, 28, this, delayLabels)
        this.PageAddSelect(3, this.setActionDelay)
        this.setActionDelay.Choose(this.GetActionDelayIndex())
        this.setActionDelay.OnEvent("Change", (*) => this.OnActionDelayChange())

        this.PageAdd(3, g.Add("Text", "x" col2 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Status overlay"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Pins to the game window. Hides when unfocused."))
        overlayVal := this.settingsManager.GetBool("showOverlay", true) ? 1 : 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setShowOverlay := this.PageAdd(3, g.Add("Checkbox",
            "x" (col2 + halfW - 16 - 110) " y" (y + 22) " w110 h22 Checked" overlayVal, "Enabled"))
        this.setShowOverlay.Value := overlayVal
        this.setShowOverlay.OnEvent("Click", (*) => this.OnShowOverlayChange())
        y += cardH + 12

        overlaySecH := 118
        this.PageAdd(3, g.Add("Text", "x" m " y" y " w" cardW " h" overlaySecH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (m + 16) " y" (y + 10) " w220 h18 BackgroundTrans", "Overlay sections"))
        posLabels := this.GetOverlayPositionLabels()
        this.setOverlayPosition := DarkSelect(g, m + cardW - 16 - ctrlW, y + 8, ctrlW, 28, this, posLabels)
        this.PageAddSelect(3, this.setOverlayPosition)
        this.setOverlayPosition.Choose(this.GetOverlayPositionIndex())
        this.setOverlayPosition.OnEvent("Change", (*) => this.OnOverlayPositionChange())
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (m + 16) " y" (y + 30) " w" (cardW - 48 - ctrlW) " h16 BackgroundTrans",
            "Choose which HUD blocks are visible. Notifications sit against the bar."))
        this.overlaySectionChecks := Map()
        sectionRows := [
            [
                ["overlayShowStatus", "Status"],
                ["overlayShowRun", "Run"],
                ["overlayShowCurrentRun", "Current"],
                ["overlayShowLastRun", "Last"],
                ["overlayShowTargets", "Targets"]
            ],
            [
                ["overlayShowSession", "Session"],
                ["overlayShowMnemonic", "Mnemonic"],
                ["overlayShowProfile", "Profile"]
            ]
        ]
        rowInnerW := cardW - 32
        g.SetFont("s9 cE4E4E7", "Segoe UI")
        loop sectionRows.Length {
            rowDefs := sectionRows[A_Index]
            rowY := y + 48 + ((A_Index - 1) * 28)
            cols := rowDefs.Length
            if (A_Index == sectionRows.Length)
                cols += 1
            colW := rowInnerW // cols
            boxX := m + 16
            for _, def in rowDefs {
                keyName := def[1]
                label := def[2]
                checked := this.settingsManager.GetBool(keyName, true) ? 1 : 0
                box := this.PageAdd(3, g.Add("Checkbox",
                    "x" boxX " y" rowY " w" (colW - 8) " h22 Checked" checked, label))
                box.Value := checked
                box.OnEvent("Click", this.MakeOverlaySectionHandler(keyName))
                this.overlaySectionChecks[keyName] := box
                boxX += colW
            }
            if (A_Index == sectionRows.Length) {
                notifyVal := this.settingsManager.GetBool("overlayShowNotifications", true) ? 1 : 0
                this.setShowNotifications := this.PageAdd(3, g.Add("Checkbox",
                    "x" boxX " y" rowY " w" (colW - 8) " h22 Checked" notifyVal, "Notifications"))
                this.setShowNotifications.Value := notifyVal
                this.setShowNotifications.OnEvent("Click", (*) => this.OnShowNotificationsChange())
            }
        }
        y += overlaySecH + 12

        autoRunH := 72
        this.PageAdd(3, g.Add("Text", "x" col1 " y" y " w" halfW " h" autoRunH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "AutoRun"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h32 BackgroundTrans Wrap",
            "Start the next picker loop from Travel or the mission-report prompt."))
        autoRunVal := this.settingsManager.GetBool("autoRunOnTravelConfirmation", false) ? 1 : 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setAutoRunOnTravel := this.PageAdd(3, g.Add("Checkbox",
            "x" (col1 + halfW - 16 - 110) " y" (y + 24) " w110 h22 Checked" autoRunVal, "Enabled"))
        this.setAutoRunOnTravel.Value := autoRunVal
        this.setAutoRunOnTravel.OnEvent("Click", (*) => this.OnAutoRunOnTravelChange())

        this.PageAdd(3, g.Add("Text", "x" col2 " y" y " w" halfW " h" autoRunH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Debug logging"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h32 BackgroundTrans Wrap",
            "Verbose OCR and scenario messages in Logs."))
        rawDebug := this.settingsManager.Get("debugMode", false)
        debugVal := (rawDebug == true || rawDebug == 1 || rawDebug == "1" || rawDebug == "true") ? 1 : 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setDebugMode := this.PageAdd(3, g.Add("Checkbox",
            "x" (col2 + halfW - 16 - 110) " y" (y + 24) " w110 h22 Checked" debugVal, "Enabled"))
        this.setDebugMode.Value := debugVal
        this.setDebugMode.OnEvent("Click", (*) => this.OnDebugModeChange())
        y += autoRunH + 12

        ; Keybinds (2×3) | Database
        dbW := 200
        bindsW := cardW - dbW - colGap
        bindsX := m
        dbX := m + bindsW + colGap
        keybindH := 128
        this.PageAdd(3, g.Add("Text", "x" bindsX " y" y " w" bindsW " h" keybindH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (bindsX + 16) " y" (y + 8) " w180 h18 BackgroundTrans", "Keybinds"))
        this.AddTextButton(3, bindsX + bindsW - 16 - 64, y + 6, 64, 24, "Reset", (*) => this.OnResetKeybinds())
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (bindsX + 16) " y" (y + 28) " w" (bindsW - 32) " h14 BackgroundTrans",
            "Click a bind, then press a key. Esc cancels."))

        bindDefs := [
            { setting: "hotkeyStart", label: "Start", fallback: "Home", prop: "setHotkeyStart" },
            { setting: "hotkeyStop", label: "Stop", fallback: "End", prop: "setHotkeyStop" },
            { setting: "hotkeyToggleAutoRun", label: "AutoRun", fallback: "Delete", prop: "setHotkeyAutoRun" },
            { setting: "hotkeyToggleGui", label: "Dashboard", fallback: "F8", prop: "setHotkeyToggle" },
            { setting: "hotkeyToggleOverlay", label: "Overlay", fallback: "Insert", prop: "setHotkeyOverlay" },
            { setting: "hotkeyExit", label: "Exit", fallback: "Pause", prop: "setHotkeyExit" }
        ]
        bindInnerGap := 16
        bindColW := (bindsW - 32 - bindInnerGap) // 2
        bindBtnW := 108
        bindLabelW := bindColW - bindBtnW - 8
        loop bindDefs.Length {
            def := bindDefs[A_Index]
            col := (A_Index <= 3) ? 0 : 1
            row := Mod(A_Index - 1, 3)
            colX := bindsX + 16 + col * (bindColW + bindInnerGap)
            rowY := y + 48 + row * 24
            g.SetFont("s9 cA1A1AA", "Segoe UI")
            this.PageAdd(3, g.Add("Text", "x" colX " y" rowY " w" bindLabelW " h20 BackgroundTrans", def.label))
            keyName := this.settingsManager.Get(def.setting, def.fallback)
            btn := this.AddTextButton(3, colX + bindLabelW + 4, rowY, bindBtnW, 22,
                this.FormatHotkeyName(keyName), this.MakeHotkeyCaptureHandler(def.setting))
            this.%def.prop% := btn
        }

        this.PageAdd(3, g.Add("Text", "x" dbX " y" y " w" dbW " h" keybindH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (dbX + 16) " y" (y + 10) " w" (dbW - 32) " h18 BackgroundTrans", "Database"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (dbX + 16) " y" (y + 32) " w" (dbW - 32) " h36 BackgroundTrans Wrap",
            "Loaded Landsraad houses and missions."))
        houseCount := IsObject(this.stateManager) ? this.stateManager.allHousesList.Length : 0
        missionCount := IsObject(this.stateManager) ? this.stateManager.allMissionsList.Length : 0
        g.SetFont("s11 bold cEAB308", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" (dbX + 16) " y" (y + 78) " w" (dbW - 32) " h36 BackgroundTrans Wrap",
            houseCount " houses`n" missionCount " missions"))
    }

    MakeHotkeyCaptureHandler(settingKey) {
        return (*) => this.CaptureHotkey(settingKey)
    }

    OnOcrLangChange() {
        if (this.isInitializing || !IsObject(this.setOcrLang))
            return

        curLang := Trim(this.setOcrLang.Value)
        if (curLang == "")
            curLang := "en-US"

        this.settingsManager.Set("ocrLanguage", curLang)
        this.ShowSessionHint()
    }

    OnCharacterNameCommit() {
        if (this.isInitializing || !IsObject(this.setCharacterName) || !IsObject(this.profileManager))
            return

        newName := Trim(this.setCharacterName.Value)
        currentName := this.profileManager.GetCurrentName()
        if (newName == "") {
            this.setCharacterName.Value := currentName
            return
        }
        if (StrLower(newName) == StrLower(currentName)) {
            this.setCharacterName.Value := currentName
            return
        }

        if !this.profileManager.RenameCurrent(newName, this.settingsManager) {
            this.setCharacterName.Value := currentName
            this.SetStatus("That character name is already used by another profile.")
            return
        }

        this.RefreshProfileDropdown(false)
        this.RefreshStatusOverlay()
        this.ShowSessionHint()
    }

    OnProfileChange() {
        if (this.isInitializing || !IsObject(this.setProfile) || !IsObject(this.profileManager))
            return

        chosenIdx := this.setProfile.Value
        if (chosenIdx == this.profileManager.GetCurrentIndex())
            return

        this.SaveMissionSelections()
        if !this.profileManager.SwitchToIndex(chosenIdx, this.stateManager, this.settingsManager) {
            this.RefreshProfileDropdown()
            this.SetStatus("Could not switch profile.")
            return
        }

        this.ApplyLoadedProfileToUi()
        this.SetStatus("Switched to " this.profileManager.GetCurrentName() ".")
    }

    OnNewProfile() {
        if (this.isInitializing || !IsObject(this.profileManager))
            return

        result := InputBox("Enter a character name for the new profile.", "New profile", "w360 h140", "")
        if (result.Result != "OK")
            return

        newName := Trim(result.Value)
        if (newName == "") {
            this.SetStatus("Character name cannot be empty.")
            return
        }

        this.SaveMissionSelections()
        if !this.profileManager.CreateProfile(newName, this.stateManager, this.settingsManager) {
            this.SetStatus("A profile with that name already exists.")
            return
        }

        this.ApplyLoadedProfileToUi()
        this.SetStatus("Created profile " this.profileManager.GetCurrentName() ".")
    }

    OnResetProfile() {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return
        this.settingsManager.ResetBasicSettings()
        this.RefreshSettingsControls()
        this.ShowSessionHint()
        this.Log("Settings reset to defaults. Stats were left unchanged.")
        this.SetStatus("Settings reset.")
    }

    OnResetKeybinds() {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return
        this.settingsManager.ResetHotkeys()
        ApplyAppHotkeys()
        this.RefreshHotkeyDisplay()
        this.ShowSessionHint()
        this.Log("Keybinds reset to Home, End, Delete, F8, Insert, and Pause.")
    }

    RefreshSettingsControls() {
        wasInit := this.isInitializing
        this.isInitializing := true

        if IsObject(this.setCharacterName)
            this.setCharacterName.Value := this.settingsManager.Get("characterName", "player")
        if IsObject(this.setGuildName)
            this.setGuildName.Value := this.settingsManager.Get("guildName", "wowza")
        if IsObject(this.setFaction) {
            faction := this.settingsManager.Get("faction", "Atreides")
            if (faction = "Harkonnen")
                this.setFaction.Choose(2)
            else
                this.setFaction.Choose(1)
        }
        if IsObject(this.setDebugMode) {
            debugOn := this.settingsManager.GetBool("debugMode", false)
            this.setDebugMode.Value := debugOn ? 1 : 0
            if IsObject(this.logger)
                this.logger.SetDebug(debugOn)
        }
        if IsObject(this.setAutoRunOnTravel)
            this.setAutoRunOnTravel.Value := this.settingsManager.GetBool("autoRunOnTravelConfirmation", false) ? 1 : 0
        if IsObject(this.setShowOverlay) {
            showOverlay := this.settingsManager.GetBool("showOverlay", true)
            this.setShowOverlay.Value := showOverlay ? 1 : 0
            StatusBar.ApplyVisibility(showOverlay)
        }
        if IsObject(this.setShowNotifications)
            this.setShowNotifications.Value := this.settingsManager.GetBool("overlayShowNotifications", true) ? 1 : 0
        if IsObject(this.overlaySectionChecks) {
            for keyName, box in this.overlaySectionChecks {
                if IsObject(box)
                    box.Value := this.settingsManager.GetBool(keyName, true) ? 1 : 0
            }
            StatusBar.RebuildLayout()
        }
        if IsObject(this.setActionDelay)
            this.setActionDelay.Choose(this.GetActionDelayIndex())
        if IsObject(this.setOverlayPosition)
            this.setOverlayPosition.Choose(this.GetOverlayPositionIndex())

        this.RefreshProfileDropdown()
        this.RefreshStatsDisplay()
        this.RefreshStatusOverlay()
        RefreshTrayAutoRunCheck()
        this.isInitializing := wasInit
    }

    RefreshStatsDisplay() {
        if IsObject(this.statsTab)
            this.statsTab.Refresh()
    }

    RefreshProfileDropdown(updateNameEdit := true) {
        if !IsObject(this.setProfile) || !IsObject(this.profileManager)
            return

        wasInit := this.isInitializing
        this.isInitializing := true
        names := this.profileManager.GetProfileNames()
        this.setProfile.Delete()
        if (names.Length > 0)
            this.setProfile.Add(names)
        this.setProfile.Choose(this.profileManager.GetCurrentIndex())
        if (updateNameEdit && IsObject(this.setCharacterName))
            this.setCharacterName.Value := this.profileManager.GetCurrentName()
        this.isInitializing := wasInit
    }

    ApplyLoadedProfileToUi() {
        this.activeSlotIdx := 0
        this.RestoreMissionSelections()
        if IsObject(this.panelLabel)
            this.panelLabel.Text := "Select a house cell to assign missions"
        loop 3 {
            if (this.mRow.Length < A_Index)
                continue
            row := this.mRow[A_Index]
            row.ddl.Delete()
            row.ddl.Choose(0)
            row.ddl.Opt("+Disabled")
            row.clearEnabled := false
            this.SetTextButtonState(row.clearBtn, false)
        }
        this.RefreshProfileDropdown()
        this.RefreshStatsDisplay()
        if IsObject(this.userState)
            this.userState.ResetSession()
        TravelAutoRun.Sync()

        global acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst
        if IsSet(acceptMissionsScenarioInst) && IsObject(acceptMissionsScenarioInst) && acceptMissionsScenarioInst.HasMethod("ResetSession")
            acceptMissionsScenarioInst.ResetSession()
        if IsSet(acceptTargettedMissionsScenarioInst) && IsObject(acceptTargettedMissionsScenarioInst) && acceptTargettedMissionsScenarioInst.HasMethod("ResetSession")
            acceptTargettedMissionsScenarioInst.ResetSession()
        StatusBar.RestoreIdle()

        this.RefreshStatusOverlay()
        this.ShowSessionHint()
    }

    OnGuildNameCommit() {
        if (this.isInitializing || !IsObject(this.setGuildName))
            return

        savedGuild := Trim(this.settingsManager.Get("guildName", "wowza"))
        curGuild := Trim(this.setGuildName.Value)
        if (StrLen(curGuild) > 25)
            curGuild := SubStr(curGuild, 1, 25)

        if (StrLen(curGuild) < 3) {
            this.setGuildName.Value := savedGuild
            this.SetStatus("Guild name must be 3-25 characters.")
            return
        }

        this.setGuildName.Value := curGuild
        if (curGuild == savedGuild)
            return

        this.settingsManager.Set("guildName", curGuild)
        this.ShowSessionHint()
    }

    OnFactionChange() {
        if (this.isInitializing || !IsObject(this.setFaction))
            return

        chosen := this.setFaction.Text
        if (chosen != "Atreides" && chosen != "Harkonnen")
            chosen := "Atreides"

        this.settingsManager.Set("faction", chosen)
        this.ShowSessionHint()
    }

    OnDebugModeChange() {
        if (this.isInitializing || !IsObject(this.setDebugMode))
            return

        debugEnabled := (this.setDebugMode.Value == 1)
        this.settingsManager.Set("debugMode", debugEnabled)

        if (IsObject(this.logger))
            this.logger.SetDebug(debugEnabled)

        this.ShowSessionHint()
    }

    OnAutoRunOnTravelChange() {
        if (this.isInitializing || !IsObject(this.setAutoRunOnTravel))
            return
        ToggleAutoRunSetting(this.setAutoRunOnTravel.Value == 1)
        this.ShowSessionHint()
    }

    OnShowOverlayChange() {
        if (this.isInitializing || !IsObject(this.setShowOverlay))
            return

        showOverlay := (this.setShowOverlay.Value == 1)
        this.settingsManager.Set("showOverlay", showOverlay)

        StatusBar.ApplyVisibility(showOverlay)

        this.ShowSessionHint()
    }

    OnShowNotificationsChange() {
        if (this.isInitializing || !IsObject(this.setShowNotifications))
            return
        enabled := (this.setShowNotifications.Value == 1)
        this.settingsManager.Set("overlayShowNotifications", enabled)
        if !enabled {
            overlay := StatusBar.overlay
            if IsObject(overlay) && overlay.HasMethod("HideSplash")
                overlay.HideSplash()
        }
        this.ShowSessionHint()
    }

    SyncOverlayEnabledCheckbox() {
        if !IsObject(this.setShowOverlay) || !IsObject(this.settingsManager)
            return
        wasInit := this.isInitializing
        this.isInitializing := true
        this.setShowOverlay.Value := this.settingsManager.GetBool("showOverlay", true) ? 1 : 0
        this.isInitializing := wasInit
    }

    MakeOverlaySectionHandler(settingKey) {
        return (*) => this.OnOverlaySectionChange(settingKey)
    }

    OnOverlaySectionChange(settingKey) {
        if (this.isInitializing || !IsObject(this.overlaySectionChecks) || !this.overlaySectionChecks.Has(settingKey))
            return
        enabled := (this.overlaySectionChecks[settingKey].Value == 1)
        this.settingsManager.Set(settingKey, enabled)
        StatusBar.RebuildLayout()
        this.ShowSessionHint()
    }

    GetOverlayPositionKeys() {
        return ["topLeft", "topMiddle", "bottomLeft", "topRight", "bottomRight"]
    }

    GetOverlayPositionLabels() {
        return ["Top left", "Top middle", "Bottom left", "Top right", "Bottom right"]
    }

    GetOverlayPositionIndex() {
        current := "topLeft"
        if IsObject(this.settingsManager)
            current := this.settingsManager.Get("overlayPosition", "topLeft")
        keys := this.GetOverlayPositionKeys()
        loop keys.Length {
            if (keys[A_Index] == current)
                return A_Index
        }
        return 1
    }

    OnOverlayPositionChange() {
        if (this.isInitializing || !IsObject(this.setOverlayPosition))
            return
        keys := this.GetOverlayPositionKeys()
        idx := this.setOverlayPosition.Value
        posKey := "topLeft"
        if (idx >= 1 && idx <= keys.Length)
            posKey := keys[idx]
        this.settingsManager.Set("overlayPosition", posKey)
        StatusBar.RebuildLayout()
        this.ShowSessionHint()
    }

    GetActionDelayValues() {
        return [40, 50, 75, 100, 200, 300]
    }

    GetActionDelayLabels() {
        labels := []
        for _, ms in this.GetActionDelayValues()
            labels.Push(ms " ms")
        return labels
    }

    GetActionDelayIndex() {
        current := 100
        if IsObject(this.settingsManager)
            current := this.settingsManager.GetInt("actionDelay", 100)
        values := this.GetActionDelayValues()
        loop values.Length {
            if (values[A_Index] == current)
                return A_Index
        }
        return 4
    }

    OnActionDelayChange() {
        if (this.isInitializing || !IsObject(this.setActionDelay))
            return

        values := this.GetActionDelayValues()
        idx := this.setActionDelay.Value
        delayMs := 100
        if (idx >= 1 && idx <= values.Length)
            delayMs := values[idx]
        this.settingsManager.Set("actionDelay", delayMs)
        this.ShowSessionHint()
    }

    FormatHotkeyName(hotkey) {
        raw := Trim(hotkey)
        if (raw == "")
            return ""
        mods := ""
        key := raw
        loop {
            first := SubStr(key, 1, 1)
            if (first == "^") {
                mods .= "Ctrl+"
                key := SubStr(key, 2)
            } else if (first == "!") {
                mods .= "Alt+"
                key := SubStr(key, 2)
            } else if (first == "+") {
                mods .= "Shift+"
                key := SubStr(key, 2)
            } else if (first == "#") {
                mods .= "Win+"
                key := SubStr(key, 2)
            } else
                break
        }
        if (key == "")
            return Trim(raw)
        return mods . key
    }

    RefreshHotkeyDisplay() {
        fallbacks := this.settingsManager.GetHotkeyFallbacks()
        if IsObject(this.setHotkeyStart)
            this.setHotkeyStart.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyStart", fallbacks["hotkeyStart"]))
        if IsObject(this.setHotkeyStop)
            this.setHotkeyStop.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyStop", fallbacks["hotkeyStop"]))
        if IsObject(this.setHotkeyAutoRun)
            this.setHotkeyAutoRun.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyToggleAutoRun", fallbacks["hotkeyToggleAutoRun"]))
        if IsObject(this.setHotkeyToggle)
            this.setHotkeyToggle.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyToggleGui", fallbacks["hotkeyToggleGui"]))
        if IsObject(this.setHotkeyOverlay)
            this.setHotkeyOverlay.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyToggleOverlay", fallbacks["hotkeyToggleOverlay"]))
        if IsObject(this.setHotkeyExit)
            this.setHotkeyExit.Text := this.FormatHotkeyName(this.settingsManager.Get("hotkeyExit", fallbacks["hotkeyExit"]))
        this.RefreshHeaderHotkeys()
        StatusBar.Refresh()
    }

    GetHotkeyFallback(settingKey) {
        fallbacks := this.settingsManager.GetHotkeyFallbacks()
        if fallbacks.Has(settingKey)
            return fallbacks[settingKey]
        return "Pause"
    }

    GetHotkeyButton(settingKey) {
        if (settingKey == "hotkeyStart")
            return this.setHotkeyStart
        if (settingKey == "hotkeyStop")
            return this.setHotkeyStop
        if (settingKey == "hotkeyToggleAutoRun")
            return this.setHotkeyAutoRun
        if (settingKey == "hotkeyToggleGui")
            return this.setHotkeyToggle
        if (settingKey == "hotkeyToggleOverlay")
            return this.setHotkeyOverlay
        return this.setHotkeyExit
    }

    GetOtherHotkeyValues(settingKey) {
        keys := []
        fallbacks := this.settingsManager.GetHotkeyFallbacks()
        for _, key in this.settingsManager.GetHotkeySettingKeys() {
            if (key == settingKey)
                continue
            keys.Push(this.settingsManager.Get(key, fallbacks[key]))
        }
        return keys
    }

    CaptureHotkey(settingKey) {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return

        otherKeys := this.GetOtherHotkeyValues(settingKey)
        targetBtn := this.GetHotkeyButton(settingKey)
        if IsObject(targetBtn)
            targetBtn.Text := "Press a key…"

        this.SetStatus("Press a key to rebind. Esc cancels.")

        SuspendAppHotkeys()

        ih := InputHook("T12")
        ih.KeyOpt("{All}", "E")
        ih.KeyOpt("{LControl}{RControl}{LAlt}{RAlt}{LShift}{RShift}{LWin}{RWin}", "-E")
        ih.Start()
        ih.Wait()

        newKey := ""
        if (ih.EndReason == "EndKey" && ih.EndKey != "" && ih.EndKey != "Escape")
            newKey := ih.EndMods . ih.EndKey

        if (newKey == "") {
            ApplyAppHotkeys()
            this.RefreshHotkeyDisplay()
            this.SetStatus("Keybind unchanged.")
            return
        }

        for _, otherKey in otherKeys {
            if (StrLower(newKey) == StrLower(otherKey)) {
                ApplyAppHotkeys()
                this.RefreshHotkeyDisplay()
                this.SetStatus("That key is already used by another action.")
                return
            }
        }

        this.settingsManager.Set(settingKey, newKey)
        if !ApplyAppHotkeys() {
            this.settingsManager.Set(settingKey, this.GetHotkeyFallback(settingKey))
            ApplyAppHotkeys()
            this.RefreshHotkeyDisplay()
            this.SetStatus("That key cannot be used. Reverted.")
            return
        }

        this.RefreshHotkeyDisplay()
        this.ShowSessionHint()
    }
}
