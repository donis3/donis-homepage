#Requires AutoHotkey v2.0+

/**
 * Locates the Dune: Awakening client. ImageSearch, OCR, and clicks use the
 * client rectangle (not the monitor), so windowed 1080p on a larger display works.
 */
class GameWindow {
    static titles := [
        "ahk_exe Dune-Win64-Shipping.exe",
        "ahk_exe Dune.exe",
        "Dune: Awakening",
        "Dune"
    ]

    static FindTitle() {
        for _, winTitle in this.titles {
            if WinExist(winTitle)
                return winTitle
        }
        return ""
    }

    static GetHwnd() {
        title := this.FindTitle()
        if (title == "")
            return 0
        return WinExist(title)
    }

    /**
     * Client area in screen pixels (excludes title bar and borders).
     */
    static GetClient() {
        hwnd := this.GetHwnd()
        if !hwnd
            return ""
        x := 0, y := 0, w := 0, h := 0
        try {
            WinGetClientPos(&x, &y, &w, &h, hwnd)
        } catch {
            return ""
        }
        if (w < 2 || h < 2)
            return ""
        return {
            hwnd: hwnd,
            x: x,
            y: y,
            w: w,
            h: h
        }
    }

    static Activate() {
        title := this.FindTitle()
        if (title == "")
            return false
        try {
            WinActivate(title)
            WinWaitActive(title, , 2)
            Sleep(100)
            return true
        }
        return false
    }

    /**
     * True when the Dune client exists and is the foreground window.
     */
    static IsActive() {
        hwnd := this.GetHwnd()
        if !hwnd
            return false
        try {
            return (WinGetID("A") == hwnd)
        } catch {
            return false
        }
    }
}
