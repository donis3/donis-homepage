#Requires AutoHotkey v2.0+

/**
 * When AutoRun is enabled and a play timer is running, poll the Travel
 * confirmation window with ImageSearch. 1000ms is enough: the dialog stays
 * until dismissed, and a cropped ImageSearch is a few milliseconds.
 */
class TravelAutoRun {
    static intervalMs := 1000
    static boundTick := ""
    static busy := false
    static suppressed := false
    static leftoverDismissUntil := 0
    static leftoverDismissMs := 10000
    static leftoverReadyAfter := 0
    static leftoverReadyDelayMs := 800
    static leftoverConfirmMs := 450
    static leftoverSettleMs := 1000
    static leftoverDismissCount := 0
    static leftoverWindowEndedLogged := false

    static Start() {
        if (this.boundTick != "")
            return
        this.boundTick := ObjBindMethod(this, "Tick")
        SetTimer(this.boundTick, this.intervalMs)
    }

    static Stop() {
        if (this.boundTick != "") {
            try SetTimer(this.boundTick, 0)
        }
        this.boundTick := ""
    }

    static IsActive() {
        return this.busy || (this.boundTick != "")
    }

    static IsSuppressed() {
        return this.suppressed
    }

    static Suppress() {
        this.suppressed := true
        this.Stop()
        StatusBar.Refresh()
    }

    static ClearSuppress() {
        if !this.suppressed
            return
        this.suppressed := false
        this.Sync()
    }

    static Sync() {
        if this.ShouldWatch()
            this.Start()
        else
            this.Stop()
        StatusBar.Refresh()
    }

    static ShouldWatch() {
        global settingsManagerInst, userStateInst, stateManagerInst
        if this.busy
            return false
        if this.suppressed
            return false
        if !IsSet(settingsManagerInst) || !IsObject(settingsManagerInst)
            return false
        autoRunOn := settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false)
        leftoverWatch := this.IsLeftoverDismissWindow()
            || (this.leftoverReadyAfter > 0 && A_TickCount < this.leftoverReadyAfter)
        if !autoRunOn && !leftoverWatch
            return false
        if !IsSet(userStateInst) || !IsObject(userStateInst)
            return false
        if userStateInst.IsRunActive()
            return false
        if !userStateInst.IsInitialized() || userStateInst.IsFirstHome()
            return false
        if !IsSet(stateManagerInst) || !IsObject(stateManagerInst)
            return false
        if !stateManagerInst.HasMethod("HasActiveRunTimer")
            return false
        return stateManagerInst.HasActiveRunTimer()
    }

    static ArmLeftoverDismiss() {
        this.leftoverReadyAfter := A_TickCount + this.leftoverReadyDelayMs
        this.leftoverDismissUntil := this.leftoverReadyAfter + this.leftoverDismissMs
        this.leftoverDismissCount := 0
        this.leftoverWindowEndedLogged := false
        this.Debug("Armed leftover View mission report? watch for "
            Integer(this.leftoverDismissMs / 1000) " seconds after ready (starts in "
            Integer(this.leftoverReadyDelayMs) " ms). Each leftover will be confirmed before Enter.")
    }

    static QuietMissionCompleteFor(ms := "") {
        this.ArmLeftoverDismiss()
    }

    static IsLeftoverDismissWindow() {
        return (this.leftoverDismissUntil > 0
            && A_TickCount >= this.leftoverReadyAfter
            && A_TickCount < this.leftoverDismissUntil)
    }

    static IsMissionCompleteQuiet() {
        return this.IsLeftoverDismissWindow()
            || (this.leftoverReadyAfter > 0 && A_TickCount < this.leftoverReadyAfter)
    }

    static MaybeLogLeftoverWindowEnded() {
        if this.leftoverWindowEndedLogged
            return
        if (this.leftoverDismissUntil <= 0 || A_TickCount < this.leftoverDismissUntil)
            return
        this.leftoverWindowEndedLogged := true
        this.leftoverDismissUntil := 0
        if (this.leftoverDismissCount > 0)
            this.Debug("Leftover watch ended. Dismissed " this.leftoverDismissCount " leftover report(s). Mission-complete watch is active.")
        else
            this.Debug("No leftover View mission report? in the first 10 seconds. Mission-complete watch is active.")
    }

    static ReportIsVisible() {
        global masterScenarioInst
        return (IsSet(masterScenarioInst) && IsObject(masterScenarioInst)
            && masterScenarioInst.HasMethod("IsMissionCompleteIndicatorVisible")
            && masterScenarioInst.IsMissionCompleteIndicatorVisible())
    }

    static Tick() {
        if !this.ShouldWatch() {
            this.Stop()
            return
        }

        ; Screen capture sees whatever is on top. Alt-tabbed / covered game must not poll.
        if !GameWindow.IsActive()
            return

        global masterScenarioInst, settingsManagerInst
        if !IsSet(masterScenarioInst) || !IsObject(masterScenarioInst)
            return

        autoRunOn := (IsSet(settingsManagerInst) && IsObject(settingsManagerInst)
            && settingsManagerInst.GetBool("autoRunOnTravelConfirmation", false))

        travelVisible := false
        if autoRunOn {
            travelVisible := (masterScenarioInst.HasMethod("IsTravelConfirmationVisible")
                && masterScenarioInst.IsTravelConfirmationVisible())
        }
        if travelVisible {
            this.StartPickerFromPrompt("Travel confirmation")
            return
        }

        if (this.leftoverReadyAfter > 0 && A_TickCount < this.leftoverReadyAfter)
            return

        reportVisible := this.ReportIsVisible()

        if this.IsLeftoverDismissWindow() {
            if reportVisible
                this.DismissLeftoverMissionReport()
            return
        }

        this.MaybeLogLeftoverWindowEnded()

        if !autoRunOn
            return

        if !reportVisible
            return

        this.StartPickerFromPrompt("Mission complete prompt")
    }

    /**
     * Confirm the leftover HUD is still there after a short wait, then Enter.
     * Skip Enter if it vanished — a false send opens chat and breaks the loop.
     * Stacked leftovers (multiple finished missions) are dismissed one by one
     * until the leftover window ends.
     */
    static DismissLeftoverMissionReport() {
        this.busy := true
        this.Stop()
        try {
            this.Debug("Possible leftover View mission report? Waiting "
                this.leftoverConfirmMs " ms to confirm before Enter.")
            Sleep(this.leftoverConfirmMs)

            if !GameWindow.IsActive() {
                this.Debug("Game is not focused after confirm wait. Skipping Enter so chat does not open.")
                return
            }
            if !this.ReportIsVisible() {
                this.Debug("Leftover icon was gone on confirm. Skipping Enter so chat does not open.")
                return
            }

            GameWindow.Activate()
            this.Debug("Leftover View mission report? confirmed. Sending Enter.")
            InputHelper.SendGameKey("Enter")
            this.Debug("Waiting 1 second for the leftover icon to clear.")
            Sleep(this.leftoverSettleMs)

            if this.ReportIsVisible() {
                this.Debug("Icon still visible after the 1 second wait. Will confirm again before the next Enter.")
                return
            }

            this.leftoverDismissCount += 1
            this.Debug("Leftover prompt closed after Enter (" this.leftoverDismissCount " dismissed). Watching for more leftovers until the window ends.")
        } catch as err {
            this.Debug("Failed to dismiss leftover View mission report?: " err.Message)
        } finally {
            this.busy := false
            this.Sync()
        }
    }

    static StartPickerFromPrompt(reason) {
        global loggerInst
        this.busy := true
        this.Stop()
        try {
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(reason " detected. AutoRun starting the picker.")
            StatusBar.SetStatus("AutoRun", "working")
            StartPickerRun()
        } finally {
            this.busy := false
            this.Sync()
        }
    }

    static Debug(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
            loggerInst.Debug("[TravelAutoRun] " message)
    }
}
