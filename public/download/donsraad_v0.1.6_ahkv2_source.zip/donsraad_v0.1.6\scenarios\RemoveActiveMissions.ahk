#Requires AutoHotkey v2.0+

/**
 * Remove Active Missions Scenario
 * Disbands the current guild (clearing all accepted missions), recreates it with the
 * configured guild name, then re-aligns to the player's faction on the Landsraad grid.
 *
 * Callable from any scenario via removeActiveMissionsScenarioInst.Execute().
 *
 * Flow:
 * 1. Confirm the Guilds tab (guilds_button.png). Press O only if it is missing.
 * 2. Wait for guild_disband.png, then disband (click + confirm).
 * 3. Poll create_guild.png in CreateGuildButton.
 * 5. Press Enter to open the create-guild form (name field focused).
 * 6. Ctrl+Backspace to clear any existing name, then type settings.guildName.
 * 7. Press Enter to submit the form, then Space to confirm (server round-trip).
 * 8. Poll guild_disband.png in GuildDisbandingButton for up to 10s.
 *    Fail and stop if the button never appears.
 * 9. Press L to open the Landsraad / mission tab.
 * 10. Click LandsraadSubGridTabButton, then the faction Align Guild button, then Space.
 */
class RemoveActiveMissionsScenario {
    settingsManager := ""
    logger := ""
    anchorMatcher := ""
    stateManager := ""
    imageVariation := 30

    __New(settingsManagerInst := "", loggerInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.settingsManager := settingsManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.stateManager := stateManagerInst
    }

    EnsureGameActive() {
        return GameWindow.Activate()
    }

    /**
     * @param {Integer} abandonedCount - Active missions dropped by this disband. -1 reads player state.
     * @returns {Boolean} - True if guild was recreated and faction aligned, false on error.
     */
    Execute(abandonedCount := -1) {
        this.Debug("[RemoveActiveMissions] Starting scenario...")
        this.EnsureGameActive()

        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") {
            this.Log("[RemoveActiveMissions] Error: GameConstants GameUI is missing.")
            return false
        }
        uiConfig := GameConstants["GameUI"]

        guildName := this.GetGuildName()
        faction := this.GetFaction()
        this.Debug("[RemoveActiveMissions] Guild=`"" guildName "`" Faction=" faction)

        if !this.EnsureGuildsTab(uiConfig)
            return false

        if !this.DisbandExistingGuild(uiConfig)
            return false

        ; 5. Open create-guild form
        InputHelper.SendGameKey("Enter")

        ; 6. Clear name and type configured guild name
        InputHelper.SendGameModifierKey("Ctrl", "Backspace")
        InputHelper.SendGameModifierKey("Ctrl", "Backspace")
        InputHelper.SendGameText(guildName)

        ; 7. Submit form, then confirm (server waits after this)
        InputHelper.SendGameKey("Enter")
        this.Debug("[RemoveActiveMissions] Confirming guild create (Space). Waiting for server...")
        InputHelper.SendGameKey("Space")
        InputHelper.MoveCursorClearOfSearch()

        ; 8. Confirm server success via guild_disband.png in GuildDisbandingButton
        if !this.WaitForUiImage(uiConfig, "GuildDisbandingButton", "guild_disband.png", 10000) {
            this.Log("[RemoveActiveMissions] Error: Guild disband button was not confirmed within 10 seconds. Stopping.")
            return false
        }
        this.Debug("[RemoveActiveMissions] Guild recreate confirmed.")

        if !this.OpenLandsraadHouseGrid(uiConfig)
            return false

        alignRegionKey := (StrLower(faction) == "harkonnen")
            ? "AlignGuildHarkonnenButton"
            : "AlignGuildAtreidesButton"
        alignClickKey := (StrLower(faction) == "harkonnen")
            ? "AlignGuildHarkonnenButtonClickCoords"
            : "AlignGuildAtreidesButtonClickCoords"

        if !this.WaitForUiImage(uiConfig, alignRegionKey, "align_guild.png", 5000) {
            this.Log("[RemoveActiveMissions] Error: Align Guild button did not appear on the Landsraad grid. Stopping.")
            return false
        }

        if !this.ClickUiPoint(uiConfig, alignClickKey, "Align Guild (" faction ")")
            return false

        InputHelper.SendGameKey("Space")

        this.Debug("[RemoveActiveMissions] Completed. Guild aligned to " faction ".")
        this.RecordGuildAbandon(abandonedCount)
        return true
    }

    RecordGuildAbandon(abandonedCount := -1) {
        count := Integer(abandonedCount)
        if (count < 0)
            count := this.GetActiveMissionCount()
        if (count < 1)
            return
        this.Debug("[RemoveActiveMissions] Counting " count " abandoned mission(s).")
        if IsObject(this.stateManager) && this.stateManager.HasMethod("IncrementGuildAbandons")
            this.stateManager.IncrementGuildAbandons(count)
        else {
            global stateManagerInst
            if IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.HasMethod("IncrementGuildAbandons")
                stateManagerInst.IncrementGuildAbandons(count)
        }
    }

    GetActiveMissionCount() {
        sm := this.stateManager
        if !IsObject(sm) {
            global stateManagerInst
            if IsSet(stateManagerInst) && IsObject(stateManagerInst)
                sm := stateManagerInst
        }
        if !IsObject(sm) || !sm.HasMethod("GetActiveMissions")
            return 0
        active := sm.GetActiveMissions()
        if (active is Array)
            return active.Length
        return 0
    }

    GetGuildName() {
        if (IsObject(this.settingsManager))
            return this.settingsManager.Get("guildName", "wowza")
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("guildName", "wowza")
        return "wowza"
    }

    GetFaction() {
        faction := "Atreides"
        if (IsObject(this.settingsManager))
            faction := this.settingsManager.Get("faction", "Atreides")
        else {
            global settingsManagerInst
            if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
                faction := settingsManagerInst.Get("faction", "Atreides")
        }
        if (StrLower(faction) != "harkonnen")
            faction := "Atreides"
        return faction
    }

    DisbandExistingGuild(uiConfig) {
        this.Debug("[RemoveActiveMissions] Waiting for Disband Guild button...")
        if !this.WaitForUiImage(uiConfig, "GuildDisbandingButton", "guild_disband.png", 2000) {
            this.Log("[RemoveActiveMissions] Error: Disband Guild button did not appear. Stopping.")
            return false
        }

        loop 3 {
            if this.IsCancelled()
                return false
            this.Debug("[RemoveActiveMissions] Disband attempt " A_Index "...")
            if !this.ClickUiPoint(uiConfig, "GuildDisbandingButtonClickCoords", "disband button")
                return false

            InputHelper.SendGameKey("Space")
            userDelay(80)
            InputHelper.SendGameKey("Space")
            if this.WaitForUiImage(uiConfig, "CreateGuildButton", "create_guild.png", 2500) {
                this.Debug("[RemoveActiveMissions] Create guild button confirmed.")
                return true
            }
        }

        this.Log("[RemoveActiveMissions] Error: Create guild button did not appear after disband. Stopping.")
        return false
    }

    OpenLandsraadHouseGrid(uiConfig) {
        if !this.EnsureLandsraadTab(uiConfig)
            return false
        if !this.ClickUiPoint(uiConfig, "LandsraadSubGridTabButton", "Landsraad grid sub-tab")
            return false
        return true
    }

    EnsureGuildsTab(uiConfig) {
        if this.IsUiImageVisible(uiConfig, "GuildsTabButton", "guilds_button.png") {
            this.Debug("[RemoveActiveMissions] Guilds tab already visible.")
            return true
        }

        loop 3 {
            this.Debug("[RemoveActiveMissions] Opening Guilds tab (O), attempt " A_Index "...")
            InputHelper.SendGameKey("o")
            if this.WaitForUiImage(uiConfig, "GuildsTabButton", "guilds_button.png", 1500)
                return true
        }

        this.Log("[RemoveActiveMissions] Error: Guilds tab did not open. Stopping.")
        return false
    }

    EnsureLandsraadTab(uiConfig) {
        if this.IsUiImageVisible(uiConfig, "LandsraadTabButton", "landsraad_button.png") {
            this.Debug("[RemoveActiveMissions] Landsraad tab already visible.")
            return true
        }

        loop 3 {
            this.Debug("[RemoveActiveMissions] Opening Landsraad tab (L), attempt " A_Index "...")
            InputHelper.SendGameKey("l")
            if this.WaitForUiImage(uiConfig, "LandsraadTabButton", "landsraad_button.png", 1500)
                return true
        }

        this.Log("[RemoveActiveMissions] Error: Landsraad tab did not open after guild create. Stopping.")
        return false
    }

    ClickUiPoint(uiConfig, keyName, label) {
        if !uiConfig.Has(keyName) {
            this.Log("[RemoveActiveMissions] Error: " keyName " missing in GameConstants.")
            return false
        }
        cfg := uiConfig[keyName]
        pos := ResolutionManager().coords(cfg.x, cfg.y)
        this.Debug("[RemoveActiveMissions] Clicking " label " at (" pos.x ", " pos.y ")...")
        InputHelper.FastClick(pos.x, pos.y)
        return true
    }

    /**
     * One ImageSearch in a GameConstants region. Returns immediately.
     */
    IsUiImageVisible(uiConfig, regionKey, imageName) {
        foundX := 0, foundY := 0
        return this.FindUiImage(uiConfig, regionKey, imageName, &foundX, &foundY)
    }

    /**
     * Polls a GameConstants region for an anchor image until timeoutMs.
     */
    WaitForUiImage(uiConfig, regionKey, imageName, timeoutMs := 5000) {
        searchArea := this.GetUiSearchArea(uiConfig, regionKey)
        if !IsObject(searchArea)
            return false

        this.MoveCursorOutOfSearchArea(searchArea)

        foundX := 0, foundY := 0
        this.Debug("[RemoveActiveMissions] Waiting up to " timeoutMs "ms for " imageName
            " in [" searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        startTime := A_TickCount
        pollMs := 40
        loop {
            if this.IsCancelled()
                return false
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation) {
                this.Debug("[RemoveActiveMissions] " imageName " found at (" foundX ", " foundY ").")
                return true
            }
            if (A_TickCount - startTime >= timeoutMs)
                return false
            Sleep(pollMs)
        }
    }

    IsCancelled() {
        global userStateInst
        return IsSet(userStateInst) && IsObject(userStateInst) && userStateInst.IsCancelRequested()
    }

    FindUiImage(uiConfig, regionKey, imageName, &foundX, &foundY) {
        searchArea := this.GetUiSearchArea(uiConfig, regionKey)
        if !IsObject(searchArea)
            return false
        this.MoveCursorOutOfSearchArea(searchArea)
        return this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation)
    }

    GetUiSearchArea(uiConfig, regionKey) {
        if !uiConfig.Has(regionKey) {
            this.Log("[RemoveActiveMissions] Error: " regionKey " missing in GameConstants.")
            return ""
        }

        btn := uiConfig[regionKey]
        return ResolutionManager().searchFromConfig(btn, 20)
    }

    MoveCursorOutOfSearchArea(searchArea) {
        InputHelper.MoveCursorClearOfSearch(searchArea)
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
