#Requires AutoHotkey v2.0+

class RectangleOverlay {
    guiObj := ""
    visible := false
    borderColor := "Red"
    borderThickness := 3

    __New(x := 0, y := 0, w := 0, h := 0) {
        this.guiObj := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        this.guiObj.BackColor := this.borderColor
        this.guiObj.MarginX := 0
        this.guiObj.MarginY := 0
        WinSetTransColor("0x000001", this.guiObj)
        this.guiObj.Show("Hide")

        if (x != 0 || y != 0 || w != 0 || h != 0)
            this.ShowAt(x, y, w, h)
    }

    ShowAt(x, y, w, h) {
        rm := ResolutionManager()
        pos := rm.coords(x, y)
        size := rm.dimensions(w, h)

        targetX := pos.x
        targetY := pos.y
        targetW := Max(1, Round(size.w))
        targetH := Max(1, Round(size.h))
        thickness := this.borderThickness

        if (this.visible)
            this.Close()

        this.guiObj := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        this.guiObj.BackColor := this.borderColor
        this.guiObj.MarginX := 0
        this.guiObj.MarginY := 0
        WinSetTransColor("0x000001", this.guiObj)

        this.guiObj.Add("Text", "x" thickness " y" thickness " w" (targetW - thickness * 2) " h" (targetH - thickness * 2) " Background000001")
        this.guiObj.Show("w" targetW " h" targetH " NoActivate")
        WinMove(targetX, targetY, targetW, targetH, this.guiObj)
        this.visible := true
    }

    /**
     * Shows a border using already-scaled screen coordinates (no ResolutionManager conversion).
     * WinMove places the box on screen pixels, matching ImageSearch CoordMode Screen
     * (game client origin + converted UI coords).
     */
    ShowAtScreen(x, y, w, h) {
        targetX := Integer(x)
        targetY := Integer(y)
        targetW := Max(1, Integer(w))
        targetH := Max(1, Integer(h))
        thickness := this.borderThickness

        if (this.visible)
            this.Close()

        this.guiObj := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        this.guiObj.BackColor := this.borderColor
        this.guiObj.MarginX := 0
        this.guiObj.MarginY := 0
        WinSetTransColor("0x000001", this.guiObj)

        this.guiObj.Add("Text", "x" thickness " y" thickness " w" (targetW - thickness * 2) " h" (targetH - thickness * 2) " Background000001")
        this.guiObj.Show("w" targetW " h" targetH " NoActivate")
        WinMove(targetX, targetY, targetW, targetH, this.guiObj)
        this.visible := true
    }

    Close() {
        if IsObject(this.guiObj)
            this.guiObj.Hide()
        this.visible := false
    }
}
