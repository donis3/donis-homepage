# Donsraad

**Easy Mission Picker** for [Dune: Awakening](https://duneawakening.com/).

A Landsraad companion that locks in the three repeatable missions you actually want — usually in the same area — so you stop eating loading screens.

Random Landsraad boards scatter you across the map. Each wrong contract is another load and a slice of the session gone. Donsraad keeps you on missions in the same region. A workaround for Funcom’s board design: random offers, long travel, too many loading screens.

## How it works

Landsraad missions are repeatable, but each specialization only shows a random handful of offers. You pick up to three targets. Donsraad keeps rolling the board until those three are sitting in your active slots.

Refresh uses the **guild disband** method:

1. Filler offers are accepted until your three active slots are full.
2. Disbanding the guild clears those actives and rolls new random offers for every specialization.
3. Repeat until your targets appear, then accept them.

Same jobs. Same region. Fewer loading screens.

## Requirements

- Windows 10 or 11
- Dune: Awakening focused when you run a pass (Landsraad does not need to be open — the app opens it if needed)
- A guild name in Settings (used to disband and refresh the board)

Coordinates are authored for **3440×1440** (21:9). Other resolutions are scaled automatically; ultrawide side padding is accounted for so the game UI stays aligned.

## Getting started

### Standalone (recommended)

From the repo root (close `Donsraad.exe` first if it is running):

```powershell
.\build.cmd
```

That writes a portable folder at `dist\Donsraad\`. Copy that folder anywhere and run `Donsraad.exe`. AutoHotkey does not need to be installed on the machine that runs it.

JSON and PNG files stay **next to the exe**, not locked inside it:

| File | Role |
| --- | --- |
| `settings.json` | App settings (defaulted at compile; written by the GUI) |
| `profiles.json` | Character profiles (defaulted at compile; written by the GUI) |
| `player_state.json` | Active session / stats (defaulted at compile; written while running) |
| `db\landsraad_houses.json` | House database (read; you can edit) |
| `db\landsraad_missions.json` | Mission database (read; you can edit) |
| `ui\donis.png` | About-tab photo |
| `ui_elements\*.png` | In-game image-search anchors |

`settings.json`, `profiles.json`, and `player_state.json` are user-specific and gitignored. The build copies clean templates from `defaults/` into the portable folder. If you drop only `Donsraad.exe` into an empty folder, it seeds PNG files and mission databases from built-in copies, then **creates** those JSON files on first run. Files that already exist are never overwritten.

Rebuild after source changes with `.\build.cmd`.

### From source

1. Install [AutoHotkey v2](https://www.autohotkey.com/).
2. Clone this repo.
3. Run `main.ahk`.

```text
Donsraad/
├── main.ahk              # source entry
├── build.cmd             # compile to dist\Donsraad\
├── defaults/             # clean JSON templates for the portable build
├── db/                   # Landsraad houses and missions
├── ui/                   # dashboard and overlay
├── ui_elements/          # ImageSearch PNGs
├── scenarios/            # initialize, accept, disband, orchestrate
└── core/                 # state, OCR, input, resolution
```

## Usage

1. **Settings** — Character name, guild name, and faction. The guild name is required for the disband refresh. Add extra profiles if you have alts.
2. **Choose targets** — On Mission Picker, click a house cell and assign up to **3 missions** total. One specialization per cell, and it must be the specialization that house actually offers. Green cells are your targets. If the offers on that cell are a different spec, the run stops with **Wrong specialization** so it cannot loop forever.
3. **First setup** — Have Dune: Awakening focused. Landsraad does not need to be open. Press **Initialize**, or press the Start key once, so Donsraad can read your current actives. If the menu is closed, the app opens it.
4. **Run the picker** — Press **Start** (default `Home`) for each pass. The app fills leftover slots, disbands to refresh offers, and takes your targets when they show. Use it whenever you need the same three missions again.
5. **Overlay** — Status, character, and available / targeted stay at the top of the screen. The count turns green when all targets are active.
6. **Dashboard** — The window **X** hides the UI so you can play. Press **Delete** (default) to bring it back. `Pause` (default) closes Donsraad. All three keys can be changed in Settings → Keybinds.

## Keybinds

| Action | Default |
| --- | --- |
| Start / run mission picker | `Home` |
| Show / hide dashboard | `Delete` |
| Exit Donsraad | `Pause` |

Rebind them in **Settings → Keybinds**. Click a bind, press a key, `Esc` cancels.

## Disclaimer

Unofficial personal tool. Not affiliated with Funcom or Dune: Awakening. Automating a live game can conflict with that game’s terms of use — run it only on your own account and at your own risk.

## Author

**Deniz Özkan** — [donis.dev](https://donis.dev)

© 2026 Deniz Özkan. All rights reserved.
