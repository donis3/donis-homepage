#Requires AutoHotkey v2.0+

/**
 * GDI+ library wrapper for AutoHotkey v2.
 * Optimized for high-speed in-memory screen capturing, cropping, and bitmap buffer management.
 */

Gdip_Token(val := -1) {
    static currentToken := 0
    if (val != -1)
        currentToken := val
    return currentToken
}

Gdip_Startup() {
    tok := Gdip_Token()
    if (tok != 0)
        return tok

    if !DllCall("GetModuleHandle", "str", "gdiplus", "uptr")
        DllCall("LoadLibrary", "str", "gdiplus")

    si := Buffer(A_PtrSize = 8 ? 24 : 16, 0)
    NumPut("uint", 1, si, 0)
    pToken := 0
    status := DllCall("gdiplus\GdiplusStartup", "uptr*", &pToken, "ptr", si, "ptr", 0)
    if (status != 0)
        throw Error("GdiplusStartup failed with status: " . status)
    
    Gdip_Token(pToken)
    return pToken
}

Gdip_Shutdown(pToken := 0) {
    tok := pToken ? pToken : Gdip_Token()
    if (tok != 0) {
        DllCall("gdiplus\GdiplusShutdown", "uptr", tok)
        if (hModule := DllCall("GetModuleHandle", "str", "gdiplus", "uptr"))
            DllCall("FreeLibrary", "ptr", hModule)
        Gdip_Token(0)
    }
}

/**
 * Captures a specified screen region directly into a GDI+ Bitmap.
 * @param {Integer} x - Top-left X coordinate.
 * @param {Integer} y - Top-left Y coordinate.
 * @param {Integer} w - Width.
 * @param {Integer} h - Height.
 * @returns {Ptr} - Pointer to GDI+ Bitmap.
 */
Gdip_BitmapFromScreen(x := 0, y := 0, w := 0, h := 0) {
    if (w <= 0 || h <= 0) {
        x := DllCall("GetSystemMetrics", "int", 76, "int") ; SM_XVIRTUALSCREEN
        y := DllCall("GetSystemMetrics", "int", 77, "int") ; SM_YVIRTUALSCREEN
        w := DllCall("GetSystemMetrics", "int", 78, "int") ; SM_CXVIRTUALSCREEN
        h := DllCall("GetSystemMetrics", "int", 79, "int") ; SM_CYVIRTUALSCREEN
    }

    chdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
    hbm := CreateDIBSection(w, h, chdc)
    obm := DllCall("SelectObject", "ptr", chdc, "ptr", hbm, "ptr")
    hhdc := DllCall("GetDC", "ptr", 0, "ptr")
    
    ; 0x00CC0020 = SRCCOPY | 0x40000000 = CAPTUREBLT
    DllCall("BitBlt", "ptr", chdc, "int", 0, "int", 0, "int", w, "int", h, "ptr", hhdc, "int", x, "int", y, "uint", 0x00CC0020 | 0x40000000)
    
    DllCall("ReleaseDC", "ptr", 0, "ptr", hhdc)
    pBitmap := 0
    DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "uptr*", &pBitmap)
    
    DllCall("SelectObject", "ptr", chdc, "ptr", obm)
    DllCall("DeleteObject", "ptr", hbm)
    DllCall("DeleteDC", "ptr", chdc)
    
    return pBitmap
}

/**
 * Crops a sub-region from an existing GDI+ Bitmap into a new GDI+ Bitmap.
 */
Gdip_CloneBitmapArea(pBitmap, x, y, w, h) {
    pBitmapOut := 0
    ; PixelFormat32bppARGB = 0x26200A
    status := DllCall("gdiplus\GdipCloneBitmapAreaI"
        , "int", x
        , "int", y
        , "int", w
        , "int", h
        , "int", 0x26200A
        , "ptr", pBitmap
        , "uptr*", &pBitmapOut)
    return status == 0 ? pBitmapOut : 0
}

Gdip_CreateHBITMAPFromBitmap(pBitmap, background := 0xffffffff) {
    hBitmap := 0
    DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "ptr", pBitmap, "uptr*", &hBitmap, "int", background)
    return hBitmap
}

Gdip_CreateBitmap(width, height, pixelFormat := 0x26200A) {
    stride := ((width * 4) + 3) & ~3
    scan0 := Buffer(stride * height, 0)
    pBitmap := 0
    DllCall("gdiplus\GdipCreateBitmapFromScan0"
        , "int", width
        , "int", height
        , "int", stride
        , "int", pixelFormat
        , "ptr", scan0.Ptr
        , "uptr*", &pBitmap)
    return pBitmap
}

Gdip_GraphicsFromImage(pBitmap) {
    g := 0
    DllCall("gdiplus\GdipGetImageGraphicsContext", "ptr", pBitmap, "uptr*", &g)
    return g
}

Gdip_SetSmoothingMode(g, mode := 4) {
    DllCall("gdiplus\GdipSetSmoothingMode", "ptr", g, "int", mode)
}

Gdip_CreateSolidBrush(color) {
    argb := color
    if (Type(color) = "String" && InStr(color, "0x") = 1)
        argb := Integer(color)
    brush := 0
    DllCall("gdiplus\GdipCreateSolidFill", "int", argb, "uptr*", &brush)
    return brush
}

Gdip_DeleteBrush(brush) {
    if (brush)
        DllCall("gdiplus\GdipDeleteBrush", "ptr", brush)
}

Gdip_FillRectangle(g, brush, x, y, width, height) {
    DllCall("gdiplus\GdipFillRectangle", "ptr", g, "ptr", brush, "float", x, "float", y, "float", width, "float", height)
}

Gdip_CreatePen(color, width := 1, unit := 2) {
    argb := color
    if (Type(color) = "String" && InStr(color, "0x") = 1)
        argb := Integer(color)
    pen := 0
    DllCall("gdiplus\GdipCreatePen1", "int", argb, "float", width, "int", unit, "uptr*", &pen)
    return pen
}

Gdip_DeletePen(pen) {
    if (pen)
        DllCall("gdiplus\GdipDeletePen", "ptr", pen)
}

Gdip_DrawRectangle(g, pen, x, y, width, height) {
    DllCall("gdiplus\GdipDrawRectangle", "ptr", g, "ptr", pen, "float", x, "float", y, "float", width, "float", height)
}

Gdip_DeleteGraphics(g) {
    if (g)
        DllCall("gdiplus\GdipDeleteGraphics", "ptr", g)
}

Gdip_GetImageWidth(pBitmap) {
    width := 0
    DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width)
    return width
}

Gdip_GetImageHeight(pBitmap) {
    height := 0
    DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height)
    return height
}

Gdip_DisposeImage(pBitmap) {
    if (pBitmap)
        return DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)
    return 0
}

Gdip_LockBits(pBitmap, x, y, w, h, &bitmapData, format := 0x26200A, lockMode := 1) {
    bitmapData := Buffer(A_PtrSize = 8 ? 32 : 24, 0)
    rect := Buffer(16, 0)
    NumPut("int", x, rect, 0)
    NumPut("int", y, rect, 4)
    NumPut("int", w, rect, 8)
    NumPut("int", h, rect, 12)
    return DllCall("gdiplus\GdipBitmapLockBits", "ptr", pBitmap, "ptr", rect, "uint", lockMode, "int", format, "ptr", bitmapData)
}

Gdip_UnlockBits(pBitmap, &bitmapData) {
    return DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", bitmapData)
}

CreateDIBSection(w, h, hdc := 0, bpp := 32, &ppvBits := 0) {
    hdc2 := hdc ? hdc : DllCall("GetDC", "ptr", 0, "ptr")
    bi := Buffer(40, 0)
    NumPut("uint", 40, bi, 0)
    NumPut("int", w, bi, 4)
    NumPut("int", -h, bi, 8) ; Top-down DIB
    NumPut("ushort", 1, bi, 12)
    NumPut("ushort", bpp, bi, 14)
    NumPut("uint", 0, bi, 16) ; BI_RGB

    hbm := DllCall("CreateDIBSection", "ptr", hdc2, "ptr", bi, "uint", 0, "ptr*", &ppvBits, "ptr", 0, "uint", 0, "ptr")
    if (!hdc)
        DllCall("ReleaseDC", "ptr", 0, "ptr", hdc2)
    return hbm
}

Gdip_SaveBitmapToFile(pBitmap, filePath, quality := 90) {
    pathParts := ""
    ext := ""
    SplitPath(filePath, , , &ext)
    ext := StrLower(ext)
    
    clsidStr := ""
    if (ext == "png")
        clsidStr := "{557CF406-1A04-11D3-9A73-0000F81EF32E}"
    else if (ext == "jpg" || ext == "jpeg")
        clsidStr := "{557CF401-1A04-11D3-9A73-0000F81EF32E}"
    else if (ext == "bmp")
        clsidStr := "{557CF400-1A04-11D3-9A73-0000F81EF32E}"
    else
        clsidStr := "{557CF406-1A04-11D3-9A73-0000F81EF32E}"

    CLSID := Buffer(16, 0)
    DllCall("ole32\CLSIDFromString", "wstr", clsidStr, "ptr", CLSID)
    return DllCall("gdiplus\GdipSaveImageToFile", "ptr", pBitmap, "wstr", filePath, "ptr", CLSID, "ptr", 0)
}
