#Requires AutoHotkey v2.0+

/**
 * Small always-on-top HUD at the top-center of the screen.
 * Click-through so it does not steal game input.
 * Count is available targetted missions / total targetted missions.
 */
class StatusOverlay {
    guiObj := ""
    statusText := ""
    progressText := ""
    stateManager := ""
    userState := ""
    profileManager := ""
    stateLabel := "Waiting"
    visible := false
    overlayW := 560
    overlayH := 28
    progressCompleteColor := "4ADE80"
    progressDefaultColor := "EAB308"

    __New(stateManagerInst := "", userStateInst := "", profileManagerInst := "") {
        this.stateManager := stateManagerInst
        this.userState := userStateInst
        this.profileManager := profileManagerInst
        this.stateLabel := this.GetReadyLabel()
        this.guiObj := Gui("-Caption +AlwaysOnTop +E0x20 +ToolWindow")
        this.guiObj.BackColor := "0F0F12"
        this.guiObj.MarginX := 0
        this.guiObj.MarginY := 0
        this.guiObj.SetFont("s8 bold cEAB308", "Segoe UI")
        this.statusText := this.guiObj.Add("Text",
            "x8 y6 w" (this.overlayW - 64) " h16 BackgroundTrans",
            this.BuildPrefix())
        this.progressText := this.guiObj.Add("Text",
            "x" (this.overlayW - 52) " y6 w44 h16 Right BackgroundTrans",
            this.GetProgressText())
        this.Show()
    }

    ApplyVisibility(show) {
        if (show)
            this.Show()
        else
            this.Hide()
    }

    BuildPrefix() {
        charName := this.GetCharacterName()
        if (charName != "")
            return this.stateLabel "   ·   " charName "   ·"
        return this.stateLabel "   ·"
    }

    BuildLine() {
        return this.BuildPrefix() "   " this.GetProgressText()
    }

    GetCharacterName() {
        if IsObject(this.profileManager)
            return this.profileManager.GetCurrentName()
        return ""
    }

    GetProgressText() {
        if IsObject(this.userState)
            return this.userState.GetProgressText(this.GetTargetedCount())
        return "0/0"
    }

    IsProgressComplete() {
        if IsObject(this.userState)
            return this.userState.IsProgressComplete(this.GetTargetedCount())
        return false
    }

    GetTargetedCount() {
        if !IsObject(this.stateManager)
            return 0
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return 0
        return targeted.Length
    }

    GetReadyLabel() {
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("GetStatusBarText"))
            return mainGuiInst.GetStatusBarText()
        if IsObject(this.userState)
            return this.userState.GetReadyLabel()
        return "Waiting"
    }

    SetState(stateLabel) {
        this.stateLabel := (stateLabel != "") ? stateLabel : this.GetReadyLabel()
        this.Refresh()
    }

    SetAvailableCount(availableCount) {
        if IsObject(this.userState)
            this.userState.SetAvailableTargetedCount(availableCount)
        this.Refresh()
    }

    RestoreSessionState() {
        this.SetState(this.GetReadyLabel())
    }

    Refresh() {
        if IsObject(this.statusText)
            this.statusText.Text := this.BuildPrefix()
        if IsObject(this.progressText) {
            this.progressText.Text := this.GetProgressText()
            color := this.IsProgressComplete() ? this.progressCompleteColor : this.progressDefaultColor
            this.progressText.SetFont("s8 bold c" color, "Segoe UI")
        }
    }

    Show() {
        x := Max(0, (A_ScreenWidth - this.overlayW) // 2)
        y := 8
        this.guiObj.Show("x" x " y" y " w" this.overlayW " h" this.overlayH " NoActivate")
        try WinSetTransparent(210, this.guiObj)
        this.visible := true
        this.Refresh()
    }

    Hide() {
        if IsObject(this.guiObj)
            this.guiObj.Hide()
        this.visible := false
    }

    Close() {
        this.Hide()
        if IsObject(this.guiObj) {
            try this.guiObj.Destroy()
        }
        this.guiObj := ""
    }
}
