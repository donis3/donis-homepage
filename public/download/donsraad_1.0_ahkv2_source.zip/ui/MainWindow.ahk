#Requires AutoHotkey v2.0+

/**
 * Donsraad — Easy Mission Picker
 *
 * Tab 1 - Mission Picker:
 *   5x5 grid of 25 house-slot boxes (house identity unknown / rotates weekly).
 *   Player assigns up to 3 missions TOTAL across all slots.
 *   A single slot can hold 1, 2, or 3 missions (all 3 on the same slot is valid).
 *   Clicking a slot opens an assignment panel below with up to 3 mission dropdowns.
 *   When the global cap of 3 is reached, unassigned slots are disabled.
 *
 * Tab 2 - Settings
 * Tab 3 - Logs
 * Tab 4 - About
 */
class DonsraadGui {
    guiObj := ""
    stateManager := ""
    settingsManager := ""
    logger := ""

    winW := 900
    winH := 900
    margin := 36
    contentW := 828
    gridX := 80
    gridW := 740
    bgColor := "0F0F12"
    surfaceColor := "18181F"
    mutedColor := "27272F"
    inputBgColor := "3F3F46"
    inputFgColor := "FAFAFA"
    gridClickableBg := "27272F"
    gridTargetedBg := "166534"
    gridDisabledBg := "3F3F46"
    gridClickableFg := "E4E4E7"
    gridTargetedFg := "ECFDF5"
    gridDisabledFg := "A1A1AA"
    gridActiveFrame := "EAB308"
    editBgBrush := 0
    ctlColorHandler := ""
    listColorHandler := ""
    styledEdits := []

    ; slotMissions[slotIdx] = Array of mission label strings (max 3 total globally)
    slotMissions := Map()

    boxFrames := []
    boxButtons := []
    activeSlotIdx := 0

    panelLabel := ""
    mRow := []
    counterLabel := ""
    hintLabel := ""
    initActionBtn := ""

    tabButtons := []
    pageControls := Map()
    activeTab := 1

    setOcrLang := ""
    setGuildName := ""
    setFaction := ""
    setDebugMode := ""
    setShowOverlay := ""
    setCharacterName := ""
    setProfile := ""
    statsAbandons := ""
    statsAccepts := ""
    setHotkeyStart := ""
    setHotkeyExit := ""
    setHotkeyToggle := ""
    headerHotkeys := ""
    statusBar := ""
    statusProgress := ""
    initScenario := ""
    userState := ""
    profileManager := ""
    isInitializing := true

    __New(stateManagerInst, settingsManagerInst := "", loggerInst := "", initScenarioInst := "", userStateInst := "", profileManagerInst := "") {
        this.isInitializing := true
        this.stateManager := stateManagerInst
        this.settingsManager := settingsManagerInst ? settingsManagerInst : SettingsManager(A_ScriptDir)
        this.logger := loggerInst
        this.initScenario := initScenarioInst
        this.userState := userStateInst
        this.profileManager := profileManagerInst

        if (IsObject(this.logger) && IsObject(this.settingsManager))
            this.logger.SetDebug(this.settingsManager.Get("debugMode", false))

        this.pageControls[1] := []
        this.pageControls[2] := []
        this.pageControls[3] := []
        this.pageControls[4] := []

        this.BuildGui()
        this.isInitializing := false
    }

    PageAdd(page, ctl) {
        this.pageControls[page].Push(ctl)
        return ctl
    }

    PageAddSelect(page, selectCtrl) {
        this.PageAdd(page, selectCtrl.face)
        this.PageAdd(page, selectCtrl.caret)
        return selectCtrl
    }

    ; -----------------------------------------------------------------------
    BuildGui() {
        this.guiObj := Gui("+Resize +MinSize820x820", "Donsraad — Easy Mission Picker")
        g := this.guiObj
        g.BackColor := this.bgColor
        g.MarginX := 0
        g.MarginY := 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")

        this.contentW := this.winW - (this.margin * 2)

        this.BuildHeader()
        this.BuildTabBar()
        this.BuildMissionPickerTab()
        this.BuildSettingsTab()
        this.BuildLogsTab()
        this.BuildAboutTab()
        this.BuildFooter()

        this.RestoreMissionSelections()
        this.SwitchTab(1)
        this.InitEditColors()
        try {
            useDark := Buffer(4, 0)
            NumPut("Int", 1, useDark)
            DllCall("dwmapi\DwmSetWindowAttribute", "ptr", g.Hwnd, "uint", 20, "ptr", useDark, "uint", 4)
        }
        g.OnEvent("Close", (*) => this.guiObj.Minimize())
    }

    AddTextButton(page, x, y, w, h, label, callback, primary := false) {
        g := this.guiObj
        bg := primary ? "EAB308" : this.mutedColor
        fg := primary ? "18181B" : "E4E4E7"
        g.SetFont("s9 bold c" fg, "Segoe UI")
        btn := this.PageAdd(page, g.Add("Text",
            "x" x " y" y " w" w " h" h " Center +0x200 Background" bg, label))
        btn.OnEvent("Click", callback)
        return btn
    }

    SetTextButtonState(ctrl, enabled, primary := false) {
        if !IsObject(ctrl)
            return
        if (primary) {
            ctrl.Opt("BackgroundEAB308")
            ctrl.SetFont("s9 bold c18181B", "Segoe UI")
        } else if (enabled) {
            ctrl.Opt("Background" this.mutedColor)
            ctrl.SetFont("s9 bold cE4E4E7", "Segoe UI")
        } else {
            ctrl.Opt("Background" this.inputBgColor)
            ctrl.SetFont("s9 bold c71717A", "Segoe UI")
        }
        ctrl.Redraw()
    }

    /**
     * Dark-theme Edit boxes: disable Windows theming and paint a visible dark field.
     */
    StyleEdit(ctrl, fontName := "Segoe UI", fontSize := 10) {
        try DllCall("uxtheme\SetWindowTheme", "ptr", ctrl.Hwnd, "wstr", "", "wstr", "")
        ctrl.Opt("-Theme Background" this.inputBgColor)
        ctrl.SetFont("s" fontSize " c" this.inputFgColor, fontName)
        this.styledEdits.Push(ctrl)
        return ctrl
    }

    InitEditColors() {
        ; BGR of #3F3F46
        if (!this.editBgBrush)
            this.editBgBrush := DllCall("gdi32\CreateSolidBrush", "uint", 0x463F3F, "ptr")
        this.ctlColorHandler := ObjBindMethod(this, "OnCtlColorEdit")
        OnMessage(0x0133, this.ctlColorHandler) ; WM_CTLCOLOREDIT
        OnMessage(0x0138, this.ctlColorHandler) ; WM_CTLCOLORSTATIC (read-only Edit)
        this.listColorHandler := ObjBindMethod(this, "OnCtlColorListBox")
        OnMessage(0x0134, this.listColorHandler) ; WM_CTLCOLORLISTBOX
    }

    OnCtlColorListBox(wParam, lParam, msg, hwnd) {
        DllCall("gdi32\SetTextColor", "ptr", wParam, "uint", 0xFAFAFA)
        DllCall("gdi32\SetBkColor", "ptr", wParam, "uint", 0x463F3F)
        DllCall("gdi32\SetBkMode", "ptr", wParam, "int", 2)
        return this.editBgBrush
    }

    OnCtlColorEdit(wParam, lParam, msg, hwnd) {
        isOurs := false
        for _, ctl in this.styledEdits {
            if (IsObject(ctl) && lParam == ctl.Hwnd) {
                isOurs := true
                break
            }
        }
        if (!isOurs)
            return
        DllCall("gdi32\SetTextColor", "ptr", wParam, "uint", 0xFAFAFA)
        DllCall("gdi32\SetBkColor", "ptr", wParam, "uint", 0x463F3F)
        DllCall("gdi32\SetBkMode", "ptr", wParam, "int", 2)
        return this.editBgBrush
    }

    BuildHeader() {
        g := this.guiObj
        m := this.margin

        g.SetFont("s16 bold cEAB308", "Segoe UI")
        g.Add("Text", "x" m " y14 w280 h26 BackgroundTrans", "DONSRAAD")

        g.SetFont("s9 c71717A", "Segoe UI")
        g.Add("Text", "x" m " y40 w360 h16 BackgroundTrans", "Easy Mission Picker")

        g.SetFont("s9 c52525B", "Segoe UI")
        this.headerHotkeys := g.Add("Text", "x" (this.winW - m - 400) " y28 w400 h16 Right BackgroundTrans",
            this.GetHotkeyHeaderText())

        g.Add("Text", "x0 y62 w" this.winW " h2 BackgroundEAB308")
    }

    BuildTabBar() {
        g := this.guiObj
        labels := ["Mission Picker", "Settings", "Logs", "About"]
        tabW := 156
        tabH := 34
        tabY := 76
        tabX := this.margin

        this.tabButtons := []
        loop labels.Length {
            idx := A_Index
            x := tabX + (idx - 1) * (tabW + 8)
            g.SetFont("s10 cA1A1AA", "Segoe UI")
            btn := g.Add("Text", "x" x " y" tabY " w" tabW " h" tabH " Center +0x200 Background" this.surfaceColor,
                labels[idx])
            btn.OnEvent("Click", this.MakeTabHandler(idx))
            this.tabButtons.Push(btn)
        }
    }

    MakeTabHandler(idx) {
        return (ctrl, *) => this.SwitchTab(idx)
    }

    SwitchTab(page) {
        DarkSelect.Dismiss()
        this.activeTab := page
        loop this.tabButtons.Length {
            idx := A_Index
            isOn := (idx == page)
            for _, ctl in this.pageControls[idx] {
                try ctl.Visible := isOn
            }
            tabBtn := this.tabButtons[idx]
            if (isOn) {
                tabBtn.Opt("BackgroundEAB308")
                tabBtn.SetFont("s10 bold c18181B", "Segoe UI")
            } else {
                tabBtn.Opt("Background" this.surfaceColor)
                tabBtn.SetFont("s10 cA1A1AA", "Segoe UI")
            }
            tabBtn.Redraw()
        }
    }

    BuildFooter() {
        g := this.guiObj
        g.Add("Text", "x0 y" (this.winH - 36) " w" this.winW " h36 Background" this.surfaceColor)
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        this.statusBar := g.Add("Text",
            "x" this.margin " y" (this.winH - 28) " w" (this.contentW - 72) " h20 +0x200 cEAB308 Background" this.surfaceColor,
            this.GetStatusBarText())
        g.SetFont("s9 bold cA1A1AA", "Segoe UI")
        this.statusProgress := g.Add("Text",
            "x" (this.margin + this.contentW - 64) " y" (this.winH - 28) " w64 h20 Right BackgroundTrans",
            this.GetProgressText())
        this.RefreshStatusProgress()
    }

    ; -----------------------------------------------------------------------
    ; TAB 1 — MISSION PICKER
    ; -----------------------------------------------------------------------
    BuildMissionPickerTab() {
        g := this.guiObj
        m := this.margin
        contentY := 124

        cellW := 140, cellH := 50, gapX := 10, gapY := 8
        this.gridW := (5 * cellW) + (4 * gapX)
        this.gridX := m + ((this.contentW - this.gridW) // 2)

        ; Toolbar aligned to the centered grid
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.hintLabel := this.PageAdd(1, g.Add("Text",
            "x" this.gridX " y" contentY " w" this.gridW " h22 BackgroundTrans",
            "Pick up to 3 repeatable missions  ·  one specialization per cell"))

        toolY := contentY + 26
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        this.counterLabel := this.PageAdd(1, g.Add("Text",
            "x" this.gridX " y" (toolY + 4) " w86 h22 BackgroundTrans",
            "0 / 3"))

        this.AddTextButton(1, this.gridX + this.gridW - 326, toolY, 126, 28,
            "Clear all", (*) => this.OnClearAllTargets())
        this.initActionBtn := this.AddTextButton(1, this.gridX + this.gridW - 188, toolY, 188, 28,
            "▶   Initialize", (*) => this.OnInitActionClick(), true)
        this.RefreshInitButton()

        ; ---- 5×5 grid, centered in the content area ----
        startX := this.gridX
        startY := toolY + 40

        this.boxFrames := []
        this.boxButtons := []
        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        loop 25 {
            idx := A_Index
            col := Mod(idx - 1, 5)
            row := (idx - 1) // 5
            x := startX + col * (cellW + gapX)
            y := startY + row * (cellH + gapY)
            frame := this.PageAdd(1, g.Add("Text",
                "x" (x - 2) " y" (y - 2) " w" (cellW + 4) " h" (cellH + 4) " Background" this.bgColor))
            btn := this.PageAdd(1, g.Add("Text",
                "x" x " y" y " w" cellW " h" cellH " Center Background" this.gridClickableBg, idx))
            btn.SetFont("s9 bold c" this.gridClickableFg, "Segoe UI")
            btn.OnEvent("Click", this.MakeBoxHandler(idx))
            this.boxFrames.Push(frame)
            this.boxButtons.Push(btn)
        }

        ; ---- Assignment card, same width as the grid ----
        panelY := startY + 5 * (cellH + gapY) - gapY + 12
        cardH := 156
        this.PageAdd(1, g.Add("Text",
            "x" this.gridX " y" panelY " w" this.gridW " h" cardH " Background" this.surfaceColor))

        g.SetFont("s9 bold cEAB308", "Segoe UI")
        this.panelLabel := this.PageAdd(1, g.Add("Text",
            "x" (this.gridX + 16) " y" (panelY + 12) " w" (this.gridW - 32) " h20 BackgroundTrans",
            "Select a house cell to assign missions"))

        this.mRow := []
        rowLabels := ["Mission 1", "Mission 2", "Mission 3"]
        labelW := 86
        clearW := 92
        rowPad := 16
        ddlX := this.gridX + rowPad + labelW + 8
        ddlW := this.gridW - (rowPad * 2) - labelW - 8 - clearW - 8
        clearX := this.gridX + this.gridW - rowPad - clearW

        loop 3 {
            rowIdx := A_Index
            ry := panelY + 36 + (rowIdx - 1) * 36

            g.SetFont("s9 cA1A1AA", "Segoe UI")
            lbl := this.PageAdd(1, g.Add("Text",
                "x" (this.gridX + rowPad) " y" ry " w" labelW " h32 +0x200 BackgroundTrans",
                rowLabels[rowIdx]))

            g.SetFont("s10 cE4E4E7", "Segoe UI")
            ddl := DarkSelect(g, ddlX, ry + 2, ddlW, 28, this)
            this.PageAddSelect(1, ddl)
            ddl.OnEvent("Change", this.MakeDdlHandler(rowIdx))
            ddl.Opt("+Disabled")

            clrBtn := this.AddTextButton(1, clearX, ry, clearW, 32,
                "Clear", this.MakeClearHandler(rowIdx))
            this.SetTextButtonState(clrBtn, false)

            this.mRow.Push({ label: lbl, ddl: ddl, clearBtn: clrBtn, clearEnabled: false })
        }
    }

    MakeBoxHandler(slotIdx) {
        return (ctrl, *) => this.OnBoxClick(slotIdx)
    }
    MakeDdlHandler(rowIdx) {
        return (ctrl, *) => this.OnDdlChange(rowIdx)
    }
    MakeClearHandler(rowIdx) {
        return (ctrl, *) => this.OnClearRow(rowIdx)
    }

    OnBoxClick(slotIdx) {
        DarkSelect.Dismiss()
        total := this.TotalMissionCount()
        cnt := 0
        if (this.slotMissions.Has(slotIdx)) {
            for _, ml in this.slotMissions[slotIdx] {
                if (ml != "")
                    cnt++
            }
        }
        if (cnt == 0 && total >= 3)
            return

        this.activeSlotIdx := slotIdx
        this.RefreshGrid()
        this.PopulatePanel(slotIdx)
    }

    /**
     * Returns the locked specialization for a cell, or "" if the cell is empty.
     */
    GetSlotSpecialization(slotIdx) {
        if (!this.slotMissions.Has(slotIdx))
            return ""
        for _, label in this.slotMissions[slotIdx] {
            if (label == "")
                continue
            parsed := this.stateManager.ParseMissionLabel(label)
            if (parsed.specialization != "")
                return parsed.specialization
        }
        return ""
    }

    PopulatePanel(slotIdx) {
        missions := this.slotMissions.Has(slotIdx) ? this.slotMissions[slotIdx] : []
        lockedSpec := this.GetSlotSpecialization(slotIdx)

        specNote := lockedSpec != "" ? "  ·  " lockedSpec : ""
        this.panelLabel.Text := "House cell " slotIdx specNote "  ·  up to 3 missions"

        totalUsed := this.TotalMissionCount()

        loop 3 {
            rowIdx := A_Index
            row := this.mRow[rowIdx]
            curLabel := missions.Length >= rowIdx ? missions[rowIdx] : ""
            takenNames := this.GetTargetedMissionNames(slotIdx, rowIdx)

            choices := []
            for _, m in this.stateManager.allMissionsList {
                mSpec := m.Has("specialization") ? m["specialization"] : ""
                mName := m.Has("name") ? m["name"] : ""
                if (lockedSpec != "" && mSpec != lockedSpec)
                    continue
                if (mName != "" && takenNames.Has(StrLower(mName)))
                    continue
                choices.Push(this.stateManager.FormatMissionLabel(mSpec, mName))
            }

            rowsFilled := 0
            loop rowIdx - 1 {
                rowsFilled += (missions.Length >= A_Index && missions[A_Index] != "") ? 1 : 0
            }
            prevFull := (rowIdx == 1) || (rowsFilled == rowIdx - 1)
            hasOwn := (curLabel != "")
            canEnable := prevFull && (totalUsed < 3 || hasOwn)

            row.ddl.Delete()
            for _, ch in choices
                row.ddl.Add([ch])

            if (canEnable) {
                row.ddl.Opt("-Disabled")
                row.clearEnabled := true
                this.SetTextButtonState(row.clearBtn, true)
            } else {
                row.ddl.Opt("+Disabled")
                row.clearEnabled := false
                this.SetTextButtonState(row.clearBtn, false)
            }

            if (curLabel != "") {
                found := false
                loop choices.Length {
                    if (choices[A_Index] == curLabel) {
                        row.ddl.Choose(A_Index)
                        found := true
                        break
                    }
                }
                if (!found)
                    row.ddl.Choose(0)
            } else {
                row.ddl.Choose(0)
            }
        }
    }

    OnDdlChange(rowIdx) {
        if (this.activeSlotIdx == 0)
            return

        chosen := this.mRow[rowIdx].ddl.Text
        if (chosen == "")
            return

        if (!this.slotMissions.Has(this.activeSlotIdx))
            this.slotMissions[this.activeSlotIdx] := []

        missions := this.slotMissions[this.activeSlotIdx]
        while (missions.Length < rowIdx)
            missions.Push("")
        missions[rowIdx] := chosen

        parts := StrSplit(chosen, " — ", , 2)
        mName := parts.Length >= 2 ? Trim(parts[2]) : chosen

        this.PersistAndRefresh()
        this.PopulatePanel(this.activeSlotIdx)
    }

    OnClearRow(rowIdx) {
        if (this.activeSlotIdx == 0)
            return
        if (!this.mRow[rowIdx].clearEnabled)
            return
        if (!this.slotMissions.Has(this.activeSlotIdx))
            return

        missions := this.slotMissions[this.activeSlotIdx]
        newMissions := []
        loop missions.Length {
            if (A_Index != rowIdx && missions[A_Index] != "")
                newMissions.Push(missions[A_Index])
        }

        if (newMissions.Length == 0)
            this.slotMissions.Delete(this.activeSlotIdx)
        else
            this.slotMissions[this.activeSlotIdx] := newMissions

        this.PersistAndRefresh()
        this.PopulatePanel(this.activeSlotIdx)
    }

    OnClearAllTargets() {
        DarkSelect.Dismiss()
        this.slotMissions := Map()
        this.activeSlotIdx := 0
        this.PersistAndRefresh()
        if IsObject(this.panelLabel)
            this.panelLabel.Text := "Select a house cell to assign missions"
        loop 3 {
            if (this.mRow.Length < A_Index)
                continue
            row := this.mRow[A_Index]
            row.ddl.Delete()
            row.ddl.Choose(0)
            row.ddl.Opt("+Disabled")
            row.clearEnabled := false
            this.SetTextButtonState(row.clearBtn, false)
        }
        this.ShowSessionHint()
    }

    TotalMissionCount() {
        total := 0
        for _, missions in this.slotMissions {
            for _, label in missions {
                if (label != "")
                    total++
            }
        }
        return total
    }

    GetTargetedMissionNames(exceptSlot := 0, exceptRow := 0) {
        taken := Map()
        for slotIdx, missions in this.slotMissions {
            for rowIdx, label in missions {
                if (label == "")
                    continue
                if (slotIdx == exceptSlot && rowIdx == exceptRow)
                    continue
                parsed := this.stateManager.ParseMissionLabel(label)
                if (parsed.missionName != "")
                    taken[StrLower(parsed.missionName)] := true
            }
        }
        return taken
    }

    RefreshGrid() {
        total := this.TotalMissionCount()
        this.counterLabel.Text := total . " / 3"

        loop 25 {
            idx := A_Index
            btn := this.boxButtons[idx]
            frame := this.boxFrames[idx]
            cnt := 0
            isActive := (idx == this.activeSlotIdx)
            spec := this.GetSlotSpecialization(idx)

            if (this.slotMissions.Has(idx)) {
                for _, ml in this.slotMissions[idx] {
                    if (ml != "")
                        cnt++
                }
            }

            if (cnt == 0)
                btn.Text := "`n" idx
            else if (spec != "")
                btn.Text := idx "`n" spec "`n" cnt "/3"
            else
                btn.Text := idx "`n" cnt "/3"

            isDisabled := (cnt == 0 && total >= 3)
            if (cnt > 0) {
                bg := this.gridTargetedBg
                fg := this.gridTargetedFg
            } else if (isDisabled) {
                bg := this.gridDisabledBg
                fg := this.gridDisabledFg
            } else {
                bg := this.gridClickableBg
                fg := this.gridClickableFg
            }

            if (isActive)
                frame.Opt("Background" this.gridActiveFrame)
            else if (cnt > 0)
                frame.Opt("Background" this.gridTargetedBg)
            else if (isDisabled)
                frame.Opt("Background" this.gridDisabledBg)
            else
                frame.Opt("Background" this.mutedColor)
            frame.Redraw()

            btn.Opt("Background" bg)
            btn.SetFont("s9 bold c" fg, "Segoe UI")
            btn.Redraw()
        }
    }

    PersistAndRefresh() {
        this.RefreshGrid()
        this.SaveMissionSelections()
        this.RefreshStatusOverlay()
        this.RefreshStatusProgress()
    }

    SaveMissionSelections() {
        this.stateManager.SaveTargetedMissionsFromSlots(this.slotMissions)
    }

    RestoreMissionSelections() {
        this.slotMissions := this.stateManager.GetTargetedMissionsBySlot()
        this.RefreshGrid()
        this.RefreshStatusOverlay()
    }

    RefreshStatusOverlay() {
        global statusOverlayInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.Refresh()
    }

    ; -----------------------------------------------------------------------
    ; TAB 2 — SETTINGS
    ; -----------------------------------------------------------------------
    BuildSettingsTab() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        cardH := 68
        colGap := 12
        halfW := (cardW - colGap) // 2
        col1 := m
        col2 := m + halfW + colGap
        ctrlW := 160
        hintW := halfW - 36 - ctrlW - 12

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w" cardW " h24 BackgroundTrans", "Settings"))
        y += 32

        ; Character | Guild
        this.PageAdd(2, g.Add("Text", "x" col1 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Character name"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Shown on the overlay. Saved when you leave the field."))
        curChar := IsObject(this.profileManager) ? this.profileManager.GetCurrentName() : this.settingsManager.Get("characterName", "Default")
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setCharacterName := this.PageAdd(2, this.StyleEdit(g.Add("Edit",
            "x" (col1 + halfW - 16 - ctrlW) " y" (y + 20) " w" ctrlW " h28 -Theme Background" this.inputBgColor,
            curChar)))
        this.setCharacterName.OnEvent("LoseFocus", (*) => this.OnCharacterNameCommit())

        this.PageAdd(2, g.Add("Text", "x" col2 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Guild name"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Used to identify your guild in Landsraad."))
        curGuild := this.settingsManager.Get("guildName", "wowza")
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setGuildName := this.PageAdd(2, this.StyleEdit(g.Add("Edit",
            "x" (col2 + halfW - 16 - ctrlW) " y" (y + 20) " w" ctrlW " h28 -Theme Background" this.inputBgColor,
            curGuild)))
        this.setGuildName.OnEvent("Change", (*) => this.OnGuildNameChange())
        y += cardH + 12

        ; Profile switcher — full width
        profileCardH := 108
        this.PageAdd(2, g.Add("Text", "x" m " y" y " w" cardW " h" profileCardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (m + 18) " y" (y + 10) " w220 h18 BackgroundTrans", "Active profile"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (m + 18) " y" (y + 30) " w360 h16 BackgroundTrans",
            "Switch character, reset this profile, or add a new one."))
        profileNames := IsObject(this.profileManager) ? this.profileManager.GetProfileNames() : ["Default"]
        if (profileNames.Length == 0)
            profileNames := ["Default"]
        this.setProfile := DarkSelect(g, m + cardW - 336, y + 16, 180, 28, this, profileNames)
        this.PageAddSelect(2, this.setProfile)
        profileIdx := IsObject(this.profileManager) ? this.profileManager.GetCurrentIndex() : 1
        this.setProfile.Choose(profileIdx)
        this.setProfile.OnEvent("Change", (*) => this.OnProfileChange())
        this.AddTextButton(2, m + cardW - 148, y + 16, 62, 28, "Reset", (*) => this.OnResetProfile())
        this.AddTextButton(2, m + cardW - 78, y + 16, 60, 28, "New", (*) => this.OnNewProfile())
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (m + 18) " y" (y + 58) " w" (cardW - 100) " h16 BackgroundTrans",
            "Total Abandons"))
        this.PageAdd(2, g.Add("Text", "x" (m + 18) " y" (y + 78) " w" (cardW - 100) " h16 BackgroundTrans",
            "Successfully Accepted Target Missions"))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.statsAbandons := this.PageAdd(2, g.Add("Text",
            "x" (m + cardW - 78) " y" (y + 56) " w60 h18 Right BackgroundTrans", "0"))
        this.statsAccepts := this.PageAdd(2, g.Add("Text",
            "x" (m + cardW - 78) " y" (y + 76) " w60 h18 Right BackgroundTrans", "0"))
        this.RefreshStatsDisplay()
        y += profileCardH + 12

        ; Faction | OCR
        this.PageAdd(2, g.Add("Text", "x" col1 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Faction"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Your Landsraad allegiance."))
        factions := ["Atreides", "Harkonnen"]
        curFaction := this.settingsManager.Get("faction", "Atreides")
        this.setFaction := DarkSelect(g, col1 + halfW - 16 - ctrlW, y + 20, ctrlW, 28, this, factions)
        this.PageAddSelect(2, this.setFaction)
        chosenIdx := 1
        loop factions.Length {
            if (factions[A_Index] == curFaction) {
                chosenIdx := A_Index
                break
            }
        }
        this.setFaction.Choose(chosenIdx)
        this.setFaction.OnEvent("Change", (*) => this.OnFactionChange())

        this.PageAdd(2, g.Add("Text", "x" col2 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "OCR language"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Windows OCR pack used to read mission names."))
        curLang := this.settingsManager.Get("ocrLanguage", "en-US")
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setOcrLang := this.PageAdd(2, this.StyleEdit(g.Add("Edit",
            "x" (col2 + halfW - 16 - ctrlW) " y" (y + 20) " w" ctrlW " h28 -Theme Background" this.inputBgColor,
            curLang)))
        this.setOcrLang.OnEvent("Change", (*) => this.OnOcrLangChange())
        y += cardH + 12

        ; Debug | Overlay
        this.PageAdd(2, g.Add("Text", "x" col1 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Debug logging"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Verbose OCR and scenario messages in Logs."))
        rawDebug := this.settingsManager.Get("debugMode", false)
        debugVal := (rawDebug == true || rawDebug == 1 || rawDebug == "1" || rawDebug == "true") ? 1 : 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setDebugMode := this.PageAdd(2, g.Add("Checkbox",
            "x" (col1 + halfW - 16 - 110) " y" (y + 22) " w110 h22 Checked" debugVal, "Enabled"))
        this.setDebugMode.Value := debugVal
        this.setDebugMode.OnEvent("Click", (*) => this.OnDebugModeChange())

        this.PageAdd(2, g.Add("Text", "x" col2 " y" y " w" halfW " h" cardH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" hintW " h18 BackgroundTrans", "Status overlay"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" hintW " h28 BackgroundTrans Wrap",
            "Top-of-screen info box with character and progress."))
        overlayVal := this.settingsManager.GetBool("showOverlay", true) ? 1 : 0
        g.SetFont("s10 cE4E4E7", "Segoe UI")
        this.setShowOverlay := this.PageAdd(2, g.Add("Checkbox",
            "x" (col2 + halfW - 16 - 110) " y" (y + 22) " w110 h22 Checked" overlayVal, "Enabled"))
        this.setShowOverlay.Value := overlayVal
        this.setShowOverlay.OnEvent("Click", (*) => this.OnShowOverlayChange())
        y += cardH + 12

        ; Keybinds | Database
        keybindH := 124
        this.PageAdd(2, g.Add("Text", "x" col1 " y" y " w" halfW " h" keybindH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 8) " w180 h18 BackgroundTrans", "Keybinds"))
        this.AddTextButton(2, col1 + halfW - 16 - 64, y + 6, 64, 24, "Reset", (*) => this.OnResetKeybinds())
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 30) " w" (halfW - 32) " h14 BackgroundTrans",
            "Click a bind, then press a key. Esc cancels."))
        bindW := 140
        bindX := col1 + halfW - 16 - bindW
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 50) " w180 h18 BackgroundTrans", "Start orchestration"))
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 72) " w180 h18 BackgroundTrans", "Show dashboard"))
        this.PageAdd(2, g.Add("Text", "x" (col1 + 16) " y" (y + 94) " w180 h18 BackgroundTrans", "Exit"))
        startKey := this.settingsManager.Get("hotkeyStart", "Home")
        toggleKey := this.settingsManager.Get("hotkeyToggleGui", "Delete")
        exitKey := this.settingsManager.Get("hotkeyExit", "Pause")
        this.setHotkeyStart := this.AddTextButton(2, bindX, y + 48, bindW, 22,
            this.FormatHotkeyName(startKey), (*) => this.CaptureHotkey("hotkeyStart"))
        this.setHotkeyToggle := this.AddTextButton(2, bindX, y + 70, bindW, 22,
            this.FormatHotkeyName(toggleKey), (*) => this.CaptureHotkey("hotkeyToggleGui"))
        this.setHotkeyExit := this.AddTextButton(2, bindX, y + 92, bindW, 22,
            this.FormatHotkeyName(exitKey), (*) => this.CaptureHotkey("hotkeyExit"))

        this.PageAdd(2, g.Add("Text", "x" col2 " y" y " w" halfW " h" keybindH " Background" this.surfaceColor))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 10) " w" (halfW - 32) " h18 BackgroundTrans", "Database"))
        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 32) " w" (halfW - 32) " h28 BackgroundTrans Wrap",
            "Loaded Landsraad houses and missions."))
        houseCount := IsObject(this.stateManager) ? this.stateManager.allHousesList.Length : 0
        missionCount := IsObject(this.stateManager) ? this.stateManager.allMissionsList.Length : 0
        g.SetFont("s12 bold cEAB308", "Segoe UI")
        this.PageAdd(2, g.Add("Text", "x" (col2 + 16) " y" (y + 70) " w" (halfW - 32) " h28 BackgroundTrans",
            houseCount " houses   ·   " missionCount " missions"))
    }

    OnOcrLangChange() {
        if (this.isInitializing || !IsObject(this.setOcrLang))
            return

        curLang := Trim(this.setOcrLang.Value)
        if (curLang == "")
            curLang := "en-US"

        this.settingsManager.Set("ocrLanguage", curLang)
        this.ShowSessionHint()
    }

    OnCharacterNameCommit() {
        if (this.isInitializing || !IsObject(this.setCharacterName) || !IsObject(this.profileManager))
            return

        newName := Trim(this.setCharacterName.Value)
        currentName := this.profileManager.GetCurrentName()
        if (newName == "") {
            this.setCharacterName.Value := currentName
            return
        }
        if (StrLower(newName) == StrLower(currentName)) {
            this.setCharacterName.Value := currentName
            return
        }

        if !this.profileManager.RenameCurrent(newName, this.settingsManager) {
            this.setCharacterName.Value := currentName
            this.SetStatus("That character name is already used by another profile.")
            return
        }

        this.RefreshProfileDropdown(false)
        this.RefreshStatusOverlay()
        this.ShowSessionHint()
    }

    OnProfileChange() {
        if (this.isInitializing || !IsObject(this.setProfile) || !IsObject(this.profileManager))
            return

        chosenIdx := this.setProfile.Value
        if (chosenIdx == this.profileManager.GetCurrentIndex())
            return

        this.SaveMissionSelections()
        if !this.profileManager.SwitchToIndex(chosenIdx, this.stateManager, this.settingsManager) {
            this.RefreshProfileDropdown()
            this.SetStatus("Could not switch profile.")
            return
        }

        this.ApplyLoadedProfileToUi()
        this.SetStatus("Switched to " this.profileManager.GetCurrentName() ".")
    }

    OnNewProfile() {
        if (this.isInitializing || !IsObject(this.profileManager))
            return

        result := InputBox("Enter a character name for the new profile.", "New profile", "w360 h140", "")
        if (result.Result != "OK")
            return

        newName := Trim(result.Value)
        if (newName == "") {
            this.SetStatus("Character name cannot be empty.")
            return
        }

        this.SaveMissionSelections()
        if !this.profileManager.CreateProfile(newName, this.stateManager, this.settingsManager) {
            this.SetStatus("A profile with that name already exists.")
            return
        }

        this.ApplyLoadedProfileToUi()
        this.SetStatus("Created profile " this.profileManager.GetCurrentName() ".")
    }

    OnResetProfile() {
        if (this.isInitializing || !IsObject(this.profileManager) || !IsObject(this.settingsManager))
            return
        if !this.profileManager.ResetCurrent(this.stateManager, this.settingsManager) {
            this.SetStatus("Could not reset this profile.")
            return
        }
        this.settingsManager.ApplySharedDefaults()
        this.ApplyLoadedProfileToUi()
        this.RefreshSettingsControls()
        this.ShowSessionHint()
        this.Log("Profile reset to defaults.")
    }

    OnResetKeybinds() {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return
        this.settingsManager.ResetHotkeys()
        ApplyAppHotkeys()
        this.RefreshHotkeyDisplay()
        this.ShowSessionHint()
        this.Log("Keybinds reset to Home, Delete, and Pause.")
    }

    RefreshSettingsControls() {
        wasInit := this.isInitializing
        this.isInitializing := true

        if IsObject(this.setCharacterName)
            this.setCharacterName.Value := this.settingsManager.Get("characterName", "player")
        if IsObject(this.setGuildName)
            this.setGuildName.Value := this.settingsManager.Get("guildName", "wowza")
        if IsObject(this.setFaction) {
            faction := this.settingsManager.Get("faction", "Atreides")
            if (faction = "Harkonnen")
                this.setFaction.Choose(2)
            else
                this.setFaction.Choose(1)
        }
        if IsObject(this.setDebugMode) {
            debugOn := this.settingsManager.GetBool("debugMode", false)
            this.setDebugMode.Value := debugOn ? 1 : 0
            if IsObject(this.logger)
                this.logger.SetDebug(debugOn)
        }
        if IsObject(this.setShowOverlay) {
            showOverlay := this.settingsManager.GetBool("showOverlay", true)
            this.setShowOverlay.Value := showOverlay ? 1 : 0
            global statusOverlayInst
            if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
                statusOverlayInst.ApplyVisibility(showOverlay)
        }

        this.RefreshProfileDropdown()
        this.RefreshStatsDisplay()
        this.RefreshStatusOverlay()
        this.isInitializing := wasInit
    }

    RefreshStatsDisplay() {
        abandons := 0
        accepts := 0
        if IsObject(this.stateManager) {
            if this.stateManager.HasMethod("GetStat") {
                abandons := this.stateManager.GetStat("guildAbandons")
                accepts := this.stateManager.GetStat("targettedAccepts")
            }
        }
        if IsObject(this.statsAbandons)
            this.statsAbandons.Text := abandons
        if IsObject(this.statsAccepts)
            this.statsAccepts.Text := accepts
    }

    RefreshProfileDropdown(updateNameEdit := true) {
        if !IsObject(this.setProfile) || !IsObject(this.profileManager)
            return

        wasInit := this.isInitializing
        this.isInitializing := true
        names := this.profileManager.GetProfileNames()
        this.setProfile.Delete()
        if (names.Length > 0)
            this.setProfile.Add(names)
        this.setProfile.Choose(this.profileManager.GetCurrentIndex())
        if (updateNameEdit && IsObject(this.setCharacterName))
            this.setCharacterName.Value := this.profileManager.GetCurrentName()
        this.isInitializing := wasInit
    }

    ApplyLoadedProfileToUi() {
        this.activeSlotIdx := 0
        this.RestoreMissionSelections()
        if IsObject(this.panelLabel)
            this.panelLabel.Text := "Select a house cell to assign missions"
        loop 3 {
            if (this.mRow.Length < A_Index)
                continue
            row := this.mRow[A_Index]
            row.ddl.Delete()
            row.ddl.Choose(0)
            row.ddl.Opt("+Disabled")
            row.clearEnabled := false
            this.SetTextButtonState(row.clearBtn, false)
        }
        this.RefreshProfileDropdown()
        this.RefreshStatsDisplay()
        if IsObject(this.userState)
            this.userState.ResetSession()

        global acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst, statusOverlayInst
        if IsSet(acceptMissionsScenarioInst) && IsObject(acceptMissionsScenarioInst) && acceptMissionsScenarioInst.HasMethod("ResetSession")
            acceptMissionsScenarioInst.ResetSession()
        if IsSet(acceptTargettedMissionsScenarioInst) && IsObject(acceptTargettedMissionsScenarioInst) && acceptTargettedMissionsScenarioInst.HasMethod("ResetSession")
            acceptTargettedMissionsScenarioInst.ResetSession()
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.RestoreSessionState()

        this.RefreshStatusOverlay()
        this.ShowSessionHint()
    }

    OnGuildNameChange() {
        if (this.isInitializing || !IsObject(this.setGuildName))
            return

        curGuild := Trim(this.setGuildName.Value)
        if (curGuild == "")
            curGuild := "wowza"

        this.settingsManager.Set("guildName", curGuild)
        this.ShowSessionHint()
    }

    OnFactionChange() {
        if (this.isInitializing || !IsObject(this.setFaction))
            return

        chosen := this.setFaction.Text
        if (chosen != "Atreides" && chosen != "Harkonnen")
            chosen := "Atreides"

        this.settingsManager.Set("faction", chosen)
        this.ShowSessionHint()
    }

    OnDebugModeChange() {
        if (this.isInitializing || !IsObject(this.setDebugMode))
            return

        debugEnabled := (this.setDebugMode.Value == 1)
        this.settingsManager.Set("debugMode", debugEnabled)

        if (IsObject(this.logger))
            this.logger.SetDebug(debugEnabled)

        this.ShowSessionHint()
    }

    OnShowOverlayChange() {
        if (this.isInitializing || !IsObject(this.setShowOverlay))
            return

        showOverlay := (this.setShowOverlay.Value == 1)
        this.settingsManager.Set("showOverlay", showOverlay)

        global statusOverlayInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.ApplyVisibility(showOverlay)

        this.ShowSessionHint()
    }

    GetHotkeyHeaderText() {
        startKey := "Home"
        toggleKey := "Delete"
        exitKey := "Pause"
        if IsObject(this.settingsManager) {
            startKey := this.settingsManager.Get("hotkeyStart", "Home")
            toggleKey := this.settingsManager.Get("hotkeyToggleGui", "Delete")
            exitKey := this.settingsManager.Get("hotkeyExit", "Pause")
        }
        return this.FormatHotkeyName(startKey) "  ·  start     "
            . this.FormatHotkeyName(toggleKey) "  ·  ui     "
            . this.FormatHotkeyName(exitKey) "  ·  exit"
    }

    FormatHotkeyName(hotkey) {
        raw := Trim(hotkey)
        if (raw == "")
            return ""
        mods := ""
        key := raw
        loop {
            first := SubStr(key, 1, 1)
            if (first == "^") {
                mods .= "Ctrl+"
                key := SubStr(key, 2)
            } else if (first == "!") {
                mods .= "Alt+"
                key := SubStr(key, 2)
            } else if (first == "+") {
                mods .= "Shift+"
                key := SubStr(key, 2)
            } else if (first == "#") {
                mods .= "Win+"
                key := SubStr(key, 2)
            } else
                break
        }
        if (key == "")
            return Trim(raw)
        return mods . key
    }

    RefreshHotkeyDisplay() {
        startKey := this.settingsManager.Get("hotkeyStart", "Home")
        toggleKey := this.settingsManager.Get("hotkeyToggleGui", "Delete")
        exitKey := this.settingsManager.Get("hotkeyExit", "Pause")
        if IsObject(this.setHotkeyStart)
            this.setHotkeyStart.Text := this.FormatHotkeyName(startKey)
        if IsObject(this.setHotkeyToggle)
            this.setHotkeyToggle.Text := this.FormatHotkeyName(toggleKey)
        if IsObject(this.setHotkeyExit)
            this.setHotkeyExit.Text := this.FormatHotkeyName(exitKey)
        if IsObject(this.headerHotkeys)
            this.headerHotkeys.Text := this.GetHotkeyHeaderText()
    }

    GetHotkeyFallback(settingKey) {
        if (settingKey == "hotkeyStart")
            return "Home"
        if (settingKey == "hotkeyToggleGui")
            return "Delete"
        return "Pause"
    }

    GetHotkeyButton(settingKey) {
        if (settingKey == "hotkeyStart")
            return this.setHotkeyStart
        if (settingKey == "hotkeyToggleGui")
            return this.setHotkeyToggle
        return this.setHotkeyExit
    }

    GetOtherHotkeyValues(settingKey) {
        keys := []
        pairs := ["hotkeyStart", "hotkeyToggleGui", "hotkeyExit"]
        fallbacks := Map("hotkeyStart", "Home", "hotkeyToggleGui", "Delete", "hotkeyExit", "Pause")
        for _, key in pairs {
            if (key == settingKey)
                continue
            keys.Push(this.settingsManager.Get(key, fallbacks[key]))
        }
        return keys
    }

    CaptureHotkey(settingKey) {
        if (this.isInitializing || !IsObject(this.settingsManager))
            return

        otherKeys := this.GetOtherHotkeyValues(settingKey)
        targetBtn := this.GetHotkeyButton(settingKey)
        if IsObject(targetBtn)
            targetBtn.Text := "Press a key…"

        this.SetStatus("Press a key to rebind. Esc cancels.")

        global boundStartHotkey, boundExitHotkey, boundToggleHotkey
        if (boundStartHotkey != "") {
            try Hotkey(boundStartHotkey, "Off")
        }
        if (boundToggleHotkey != "") {
            try Hotkey(boundToggleHotkey, "Off")
        }
        if (boundExitHotkey != "") {
            try Hotkey(boundExitHotkey, "Off")
        }

        ih := InputHook("T12")
        ih.KeyOpt("{All}", "E")
        ih.KeyOpt("{LControl}{RControl}{LAlt}{RAlt}{LShift}{RShift}{LWin}{RWin}", "-E")
        ih.Start()
        ih.Wait()

        newKey := ""
        if (ih.EndReason == "EndKey" && ih.EndKey != "" && ih.EndKey != "Escape")
            newKey := ih.EndMods . ih.EndKey

        if (newKey == "") {
            ApplyAppHotkeys()
            this.RefreshHotkeyDisplay()
            this.SetStatus("Keybind unchanged.")
            return
        }

        for _, otherKey in otherKeys {
            if (StrLower(newKey) == StrLower(otherKey)) {
                ApplyAppHotkeys()
                this.RefreshHotkeyDisplay()
                this.SetStatus("That key is already used by another action.")
                return
            }
        }

        this.settingsManager.Set(settingKey, newKey)
        if !ApplyAppHotkeys() {
            this.settingsManager.Set(settingKey, this.GetHotkeyFallback(settingKey))
            ApplyAppHotkeys()
            this.RefreshHotkeyDisplay()
            this.SetStatus("That key cannot be used. Reverted.")
            return
        }

        this.RefreshHotkeyDisplay()
        this.ShowSessionHint()
    }

    ; -----------------------------------------------------------------------
    ; TAB 3 — LOGS
    ; -----------------------------------------------------------------------
    BuildLogsTab() {
        g := this.guiObj
        m := this.margin
        y := 124

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" m " y" y " w" (this.contentW - 140) " h24 BackgroundTrans", "Logs"))

        this.AddTextButton(3, m + this.contentW - 120, y - 2, 120, 28, "Clear", (*) => this.ClearLogs())

        g.SetFont("s8 c71717A", "Segoe UI")
        this.PageAdd(3, g.Add("Text", "x" m " y" (y + 28) " w" this.contentW " h16 BackgroundTrans",
            "Scenario and OCR output while the app is running."))

        logBox := this.PageAdd(3, this.StyleEdit(g.Add("Edit",
            "x" m " y" (y + 50) " w" this.contentW " h" (this.winH - y - 50 - 52)
            " +ReadOnly +HScroll -Wrap -Theme Background" this.inputBgColor, ""),
            "Consolas", 9))
        logBox.Opt("-Tabstop")
        if (IsObject(this.logger))
            this.logger.BindGui(this.guiObj, logBox)
    }

    ; -----------------------------------------------------------------------
    ; TAB 4 — ABOUT
    ; -----------------------------------------------------------------------
    BuildAboutTab() {
        g := this.guiObj
        m := this.margin
        y := 124
        cardW := this.contentW
        pad := 20
        innerW := cardW - pad * 2

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" cardW " h24 BackgroundTrans", "About"))
        y += 32

        brandH := 72
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" cardW " h" brandH " Background" this.surfaceColor))
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w4 h" brandH " BackgroundEAB308"))
        g.SetFont("s16 bold cEAB308", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" (m + pad) " y" (y + 10) " w" innerW " h24 BackgroundTrans",
            "DONSRAAD"))
        g.SetFont("s10 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" (m + pad) " y" (y + 38) " w" innerW " h20 BackgroundTrans",
            "Easy Mission Picker"))
        y += brandH + 12

        helpH := 336
        colGap := 28
        colW := (innerW - colGap) // 2
        leftX := m + pad
        rightX := leftX + colW + colGap
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" cardW " h" helpH " Background" this.surfaceColor))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" leftX " y" (y + 12) " w" innerW " h18 BackgroundTrans",
            "Help"))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" leftX " y" (y + 38) " w" colW " h18 BackgroundTrans",
            "How it works"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" leftX " y" (y + 60) " w" colW " h" (helpH - 72) " BackgroundTrans Wrap",
            "Landsraad missions are repeatable, but each specialization only shows a random handful of offers. "
            "You pick up to three missions you want to run over and over — ideally in the same area — and Donsraad "
            "keeps rolling the board until those three are sitting in your active slots.`n`n"
            "Refresh uses the guild disband method. Filler offers are accepted until your three slots are full. "
            "Disbanding the guild removes those actives and rolls new random offers for every specialization. "
            "Repeat until your targets appear, then accept them. Same jobs, same region, fewer loading screens."))

        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" rightX " y" (y + 38) " w" colW " h18 BackgroundTrans",
            "How to use"))
        g.SetFont("s8 cA1A1AA", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" rightX " y" (y + 60) " w" colW " h" (helpH - 72) " BackgroundTrans Wrap",
            "1.  Settings — Set character, guild name, and faction. Guild name is used when the app disbands to roll a new board.`n`n"
            "2.  Choose targets — On Mission Picker, click a house cell and assign up to 3 missions total. One specialization per cell, and it must match what that house offers. Green cells are your targets. Wrong specialization stops the run.`n`n"
            "3.  First setup — Have Dune: Awakening focused (Landsraad does not need to be open). Press Initialize, or press Start once, so Donsraad can read your current actives.`n`n"
            "4.  Run the picker — Press Start (default Home) until all targeted missions are active. After finishing them, press Start again to roll the next set.`n`n"
            "5.  Overlay — Status, character, and available / targeted stay at the top of the screen. The count turns green when all targets are active.`n`n"
            "6.  Dashboard — Window X hides the UI. Delete (default) brings it back. Pause (default) exits. Rebind all three in Settings → Keybinds."))
        y += helpH + 12

        devH := this.winH - y - 52
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w" cardW " h" devH " Background" this.surfaceColor))
        this.PageAdd(4, g.Add("Text", "x" m " y" y " w4 h" devH " BackgroundEAB308"))
        g.SetFont("s10 bold cEAB308", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" (m + pad) " y" (y + 14) " w" innerW " h20 BackgroundTrans",
            "Developer"))

        picSize := 88
        picX := m + pad
        picY := y + 44
        photoPath := A_ScriptDir "\ui\donis.png"
        textX := picX
        nameW := innerW
        if FileExist(photoPath) {
            this.PageAdd(4, g.Add("Text",
                "x" (picX - 2) " y" (picY - 2) " w" (picSize + 4) " h" (picSize + 4) " BackgroundEAB308"))
            this.PageAdd(4, g.Add("Picture",
                "x" picX " y" picY " w" picSize " h" picSize, photoPath))
            textX := picX + picSize + 16
            nameW := innerW - picSize - 16
        }

        g.SetFont("s12 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" textX " y" (y + 48) " w" nameW " h22 BackgroundTrans",
            "Deniz Özkan"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" textX " y" (y + 72) " w" nameW " h18 BackgroundTrans",
            "Dune: Awakening Landsraad companion"))
        g.SetFont("s9 bold cEAB308", "Segoe UI")
        siteLink := this.PageAdd(4, g.Add("Text", "x" textX " y" (y + 94) " w" nameW " h18 BackgroundTrans",
            "donis.dev"))
        siteLink.OnEvent("Click", (*) => this.OpenDeveloperSite())

        purposeY := y + 148
        g.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.PageAdd(4, g.Add("Text", "x" (m + pad) " y" purposeY " w" innerW " h18 BackgroundTrans",
            "Why this exists"))
        g.SetFont("s9 cA1A1AA", "Segoe UI")
        this.PageAdd(4, g.Add("Text",
            "x" (m + pad) " y" (purposeY + 22) " w" innerW " h72 BackgroundTrans Wrap",
            "Random Landsraad missions scatter you across the map. Each wrong contract is another loading screen "
            "and a slice of the session gone. Donsraad keeps you on missions in the same area so you can actually play. "
            "A workaround for Funcom's Landsraad design — random boards, long travel, too many loading screens."))

        g.SetFont("s8 c52525B", "Segoe UI")
        this.PageAdd(4, g.Add("Text",
            "x" (m + pad) " y" (y + devH - 28) " w" innerW " h16 BackgroundTrans",
            "© 2026 Deniz Özkan. All rights reserved."))
    }

    OpenDeveloperSite() {
        Run("https://donis.dev")
    }

    ClearLogs() {
        if (IsObject(this.logger))
            this.logger.Clear()
    }

    Log(message) {
        if (IsObject(this.logger))
            this.logger.Log(message)
    }

    RunInitializeScenario() {
        global statusOverlayInst

        if this.GetTargetedCount() < 1 {
            this.Log("[Initialize] No targetted missions are selected. Stopping.")
            this.SetStatus("No targetted missions")
            if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
                statusOverlayInst.SetState("No targetted missions")
            return
        }

        this.SetStatus("Running Initialize…")
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.SetState("Initialize")
        success := false

        if IsObject(this.initScenario) {
            success := this.initScenario.Execute(true)
        } else {
            global initializeScenarioInst
            if IsSet(initializeScenarioInst) && IsObject(initializeScenarioInst) {
                success := initializeScenarioInst.Execute(true)
            } else {
                initInst := InitializeScenario(this.stateManager, this.logger, "", this.userState)
                success := initInst.Execute(true)
            }
        }

        this.ShowSessionHint()
    }

    GetReadyLabel() {
        if IsObject(this.userState)
            return this.userState.GetReadyLabel()
        return "Waiting"
    }

    GetStatusBarText() {
        keyName := this.GetStartHotkeyName()
        if this.IsSessionReady()
            return "Press " keyName " to run mission picker"
        return "Press " keyName " to run first setup"
    }

    GetStartHotkeyName() {
        startKey := "Home"
        if IsObject(this.settingsManager)
            startKey := this.settingsManager.Get("hotkeyStart", "Home")
        name := this.FormatHotkeyName(startKey)
        return (name != "") ? name : "Home"
    }

    IsSessionReady() {
        return IsObject(this.userState) && this.userState.IsInitialized()
    }

    OnInitActionClick() {
        if this.IsSessionReady()
            this.ResetSessionState()
        else
            this.RunInitializeScenario()
    }

    ResetSessionState() {
        if IsObject(this.userState)
            this.userState.ResetSession()

        global acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst, statusOverlayInst
        if IsSet(acceptMissionsScenarioInst) && IsObject(acceptMissionsScenarioInst) && acceptMissionsScenarioInst.HasMethod("ResetSession")
            acceptMissionsScenarioInst.ResetSession()
        if IsSet(acceptTargettedMissionsScenarioInst) && IsObject(acceptTargettedMissionsScenarioInst) && acceptTargettedMissionsScenarioInst.HasMethod("ResetSession")
            acceptTargettedMissionsScenarioInst.ResetSession()
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.RestoreSessionState()

        this.ShowSessionHint()
        this.Log("Session reset. Run Initialize to start again.")
    }

    RefreshInitButton() {
        if !IsObject(this.initActionBtn)
            return
        if this.IsSessionReady() {
            this.initActionBtn.Text := "■   Ready"
            this.initActionBtn.Opt("Background991B1B")
            this.initActionBtn.SetFont("s9 bold cFEE2E2", "Segoe UI")
        } else {
            this.initActionBtn.Text := "▶   Initialize"
            this.initActionBtn.Opt("BackgroundEAB308")
            this.initActionBtn.SetFont("s9 bold c18181B", "Segoe UI")
        }
        this.initActionBtn.Redraw()
    }

    GetProgressText() {
        total := this.GetTargetedCount()
        if IsObject(this.userState)
            return this.userState.GetProgressText(total)
        return "0/0"
    }

    GetTargetedCount() {
        if !IsObject(this.stateManager)
            return 0
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return 0
        return targeted.Length
    }

    IsProgressComplete() {
        if IsObject(this.userState)
            return this.userState.IsProgressComplete(this.GetTargetedCount())
        return false
    }

    RefreshStatusProgress() {
        if !IsObject(this.statusProgress)
            return
        this.statusProgress.Text := this.GetProgressText()
        if this.IsProgressComplete()
            this.statusProgress.SetFont("s9 bold c4ADE80", "Segoe UI")
        else
            this.statusProgress.SetFont("s9 bold cA1A1AA", "Segoe UI")
    }

    ReloadState() {
        this.stateManager.LoadDatabases()
        this.stateManager.LoadPlayerState()
        this.SetStatus("Databases and state reloaded.")
    }

    SetStatus(msg) {
        if !IsObject(this.statusBar)
            return
        this.statusBar.Text := msg
        this.statusBar.SetFont("s9 bold cE4E4E7", "Segoe UI")
        this.RefreshStatusProgress()
        this.RefreshInitButton()
    }

    ShowSessionHint() {
        if !IsObject(this.statusBar)
            return
        this.statusBar.Text := this.GetStatusBarText()
        this.statusBar.SetFont("s9 bold cEAB308", "Segoe UI")
        this.statusBar.Redraw()
        this.RefreshStatusProgress()
        this.RefreshInitButton()
        global statusOverlayInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.RestoreSessionState()
    }

    Show() {
        try WinRestore("ahk_id " this.guiObj.Hwnd)
        this.guiObj.Show("w" this.winW " h" this.winH)
        this.ShowSessionHint()
    }

    Hide() {
        DarkSelect.Dismiss()
        this.guiObj.Minimize()
    }

    Toggle() {
        hwnd := this.guiObj.Hwnd
        if DllCall("IsIconic", "ptr", hwnd) || !DllCall("IsWindowVisible", "ptr", hwnd)
            this.Show()
        else
            this.Hide()
    }
}

/**
 * Dark themed dropdown. Native ComboBox/DropDownList stay white under Windows theming.
 */
class DarkSelect {
    static openInst := ""
    static popupGui := ""
    static popupList := ""

    face := ""
    ownerGui := ""
    host := ""
    items := []
    selectedIndex := 0
    enabled := true
    changeCallback := ""
    ignoreListChange := false
    caret := ""
    totalW := 0
    caretW := 24
    placeholder := "Select…"

    __New(guiObj, x, y, w, h, host, items := "") {
        this.ownerGui := guiObj
        this.host := host
        this.totalW := w
        this.items := []
        if (items is Array) {
            for _, item in items
                this.items.Push(item)
        }
        labelW := Max(40, w - this.caretW)
        guiObj.SetFont("s10 cFAFAFA", "Segoe UI")
        this.face := guiObj.Add("Text",
            "x" x " y" y " w" labelW " h" h " +0x200 Background" host.inputBgColor,
            this.FormatFaceText())
        this.face.OnEvent("Click", (*) => this.ToggleList())
        this.caret := guiObj.Add("Text",
            "x" (x + labelW) " y" y " w" this.caretW " h" h " Center +0x200 Background" host.inputBgColor,
            "▾")
        this.caret.OnEvent("Click", (*) => this.ToggleList())
        this.RefreshFace()
    }

    Text {
        get {
            if (this.selectedIndex < 1 || this.selectedIndex > this.items.Length)
                return ""
            return this.items[this.selectedIndex]
        }
    }

    Value {
        get => this.selectedIndex
    }

    OnEvent(eventName, callback) {
        if (eventName = "Change")
            this.changeCallback := callback
    }

    Delete() {
        this.items := []
        this.selectedIndex := 0
        this.RefreshFace()
    }

    Add(items) {
        if (items is Array) {
            for _, item in items
                this.items.Push(item)
        } else if (items != "")
            this.items.Push(items)
        this.RefreshFace()
    }

    Choose(index) {
        idx := Integer(index)
        if (idx < 0)
            idx := 0
        if (idx > this.items.Length)
            idx := 0
        this.selectedIndex := idx
        this.RefreshFace()
    }

    Opt(option) {
        if InStr(option, "-Disabled")
            this.enabled := true
        else if InStr(option, "Disabled")
            this.enabled := false
        this.RefreshFace()
    }

    FormatFaceText() {
        label := this.Text
        if (label == "")
            label := this.placeholder
        return "  " label
    }

    RefreshFace() {
        if !IsObject(this.face)
            return
        this.face.Text := this.FormatFaceText()
        if this.enabled {
            bg := this.host.inputBgColor
            fg := "FAFAFA"
        } else {
            bg := this.host.mutedColor
            fg := "71717A"
        }
        this.face.Opt("Background" bg)
        this.face.SetFont("s10 c" fg, "Segoe UI")
        this.face.Redraw()
        if IsObject(this.caret) {
            this.caret.Opt("Background" bg)
            this.caret.SetFont("s10 c" fg, "Segoe UI")
            this.caret.Redraw()
        }
    }

    ToggleList() {
        if !this.enabled
            return
        if (DarkSelect.openInst = this) {
            this.CloseList()
            return
        }
        this.OpenList()
    }

    OpenList() {
        if (this.items.Length == 0)
            return
        DarkSelect.Dismiss()
        DarkSelect.EnsurePopup()
        this.ignoreListChange := true
        DarkSelect.popupList.Delete()
        DarkSelect.popupList.Add(this.items)
        if (this.selectedIndex > 0)
            DarkSelect.popupList.Choose(this.selectedIndex)
        this.ignoreListChange := false

        this.face.GetPos(&fx, &fy, &fw, &fh)
        WinGetClientPos(&wx, &wy, , , this.ownerGui.Hwnd)
        rowH := 22
        listH := Min(this.items.Length, 12) * rowH + 6
        popupW := this.totalW > 0 ? this.totalW : fw
        DarkSelect.popupList.Move(0, 0, popupW, listH)
        DarkSelect.popupGui.Show("x" (wx + fx) " y" (wy + fy + fh) " w" popupW " h" listH)
        DarkSelect.openInst := this
    }

    CloseList() {
        if IsObject(DarkSelect.popupGui)
            DarkSelect.popupGui.Hide()
        if (DarkSelect.openInst = this)
            DarkSelect.openInst := ""
    }

    static Dismiss() {
        if IsObject(DarkSelect.openInst)
            DarkSelect.openInst.CloseList()
    }

    static EnsurePopup() {
        if IsObject(DarkSelect.popupGui)
            return
        pop := Gui("-Caption +ToolWindow +AlwaysOnTop")
        pop.BackColor := "3F3F46"
        pop.MarginX := 0
        pop.MarginY := 0
        pop.SetFont("s10 cFAFAFA", "Segoe UI")
        lb := pop.Add("ListBox", "x0 y0 w400 h220 -Theme Background3F3F46")
        try DllCall("uxtheme\SetWindowTheme", "ptr", lb.Hwnd, "wstr", "", "wstr", "")
        lb.OnEvent("Change", (*) => DarkSelect.OnPopupChange())
        DarkSelect.popupGui := pop
        DarkSelect.popupList := lb
    }

    static OnPopupChange() {
        inst := DarkSelect.openInst
        if !IsObject(inst) || inst.ignoreListChange
            return
        idx := DarkSelect.popupList.Value
        if (idx < 1)
            return
        inst.Choose(idx)
        inst.CloseList()
        if IsObject(inst.changeCallback)
            inst.changeCallback.Call(inst)
    }
}
