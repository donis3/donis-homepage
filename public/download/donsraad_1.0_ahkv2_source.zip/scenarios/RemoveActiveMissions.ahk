#Requires AutoHotkey v2.0+

/**
 * Remove Active Missions Scenario
 * Disbands the current guild (clearing all accepted missions), recreates it with the
 * configured guild name, then re-aligns to the player's faction on the Landsraad grid.
 *
 * Callable from any scenario via removeActiveMissionsScenarioInst.Execute().
 *
 * Flow:
 * 1. Press O to open the Guild tab (wait 100ms for fade-in).
 * 2. Click GuildDisbandingButtonClickCoords.
 * 3. Press Space twice to confirm disband.
 * 4. Wait 500ms, then confirm create_guild.png in CreateGuildButton.
 * 5. Press Enter to open the create-guild form (name field focused).
 * 6. Ctrl+Backspace to clear any existing name, then type settings.guildName.
 * 7. Press Enter to submit the form, then Space to confirm (server round-trip).
 * 8. Poll guild_disband.png in GuildDisbandingButton for up to 10s.
 *    Fail and stop if the button never appears.
 * 9. Press L to open the Landsraad / mission tab.
 * 10. Click LandsraadSubGridTabButton, then the faction Align Guild button, then Space.
 */
class RemoveActiveMissionsScenario {
    settingsManager := ""
    logger := ""
    anchorMatcher := ""
    stateManager := ""
    clientWaitMs := 100
    imageVariation := 30

    __New(settingsManagerInst := "", loggerInst := "", anchorMatcherInst := "", stateManagerInst := "") {
        this.settingsManager := settingsManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.stateManager := stateManagerInst
    }

    EnsureGameActive() {
        gameWindows := ["ahk_exe Dune-Win64-Shipping.exe", "ahk_exe Dune.exe", "Dune: Awakening", "Dune"]
        for _, winTitle in gameWindows {
            if WinExist(winTitle) {
                try {
                    WinActivate(winTitle)
                    WinWaitActive(winTitle, , 2)
                    Sleep(100)
                    return true
                }
            }
        }
        return false
    }

    /**
     * @param {Integer} abandonedCount - Active missions dropped by this disband. -1 reads player state.
     * @returns {Boolean} - True if guild was recreated and faction aligned, false on error.
     */
    Execute(abandonedCount := -1) {
        this.Debug("[RemoveActiveMissions] Starting scenario...")
        this.EnsureGameActive()

        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") {
            this.Log("[RemoveActiveMissions] Error: GameConstants GameUI is missing.")
            return false
        }
        uiConfig := GameConstants["GameUI"]

        guildName := this.GetGuildName()
        faction := this.GetFaction()
        this.Debug("[RemoveActiveMissions] Guild=`"" guildName "`" Faction=" faction)

        ; 1. Guild tab
        this.Debug("[RemoveActiveMissions] Opening Guild tab (O)...")
        InputHelper.SendGameKey("o")
        Sleep(1000)

        ; 2. Click disband
        if !this.ClickUiPoint(uiConfig, "GuildDisbandingButtonClickCoords", "disband button")
            return false
        InputHelper.WaitClient(this.clientWaitMs)

        ; 3. Confirm disband — Space twice
        InputHelper.SendGameKey("Space")
        InputHelper.WaitClient(this.clientWaitMs)
        InputHelper.SendGameKey("Space")
        Sleep(500)

        ; 4. Create guild button must be visible before opening the form
        if !this.WaitForUiImage(uiConfig, "CreateGuildButton", "create_guild.png", 5000) {
            this.Log("[RemoveActiveMissions] Error: Create guild button did not appear after disband. Stopping.")
            return false
        }
        this.Debug("[RemoveActiveMissions] Create guild button confirmed.")

        ; 5. Open create-guild form
        InputHelper.SendGameKey("Enter")
        InputHelper.WaitClient(this.clientWaitMs)

        ; 6. Clear name and type configured guild name
        InputHelper.SendGameModifierKey("Ctrl", "Backspace")
        InputHelper.WaitClient(this.clientWaitMs)
        InputHelper.SendGameModifierKey("Ctrl", "Backspace")
        InputHelper.WaitClient(this.clientWaitMs)
        InputHelper.SendGameText(guildName)
        InputHelper.WaitClient(this.clientWaitMs)

        ; 7. Submit form, then confirm (server waits after this)
        InputHelper.SendGameKey("Enter")
        InputHelper.WaitClient(this.clientWaitMs)
        this.Debug("[RemoveActiveMissions] Confirming guild create (Space). Waiting for server...")
        InputHelper.SendGameKey("Space")
        InputHelper.FastMove(0, 0)

        ; 8. Confirm server success via guild_disband.png in GuildDisbandingButton
        if !this.WaitForUiImage(uiConfig, "GuildDisbandingButton", "guild_disband.png", 10000) {
            this.Log("[RemoveActiveMissions] Error: Guild disband button was not confirmed within 10 seconds. Stopping.")
            return false
        }
        this.Debug("[RemoveActiveMissions] Guild recreate confirmed.")

        ; 9. Landsraad / mission tab
        this.Debug("[RemoveActiveMissions] Opening Landsraad tab (L)...")
        InputHelper.SendGameKey("l")
        Sleep(100)

        ; 10. House grid sub-tab, then align by faction
        if !this.ClickUiPoint(uiConfig, "LandsraadSubGridTabButton", "Landsraad grid sub-tab")
            return false
        InputHelper.WaitClient(this.clientWaitMs)

        alignKey := (StrLower(faction) == "harkonnen")
            ? "AlignGuildHarkonnenButtonClickCoords"
            : "AlignGuildAtreidesButtonClickCoords"
        if !this.ClickUiPoint(uiConfig, alignKey, "Align Guild (" faction ")")
            return false
        InputHelper.WaitClient(this.clientWaitMs)

        InputHelper.SendGameKey("Space")
        InputHelper.WaitClient(this.clientWaitMs)

        this.Log("[RemoveActiveMissions] Completed. Guild aligned to " faction ".")
        this.RecordGuildAbandon(abandonedCount)
        return true
    }

    RecordGuildAbandon(abandonedCount := -1) {
        count := Integer(abandonedCount)
        if (count < 0)
            count := this.GetActiveMissionCount()
        if (count < 1)
            return
        this.Log("[RemoveActiveMissions] Counting " count " abandoned mission(s).")
        if IsObject(this.stateManager) && this.stateManager.HasMethod("IncrementGuildAbandons")
            this.stateManager.IncrementGuildAbandons(count)
        else {
            global stateManagerInst
            if IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.HasMethod("IncrementGuildAbandons")
                stateManagerInst.IncrementGuildAbandons(count)
        }
    }

    GetActiveMissionCount() {
        sm := this.stateManager
        if !IsObject(sm) {
            global stateManagerInst
            if IsSet(stateManagerInst) && IsObject(stateManagerInst)
                sm := stateManagerInst
        }
        if !IsObject(sm) || !sm.HasMethod("GetActiveMissions")
            return 0
        active := sm.GetActiveMissions()
        if (active is Array)
            return active.Length
        return 0
    }

    GetGuildName() {
        if (IsObject(this.settingsManager))
            return this.settingsManager.Get("guildName", "wowza")
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("guildName", "wowza")
        return "wowza"
    }

    GetFaction() {
        faction := "Atreides"
        if (IsObject(this.settingsManager))
            faction := this.settingsManager.Get("faction", "Atreides")
        else {
            global settingsManagerInst
            if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
                faction := settingsManagerInst.Get("faction", "Atreides")
        }
        if (StrLower(faction) != "harkonnen")
            faction := "Atreides"
        return faction
    }

    ClickUiPoint(uiConfig, keyName, label) {
        if !uiConfig.Has(keyName) {
            this.Log("[RemoveActiveMissions] Error: " keyName " missing in GameConstants.")
            return false
        }
        cfg := uiConfig[keyName]
        pos := ResolutionManager().coords(cfg.x, cfg.y)
        this.Debug("[RemoveActiveMissions] Clicking " label " at (" pos.x ", " pos.y ")...")
        InputHelper.FastClick(pos.x, pos.y)
        return true
    }

    /**
     * Polls a GameConstants region for an anchor image until timeoutMs.
     */
    WaitForUiImage(uiConfig, regionKey, imageName, timeoutMs := 5000) {
        if !uiConfig.Has(regionKey) {
            this.Log("[RemoveActiveMissions] Error: " regionKey " missing in GameConstants.")
            return false
        }

        btn := uiConfig[regionKey]
        rm := ResolutionManager()
        pos := rm.coords(btn.x, btn.y)
        size := rm.dimensions(btn.w, btn.h)
        padding := 20
        searchArea := {
            x1: Max(0, pos.x - padding),
            y1: Max(0, pos.y - padding),
            x2: Min(A_ScreenWidth, pos.x + size.w + padding),
            y2: Min(A_ScreenHeight, pos.y + size.h + padding)
        }

        foundX := 0, foundY := 0
        this.Debug("[RemoveActiveMissions] Waiting up to " timeoutMs "ms for " imageName
            " in [" searchArea.x1 ", " searchArea.y1 ", " searchArea.x2 ", " searchArea.y2 "]...")

        startTime := A_TickCount
        while (A_TickCount - startTime < timeoutMs) {
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation) {
                this.Debug("[RemoveActiveMissions] " imageName " found at (" foundX ", " foundY ").")
                return true
            }
            Sleep(150)
        }
        return false
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
