#Requires AutoHotkey v2.0+

/**
 * Initialize Scenario
 * - Reads player state and saves it.
 * 
 * Flow:
 * 1. Searches for landsraad_button.png within the LandsraadTabButton coordinates defined in GameConstants.
 *    - 1-a: If not found, sends key "L" and waits 300ms to load.
 *    - 1-b: If found, logs confirmation that we are at the correct main tab.
 *    - 1-c: If still not found, stops scenario execution and logs that mission menu could not be opened.
 * 2. Reads active missions using the coordinates from gameconstants. There are 3 active mission slots each may contain a mission.
 * 3. If a mission is found, save it into player state as {missionName: "missionName", specialization: "specialization", isTargetted: true  | false}
 * 4. If there are no targetted missions, stop before touching the game (same as Master / Start keybind).
 * 5. If player has targetted missions, compare active missions in the player state. If all targetted missions are active, stop for now.
 */
class InitializeScenario {
    stateManager := ""
    logger := ""
    anchorMatcher := ""
    userState := ""

    __New(stateManagerInst := "", loggerInst := "", anchorMatcherInst := "", userStateInst := "") {
        this.stateManager := stateManagerInst
        this.logger := loggerInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
        this.userState := userStateInst
    }

    /**
     * Ensures the game window is active if it is running, or waits briefly if requested.
     */
    EnsureGameActive() {
        gameWindows := ["ahk_exe Dune-Win64-Shipping.exe", "ahk_exe Dune.exe", "Dune: Awakening", "Dune"]
        for _, winTitle in gameWindows {
            if WinExist(winTitle) {
                try {
                    WinActivate(winTitle)
                    WinWaitActive(winTitle, , 2)
                    Sleep(100)
                    return true
                }
            }
        }
        return false
    }

    /**
     * Executes the initialization scenario.
     * @param {Boolean} closeMenu - When true (Initialize button), send Esc after reading actives. Master leaves the menu open for the rest of first-run.
     * @returns {Boolean} - True if initialize completed (or all targeted missions are already active), false on error / no targets.
     */
    Execute(closeMenu := false) {
        this.Debug("[Initialize] Starting initialization scenario...")

        if !this.HasTargetedMissions() {
            this.Log("[Initialize] No targetted missions are selected. Stopping.")
            return false
        }

        ; Ensure game window is focused if present
        this.EnsureGameActive()

        ; Step 1: Read and persist player state
        if IsObject(this.stateManager) {
            this.stateManager.LoadPlayerState()
            this.stateManager.SavePlayerState()
            this.Debug("[Initialize] Player state verified and saved.")
        }

        ; Step 2: Retrieve LandsraadTabButton bounds from GameConstants
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has(
            "LandsraadTabButton") {
            this.Log("[Initialize] Error: LandsraadTabButton configuration missing in GameConstants.")
            return false
        }

        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        rm := ResolutionManager()
        pos := rm.coords(tabBtnConfig.x, tabBtnConfig.y)
        size := rm.dimensions(tabBtnConfig.w, tabBtnConfig.h)

        ; Search area with padding
        searchPadding := 20
        searchArea := {
            x1: Max(0, pos.x - searchPadding),
            y1: Max(0, pos.y - searchPadding),
            x2: Min(A_ScreenWidth, pos.x + size.w + searchPadding),
            y2: Min(A_ScreenHeight, pos.y + size.h + searchPadding)
        }

        imageName := "landsraad_button.png"
        variation := 30
        foundX := 0, foundY := 0

        this.Debug("[Initialize] Searching for " imageName " in region [" searchArea.x1 ", " searchArea.y1 ", " searchArea
            .x2 ", " searchArea.y2 "]...")

        found := this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, variation)

        ; 1-a: If button is not found, send key "L" with hold duration and wait for UI transition
        if (!found) {
            this.Debug("[Initialize] Landsraad tab button not found. Sending key 'L' (game input)...")
            InputHelper.SendGameKey("l", 60)

            ; Poll for button to appear during menu transition (up to 1200ms)
            startTime := A_TickCount
            while (A_TickCount - startTime < 1200) {
                Sleep(150)
                if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, variation) {
                    found := true
                    break
                }
            }
        }

        ; 1-b: If button is found
        if (found) {
            this.Debug("[Initialize] Landsraad button detected at (" foundX ", " foundY "). Confirmed on correct main tab."
            )

            ; Click on subtab (770, 180) in reference coordinates
            subTabConfig := GameConstants["GameUI"].Has("LandsraadSubTabButton")
                ? GameConstants["GameUI"]["LandsraadSubTabButton"]
                : { x: 770, y: 180 }
            subPos := rm.coords(subTabConfig.x, subTabConfig.y)
            this.Debug("[Initialize] Clicking Landsraad sub-tab at (" subPos.x ", " subPos.y ")...")
            InputHelper.FastClick(subPos.x, subPos.y)
            Sleep(400)

            success := this.ProcessActiveMissions()
            if (success) {
                this.MarkInitialized()
                if (closeMenu)
                    this.MarkFirstHomeDone()
            }
            if (closeMenu)
                this.CloseOpenMenu()
            return success
        }

        ; 1-c: If still not found, stop and log error
        this.Log("[Initialize] Error: Landsraad tab button could not be found. Mission menu could not be opened.")
        return false
    }

    MarkInitialized() {
        if IsObject(this.userState)
            this.userState.SetInitialized(true)
    }

    MarkFirstHomeDone() {
        if IsObject(this.userState)
            this.userState.MarkFirstHomeDone()
    }

    CloseOpenMenu() {
        this.Debug("[Initialize] Sending Esc to close the open menu.")
        InputHelper.SendGameKey("Esc")
        InputHelper.WaitClient(100)
    }

    /**
     * Steps 2-5: OCR the 3 active mission slots, persist them, then compare against targeted missions.
     */
    ProcessActiveMissions() {
        if !IsObject(this.stateManager) {
            this.Log("[Initialize] Error: State manager is unavailable; cannot process active missions.")
            return false
        }

        this.Debug("[Initialize] Reading active mission slots...")
        ocrResults := this.ReadActiveMissions()
        targetedMissions := this.stateManager.GetTargetedMissions()
        targetedNames := Map()
        for _, targeted in targetedMissions {
            if (targeted.missionName != "")
                targetedNames[StrLower(targeted.missionName)] := true
        }

        activeMissions := []
        for _, result in ocrResults {
            if (result.matchedName == "" || result.confidence < 0.4)
                continue

            isTargetted := targetedNames.Has(StrLower(result.matchedName))
            activeMissions.Push({
                missionName: result.matchedName,
                specialization: result.specialization,
                isTargetted: isTargetted
            })
        }

        this.stateManager.SaveActiveMissions(activeMissions)

        if (activeMissions.Length == 0)
            this.Log("[Initialize] No active missions detected in the 3 slots.")
        else {
            this.Debug("[Initialize] Saved " activeMissions.Length " active mission(s) to player state.")
            for _, mission in activeMissions {
                targetInfo := mission.isTargetted ? "targetted" : "not targetted"
                specInfo := mission.specialization != "" ? " [" mission.specialization "]" : ""
                this.Debug("[Initialize] Active: `"" mission.missionName "`"" specInfo " (" targetInfo ")")
            }
        }

        if !this.HasTargetedMissions() {
            this.Log("[Initialize] No targetted missions are selected. Stopping.")
            this.SetAvailableTargetedCount(0)
            return false
        }

        missing := []
        for _, targeted in targetedMissions {
            foundActive := false
            for _, active in activeMissions {
                if (StrLower(active.missionName) == StrLower(targeted.missionName)) {
                    foundActive := true
                    break
                }
            }
            if (!foundActive)
                missing.Push(targeted.missionName)
        }

        if (missing.Length == 0) {
            this.Log("[Initialize] All targetted missions are already active. Stopping for now.")
            this.SetAvailableTargetedCount(targetedMissions.Length)
            return true
        }

        this.Log("[Initialize] " missing.Length " targetted mission(s) are not active: " this.JoinNames(missing) ".")
        this.SetAvailableTargetedCount(0)
        return true
    }

    SetAvailableTargetedCount(count) {
        if IsObject(this.userState)
            this.userState.SetAvailableTargetedCount(count)
        global statusOverlayInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.Refresh()
    }

    /**
     * Calculates screen bounding boxes for the 3 vertical active mission slots.
     */
    GetActiveMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("ActiveMissionFirstPosition") || !uiConfig.Has("ActiveMissionTextSize")
            return []

        firstPos := uiConfig["ActiveMissionFirstPosition"]
        textSize := uiConfig["ActiveMissionTextSize"]
        spacing := uiConfig.Has("ActiveMissionSpacing") ? uiConfig["ActiveMissionSpacing"] : 0

        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            refX := firstPos.x
            refY := firstPos.y + ((missionIndex - 1) * spacing)
            refW := textSize.x
            refH := textSize.y

            pos := rm.coords(refX, refY)
            size := rm.dimensions(refW, refH)

            boxes.Push({
                index: missionIndex,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    /**
     * Reads text inside each active mission slot via WinRT OCR and matches against the mission DB.
     */
    ReadActiveMissions() {
        boxes := this.GetActiveMissionBoxes()
        if (boxes.Length == 0) {
            this.Log("[Initialize] Error: Unable to determine active mission box positions from GameConstants.")
            return []
        }

        candidates := this.GetCandidateMissions()
        ocrLang := this.GetOcrLanguage()
        results := []

        this.Debug("[Initialize] Scanning " boxes.Length " active mission slots...")

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                rawText := ocrResult.text
                normalized := Ocr.NormalizeText(rawText)
                matched := Ocr.FindBestMatch(normalized, candidates)

                matchedName := matched.matchedName
                specialization := ""
                if (IsObject(matched.item) && matched.item.HasOwnProp("specialization"))
                    specialization := matched.item.specialization
                else if (IsObject(matched.item) && matched.item is Map && matched.item.Has("specialization"))
                    specialization := matched.item["specialization"]
                else if (IsObject(this.stateManager))
                    specialization := this.stateManager.GetMissionSpecialization(matchedName)

                results.Push({
                    index: box.index,
                    matchedName: (matched.confidence >= 0.4) ? matchedName : "",
                    specialization: specialization,
                    confidence: matched.confidence,
                    normalizedText: normalized
                })

                if (matchedName != "" && matched.confidence >= 0.4) {
                    specInfo := specialization != "" ? " [" specialization "]" : ""
                    this.Debug("[Initialize] Slot " box.index ": `"" matchedName "`"" specInfo " (Raw: `"" normalized "`")")
                } else if (normalized != "") {
                    this.Debug("[Initialize] Slot " box.index ": `"" normalized "`" (Unrecognized)")
                } else {
                    this.Debug("[Initialize] Slot " box.index ": (Empty / No text detected)")
                }
            } catch as err {
                this.Debug("[Initialize] Error reading Slot " box.index ": " err.Message)
                results.Push({
                    index: box.index,
                    matchedName: "",
                    specialization: "",
                    confidence: 0.0,
                    normalizedText: ""
                })
            }
        }

        return results
    }

    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        return []
    }

    GetOcrLanguage() {
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            return settingsManagerInst.Get("ocrLanguage", "en-US")
        return "en-US"
    }

    HasTargetedMissions() {
        if !IsObject(this.stateManager)
            return false
        targeted := this.stateManager.GetTargetedMissions()
        return (targeted is Array) && targeted.Length > 0
    }

    JoinNames(names) {
        joined := ""
        for idx, name in names {
            if (idx > 1)
                joined .= ", "
            joined .= name
        }
        return joined
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
