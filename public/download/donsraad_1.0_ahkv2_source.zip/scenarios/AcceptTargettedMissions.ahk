#Requires AutoHotkey v2.0+

/**
 * Accept Targetted Missions Scenario
 * Same house loop as AcceptMissions, but accepts the targetted offers (Space).
 * Runs once per cycle after missingTargettedMissionCount is 0.
 *
 * After each house's targetted missions are accepted, shows a Success label.
 *
 * Callable via acceptTargettedMissionsScenarioInst.Execute().
 *
 * Assumes the Landsraad house grid tab is already open.
 */
class AcceptTargettedMissionsScenario extends AcceptMissionsScenario {
    Execute() {
        this.lastStatus := this.MakeStatus()
        this.ResetSession()
        this.Debug("[AcceptTargettedMissions] Starting scenario...")
        this.EnsureGameActive()

        if !IsObject(this.stateManager) {
            this.SetStatus(0, "State manager is unavailable.")
            this.Log("[AcceptTargettedMissions] Error: State manager is unavailable.")
            return false
        }

        targeted := this.stateManager.GetTargetedMissions()
        if (targeted.Length == 0) {
            this.SetStatus(0, "No targetted missions were found.")
            this.Log("[AcceptTargettedMissions] No targetted missions were found. Stopping.")
            return false
        }

        houses := this.GetTargetedHouses(targeted)
        acceptedCount := 0
        maxActive := 3
        this.Debug("[AcceptTargettedMissions] Looping " houses.Length " targetted house(s).")

        for houseIdx, house in houses {
            if (acceptedCount >= maxActive) {
                this.Log("[AcceptTargettedMissions] Reached " maxActive " accepted missions. Stopping.")
                break
            }

            this.Debug("[AcceptTargettedMissions] House cell " house.gridLocation
                " (row " house.gridRow ", col " house.gridCol ").")

            if !this.OpenHouse(house) {
                this.FailOfferWindow(house)
                this.SetStatus(0, "Offer window did not open at grid " house.gridLocation ".", acceptedCount)
                return false
            }

            offered := this.ReadOfferedMissions()
            recognized := this.GetRecognizedMissions(offered)
            this.LogOfferedMissions(offered)

            if (recognized.Length != 3) {
                this.FailMissionRead(house)
                this.SetStatus(0, "Failed to read offered missions at grid " house.gridLocation ".", acceptedCount)
                return false
            }

            if !this.HouseSpecializationMatches(house, recognized) {
                this.SetStatus(0, "Wrong specialization", acceptedCount)
                return false
            }

            targetedOffers := this.GetTargetedOffers(recognized, house)
            if (targetedOffers.Length == 0) {
                this.Log("[AcceptTargettedMissions] No targetted offers on house " house.gridLocation ". Stopping.")
                this.CloseOfferWindowIfOpen()
                this.SetStatus(0, "No targetted offers at grid " house.gridLocation ".", acceptedCount)
                return false
            }

            this.Debug("[AcceptTargettedMissions] " targetedOffers.Length " targetted offer(s) on house "
                house.gridLocation ".")

            for offerIdx, offer in targetedOffers {
                if (acceptedCount >= maxActive)
                    break

                if (offerIdx > 1) {
                    this.Debug("[AcceptTargettedMissions] Re-opening house " house.gridLocation
                        " for the next targetted mission.")
                    if !this.OpenHouse(house) {
                        this.FailOfferWindow(house)
                        this.SetStatus(0, "Offer window did not open at grid " house.gridLocation ".", acceptedCount)
                        return false
                    }
                }

                this.Log("[AcceptTargettedMissions] Accepting targetted " offer.matchedName
                    " on house " house.gridLocation " slot " offer.index ".")
                this.ClickMissionOffer(offer)
                InputHelper.SendGameKey("Space")
                this.MarkAccepted(offer.matchedName)
                acceptedCount := this.sessionAcceptedCount
                this.RecordTargettedAccept()
                this.Debug("[AcceptTargettedMissions] Accepted count: " acceptedCount "/" maxActive ".")
                InputHelper.WaitClient(this.clientWaitMs)
                InputHelper.FastMove(0, 0)
                Sleep(this.houseOpenWaitMs)
            }

            this.CloseOfferWindowIfOpen()
            this.ShowHouseSuccess(house)
        }

        this.SetStatus(0, "", acceptedCount, acceptedCount)
        this.Log("[AcceptTargettedMissions] Finished. accepted=" acceptedCount ".")
        return true
    }

    GetTargetedOffers(recognized, house) {
        houseNames := Map()
        if IsObject(house.missions) {
            for _, mission in house.missions {
                if (mission.missionName != "")
                    houseNames[StrLower(mission.missionName)] := true
            }
        }

        targetedOffers := []
        for _, entry in recognized {
            if !houseNames.Has(StrLower(entry.matchedName))
                continue
            if this.IsAlreadyAccepted(entry.matchedName)
                continue
            targetedOffers.Push(entry)
        }
        return targetedOffers
    }

    RecordTargettedAccept() {
        if IsObject(this.stateManager) && this.stateManager.HasMethod("IncrementTargettedAccepts")
            this.stateManager.IncrementTargettedAccepts(1)
    }

    ShowHouseSuccess(house) {
        this.Log("[AcceptTargettedMissions] Success: house " house.gridLocation ".")
        this.SetOverlayState("Success")
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus("Success")
    }

    Log(message) {
        message := StrReplace(message, "[AcceptMissions]", "[AcceptTargettedMissions]")
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        message := StrReplace(message, "[AcceptMissions]", "[AcceptTargettedMissions]")
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
