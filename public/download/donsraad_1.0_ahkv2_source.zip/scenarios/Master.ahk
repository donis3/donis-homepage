#Requires AutoHotkey v2.0+

/**
 * Master orchestration scenario.
 * Home runs this.
 *
 * First Home press:
 *   Initialize if the session is still waiting, then RemoveActiveMissions if
 *   the player has active missions that are missing targetted ones.
 *
 * Later Home presses:
 *   Skip Initialize. Run the accept sequence again each time Home is pressed
 *   (missions may have been cleared in-game).
 *   Loop AcceptMissions until missingTargettedMissionCount is 0, then run
 *   AcceptTargettedMissions once.
 *
 * Callable via masterScenarioInst.Execute().
 */
class MasterScenario {
    stateManager := ""
    userState := ""
    logger := ""
    initializeScenario := ""
    removeActiveMissionsScenario := ""
    acceptMissionsScenario := ""
    acceptTargettedMissionsScenario := ""
    anchorMatcher := ""
    imageVariation := 30

    __New(stateManagerInst := "", userStateInst := "", loggerInst := "", initializeScenarioInst := "", removeActiveMissionsScenarioInst := "", acceptMissionsScenarioInst := "", acceptTargettedMissionsScenarioInst := "", anchorMatcherInst := "") {
        this.stateManager := stateManagerInst
        this.userState := userStateInst
        this.logger := loggerInst
        this.initializeScenario := initializeScenarioInst
        this.removeActiveMissionsScenario := removeActiveMissionsScenarioInst
        this.acceptMissionsScenario := acceptMissionsScenarioInst
        this.acceptTargettedMissionsScenario := acceptTargettedMissionsScenarioInst
        this.anchorMatcher := anchorMatcherInst ? anchorMatcherInst : AnchorMatcher(A_ScriptDir)
    }

    Execute() {
        this.Debug("[Master] Starting orchestration...")
        this.SetOverlayState("Orchestrate")
        this.SetGuiStatus("Orchestrate")

        if !IsObject(this.stateManager) {
            this.StopWithError("State manager is unavailable.")
            return false
        }

        if !this.HasTargetedMissions() {
            this.Log("[Master] No targetted missions are selected. Stopping.")
            this.StopWithMessage("No targetted missions")
            return false
        }

        if this.IsFirstHome()
            return this.ExecuteFirstRun()
        return this.ExecuteLaterRun()
    }

    /**
     * First Home: Initialize if needed, then clear leftover actives if they
     * are not the targetted set. Stops so the player can press Home again.
     */
    ExecuteFirstRun() {
        this.Debug("[Master] First Home run.")

        if !this.EnsureInitialized()
            return false

        if this.HasActiveMissions() && this.AllTargetedMissionsAreActive() {
            this.MarkFirstHomeDone()
            this.CloseOpenMenu()
            return this.TargetAchieved()
        }

        if this.HasActiveMissions() && !this.AllTargetedMissionsAreActive() {
            this.Log("[Master] Active missions are missing targetted ones. Removing actives...")
            if !this.RunRemoveActiveMissions()
                return false
        } else {
            this.Debug("[Master] No leftover active missions to remove.")
        }

        this.MarkFirstHomeDone()
        this.CloseOpenMenu()
        this.SetAvailableCount(0)
        this.Log("[Master] First run complete. Press the Start key to continue.")
        this.RestoreSessionState()
        return true
    }

    /**
     * Later Home presses: skip Initialize and run the accept cycle again.
     */
    ExecuteLaterRun() {
        this.Debug("[Master] Later Home run. Skipping Initialize.")

        if !this.HasTargetedMissions() {
            this.Log("[Master] No targetted missions are selected. Stopping.")
            this.StopWithMessage("No targetted missions")
            return false
        }

        this.SetAvailableCount(0)
        this.EnsureLandsraadTabVisible()
        return this.RunAcceptMissionsUntilAvailable()
    }

    /**
     * Loop AcceptMissions until missingTargettedMissionCount is 0.
     * Global accept cap is 3; hitting it runs RemoveActiveMissions (max 50).
     * Loop counters reset each time this sequence starts.
     */
    RunAcceptMissionsUntilAvailable() {
        if !IsObject(this.acceptMissionsScenario) {
            this.StopWithError("Accept missions error")
            return false
        }

        maxRemoves := 50
        maxAcceptPasses := 100
        removeCount := 0
        acceptPass := 0
        totalCount := this.GetTargetedCount()
        missing := totalCount

        this.Log("[Master] Starting accept sequence. Loop counts reset. targetted="
            totalCount ".")
        if this.acceptMissionsScenario.HasMethod("ResetSession")
            this.acceptMissionsScenario.ResetSession()
        this.ShowAcceptProgress(missing, totalCount)

        if this.HasActiveMissions() && !this.AllTargetedMissionsAreActive() {
            this.Log("[Master] Clearing leftover active missions before accept loop...")
            if !this.RunRemoveActiveMissions(false)
                return false
            removeCount++
            this.EnsureLandsraadTabVisible()
        }

        loop {
            if (missing == 0)
                break

            if (acceptPass >= maxAcceptPasses) {
                this.Log("[Master] Accept Missions loop exceeded " maxAcceptPasses " passes. Stopping.")
                this.StopWithError("Accept missions loop exceeded 100")
                return false
            }

            acceptPass++
            this.ShowAcceptProgress(missing, totalCount)
            this.Debug("[Master] Accept Missions pass " acceptPass
                " (removes " removeCount "/" maxRemoves ").")

            success := this.acceptMissionsScenario.Execute()
            status := this.acceptMissionsScenario.GetStatus()
            if (!success || (IsObject(status) && status.error != "")) {
                errText := (IsObject(status) && status.error != "") ? status.error : "Accept missions error"
                this.Log("[Master] Accept Missions failed: " errText)
                this.StopWithError(errText)
                return false
            }

            missing := IsObject(status) ? status.missingTargettedMissionCount : 0
            accepted := (IsObject(status) && status.HasOwnProp("acceptedCount")) ? status.acceptedCount : 0
            newAccepted := (IsObject(status) && status.HasOwnProp("newAcceptedCount")) ? status.newAcceptedCount : 0
            this.ShowAcceptProgress(missing, totalCount)
            this.Log("[Master] Pass " acceptPass ": missing=" missing "/" totalCount
                " accepted=" accepted " newAccepted=" newAccepted ".")

            if (missing == 0)
                break

            shouldRemove := (accepted >= 3) || (newAccepted == 0 && accepted > 0)
            if (shouldRemove) {
                if (removeCount >= maxRemoves) {
                    this.Log("[Master] RemoveActiveMissions exceeded " maxRemoves " runs. Stopping.")
                    this.StopWithError("Remove missions loop exceeded 50")
                    return false
                }

                if (accepted >= 3)
                    this.Log("[Master] Global accept cap (3) reached. Removing actives ("
                        (removeCount + 1) "/" maxRemoves ")...")
                else
                    this.Log("[Master] No new unique missions left to accept. Removing actives ("
                        (removeCount + 1) "/" maxRemoves ")...")

                if !this.RunRemoveActiveMissions(false, accepted)
                    return false
                if this.acceptMissionsScenario.HasMethod("ResetSession")
                    this.acceptMissionsScenario.ResetSession()
                removeCount++
                this.EnsureLandsraadTabVisible()
            }
        }

        this.Log("[Master] missingTargettedMissionCount=0. Running Accept Targetted Missions...")
        return this.RunAcceptTargettedMissions(totalCount)
    }

    /**
     * One pass: accept the targetted offers on each targetted house.
     */
    RunAcceptTargettedMissions(totalCount) {
        if !IsObject(this.acceptTargettedMissionsScenario) {
            this.StopWithError("Accept targetted missions error")
            return false
        }

        this.SetAvailableCount(totalCount)
        this.SetOverlayState("Accept targetted")
        this.SetGuiStatus("Accept targetted")

        if !this.acceptTargettedMissionsScenario.Execute() {
            this.Log("[Master] Accept Targetted Missions failed. Stopping.")
            this.StopWithError("Accept targetted missions error")
            return false
        }

        this.Log("[Master] Targetted missions accepted.")
        this.SetAvailableCount(totalCount)
        this.CloseOpenMenu()
        this.RestoreSessionState()
        return true
    }

    ShowAcceptProgress(missingCount, totalCount) {
        availableCount := totalCount - missingCount
        if (availableCount < 0)
            availableCount := 0
        this.SetAvailableCount(availableCount)
        this.SetOverlayState("Working, please wait")
        this.SetGuiStatus("Working, please wait")
    }

    SetAvailableCount(count) {
        if IsObject(this.userState)
            this.userState.SetAvailableTargetedCount(count)
        global statusOverlayInst, mainGuiInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.Refresh()
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatusProgress"))
            mainGuiInst.RefreshStatusProgress()
    }

    GetProgressText(totalCount := 0) {
        if (totalCount < 1)
            totalCount := this.GetTargetedCount()
        if IsObject(this.userState)
            return this.userState.GetProgressText(totalCount)
        return "0/3"
    }

    GetTargetedCount() {
        targeted := this.stateManager.GetTargetedMissions()
        if !(targeted is Array)
            return 0
        return targeted.Length
    }

    EnsureInitialized() {
        if this.IsInitialized() {
            this.Debug("[Master] Session is ready.")
            return true
        }

        this.Log("[Master] Session is waiting. Running Initialize...")
        this.SetOverlayState("Initialize")
        this.SetGuiStatus("Initialize")

        if !IsObject(this.initializeScenario) {
            this.StopWithError("Initialize error")
            return false
        }

        if !this.initializeScenario.Execute() {
            this.Log("[Master] Initialize failed. Stopping.")
            this.StopWithError("Initialize error")
            return false
        }

        this.Debug("[Master] Initialize completed. Session is ready.")
        return true
    }

    RunRemoveActiveMissions(showStatus := true, abandonedCount := -1) {
        if !IsObject(this.removeActiveMissionsScenario) {
            this.StopWithError("Remove missions error")
            return false
        }

        if (showStatus) {
            this.SetOverlayState("Remove missions")
            this.SetGuiStatus("Remove missions")
        }
        if !this.removeActiveMissionsScenario.Execute(abandonedCount) {
            this.Log("[Master] RemoveActiveMissions failed. Stopping.")
            this.StopWithError("Remove missions error")
            return false
        }

        this.stateManager.SaveActiveMissions([])
        this.SetAvailableCount(0)
        this.Log("[Master] Active missions cleared.")
        return true
    }

    /**
     * After first run the Landsraad menu is still open. Esc closes it.
     */
    CloseOpenMenu() {
        this.Debug("[Master] Sending Esc to close the open menu.")
        InputHelper.SendGameKey("Esc")
        InputHelper.WaitClient(100)
    }

    /**
     * Ready-state Home: landsraad_button.png must be in LandsraadTabButton.
     * If it is missing, press L and wait 500ms before Accept Missions.
     */
    EnsureLandsraadTabVisible() {
        searchArea := this.GetLandsraadTabSearchArea()
        foundX := 0, foundY := 0
        imageName := "landsraad_button.png"

        if IsObject(searchArea) && IsObject(this.anchorMatcher) {
            this.Debug("[Master] Checking LandsraadTabButton for " imageName "...")
            if this.anchorMatcher.FindAnchor(imageName, &foundX, &foundY, searchArea, this.imageVariation) {
                this.Debug("[Master] Landsraad tab is visible at (" foundX ", " foundY ").")
                return
            }
        }

        this.Log("[Master] Landsraad tab not visible. Sending L.")
        InputHelper.SendGameKey("l")
        Sleep(500)
    }

    GetLandsraadTabSearchArea() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI") || !GameConstants["GameUI"].Has("LandsraadTabButton")
            return ""

        tabBtnConfig := GameConstants["GameUI"]["LandsraadTabButton"]
        rm := ResolutionManager()
        pos := rm.coords(tabBtnConfig.x, tabBtnConfig.y)
        size := rm.dimensions(tabBtnConfig.w, tabBtnConfig.h)
        padding := 20
        return {
            x1: Max(0, pos.x - padding),
            y1: Max(0, pos.y - padding),
            x2: Min(A_ScreenWidth, pos.x + size.w + padding),
            y2: Min(A_ScreenHeight, pos.y + size.h + padding)
        }
    }

    TargetAchieved() {
        this.Log("[Master] All targetted missions are already active. Target achieved.")
        this.SetAvailableCount(this.GetTargetedCount())
        this.RestoreSessionState()
        return true
    }

    IsInitialized() {
        return IsObject(this.userState) && this.userState.IsInitialized()
    }

    IsFirstHome() {
        return !IsObject(this.userState) || this.userState.IsFirstHome()
    }

    MarkFirstHomeDone() {
        if IsObject(this.userState)
            this.userState.MarkFirstHomeDone()
    }

    HasTargetedMissions() {
        targeted := this.stateManager.GetTargetedMissions()
        return (targeted is Array) && targeted.Length > 0
    }

    HasActiveMissions() {
        active := this.stateManager.GetActiveMissions()
        return (active is Array) && active.Length > 0
    }

    AllTargetedMissionsAreActive() {
        targeted := this.stateManager.GetTargetedMissions()
        active := this.stateManager.GetActiveMissions()
        if (!(targeted is Array) || targeted.Length == 0)
            return false
        if (!(active is Array) || active.Length == 0)
            return false

        activeNames := Map()
        for _, mission in active {
            if (mission.missionName != "")
                activeNames[StrLower(mission.missionName)] := true
        }

        for _, mission in targeted {
            if (mission.missionName == "")
                continue
            if !activeNames.Has(StrLower(mission.missionName))
                return false
        }
        return true
    }

    StopWithMessage(message) {
        this.SetGuiStatus(message)
        this.SetOverlayState(message)
    }

    StopWithError(message) {
        this.SetGuiStatus(message)
        this.SetOverlayState(message)
    }

    RestoreSessionState() {
        global statusOverlayInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.RestoreSessionState()
        this.SetGuiSessionStatus()
    }

    SetGuiSessionStatus() {
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("ShowSessionHint"))
            mainGuiInst.ShowSessionHint()
        else if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("GetStatusBarText"))
            this.SetGuiStatus(mainGuiInst.GetStatusBarText())
        else
            this.SetGuiStatus(IsObject(this.userState) ? this.userState.GetReadyLabel() : "Waiting")
    }

    SetOverlayState(label) {
        global statusOverlayInst
        if (IsSet(statusOverlayInst) && IsObject(statusOverlayInst))
            statusOverlayInst.SetState(label)
    }

    SetGuiStatus(message) {
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("SetStatus"))
            mainGuiInst.SetStatus(message)
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }
}
