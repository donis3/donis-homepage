#Requires AutoHotkey v2.0+
#SingleInstance Force
Persistent(true)
SetWorkingDir(A_ScriptDir)

;@Ahk2Exe-SetName Donsraad
;@Ahk2Exe-SetDescription Easy Mission Picker for Dune: Awakening
;@Ahk2Exe-SetProductName Donsraad
;@Ahk2Exe-SetCompanyName Deniz Özkan
;@Ahk2Exe-SetCopyright Copyright 2026 Deniz Özkan
;@Ahk2Exe-SetOrigFilename Donsraad.exe
;@Ahk2Exe-SetLanguage 0x0409

; Keep JSON and PNG on disk next to the script or exe. FileInstall only
; seeds missing files from a compiled build; existing files are never overwritten.
EnsureRuntimeFiles()

; ==============================================================================
; HIGH-SPEED GLOBAL INPUT INITIALIZATION
; ==============================================================================
SetControlDelay(-1)
SetMouseDelay(-1)
SetKeyDelay(-1, -1)
SendMode("Input")

; ==============================================================================
; GLOBAL INSTANCES & INITIALIZATION
; ==============================================================================
global resolutionManagerInst := ResolutionManager()
global gdipToken := Gdip_Startup()
global stateManagerInst := LandsraadStateManager(A_ScriptDir)
global settingsManagerInst := SettingsManager(A_ScriptDir)
global loggerInst := Logger(settingsManagerInst.Get("debugMode", false))
if IsObject(stateManagerInst) && (stateManagerInst.dbErrors is Array) {
    for _, dbMsg in stateManagerInst.dbErrors
        loggerInst.Log("[Database] " dbMsg)
    if !stateManagerInst.AreDatabasesReady()
        loggerInst.Log("[Database] Houses or missions database is not ready. Mission Picker will be empty until the JSON files are fixed.")
}
global anchorMatcherInst := AnchorMatcher(A_ScriptDir)

global profileManagerInst := ProfileManager(A_ScriptDir)
profileManagerInst.Initialize(stateManagerInst, settingsManagerInst)
global userStateInst := UserState()
global initializeScenarioInst := InitializeScenario(stateManagerInst, loggerInst, anchorMatcherInst, userStateInst)
global removeActiveMissionsScenarioInst := RemoveActiveMissionsScenario(settingsManagerInst, loggerInst, anchorMatcherInst, stateManagerInst)
global acceptMissionsScenarioInst := AcceptMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst)
global acceptTargettedMissionsScenarioInst := AcceptTargettedMissionsScenario(stateManagerInst, loggerInst, anchorMatcherInst)
global masterScenarioInst := MasterScenario(stateManagerInst, userStateInst, loggerInst, initializeScenarioInst, removeActiveMissionsScenarioInst, acceptMissionsScenarioInst, acceptTargettedMissionsScenarioInst, anchorMatcherInst)
global mainGuiInst := DonsraadGui(stateManagerInst, settingsManagerInst, loggerInst, initializeScenarioInst, userStateInst, profileManagerInst)
global statusOverlayInst := StatusOverlay(stateManagerInst, userStateInst, profileManagerInst)
statusOverlayInst.ApplyVisibility(settingsManagerInst.GetBool("showOverlay", true))
; global houseGridDebugInst := HouseGridDebug()
global missionHandlerDebugInst := MissionHandlerDebug(loggerInst, stateManagerInst)
global activeMissionDebugInst := ActiveMissionDebug(loggerInst, stateManagerInst)

; Register cleanup on script exit
OnExit(AppExitHandler)

; Show initial dashboard
global boundStartHotkey := ""
global boundExitHotkey := ""
global boundToggleHotkey := ""
mainGuiInst.Show()
ApplyAppHotkeys()
if A_IsCompiled
    loggerInst.Log("Standalone build. Data folder: " A_ScriptDir)
loggerInst.Log("Application ready. Donsraad dashboard loaded.")

; ==============================================================================
; HOTKEYS
; Bound at runtime from settings (defaults: Home = start, End = exit)
; ==============================================================================

ApplyAppHotkeys() {
    global settingsManagerInst, boundStartHotkey, boundExitHotkey, boundToggleHotkey
    startKey := "Home"
    exitKey := "Pause"
    toggleKey := "Delete"
    if IsObject(settingsManagerInst) {
        startKey := settingsManagerInst.Get("hotkeyStart", "Home")
        exitKey := settingsManagerInst.Get("hotkeyExit", "Pause")
        toggleKey := settingsManagerInst.Get("hotkeyToggleGui", "Delete")
    }
    if (Trim(startKey) == "")
        startKey := "Home"
    if (Trim(exitKey) == "")
        exitKey := "Pause"
    if (Trim(toggleKey) == "")
        toggleKey := "Delete"

    oldStart := boundStartHotkey
    oldExit := boundExitHotkey
    oldToggle := boundToggleHotkey

    startOk := BindAppHotkey(startKey, OnStartHotkey)
    if !startOk {
        startKey := "Home"
        startOk := BindAppHotkey("Home", OnStartHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyStart", "Home")
    }

    exitOk := BindAppHotkey(exitKey, OnExitHotkey)
    if !exitOk {
        exitKey := "Pause"
        exitOk := BindAppHotkey("Pause", OnExitHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyExit", "Pause")
    }

    toggleOk := BindAppHotkey(toggleKey, OnToggleGuiHotkey)
    if !toggleOk {
        toggleKey := "Delete"
        toggleOk := BindAppHotkey("Delete", OnToggleGuiHotkey)
        if IsObject(settingsManagerInst)
            settingsManagerInst.Set("hotkeyToggleGui", "Delete")
    }

    newKeys := Map()
    newKeys[StrLower(startKey)] := true
    newKeys[StrLower(exitKey)] := true
    newKeys[StrLower(toggleKey)] := true

    if (oldStart != "" && !newKeys.Has(StrLower(oldStart))) {
        try Hotkey(oldStart, "Off")
    }
    if (oldExit != "" && !newKeys.Has(StrLower(oldExit))) {
        try Hotkey(oldExit, "Off")
    }
    if (oldToggle != "" && !newKeys.Has(StrLower(oldToggle))) {
        try Hotkey(oldToggle, "Off")
    }

    boundStartHotkey := startKey
    boundExitHotkey := exitKey
    boundToggleHotkey := toggleKey
    return startOk && exitOk && toggleOk
}

BindAppHotkey(key, callback) {
    try {
        Hotkey(key, callback)
        Hotkey(key, "On")
        return true
    } catch {
        return false
    }
}

OnStartHotkey(*) {
    global masterScenarioInst
    if (IsSet(masterScenarioInst) && IsObject(masterScenarioInst))
        masterScenarioInst.Execute()
}

OnToggleGuiHotkey(*) {
    global mainGuiInst
    if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("Toggle"))
        mainGuiInst.Toggle()
}

OnExitHotkey(*) {
    ExitApp()
}

; ==============================================================================
; EXIT HANDLER
; ==============================================================================
AppExitHandler(exitReason, exitCode) {
    global gdipToken, stateManagerInst, statusOverlayInst, profileManagerInst
    try {
        if IsSet(statusOverlayInst) && IsObject(statusOverlayInst)
            statusOverlayInst.Close()
    }
    try {
        if IsSet(stateManagerInst) && IsObject(stateManagerInst)
            stateManagerInst.SavePlayerState()
    }
    try {
        if IsSet(profileManagerInst) && IsObject(profileManagerInst) && IsSet(stateManagerInst) && IsObject(stateManagerInst)
            profileManagerInst.SaveAll(stateManagerInst)
    }
    try {
        if (gdipToken)
            Gdip_Shutdown(gdipToken)
    }
    return 0
}

; ==============================================================================
; RUNTIME DATA (external JSON / PNG next to the exe)
; FileInstall source paths must be string literals for Ahk2Exe.
; Overwrite flag 0: never replace a file the user already has on disk.
; ==============================================================================
EnsureRuntimeFiles() {
    DirCreate(A_ScriptDir "\db")
    DirCreate(A_ScriptDir "\ui")
    DirCreate(A_ScriptDir "\ui_elements")

    dest := A_ScriptDir "\db\landsraad_houses.json"
    if !FileExist(dest)
        FileInstall "db\landsraad_houses.json", dest, 0
    dest := A_ScriptDir "\db\landsraad_missions.json"
    if !FileExist(dest)
        FileInstall "db\landsraad_missions.json", dest, 0
    dest := A_ScriptDir "\ui\donis.png"
    if !FileExist(dest)
        FileInstall "ui\donis.png", dest, 0
    dest := A_ScriptDir "\ui_elements\accept_mission_anchor.png"
    if !FileExist(dest)
        FileInstall "ui_elements\accept_mission_anchor.png", dest, 0
    dest := A_ScriptDir "\ui_elements\align_guild.png"
    if !FileExist(dest)
        FileInstall "ui_elements\align_guild.png", dest, 0
    dest := A_ScriptDir "\ui_elements\create_guild.png"
    if !FileExist(dest)
        FileInstall "ui_elements\create_guild.png", dest, 0
    dest := A_ScriptDir "\ui_elements\guild_disband.png"
    if !FileExist(dest)
        FileInstall "ui_elements\guild_disband.png", dest, 0
    dest := A_ScriptDir "\ui_elements\landsraad_button.png"
    if !FileExist(dest)
        FileInstall "ui_elements\landsraad_button.png", dest, 0
    dest := A_ScriptDir "\ui_elements\landsraad-corner.png"
    if !FileExist(dest)
        FileInstall "ui_elements\landsraad-corner.png", dest, 0
}

; ==============================================================================
; INCLUDES
; ==============================================================================
#Include lib\JSON.ahk
#Include lib\Gdip.ahk
#Include core\Constants.ahk
#Include core\Logger.ahk
#Include core\ResolutionManager.ahk
#Include core\OCR.ahk
#Include core\SettingsManager.ahk
#Include core\StateManager.ahk
#Include core\ProfileManager.ahk
#Include core\UserState.ahk
#Include core\AnchorMatcher.ahk
#Include core\InputHelper.ahk
#Include debug\RectangleOverlay.ahk
; #Include debug\HouseGridDebug.ahk
#Include debug\MissionHandlerDebug.ahk
#Include debug\ActiveMissionDebug.ahk
#Include scenarios\Initialize.ahk
#Include scenarios\RemoveActiveMissions.ahk
#Include scenarios\AcceptMissions.ahk
#Include scenarios\AcceptTargettedMissions.ahk
#Include scenarios\Master.ahk
#Include ui\StatusOverlay.ahk
#Include ui\MainWindow.ahk