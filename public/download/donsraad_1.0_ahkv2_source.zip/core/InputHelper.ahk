#Requires AutoHotkey v2.0+

/**
 * High-speed input helper for AutoHotkey v2.
 * Delivers immediate, high-throughput inputs without artificial jitter or movement delays.
 */
class InputHelper {
    /**
     * Instantly clicks at the specified screen coordinates.
     */
    static FastClick(x, y, button := "Left", count := 1) {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        Click(x . " " . y . " " . button . " " . count)
        CoordMode("Mouse", prevMode)
    }

    /**
     * Moves to a point, waits for hover, then holds a click so Unreal UI registers it.
     */
    static SendGameClick(x, y, holdMs := 60, hoverMs := 80) {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseMove(x, y, 0)
        Sleep(hoverMs)
        Click("Left Down")
        Sleep(holdMs)
        Click("Left Up")
        CoordMode("Mouse", prevMode)
    }

    /**
     * Instantly moves cursor to screen coordinates.
     */
    static FastMove(x, y) {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseMove(x, y, 0)
        CoordMode("Mouse", prevMode)
    }

    /**
     * Finds an anchor image and instantly clicks at a relative offset.
     * @param {Object} anchorMatcherInst - Instance of AnchorMatcher
     * @param {String} imageName - Anchor image name
     * @param {Integer} offsetX - Relative X offset
     * @param {Integer} offsetY - Relative Y offset
     * @param {Integer} variation - Color variation tolerance
     * @returns {Boolean} - True if anchor found and clicked
     */
    static ClickAnchorOffset(anchorMatcherInst, imageName, offsetX := 0, offsetY := 0, variation := 25) {
        targetX := 0, targetY := 0
        if anchorMatcherInst.FindAnchorOffset(imageName, offsetX, offsetY, &targetX, &targetY, "", variation) {
            this.FastClick(targetX, targetY)
            return true
        }
        return false
    }

    /**
     * Instantly drags from (x1, y1) to (x2, y2).
     */
    static FastDrag(x1, y1, x2, y2, button := "Left") {
        prevMode := A_CoordModeMouse
        CoordMode("Mouse", "Screen")
        MouseClickDrag(button, x1, y1, x2, y2, 0)
        CoordMode("Mouse", prevMode)
    }

    /**
     * Sends raw keystrokes at maximum speed.
     */
    static SendInstant(keys) {
        SendInput(keys)
    }

    /**
     * Sends a key press with an explicit hold duration so Unreal Engine / game tick loops register it.
     * Uses SendEvent with down/up and a discrete sleep.
     * @param {String} key - Key name (e.g. "l", "Esc", "Tab")
     * @param {Integer} holdMs - Duration to hold the key down in ms (default 60ms)
     */
    static SendGameKey(key, holdMs := 60) {
        SendEvent("{" key " down}")
        Sleep(holdMs)
        SendEvent("{" key " up}")
    }

    /**
     * Sends a modifier+key combination with an explicit hold so the game registers it.
     */
    static SendGameModifierKey(modKey, key, holdMs := 40) {
        SendEvent("{" modKey " down}")
        Sleep(20)
        SendEvent("{" key " down}")
        Sleep(holdMs)
        SendEvent("{" key " up}")
        SendEvent("{" modKey " up}")
    }

    /**
     * Types text into an already-focused field as fast as the game will accept.
     */
    static SendGameText(text) {
        SendEvent("{Text}" text)
    }

    /**
     * Short pause after a client-side UI action.
     */
    static WaitClient(ms := 100) {
        Sleep(ms)
    }
}
