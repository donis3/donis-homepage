#Requires AutoHotkey v2.0+

/**
 * In-memory session flags. Not written to player_state.json.
 * Resets when the script reloads.
 */
class UserState {
    initialized := false
    firstHomeDone := false
    availableTargetedCount := 0

    IsInitialized() {
        return this.initialized
    }

    SetInitialized(value := true) {
        this.initialized := value ? true : false
    }

    IsFirstHome() {
        return !this.firstHomeDone
    }

    MarkFirstHomeDone() {
        this.firstHomeDone := true
    }

    SetAvailableTargetedCount(count) {
        n := Integer(count)
        this.availableTargetedCount := (n < 0) ? 0 : n
    }

    ResetSession() {
        this.initialized := false
        this.firstHomeDone := false
        this.availableTargetedCount := 0
    }

    GetAvailableTargetedCount() {
        return this.availableTargetedCount
    }

    GetProgressText(totalCount := 0) {
        total := Integer(totalCount)
        if (total < 0)
            total := 0
        return this.availableTargetedCount "/" total
    }

    IsProgressComplete(totalCount := 0) {
        total := Integer(totalCount)
        if (total < 1)
            return false
        return this.availableTargetedCount >= total
    }

    GetReadyLabel() {
        return this.initialized ? "Ready" : "Waiting"
    }
}
