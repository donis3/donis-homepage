#Requires AutoHotkey v2.0+

/**
 * Landsraad State Manager class.
 * Handles database lookups and player state persistence (player_state.json).
 */
class LandsraadStateManager {
    workspaceRoot := ""
    dbHousesPath := ""
    dbMissionsPath := ""
    playerStatePath := ""

    housesMap := Map()           ; "House Alexin" -> "Crafting"
    missionsBySpec := Map()      ; "Crafting" -> ["Convergence", ...]
    missionSpecMap := Map()      ; "Convergence" -> "Crafting"
    allHousesList := []          ; [{house: "House Alexin", specialization: "Crafting"}]
    allMissionsList := []        ; [{specialization: "Crafting", name: "Convergence"}]
    dbErrors := []
    housesReady := false
    missionsReady := false

    currentPlayerState := Map()  ; Runtime state loaded from player_state.json

    __New(rootDir := "") {
        if (rootDir == "")
            rootDir := A_ScriptDir
        
        this.workspaceRoot := rootDir
        this.dbHousesPath := rootDir . "\db\landsraad_houses.json"
        this.dbMissionsPath := rootDir . "\db\landsraad_missions.json"
        this.playerStatePath := rootDir . "\player_state.json"

        this.LoadDatabases()
        this.LoadPlayerState()
    }

    /**
     * Loads landsraad_houses.json and landsraad_missions.json into memory.
     * Each file must exist, parse as JSON, and be a non-empty array.
     */
    LoadDatabases() {
        this.dbErrors := []
        this.housesReady := false
        this.missionsReady := false
        this.housesMap := Map()
        this.missionSpecMap := Map()
        this.allHousesList := []
        this.allMissionsList := []
        this.missionsBySpec := Map()
        this.missionsBySpec["Crafting"] := []
        this.missionsBySpec["Gathering"] := []
        this.missionsBySpec["Exploration"] := []
        this.missionsBySpec["Combat"] := []
        this.missionsBySpec["Sabotage"] := []

        parsedHouses := this.LoadJsonArray(this.dbHousesPath, "houses")
        if (parsedHouses is Array) {
            this.allHousesList := parsedHouses
            this.housesReady := true
            for _, item in parsedHouses {
                if !(item is Map)
                    continue
                hName := item.Has("house") ? item["house"] : ""
                hSpec := item.Has("specialization") ? item["specialization"] : ""
                if (hName != "") {
                    this.housesMap[StrLower(hName)] := hSpec
                    this.housesMap[hName] := hSpec
                }
            }
        }

        parsedMissions := this.LoadJsonArray(this.dbMissionsPath, "missions")
        if (parsedMissions is Array) {
            this.allMissionsList := parsedMissions
            this.missionsReady := true
            for _, item in parsedMissions {
                if !(item is Map)
                    continue
                mName := item.Has("name") ? item["name"] : ""
                mSpec := item.Has("specialization") ? item["specialization"] : ""
                if (mName != "") {
                    this.missionSpecMap[StrLower(mName)] := mSpec
                    this.missionSpecMap[mName] := mSpec
                    if (!this.missionsBySpec.Has(mSpec))
                        this.missionsBySpec[mSpec] := []
                    this.missionsBySpec[mSpec].Push(mName)
                }
            }
        }
    }

    LoadJsonArray(path, label) {
        if !FileExist(path) {
            this.dbErrors.Push("Missing " label " database: " path)
            return ""
        }
        try {
            rawJson := FileRead(path, "UTF-8")
            parsed := JSON.Parse(rawJson)
            if !(parsed is Array) {
                this.dbErrors.Push(label " database is not a JSON array: " path)
                return ""
            }
            if (parsed.Length < 1) {
                this.dbErrors.Push(label " database is empty: " path)
                return ""
            }
            return parsed
        } catch as err {
            this.dbErrors.Push("Failed to parse " label " database: " err.Message)
            return ""
        }
    }

    AreDatabasesReady() {
        return this.housesReady && this.missionsReady
    }

    /**
     * Loads player state from player_state.json or initializes a default template.
     */
    LoadPlayerState() {
        if FileExist(this.playerStatePath) {
            try {
                rawJson := FileRead(this.playerStatePath, "UTF-8")
                this.currentPlayerState := JSON.Parse(rawJson)
                if (this.currentPlayerState is Map) {
                    this.MigrateMissionSelections()
                    this.NormalizePlayerState()
                    return
                }
            } catch {
                ; If corrupt or error, recreate default
            }
        }

        this.currentPlayerState := this.GetDefaultPlayerState()
        this.SavePlayerState()
    }

    GetDefaultPlayerState() {
        return Map(
            "version", "1.0",
            "lastUpdated", FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss"),
            "activeMissions", [],
            "targettedMissions", [],
            "guildAbandons", 0,
            "targettedAccepts", 0
        )
    }

    ApplyPlayerState(stateMap) {
        if !(stateMap is Map) || stateMap.Count == 0
            this.currentPlayerState := this.GetDefaultPlayerState()
        else
            this.currentPlayerState := stateMap
        this.MigrateMissionSelections()
        this.NormalizePlayerState()
        this.SavePlayerState()
    }

    ClonePlayerState() {
        try {
            return JSON.Parse(JSON.Stringify(this.currentPlayerState))
        } catch {
            return this.GetDefaultPlayerState()
        }
    }

    /**
     * Persists runtime state to player_state.json with UTF-8 encoding.
     */
    SavePlayerState() {
        this.currentPlayerState["lastUpdated"] := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
        jsonString := JSON.Stringify(this.currentPlayerState, 2)
        
        fileObj := FileOpen(this.playerStatePath, "w", "UTF-8")
        fileObj.Write(jsonString)
        fileObj.Close()

        global profileManagerInst
        if IsSet(profileManagerInst) && IsObject(profileManagerInst) {
            profileManagerInst.CaptureCurrentState(this)
            profileManagerInst.SaveProfilesFile()
        }
    }

    /**
     * Looks up specialization for a house name.
     */
    GetHouseSpecialization(houseName) {
        if (this.housesMap.Has(houseName))
            return this.housesMap[houseName]
        if (this.housesMap.Has(StrLower(houseName)))
            return this.housesMap[StrLower(houseName)]
        return ""
    }

    /**
     * Looks up specialization for a mission name.
     */
    GetMissionSpecialization(missionName) {
        if (this.missionSpecMap.Has(missionName))
            return this.missionSpecMap[missionName]
        if (this.missionSpecMap.Has(StrLower(missionName)))
            return this.missionSpecMap[StrLower(missionName)]
        return ""
    }

    /**
     * Converts a 1-based 5x5 slot index into row/col (1-based, left-to-right, top-to-bottom).
     */
    SlotToGrid(slotIdx) {
        if (slotIdx < 1)
            return { row: 0, col: 0 }
        return {
            row: ((slotIdx - 1) // 5) + 1,
            col: Mod(slotIdx - 1, 5) + 1
        }
    }

    FormatMissionLabel(specialization, missionName) {
        if (specialization != "")
            return specialization . " — " . missionName
        return missionName
    }

    ParseMissionLabel(label) {
        spec := ""
        name := Trim(label)
        parts := StrSplit(label, " — ", , 2)
        if (parts.Length >= 2) {
            spec := Trim(parts[1])
            name := Trim(parts[2])
        }
        if (spec == "" && name != "")
            spec := this.GetMissionSpecialization(name)
        return {
            missionName: name,
            specialization: spec
        }
    }

    /**
     * Reads one persisted targetted-mission record (Map or object) into a typed object.
     */
    ParseTargetedEntry(entry, fallbackSlot := 0) {
        gridLocation := fallbackSlot
        missionName := ""
        specialization := ""

        if (entry is Map) {
            if (entry.Has("gridLocation"))
                gridLocation := entry["gridLocation"]
            else if (entry.Has("slot"))
                gridLocation := entry["slot"]
            if (entry.Has("missionName"))
                missionName := entry["missionName"]
            if (entry.Has("specialization"))
                specialization := entry["specialization"]
        } else if (IsObject(entry)) {
            if (entry.HasOwnProp("gridLocation"))
                gridLocation := entry.gridLocation
            else if (entry.HasOwnProp("slot"))
                gridLocation := entry.slot
            if (entry.HasOwnProp("missionName"))
                missionName := entry.missionName
            if (entry.HasOwnProp("specialization"))
                specialization := entry.specialization
        } else if (entry is String) {
            parsed := this.ParseMissionLabel(entry)
            missionName := parsed.missionName
            specialization := parsed.specialization
        }

        if (specialization == "" && missionName != "")
            specialization := this.GetMissionSpecialization(missionName)

        grid := this.SlotToGrid(gridLocation)
        return {
            gridLocation: gridLocation,
            gridRow: grid.row,
            gridCol: grid.col,
            missionName: missionName,
            specialization: specialization
        }
    }

    BuildTargetedRecord(gridLocation, missionName, specialization) {
        grid := this.SlotToGrid(gridLocation)
        return Map(
            "gridLocation", gridLocation,
            "gridRow", grid.row,
            "gridCol", grid.col,
            "missionName", missionName,
            "specialization", specialization
        )
    }

    /**
     * Migrates legacy missionSelections labels into targettedMissions, then drops the old key.
     */
    MigrateMissionSelections() {
        hasLegacy := this.currentPlayerState.Has("missionSelections")
        hasNew := this.currentPlayerState.Has("targettedMissions")
            && this.currentPlayerState["targettedMissions"] is Array
            && this.currentPlayerState["targettedMissions"].Length > 0

        if (hasLegacy && !hasNew) {
            converted := []
            saved := this.currentPlayerState["missionSelections"]
            if (saved is Array) {
                for _, entry in saved {
                    if (!(entry is Map))
                        continue
                    slotIdx := entry.Has("slot") ? entry["slot"] : 0
                    if (!entry.Has("missions") || !(entry["missions"] is Array))
                        continue
                    for _, label in entry["missions"] {
                        if (label == "")
                            continue
                        parsed := this.ParseMissionLabel(label)
                        converted.Push(this.BuildTargetedRecord(slotIdx, parsed.missionName, parsed.specialization))
                    }
                }
            }
            this.currentPlayerState["targettedMissions"] := converted
        }

        if (hasLegacy)
            this.currentPlayerState.Delete("missionSelections")

        if (!this.currentPlayerState.Has("targettedMissions"))
            this.currentPlayerState["targettedMissions"] := []

        if (hasLegacy)
            this.SavePlayerState()
    }

    /**
     * Drops unused legacy fields and ensures profile stats exist.
     */
    NormalizePlayerState() {
        if !(this.currentPlayerState is Map)
            this.currentPlayerState := this.GetDefaultPlayerState()

        dirty := false
        for _, key in ["dailyStats", "completedMissions", "activeHouses"] {
            if this.currentPlayerState.Has(key) {
                this.currentPlayerState.Delete(key)
                dirty := true
            }
        }
        if this.EnsureStatKey("guildAbandons")
            dirty := true
        if this.EnsureStatKey("targettedAccepts")
            dirty := true
        if (!this.currentPlayerState.Has("activeMissions") || !(this.currentPlayerState["activeMissions"] is Array)) {
            this.currentPlayerState["activeMissions"] := []
            dirty := true
        }
        if (!this.currentPlayerState.Has("targettedMissions") || !(this.currentPlayerState["targettedMissions"] is Array)) {
            this.currentPlayerState["targettedMissions"] := []
            dirty := true
        }
        if (dirty)
            this.SavePlayerState()
    }

    EnsureStatKey(key) {
        if this.currentPlayerState.Has(key) {
            try {
                n := Integer(this.currentPlayerState[key])
            } catch {
                n := 0
            }
            if (n < 0)
                n := 0
            if (this.currentPlayerState[key] != n) {
                this.currentPlayerState[key] := n
                return true
            }
            return false
        }
        this.currentPlayerState[key] := 0
        return true
    }

    GetStat(key) {
        this.EnsureStatKey(key)
        return Integer(this.currentPlayerState[key])
    }

    IncrementStat(key, amount := 1) {
        add := Integer(amount)
        if (add < 1)
            return this.GetStat(key)
        n := this.GetStat(key) + add
        this.currentPlayerState[key] := n
        this.SavePlayerState()
        global mainGuiInst
        if (IsSet(mainGuiInst) && IsObject(mainGuiInst) && mainGuiInst.HasMethod("RefreshStatsDisplay"))
            mainGuiInst.RefreshStatsDisplay()
        return n
    }

    IncrementGuildAbandons(amount := 1) {
        n := this.IncrementStat("guildAbandons", amount)
        this.LogStat("[State] Total abandons: " n " (+" Integer(amount) ")")
        return n
    }

    IncrementTargettedAccepts(amount := 1) {
        n := this.IncrementStat("targettedAccepts", amount)
        this.LogStat("[State] Successfully accepted target missions: " n " (+" Integer(amount) ")")
        return n
    }

    LogStat(message) {
        global loggerInst
        if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Log")
            loggerInst.Log(message)
    }

    /**
     * Returns missions the player selected in the Mission Picker.
     * Each entry is {gridLocation, gridRow, gridCol, missionName, specialization}.
     */
    GetTargetedMissions() {
        targeted := []
        if (!this.currentPlayerState.Has("targettedMissions") || !(this.currentPlayerState["targettedMissions"] is Array))
            return targeted

        for _, entry in this.currentPlayerState["targettedMissions"] {
            parsed := this.ParseTargetedEntry(entry)
            if (parsed.missionName == "")
                continue
            targeted.Push(parsed)
        }

        return targeted
    }

    /**
     * Groups targetted missions by grid slot as dropdown labels for the Mission Picker UI.
     * @returns {Map} slotIdx -> Array of "Specialization — Mission Name"
     */
    GetTargetedMissionsBySlot() {
        bySlot := Map()
        for _, mission in this.GetTargetedMissions() {
            slotIdx := mission.gridLocation
            if (slotIdx < 1 || slotIdx > 25)
                continue
            if (!bySlot.Has(slotIdx))
                bySlot[slotIdx] := []
            bySlot[slotIdx].Push(this.FormatMissionLabel(mission.specialization, mission.missionName))
        }
        return bySlot
    }

    /**
     * Persists Mission Picker assignments as structured targettedMissions.
     * @param {Map} slotMissions - slotIdx -> Array of "Specialization — Mission Name" labels
     */
    SaveTargetedMissionsFromSlots(slotMissions) {
        records := []
        if (IsObject(slotMissions)) {
            for slotIdx, missions in slotMissions {
                if (!IsObject(missions))
                    continue
                for _, label in missions {
                    if (label == "")
                        continue
                    parsed := this.ParseMissionLabel(label)
                    if (parsed.missionName == "")
                        continue
                    records.Push(this.BuildTargetedRecord(slotIdx, parsed.missionName, parsed.specialization))
                }
            }
        }

        this.currentPlayerState["targettedMissions"] := records
        if (this.currentPlayerState.Has("missionSelections"))
            this.currentPlayerState.Delete("missionSelections")
        this.SavePlayerState()
    }

    /**
     * Replaces the active-missions list in player state and persists it.
     * @param {Array} activeMissions - Array of {missionName, specialization, isTargetted}
     */
    SaveActiveMissions(activeMissions) {
        records := []
        if (IsObject(activeMissions)) {
            for _, mission in activeMissions {
                if (!IsObject(mission))
                    continue

                mName := ""
                mSpec := ""
                mTargetted := false

                if (mission.HasOwnProp("missionName"))
                    mName := mission.missionName
                else if (mission is Map && mission.Has("missionName"))
                    mName := mission["missionName"]

                if (mission.HasOwnProp("specialization"))
                    mSpec := mission.specialization
                else if (mission is Map && mission.Has("specialization"))
                    mSpec := mission["specialization"]

                if (mission.HasOwnProp("isTargetted"))
                    mTargetted := mission.isTargetted
                else if (mission is Map && mission.Has("isTargetted"))
                    mTargetted := mission["isTargetted"]

                if (mName == "")
                    continue

                records.Push(Map(
                    "missionName", mName,
                    "specialization", mSpec,
                    "isTargetted", mTargetted ? true : false
                ))
            }
        }

        this.currentPlayerState["activeMissions"] := records
        this.SavePlayerState()
    }

    /**
     * Returns the 3 active mission slots last saved to player state.
     * Each entry is {missionName, specialization, isTargetted}.
     */
    GetActiveMissions() {
        active := []
        if (!this.currentPlayerState.Has("activeMissions") || !(this.currentPlayerState["activeMissions"] is Array))
            return active

        for _, entry in this.currentPlayerState["activeMissions"] {
            mName := ""
            mSpec := ""
            mTargetted := false

            if (entry is Map) {
                if entry.Has("missionName")
                    mName := entry["missionName"]
                if entry.Has("specialization")
                    mSpec := entry["specialization"]
                if entry.Has("isTargetted")
                    mTargetted := entry["isTargetted"]
            } else if IsObject(entry) {
                if entry.HasOwnProp("missionName")
                    mName := entry.missionName
                if entry.HasOwnProp("specialization")
                    mSpec := entry.specialization
                if entry.HasOwnProp("isTargetted")
                    mTargetted := entry.isTargetted
            }

            if (mName == "")
                continue

            active.Push({
                missionName: mName,
                specialization: mSpec,
                isTargetted: mTargetted ? true : false
            })
        }

        return active
    }
}
