#Requires AutoHotkey v2.0+

; Store some coordinates and offsets for common UI elements to avoid repeated image searches.
; All values are calculated in 3440x1440 resolution and will be scaled for other resolutions.
; The offsets are relative to the top-left corner of the anchor image.

GameConstants := Map(
    "GameUI", Map(
        "HouseGridSize", 5, ; Number of houses in the grid (5x5)
        "FirstGridPosition", { x: 1074, y: 333 }, ; First grid position (3440x1440)
        "GridSpacing", { x: 19, y: 19 }, ; Grid spacing (3440x1440)
        "GridCellSize", { x: 243, y: 138 }, ; Grid cell size (3440x1440)
        "MissionSelectorFirstPosition", { x: 1387, y: 624 }, ; 3-line mission text anchor (3440x1440)
        "MissionTextSize", { x: 200, y: 83 }, ; 3-line mission title selection box (3440x1440)
        "MissionSelectorSpacing", 23, ;(3440x1440)
        ; Active mission UI displays 3 boxes vertically, each with the mission name
        "ActiveMissionFirstPosition", { x: 1405, y: 461 }, ; 3-line active mission text anchor (3440x1440)
        "ActiveMissionTextSize", { x: 200, y: 82 }, ; 3-line active mission title selection box (3440x1440)
        "ActiveMissionSpacing", 250, ; Vertical Spacing between active mission slots (3440x1440)
        ; Buttons
        "LandsraadTabButton", { x: 1900, y: 43, w: 166, h: 50 }, ; Landsraad tab button anchor to search for button image (3440x1440)
        "LandsraadSubTabButton", { x: 770, y: 180 }, ; Landsraad sub-tab to go to active missions tab (3440x1440)
        "LandsraadSubGridTabButton", { x: 670, y: 200 }, ; Landsraad sub tab button click coords to go to house grid tab (3440x1440)
        ; Guild Disbanding (this removes all active missions)
        "GuildDisbandingButtonClickCoords", { x: 753, y: 1193 }, ; Guild disband button coords (3440x1440)
        "GuildDisbandingButton", { x: 610, y: 1165, w: 270, h: 59 }, ; Guild disband button coords (3440x1440)
        "CreateGuildButton", { x: 2083, y: 1096, w: 213, h: 53 }, ; Create guild button coords (3440x1440)
        "AlignGuildAtreidesButtonClickCoords", { x: 800, y: 1234 }, ; Align guild button click coords (3440x1440)
        "AlignGuildAtreidesButton", { x: 664, y: 1205, w: 292, h: 62 }, ; Align guild button coords (3440x1440)
        "AlignGuildHarkonnenButtonClickCoords", { x: 2611, y: 1234 }, ; Align guild button click coords (3440x1440)
        "AlignGuildHarkonnenButton", { x: 2483, y: 1205, w: 292, h: 62 }, ; Align guild button coords (3440x1440)
        ; Accept Mission Window
        "AcceptMissionAnchor", {x: 1709, y: 282, w: 23, h: 42}, ; Accept mission anchor coords (3440x1440)
    ),
)