#Requires AutoHotkey v2.0+

class ActiveMissionDebug {
    overlay := []
    visible := false
    logger := ""
    stateManager := ""

    __New(loggerInst := "", stateManagerInst := "") {
        this.overlay := []
        this.logger := loggerInst
        this.stateManager := stateManagerInst
    }

    /**
     * Calculates reference and screen bounding boxes for the vertical active mission slots (ACCEPTED column).
     */
    GetActiveMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("ActiveMissionFirstPosition") || !uiConfig.Has("ActiveMissionTextSize")
            return []

        firstPos := uiConfig["ActiveMissionFirstPosition"]
        textSize := uiConfig["ActiveMissionTextSize"]
        spacing := uiConfig.Has("ActiveMissionSpacing") ? uiConfig["ActiveMissionSpacing"] : 0

        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            refX := firstPos.x
            refY := firstPos.y + ((missionIndex - 1) * spacing)
            refW := textSize.x
            refH := textSize.y

            pos := rm.coords(refX, refY)
            size := rm.dimensions(refW, refH)

            boxes.Push({
                index: missionIndex,
                refX: refX,
                refY: refY,
                refW: refW,
                refH: refH,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    /**
     * Shows debug overlays on the active mission boxes and scans them with OCR.
     */
    LocateActiveMissions() {
        boxes := this.GetActiveMissionBoxes()
        if (boxes.Length == 0)
            return

        this.Hide()

        ; Draw debug overlay rectangles
        for _, box in boxes {
            overlay := RectangleOverlay()
            overlay.ShowAt(box.refX, box.refY, box.refW, box.refH)
            this.overlay.Push(overlay)
        }

        this.visible := true

        ; Read and log text from each active box
        this.ReadActiveMissions(boxes)
    }

    /**
     * Reads text inside each active mission slot via WinRT OCR, matches against mission DB, and logs results.
     */
    ReadActiveMissions(boxes := "") {
        if (!IsObject(boxes) || boxes.Length == 0)
            boxes := this.GetActiveMissionBoxes()

        if (boxes.Length == 0) {
            this.Debug("[Active Mission OCR] Unable to determine active mission box positions.")
            return []
        }

        candidates := this.GetCandidateMissions()

        ocrLang := "en-US"
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            ocrLang := settingsManagerInst.Get("ocrLanguage", "en-US")

        this.Debug("[Active Mission OCR] Scanning " boxes.Length " active mission slots on screen...")

        results := []

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                rawText := ocrResult.text
                normalized := Ocr.NormalizeText(rawText)

                matched := Ocr.FindBestMatch(normalized, candidates)

                matchedName := matched.matchedName
                specialization := ""

                if (IsObject(matched.item) && matched.item.HasOwnProp("specialization"))
                    specialization := matched.item.specialization
                else if (IsObject(this.stateManager))
                    specialization := this.stateManager.GetMissionSpecialization(matchedName)

                entry := {
                    index: box.index,
                    rawText: rawText,
                    normalizedText: normalized,
                    matchedName: matchedName,
                    specialization: specialization,
                    confidence: matched.confidence,
                    box: box
                }
                results.Push(entry)

                if (matchedName != "" && matched.confidence > 0) {
                    specInfo := specialization != "" ? " [" specialization "]" : ""
                    this.Debug("[Active Mission OCR] Slot " box.index ": `"" matchedName "`"" specInfo " (Raw: `"" normalized "`")")
                } else if (normalized != "") {
                    this.Debug("[Active Mission OCR] Slot " box.index ": `"" normalized "`" (Unrecognized mission)")
                } else {
                    this.Debug("[Active Mission OCR] Slot " box.index ": (Empty / No text detected)")
                }
            } catch as err {
                this.Debug("[Active Mission OCR] Error reading Slot " box.index ": " err.Message)
                results.Push({
                    index: box.index,
                    rawText: "",
                    normalizedText: "",
                    matchedName: "",
                    specialization: "",
                    confidence: 0.0,
                    box: box,
                    error: err.Message
                })
            }
        }

        return results
    }

    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        dbPath := A_ScriptDir "\db\landsraad_missions.json"
        if FileExist(dbPath) {
            try {
                parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
                if (parsed is Array)
                    return parsed
            }
        }

        return []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }

    Hide() {
        if IsObject(this.overlay) {
            for index, overlay in this.overlay {
                if IsObject(overlay)
                    overlay.Close()
            }
            this.overlay := []
        }
        this.visible := false
    }
}
