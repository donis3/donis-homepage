#Requires AutoHotkey v2.0+

class MissionHandlerDebug {
    overlay := []
    visible := false
    logger := ""
    stateManager := ""

    __New(loggerInst := "", stateManagerInst := "") {
        this.overlay := []
        this.logger := loggerInst
        this.stateManager := stateManagerInst
    }

    /**
     * Calculates reference and active screen bounding boxes for the 3 mission selector slots.
     */
    GetMissionBoxes() {
        global GameConstants
        if !IsObject(GameConstants) || !GameConstants.Has("GameUI")
            return []

        uiConfig := GameConstants["GameUI"]
        if !uiConfig.Has("MissionSelectorFirstPosition") || !uiConfig.Has("MissionTextSize")
            return []

        firstPos := uiConfig["MissionSelectorFirstPosition"]
        textSize := uiConfig["MissionTextSize"]
        spacing := uiConfig.Has("MissionSelectorSpacing") ? uiConfig["MissionSelectorSpacing"] : 0

        rm := ResolutionManager()
        boxes := []

        loop 3 {
            missionIndex := A_Index
            refX := firstPos.x + ((missionIndex - 1) * (textSize.x + spacing))
            refY := firstPos.y
            refW := textSize.x
            refH := textSize.y

            pos := rm.coords(refX, refY)
            size := rm.dimensions(refW, refH)

            boxes.Push({
                index: missionIndex,
                refX: refX,
                refY: refY,
                refW: refW,
                refH: refH,
                screenX: pos.x,
                screenY: pos.y,
                screenW: Max(1, Round(size.w)),
                screenH: Max(1, Round(size.h))
            })
        }

        return boxes
    }

    /**
     * Draws the 3-line mission selector boxes and performs OCR to read the text.
     */
    LocateMission(num := 1) {
        boxes := this.GetMissionBoxes()
        if (boxes.Length == 0)
            return

        this.Hide()

        ; Draw debug overlay rectangles
        for _, box in boxes {
            overlay := RectangleOverlay()
            overlay.ShowAt(box.refX, box.refY, box.refW, box.refH)
            this.overlay.Push(overlay)
        }

        this.visible := true

        ; Read and log text from each box
        this.ReadMissions(boxes)
    }

    /**
     * Reads the text inside each of the 3 mission boxes using native Windows OCR,
     * matches against known database missions, and logs the results.
     */
    ReadMissions(boxes := "") {
        if (!IsObject(boxes) || boxes.Length == 0)
            boxes := this.GetMissionBoxes()

        if (boxes.Length == 0) {
            this.Debug("[Mission OCR] Unable to determine mission box positions.")
            return []
        }

        ; Obtain candidate missions for fuzzy/exact matching
        candidates := this.GetCandidateMissions()

        ocrLang := "en-US"
        global settingsManagerInst
        if (IsSet(settingsManagerInst) && IsObject(settingsManagerInst))
            ocrLang := settingsManagerInst.Get("ocrLanguage", "en-US")

        this.Debug("[Mission OCR] Scanning " boxes.Length " mission boxes on screen...")

        results := []

        for _, box in boxes {
            try {
                ocrResult := Ocr.FromRect(box.screenX, box.screenY, box.screenW, box.screenH, ocrLang)
                rawText := ocrResult.text
                normalized := Ocr.NormalizeText(rawText)

                matched := Ocr.FindBestMatch(normalized, candidates)

                matchedName := matched.matchedName
                specialization := ""

                ; Determine specialization if known
                if (IsObject(matched.item) && matched.item.HasOwnProp("specialization"))
                    specialization := matched.item.specialization
                else if (IsObject(this.stateManager))
                    specialization := this.stateManager.GetMissionSpecialization(matchedName)

                entry := {
                    index: box.index,
                    rawText: rawText,
                    normalizedText: normalized,
                    matchedName: matchedName,
                    specialization: specialization,
                    confidence: matched.confidence,
                    box: box
                }
                results.Push(entry)

                ; Log findings
                if (matchedName != "" && matched.confidence > 0) {
                    specInfo := specialization != "" ? " [" specialization "]" : ""
                    this.Debug("[Mission OCR] Box " box.index ": `"" matchedName "`"" specInfo " (Raw: `"" normalized "`")")
                } else if (normalized != "") {
                    this.Debug("[Mission OCR] Box " box.index ": `"" normalized "`" (Unrecognized mission)")
                } else {
                    this.Debug("[Mission OCR] Box " box.index ": (No text detected)")
                }
            } catch as err {
                this.Debug("[Mission OCR] Error reading Box " box.index ": " err.Message)
                results.Push({
                    index: box.index,
                    rawText: "",
                    normalizedText: "",
                    matchedName: "",
                    specialization: "",
                    confidence: 0.0,
                    box: box,
                    error: err.Message
                })
            }
        }

        return results
    }

    /**
     * Retrieves all known missions from StateManager or database file.
     */
    GetCandidateMissions() {
        if (IsObject(this.stateManager) && this.stateManager.allMissionsList.Length > 0)
            return this.stateManager.allMissionsList

        global stateManagerInst
        if (IsSet(stateManagerInst) && IsObject(stateManagerInst) && stateManagerInst.allMissionsList.Length > 0)
            return stateManagerInst.allMissionsList

        dbPath := A_ScriptDir "\db\landsraad_missions.json"
        if FileExist(dbPath) {
            try {
                parsed := JSON.Parse(FileRead(dbPath, "UTF-8"))
                if (parsed is Array)
                    return parsed
            }
        }

        return []
    }

    Log(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Log")
            this.logger.Log(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst)
                loggerInst.Log(message)
        }
    }

    Debug(message) {
        if IsObject(this.logger) && this.logger.HasMethod("Debug")
            this.logger.Debug(message)
        else {
            global loggerInst
            if IsSet(loggerInst) && IsObject(loggerInst) && loggerInst.HasMethod("Debug")
                loggerInst.Debug(message)
        }
    }

    Hide() {
        if IsObject(this.overlay) {
            for index, overlay in this.overlay {
                if IsObject(overlay)
                    overlay.Close()
            }
            this.overlay := []
        }
        this.visible := false
    }
}
